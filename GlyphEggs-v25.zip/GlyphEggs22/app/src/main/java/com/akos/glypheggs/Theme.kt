package com.akos.glypheggs

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.content.Context
import android.content.Intent
import android.graphics.Canvas
import android.graphics.ColorFilter
import android.graphics.LinearGradient
import android.graphics.Paint
import android.graphics.Path
import android.graphics.PixelFormat
import android.graphics.RadialGradient
import android.graphics.Shader
import android.graphics.drawable.Drawable

/*
 * Titkos neon témák. Kitűzőkkel oldódnak fel, sorban; az első után megjelenik a titkos menü
 * (Stat fül és Beállítások). Titkos gomb: a Főoldalon a hátlap képét 10 mp-ig nyomva tartva mind feloldódik.
 */
enum class NeonTheme(
    val title: String,
    val desc: String,
    val top: Int, val bottom: Int,
    val card: Int, val line: Int,
    val a: Int, val b: Int,
    val text: Int, val sub: Int, val unlit: Int,
    val deco: String,
    /** Ennyi kitűző kell a feloldáshoz. */
    val badges: Int
) {
    NIGHT_CITY("Night City", "Cyberpunk · magenta × cián", 0xFF2A0840.toInt(), 0xFF05000B.toInt(),
        0xE6140626.toInt(), 0xFF3A1E5A.toInt(), 0xFFFF2BD6.toInt(), 0xFF00F0FF.toInt(), 0xFFFBE9FF.toInt(), 0xFFB48AD0.toInt(), 0xFF2A1840.toInt(), "scan", 2),
    SYNTHWAVE("Synthwave", "80-as évek naplemente", 0xFF120428.toInt(), 0xFFFF6A5C.toInt(),
        0xD9180630.toInt(), 0xFF4A2370.toInt(), 0xFFFF6AC1.toInt(), 0xFFFFD36C.toInt(), 0xFFFFF2FB.toInt(), 0xFFD8A6E8.toInt(), 0xFF3B1A5C.toInt(), "grid", 4),
    TOXIC("Toxic", "Savzöld · radioaktív", 0xFF13240A.toInt(), 0xFF020302.toInt(),
        0xE60A1208.toInt(), 0xFF24361A.toInt(), 0xFFB6FF00.toInt(), 0xFFE8FF6A.toInt(), 0xFFEFFFD6.toInt(), 0xFF8FAE6A.toInt(), 0xFF1D2A14.toInt(), "hazard", 6),
    GRID_RUNNER("Grid Runner", "Tron-kék · lézerrács", 0xFF01040A.toInt(), 0xFF031226.toInt(),
        0xE6020E1E.toInt(), 0xFF0E2C44.toInt(), 0xFF00D9FF.toInt(), 0xFFFF9A1F.toInt(), 0xFFE3F8FF.toInt(), 0xFF6FA6C4.toInt(), 0xFF0D2236.toInt(), "tron", 8),
    ULTRAVIOLET("Ultraviolet", "Nothing-piros × UV-lila", 0xFF2A0A4A.toInt(), 0xFF050309.toInt(),
        0xE6120820.toInt(), 0xFF2E1D48.toInt(), 0xFFFF1F3D.toInt(), 0xFF9D5CFF.toInt(), 0xFFF6EEFF.toInt(), 0xFFA58BC9.toInt(), 0xFF24183A.toInt(), "uv", 11),
    VAPORWAVE("Vaporwave", "Pasztell neon · menta × rózsa", 0xFF2B1B4D.toInt(), 0xFF1F5B6B.toInt(),
        0xCC281846.toInt(), 0xFF5A4580.toInt(), 0xFFFF9CE3.toInt(), 0xFF7DFCD9.toInt(), 0xFFFFF6FD.toInt(), 0xFFCBB5E6.toInt(), 0xFF4A3A6C.toInt(), "sun", 14),
    ARCADE("Arcade RGB", "Szivárvány · játékterem", 0xFF1A1A1A.toInt(), 0xFF060606.toInt(),
        0xF0101010.toInt(), 0xFF2A2A2A.toInt(), 0xFFFF3B3B.toInt(), 0xFF3BFF8A.toInt(), 0xFFFFFFFF.toInt(), 0xFF9A9A9A.toInt(), 0xFF222222.toInt(), "rgb", 18);

    val rainbow: Boolean get() = this == ARCADE
}

val RAINBOW = intArrayOf(0xFFFF3B3B.toInt(), 0xFFFF9F1A.toInt(), 0xFFFFE11A.toInt(), 0xFF3BFF8A.toInt(),
    0xFF1AD9FF.toInt(), 0xFF5B6BFF.toInt(), 0xFFD23BFF.toInt())

object NeonThemes {
    private const val CHANNEL = "glyph_eggs_badges"

    /** Feloldva-e: elég kitűző, vagy a titkos gomb mindet feloldotta. */
    fun unlocked(c: Context, t: NeonTheme): Boolean =
        Settings.neonCheat(c) || Achievements.unlocked(c).size >= t.badges

    fun unlockedList(c: Context) = NeonTheme.entries.filter { unlocked(c, it) }

    /** Látszik-e már a titkos menü. */
    fun menuVisible(c: Context) = unlockedList(c).isNotEmpty()

    fun current(c: Context): NeonTheme? =
        NeonTheme.entries.firstOrNull { it.name == Settings.neonTheme(c) }?.takeIf { unlocked(c, it) }

    /** Új kitűző után: ha új téma oldódott fel, értesít (egyszer). */
    fun checkNew(c: Context) {
        val n = unlockedList(c).size
        val seen = Settings.themesSeen(c)
        if (n <= seen) return
        Settings.setThemesSeen(c, n)
        val t = unlockedList(c).last()
        if (!Settings.notifBadges(c)) return
        try {
            val nm = c.getSystemService(NotificationManager::class.java)
            nm.createNotificationChannel(NotificationChannel(CHANNEL, "Kitűzők", NotificationManager.IMPORTANCE_DEFAULT))
            val open = PendingIntent.getActivity(c, 5300, Intent(c, NeonActivity::class.java).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK),
                PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT)
            nm.notify(5300, Notification.Builder(c, CHANNEL)
                .setSmallIcon(R.drawable.ic_trophy)
                .setContentTitle(if (seen == 0) "🔓 Titkos menü feloldva!" else "🔓 Új neon téma: ${t.title}")
                .setContentText(if (seen == 0) "Első neon témád: ${t.title}. Stat fül → Titkos menü" else t.desc)
                .setContentIntent(open)
                .setAutoCancel(true)
                .build())
        } catch (e: Throwable) { }
    }
}

/**
 * A neon háttér: színátmenet + a téma díszítése (rács a horizonton, képcső-csíkok, figyelmeztető csík,
 * napkorong, UV-derengés). A görgetett tartalom mögött áll.
 */
class NeonBackground(private val t: NeonTheme) : Drawable() {
    private val p = Paint(Paint.ANTI_ALIAS_FLAG)
    /** Lekerekítés (kártyákon); 0 = teljes oldal. */
    var radius = 0f
    private val clip = Path()

    override fun draw(canvas: Canvas) {
        val w = bounds.width().toFloat()
        val h = bounds.height().toFloat()
        canvas.save()
        canvas.translate(bounds.left.toFloat(), bounds.top.toFloat())
        if (radius > 0f) {
            clip.reset()
            clip.addRoundRect(android.graphics.RectF(0f, 0f, w, h), radius, radius, Path.Direction.CW)
            canvas.clipPath(clip)
        }
        paint(canvas, w, h)
        canvas.restore()
    }

    private fun paint(canvas: Canvas, w: Float, h: Float) {
        p.shader = LinearGradient(0f, 0f, 0f, h, t.top, t.bottom, Shader.TileMode.CLAMP)
        canvas.drawRect(0f, 0f, w, h, p)
        p.shader = null
        when (t.deco) {
            "scan", "rgb" -> {
                // Képcső-csíkozás + két színes derengés
                p.shader = RadialGradient(w * 0.85f, 0f, w * 0.9f, (t.a and 0xFFFFFF) or 0x40000000, 0, Shader.TileMode.CLAMP)
                canvas.drawRect(0f, 0f, w, h, p)
                p.shader = RadialGradient(w * 0.1f, h * 0.85f, w * 0.8f, (t.b and 0xFFFFFF) or 0x26000000, 0, Shader.TileMode.CLAMP)
                canvas.drawRect(0f, 0f, w, h, p)
                p.shader = null
                p.color = 0x0AFFFFFF
                var y = 0f
                while (y < h) { canvas.drawRect(0f, y, w, y + 2f, p); y += 6f }
            }
            "grid", "tron" -> {
                // Napkorong (synthwave) és perspektivikus rács a képernyő alján
                if (t.deco == "grid") {
                    p.shader = RadialGradient(w / 2, h * 0.72f, w * 0.45f, 0x66FFD36C, 0, Shader.TileMode.CLAMP)
                    canvas.drawRect(0f, 0f, w, h, p)
                    p.shader = null
                }
                p.color = (t.a and 0xFFFFFF) or 0x66000000
                p.strokeWidth = 2.5f
                val horizon = h * 0.70f
                val cx = w / 2
                for (i in -12..12) canvas.drawLine(cx + i * w * 0.04f, horizon, cx + i * w * 0.45f, h, p)
                var k = 0
                while (k < 14) {
                    val f = k / 14f
                    val y = horizon + (h - horizon) * f * f
                    canvas.drawLine(0f, y, w, y, p)
                    k++
                }
            }
            "hazard" -> {
                p.shader = RadialGradient(w * 0.2f, h * 0.1f, w, (t.a and 0xFFFFFF) or 0x30000000, 0, Shader.TileMode.CLAMP)
                canvas.drawRect(0f, 0f, w, h, p)
                p.shader = null
                // Sárga-fekete csíkok alul
                val sh = 34f
                p.color = t.a
                val path = Path()
                var x = -sh
                while (x < w + sh) {
                    path.reset()
                    path.moveTo(x, h)
                    path.lineTo(x + sh, h - sh)
                    path.lineTo(x + sh * 2, h - sh)
                    path.lineTo(x + sh, h)
                    path.close()
                    canvas.drawPath(path, p)
                    x += sh * 2
                }
            }
            "sun" -> {
                p.shader = RadialGradient(w * 1.05f, h * 0.25f, w * 0.75f, (t.a and 0xFFFFFF) or 0x55000000, 0, Shader.TileMode.CLAMP)
                canvas.drawRect(0f, 0f, w, h, p)
                p.shader = RadialGradient(0f, h, w, (t.b and 0xFFFFFF) or 0x40000000, 0, Shader.TileMode.CLAMP)
                canvas.drawRect(0f, 0f, w, h, p)
                p.shader = null
            }
            "uv" -> {
                p.shader = RadialGradient(w / 2, h, h * 0.45f, (t.b and 0xFFFFFF) or 0x55000000, 0, Shader.TileMode.CLAMP)
                canvas.drawRect(0f, 0f, w, h, p)
                p.shader = null
            }
        }
    }

    override fun setAlpha(alpha: Int) {}
    override fun setColorFilter(colorFilter: ColorFilter?) {}
    @Deprecated("Drawable API")
    override fun getOpacity(): Int = PixelFormat.OPAQUE
}
