package com.akos.glypheggs

import android.content.Context
import android.hardware.Sensor
import android.hardware.SensorEvent
import android.hardware.SensorEventListener
import android.hardware.SensorManager
import android.os.Handler
import android.os.HandlerThread
import android.os.Looper
import android.os.PowerManager
import android.os.SystemClock
import kotlinx.coroutines.flow.MutableSharedFlow
import kotlinx.coroutines.flow.MutableStateFlow
import kotlin.math.abs
import kotlin.math.max
import kotlin.math.sqrt

/**
 * Szenzorfigyelés és mozdulat-felismerés.
 *
 * Két üzemmód:
 *  - **Készenlét** (figyelés bekapcsolva): felismeri az indító mozdulatokat ([Trigger]),
 *    és szól a [onTrigger] callbacknek. Csak azokat a szenzorokat és csak akkora
 *    mintavétellel járatja, amire a kiosztott mozdulatokhoz szükség van.
 *  - **Játék mód** (egy funkció fut): gyors gyorsulásmérő, a dőlés irányát a [tilt] adja.
 *
 * A [faceDown] mindkét módban mutatja, hogy a telefon kijelzővel lefelé fekszik-e
 * (szimulációs módban a kijelzővel felfelé fekvés is számít).
 *
 * Az időzítéshez a szenzoresemények saját időbélyegét használja, így a kötegelt
 * (energiatakarékos) adatküldésnél is pontos.
 */
class MotionDetector(context: Context, private val onTrigger: (Trigger) -> Unit) : SensorEventListener {

    private val sm = context.getSystemService(SensorManager::class.java)

    /** Wake-up változat, ha van: kikapcsolt képernyőnél is felébreszti a processzort. */
    private val accel: Sensor? =
        sm.getDefaultSensor(Sensor.TYPE_ACCELEROMETER, true)
            ?: sm.getDefaultSensor(Sensor.TYPE_ACCELEROMETER)
    private val gyro: Sensor? = sm.getDefaultSensor(Sensor.TYPE_GYROSCOPE)

    private val thread = HandlerThread("glyph-motion").apply { start() }
    private val handler = Handler(thread.looper)
    private val mainHandler = Handler(Looper.getMainLooper())

    private val wakeLock = context.getSystemService(PowerManager::class.java)
        .newWakeLock(PowerManager.PARTIAL_WAKE_LOCK, "GlyphEggs:motion")
        .apply { setReferenceCounted(false) }

    private val appContext = context.applicationContext

    /** Aktuális dőlés iránya játék közben (null = középen). */
    val tilt = MutableStateFlow<Direction?>(null)

    /** Kijelzővel lefelé fekszik-e (szimulációban kijelzővel felfelé is). */
    val faceDown = MutableStateFlow(false)

    /** Valóban kijelzővel felfelé fekszik-e (a „Megfordítás” leállításhoz). */
    val faceUp = MutableStateFlow(false)

    /** Valóban kijelzővel lefelé fekszik-e (a szimulációtól függetlenül). */
    val reallyDown = MutableStateFlow(false)

    /** Játék közben: egy-egy kopogás a telefonon (fekve). Az érték az időbélyeg (ms). */
    val knockEvents = MutableSharedFlow<Long>(extraBufferCapacity = 16)

    /** Játék közben: egy rövid megrázás (kézben). */
    val shakeEvents = MutableSharedFlow<Long>(extraBufferCapacity = 16)

    /** Játék közben: minden egyes erős rázás-csúcs (a leggyorsabb jel, pl. a Dínó ugrásához). */
    val shakeHits = MutableSharedFlow<Long>(extraBufferCapacity = 16)

    // --- állapot ---
    private var watching = false
    private var triggers: Set<Trigger> = emptySet()
    private var gameMode = false

    private enum class AccelRate { OFF, LOW, MEDIUM, KNOCK, GAME }
    private var accelRate = AccelRate.OFF
    private var gyroOn = false

    private val g = FloatArray(3)
    private var gInit = false
    private var lastAccelNs = 0L
    private var linZ = 0f
    private var linMag = 0f

    private var placed = false
    private var placedAtMs = 0L
    private var cooldownUntilMs = 0L

    // forgatások
    private var lastGyroNs = 0L
    private var moveActive = false
    private var moveAngle = 0f
    private var moveStartMs = 0L
    private var quietSinceMs = 0L
    private var lastW = 0f
    private val moves = ArrayDeque<Char>() // 'R' jobbra, 'L' balra
    private var lastMoveEndMs = 0L

    // kopogás
    private var knocks = 0
    private var lastKnockMs = 0L

    // rázás
    private var shakePeaks = 0
    private var firstShakeMs = 0L
    private var lastShakePeakMs = 0L
    private var shakenAtMs = 0L

    // játék közbeni kopogás / rázás
    private var gameStartMs = 0L
    private var gameKnockMs = 0L
    private var gameShakePeaks = 0
    private var gameShakeFirstMs = 0L
    private var gameShakePeakMs = 0L
    private var gameShakeEmitMs = 0L

    // hengerítés (kézben, a hosszanti tengely körül)
    private var lastAccelMs = 0L
    private var rollAwakeUntilMs = 0L
    private val rollSamples = ArrayDeque<Pair<Long, Float>>()
    private var rollSum = 0f

    // rázás-töltés indító mozdulat (készenlétben)
    private var sfPeaks = 0
    private var sfFirstMs = 0L
    private var sfPeakMs = 0L

    // lefordítás
    private var lastStable = 0 // +1 = kijelző felfelé, -1 = kijelző lefelé, 0 = egyik sem
    private val flipTimes = ArrayDeque<Long>()

    private var lastDebug = 0L
    private var lastGesture = "–"

    // ------------------------------------------------------------------ vezérlés

    fun start() {
        if (accel == null) {
            DebugState.log("Nincs gyorsulásmérő!")
            return
        }
        if (gyro == null) DebugState.log("Nincs giroszkóp – a forgatós mozdulatok nem működnek")
        handler.post { updateSensors() }
        DebugState.log("Szenzorfigyelés indult (wake-up gyorsulásmérő: ${accel.isWakeUpSensor})")
    }

    fun stop() {
        handler.post {
            sm.unregisterListener(this)
            accelRate = AccelRate.OFF
            gyroOn = false
            EnergyMeter.setSensors(0.0)
            if (wakeLock.isHeld) wakeLock.release()
            thread.quitSafely()
        }
    }

    /** Mozdulatfigyelés be/ki, és mely mozdulatokat kell felismerni. */
    fun setWatching(on: Boolean, active: Set<Trigger>) {
        handler.post {
            watching = on
            triggers = active
            resetGestures()
            if (!on && !gameMode && wakeLock.isHeld) wakeLock.release()
            updateSensors()
        }
    }

    fun setGameMode(on: Boolean) {
        handler.post {
            if (gameMode == on) return@post
            gameMode = on
            tilt.value = null
            resetGestures()
            if (on) {
                wakeLock.acquire(30 * 60 * 1000L)
                gameStartMs = SystemClock.elapsedRealtime()
            } else {
                if (wakeLock.isHeld) wakeLock.release()
                cooldownUntilMs = SystemClock.elapsedRealtime() + 3_000
            }
            updateSensors()
        }
    }

    /** A szűrt gravitáció-vektor (x, y, z m/s²) – a vízmértékhez és az Egyensúlyhoz. */
    fun gravity(): FloatArray = g.copyOf()

    /** Hosszabb feladatokhoz (időzítő): ennyi ideig ébren tartja a processzort. */
    fun holdAwake(ms: Long) {
        handler.post { wakeLock.acquire(ms) }
    }

    private fun has(t: Trigger) = watching && t in triggers
    private fun anyGyro() = watching && triggers.any { it.usesGyro }
    private fun anyKnock() = watching && triggers.any { it.isKnock }

    /** Csak azt járatja, amire most szükség van. */
    private fun updateSensors() {
        val wantAccel = when {
            gameMode -> AccelRate.GAME
            placed && anyKnock() -> AccelRate.KNOCK
            (!placed && (has(Trigger.SHAKE) || has(Trigger.FLIP_2) || has(Trigger.ROLL_3))) || has(Trigger.SHAKE_FILL) -> AccelRate.MEDIUM
            else -> AccelRate.LOW
        }
        if (wantAccel != accelRate) {
            val s = accel
            if (s != null) {
                sm.unregisterListener(this, s)
                when (wantAccel) {
                    // 100 Hz: a dőlés mellett a kopogást és a rázást is figyeli
                    AccelRate.GAME -> sm.registerListener(this, s, 10_000, 0, handler)
                    // 100 Hz, 1 mp-es kötegekben: a kopogás rövid csúcs, ehhez sűrű minta kell
                    AccelRate.KNOCK -> sm.registerListener(this, s, 10_000, 1_000_000, handler)
                    AccelRate.MEDIUM -> sm.registerListener(this, s, 20_000, 1_000_000, handler)
                    // ~5 Hz, 1 mp-es kötegek: kevés ébresztés, alacsony fogyasztás
                    AccelRate.LOW -> sm.registerListener(this, s, SensorManager.SENSOR_DELAY_NORMAL, 1_000_000, handler)
                    AccelRate.OFF -> Unit
                }
                lastAccelNs = 0L
            }
            accelRate = wantAccel
        }

        // Fekve: forgatós mozdulatokhoz. Kézben: a hengerítéshez, de csak mozgás után egy ideig (akkukímélés)
        val wantGyro = !gameMode && (
            (placed && anyGyro()) ||
                (has(Trigger.ROLL_3) && lastAccelMs < rollAwakeUntilMs)
            )
        if (wantGyro != gyroOn) {
            val s = gyro
            if (s != null) {
                if (wantGyro) {
                    lastGyroNs = 0L
                    moveActive = false
                    sm.registerListener(this, s, SensorManager.SENSOR_DELAY_GAME, 0, handler)
                    keepAwake()
                } else {
                    sm.unregisterListener(this, s)
                }
            }
            gyroOn = wantGyro && s != null
        }
        reportEnergy()
    }

    /** A most bekapcsolt szenzorok becsült áramfelvétele a fogyasztásmérőnek. */
    private fun reportEnergy() {
        var ma = when (accelRate) {
            AccelRate.GAME -> Config.SENSOR_GAME_MA
            AccelRate.KNOCK -> Config.SENSOR_KNOCK_MA
            AccelRate.MEDIUM -> Config.SENSOR_MEDIUM_MA
            AccelRate.LOW -> Config.SENSOR_LOW_MA
            AccelRate.OFF -> 0.0
        }
        if (gyroOn) ma += Config.SENSOR_GYRO_MA
        EnergyMeter.setSensors(ma)
    }

    private fun keepAwake() = wakeLock.acquire(Config.KEEP_AWAKE_MS)

    private fun resetGestures() {
        moves.clear()
        moveActive = false
        knocks = 0
        shakePeaks = 0
        sfPeaks = 0
        shakenAtMs = 0L
        flipTimes.clear()
    }

    private fun fire(t: Trigger, nowMs: Long) {
        if (!has(t)) return
        if (nowMs < cooldownUntilMs) return
        cooldownUntilMs = nowMs + Config.GESTURE_COOLDOWN_MS
        lastGesture = t.title
        DebugState.log("Mozdulat felismerve: ${t.title}")
        resetGestures()
        mainHandler.post { onTrigger(t) }
    }

    // ------------------------------------------------------------------ szenzorok

    override fun onSensorChanged(event: SensorEvent) {
        when (event.sensor.type) {
            Sensor.TYPE_ACCELEROMETER -> onAccel(event)
            Sensor.TYPE_GYROSCOPE -> onGyro(event)
        }
    }

    private fun onAccel(event: SensorEvent) {
        val v = event.values
        val tMs = event.timestamp / 1_000_000
        val dt = if (lastAccelNs == 0L) 0.02f else ((event.timestamp - lastAccelNs) / 1e9f).coerceIn(0.001f, 1f)
        lastAccelNs = event.timestamp

        // Gravitáció: aluláteresztő szűrő. Játékban a megszokott gyors követés,
        // készenlétben időállandós (≈0,25 s), hogy a mintavételtől függetlenül működjön.
        val tau = if (gameMode) 0.047f else 0.25f
        val alpha = tau / (tau + dt)
        if (!gInit) {
            v.copyInto(g, 0, 0, 3)
            gInit = true
        } else {
            for (i in 0..2) g[i] = alpha * g[i] + (1 - alpha) * v[i]
        }
        val lx = v[0] - g[0]
        val ly = v[1] - g[1]
        linZ = v[2] - g[2]
        linMag = sqrt(lx * lx + ly * ly + linZ * linZ)

        val down = g[2] < -Config.FLAT_Z
        val up = g[2] > Config.FLAT_Z
        val nowPlaced = down || (GlyphMirror.simulatorOpen && up)
        faceDown.value = nowPlaced
        faceUp.value = up
        reallyDown.value = down

        if (gameMode) {
            updateTilt()
            detectGameInputs(nowPlaced, tMs)
        } else if (watching) {
            onPlacedChange(nowPlaced, tMs)
            if (placed && linMag > 0.5f) keepAwake()
            detectRollWake(tMs)
            detectFlip(down, up, tMs)
            detectShake(tMs)
            detectShakeFill(tMs)
            detectKnock(tMs)
        } else if (nowPlaced != placed) {
            placed = nowPlaced
            updateSensors()
        }

        val now = SystemClock.elapsedRealtime()
        if (now - lastDebug > 150) {
            lastDebug = now
            DebugState.sensor.value = ("x=%.1f  y=%.1f  z=%.1f\n" +
                "fekszik: %s   dőlés: %s\n" +
                "forgatás: %s %s   kopogás: %d\n" +
                "hengerítés: %.1f kör   utolsó mozdulat: %s").format(
                g[0], g[1], g[2],
                if (nowPlaced) "igen" else "nem",
                tilt.value?.label ?: "középen",
                if (moveActive) "%.0f°".format(Math.toDegrees(moveAngle.toDouble())) else "–",
                moves.joinToString(""),
                knocks,
                abs(rollSum) / (2f * Math.PI.toFloat()),
                lastGesture
            )
        }
    }

    private fun onPlacedChange(nowPlaced: Boolean, tMs: Long) {
        if (nowPlaced == placed) return
        placed = nowPlaced
        if (nowPlaced) {
            placedAtMs = tMs
            keepAwake()
            // Rázás után lerakva?
            if (shakenAtMs != 0L && tMs - shakenAtMs <= Config.SHAKE_PLACE_MS) {
                shakenAtMs = 0L
                fire(Trigger.SHAKE, tMs)
            }
        } else {
            moves.clear()
            moveActive = false
            knocks = 0
        }
        updateSensors()
    }

    // --- Hengerítés: kézben mozgatva bekapcsol a giroszkóp, nyugalomban kikapcsol ---
    private fun detectRollWake(tMs: Long) {
        lastAccelMs = tMs
        if (!has(Trigger.ROLL_3)) return
        if (linMag > Config.ROLL_WAKE_ACCEL) {
            val wasOff = lastAccelMs >= rollAwakeUntilMs
            rollAwakeUntilMs = tMs + Config.ROLL_AWAKE_MS
            if (wasOff) {
                keepAwake()
                updateSensors()
            }
        } else if (gyroOn && tMs >= rollAwakeUntilMs) {
            rollSamples.clear()
            rollSum = 0f
            updateSensors()
        }
    }

    /** A hosszanti (y) tengely körüli forgás összegzése egy időablakban; 3 teljes kör = indul. */
    private fun onRoll(wy: Float, dt: Float, tMs: Long) {
        val d = wy * dt
        rollSamples.addLast(tMs to d)
        rollSum += d
        while (rollSamples.isNotEmpty() && tMs - rollSamples.first().first > Config.ROLL_WINDOW_MS) {
            rollSum -= rollSamples.removeFirst().second
        }
        if (abs(wy) > 1f) rollAwakeUntilMs = tMs + Config.ROLL_AWAKE_MS
        val target = Config.ROLL_TURNS * 2f * Math.PI.toFloat() * Config.ROLL_TOLERANCE
        if (abs(rollSum) >= target) {
            DebugState.log("Hengerítés: %.1f kör".format(abs(rollSum) / (2f * Math.PI.toFloat())))
            rollSamples.clear()
            rollSum = 0f
            fire(Trigger.ROLL_3, tMs)
        }
    }

    // --- Lefordítás 2×: két "felfelé → lefelé" átmenet rövid időn belül ---
    private fun detectFlip(down: Boolean, up: Boolean, tMs: Long) {
        if (!has(Trigger.FLIP_2)) return
        // Hengerítés közben a kijelző is átfordul – az nem lefordítás
        if (abs(rollSum) > Math.PI.toFloat()) return
        val state = if (up) 1 else if (down) -1 else 0
        if (state == 0 || state == lastStable) return
        if (state == -1 && lastStable == 1) {
            flipTimes.addLast(tMs)
            while (flipTimes.isNotEmpty() && tMs - flipTimes.first() > Config.FLIP_WINDOW_MS) flipTimes.removeFirst()
            DebugState.log("Lefordítás ${flipTimes.size}/2")
            if (flipTimes.size >= 2) fire(Trigger.FLIP_2, tMs)
        }
        lastStable = state
    }

    // --- Rázás: több erős csúcs rövid időn belül, utána le kell tenni ---
    private fun detectShake(tMs: Long) {
        if (!has(Trigger.SHAKE) || placed) return
        if (linMag < Config.SHAKE_THRESHOLD || tMs - lastShakePeakMs < 120) return
        if (shakePeaks == 0 || tMs - firstShakeMs > Config.SHAKE_WINDOW_MS) {
            shakePeaks = 0
            firstShakeMs = tMs
        }
        shakePeaks++
        lastShakePeakMs = tMs
        if (shakePeaks >= Config.SHAKE_PEAKS) {
            shakePeaks = 0
            shakenAtMs = tMs
            DebugState.log("Megrázva – tedd le kijelzővel lefelé")
        }
    }

    // --- Rázás-töltés: az első rázás elindítja a funkciót, a töltést a szolgáltatás számolja ---
    private fun detectShakeFill(tMs: Long) {
        if (!has(Trigger.SHAKE_FILL)) return
        if (linMag < Config.GAME_SHAKE_THRESHOLD || tMs - sfPeakMs < 100) return
        if (sfPeaks == 0 || tMs - sfFirstMs > Config.GAME_SHAKE_WINDOW_MS) {
            sfPeaks = 0
            sfFirstMs = tMs
        }
        sfPeaks++
        sfPeakMs = tMs
        if (sfPeaks >= Config.GAME_SHAKE_PEAKS) {
            sfPeaks = 0
            fire(Trigger.SHAKE_FILL, tMs)
        }
    }

    // --- Kopogás: rövid függőleges ütés-csúcsok, a sorozat végén számol ---
    private fun detectKnock(tMs: Long) {
        if (!anyKnock() || !placed) return
        // Sorozat vége: elég idő telt el az utolsó kopogás óta
        if (knocks > 0 && tMs - lastKnockMs > Config.KNOCK_MAX_GAP_MS) {
            val n = knocks
            knocks = 0
            when (n) {
                2 -> fire(Trigger.KNOCK_2, tMs)
                3 -> fire(Trigger.KNOCK_3, tMs)
                else -> DebugState.log("Kopogás: $n (nem 2 vagy 3)")
            }
        }
        if (tMs - placedAtMs < Config.KNOCK_SETTLE_MS) return
        if (moveActive) return // forgatás közben nem kopogás
        val threshold = Config.KNOCK_THRESHOLDS[Settings.knockSensitivity(appContext)]
        if (abs(linZ) > threshold && tMs - lastKnockMs > Config.KNOCK_MIN_GAP_MS) {
            knocks++
            lastKnockMs = tMs
            keepAwake()
        }
    }

    // --- Játék közbeni kopogás és rázás (a Zárfeltörő, a Széf és a Tojás használja) ---
    private fun detectGameInputs(nowPlaced: Boolean, tMs: Long) {
        if (tMs - gameStartMs < 400) return
        if (nowPlaced) {
            val threshold = Config.KNOCK_THRESHOLDS[Settings.knockSensitivity(appContext)]
            if (abs(linZ) > threshold && tMs - gameKnockMs > Config.KNOCK_MIN_GAP_MS) {
                gameKnockMs = tMs
                knockEvents.tryEmit(tMs)
            }
        }
        if (linMag > Config.GAME_SHAKE_THRESHOLD && tMs - gameShakePeakMs > 100) {
            if (gameShakePeaks == 0 || tMs - gameShakeFirstMs > Config.GAME_SHAKE_WINDOW_MS) {
                gameShakePeaks = 0
                gameShakeFirstMs = tMs
            }
            gameShakePeaks++
            gameShakePeakMs = tMs
            shakeHits.tryEmit(tMs)
            if (gameShakePeaks >= Config.GAME_SHAKE_PEAKS && tMs - gameShakeEmitMs > Config.GAME_SHAKE_REFRACTORY_MS) {
                gameShakePeaks = 0
                gameShakeEmitMs = tMs
                shakeEvents.tryEmit(tMs)
            }
        }
    }

    // --- Dőlés játék közben ---
    private fun updateTilt() {
        var x = g[0]
        var y = g[1]
        if (Config.INVERT_X) x = -x
        if (Config.INVERT_Y) y = -y
        val ax = abs(x)
        val ay = abs(y)
        val m = max(ax, ay)
        // A tengelyek a telefonhoz kötöttek, így kijelzővel felfelé és lefelé is ugyanazt adják
        val new = when {
            m < Config.TILT_OFF -> null
            m >= Config.TILT_ON ->
                if (ax > ay) {
                    if (x > 0) Direction.RIGHT else Direction.LEFT
                } else {
                    if (y < 0) Direction.FORWARD else Direction.BACK
                }
            else -> tilt.value
        }
        if (new != tilt.value) tilt.value = new
    }

    // --- Forgatások: mozdulatokra bontva (kezdet → nyugalom), utána besorolás ---
    private fun onGyro(event: SensorEvent) {
        if (!gyroOn) return
        val ts = event.timestamp
        val prev = lastGyroNs
        lastGyroNs = ts
        if (prev == 0L) return
        val dt = (ts - prev) / 1e9f
        if (dt <= 0f || dt > 0.5f) return
        val tMs = ts / 1_000_000

        // Hengerítés a hosszanti tengely körül: közben a kijelző hol fel, hol le néz,
        // ezért a fekvés-állapottól függetlenül számolja; ilyenkor a többi forgatást nem nézi
        if (has(Trigger.ROLL_3)) {
            val wy = event.values[1]
            onRoll(wy, dt, tMs)
            if (abs(wy) > 1f || !placed) return
        } else if (!placed) {
            return
        }

        // Felülről nézve óramutató irány = pozitív, akár lefelé, akár felfelé néz a kijelző
        val orient = if (g[2] < 0f) 1f else -1f
        var w = event.values[2] * orient
        if (Config.INVERT_TURN) w = -w
        lastW = w

        if (!moveActive) {
            if (abs(w) < Config.MOVE_START_RAD_S) return
            moveActive = true
            moveAngle = 0f
            moveStartMs = tMs
            quietSinceMs = 0L
            keepAwake()
        }
        moveAngle += w * dt

        if (abs(w) < Config.MOVE_STOP_RAD_S) {
            if (quietSinceMs == 0L) quietSinceMs = tMs
            else if (tMs - quietSinceMs > Config.MOVE_END_MS) endMove(tMs)
        } else {
            quietSinceMs = 0L
        }
        if (moveActive && tMs - moveStartMs > 8_000) endMove(tMs)
    }

    private fun endMove(tMs: Long) {
        moveActive = false
        val deg = Math.toDegrees(moveAngle.toDouble()).toFloat()
        val a = abs(deg)
        when {
            a >= Config.SPIN_GESTURE_DEG -> {
                DebugState.log("Megpörgetés (%.0f°)".format(deg))
                moves.clear()
                fire(Trigger.SPIN, tMs)
            }
            a >= Config.TURN_MIN_DEG && a <= Config.TURN_MAX_DEG -> {
                val c = if (deg > 0) 'R' else 'L'
                if (lastMoveEndMs != 0L && tMs - lastMoveEndMs > Config.TURN_GAP_MS) moves.clear()
                moves.addLast(c)
                lastMoveEndMs = tMs
                DebugState.log("Forgatás %s (%.0f°)".format(if (c == 'R') "jobbra" else "balra", a))
                matchMoves(tMs)
            }
            else -> Unit // túl kicsi vagy félbehagyott mozdulat
        }
    }

    private fun matchMoves(tMs: Long) {
        if (moves.size < 2) return
        val pair = "${moves[moves.size - 2]}${moves[moves.size - 1]}"
        val t = when (pair) {
            "RR" -> Trigger.RIGHT_2
            "LL" -> Trigger.LEFT_2
            "RL" -> Trigger.RIGHT_LEFT
            else -> Trigger.LEFT_RIGHT
        }
        if (has(t)) {
            fire(t, tMs)
        } else {
            // Nem illik semmire: az utolsó forgatás lehet egy új pár eleje
            val last = moves.last()
            moves.clear()
            moves.addLast(last)
        }
    }

    override fun onAccuracyChanged(sensor: Sensor?, accuracy: Int) = Unit
}
