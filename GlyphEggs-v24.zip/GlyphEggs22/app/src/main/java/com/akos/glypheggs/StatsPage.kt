package com.akos.glypheggs

import android.app.Activity
import android.app.AlertDialog
import android.content.Context
import android.graphics.Canvas
import android.graphics.Paint
import android.view.Gravity
import android.view.View
import android.view.ViewGroup.LayoutParams.MATCH_PARENT
import android.view.ViewGroup.LayoutParams.WRAP_CONTENT
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.TextView
import java.time.LocalDate
import kotlin.math.ceil

/** Pontoszlopos diagram (Nothing-stílus): minden oszlop pontokból, az utolsó (ma) piros. */
class DotColumns(context: Context) : View(context) {
    var values: IntArray = IntArray(0)
    var labels: List<String> = emptyList()
    var rows = 8
    var highlightLast = true
    private val p = Paint(Paint.ANTI_ALIAS_FLAG)

    override fun onDraw(canvas: Canvas) {
        val n = values.size
        if (n == 0) return
        val d = resources.displayMetrics.density
        val labelH = 16 * d
        val colW = width.toFloat() / n
        val stepY = (height - labelH) / rows
        val r = minOf(colW, stepY) * 0.3f
        val max = (values.maxOrNull() ?: 0).coerceAtLeast(1)
        p.textSize = 10 * d
        p.textAlign = Paint.Align.CENTER
        for (i in 0 until n) {
            val lit = if (values[i] == 0) 0 else ceil(values[i] * rows / max.toFloat()).toInt().coerceIn(1, rows)
            val cx = colW * i + colW / 2
            for (k in 0 until rows) {
                val cy = height - labelH - stepY * k - stepY / 2
                p.color = when {
                    k >= lit -> 0xFF2A2A2A.toInt()
                    highlightLast && i == n - 1 -> Ui.RED
                    else -> 0xFFEDEDED.toInt()
                }
                canvas.drawCircle(cx, cy, r, p)
            }
            labels.getOrNull(i)?.let {
                p.color = if (highlightLast && i == n - 1) Ui.RED else Ui.SUB
                canvas.drawText(it, cx, height - 3 * d, p)
            }
        }
    }
}

/** 24 órás „mikor játszol” pontsor: minél többet, annál fényesebb a pont. */
class HourDots(context: Context) : View(context) {
    var values = IntArray(24)
    private val p = Paint(Paint.ANTI_ALIAS_FLAG)
    override fun onDraw(canvas: Canvas) {
        val d = resources.displayMetrics.density
        val max = (values.maxOrNull() ?: 0).coerceAtLeast(1)
        val step = width / 24f
        val cy = (height - 16 * d) / 2
        p.textSize = 10 * d
        p.textAlign = Paint.Align.CENTER
        for (h in 0 until 24) {
            val t = values[h] / max.toFloat()
            p.color = if (values[h] == 0) 0xFF262626.toInt() else BadgeArt.mix(0xFF444444.toInt(), 0xFFFFFFFF.toInt(), t)
            if (values[h] == max && max > 0) p.color = Ui.RED
            canvas.drawCircle(step * h + step / 2, cy, step * (0.18f + 0.17f * t), p)
            if (h % 6 == 0) { p.color = Ui.SUB; canvas.drawText("$h", step * h + step / 2, height - 3 * d, p) }
        }
    }
}

/** Vízszintes pontsor egy arányhoz (0..1). */
class DotLine(context: Context, private val frac: Float, private val color: Int) : View(context) {
    private val p = Paint(Paint.ANTI_ALIAS_FLAG)
    override fun onDraw(canvas: Canvas) {
        val n = 20
        val step = width / n.toFloat()
        val lit = Math.round(frac * n).coerceIn(if (frac > 0f) 1 else 0, n)
        for (i in 0 until n) {
            p.color = if (i < lit) color else 0xFF2A2A2A.toInt()
            canvas.drawCircle(step * i + step / 2, height / 2f, minOf(step, height.toFloat()) * 0.32f, p)
        }
    }
}

/**
 * A Stat fül: szint (XP), összesítés, ábrák, kiértékelés, játékonkénti kártyák és a mozgó kitűzők.
 * A [tick] hívja a fül élő ciklusa (~30 kép/mp), ez mozgatja a kitűzőket.
 */
class StatsPage(private val a: Activity) {

    private val badgeViews = mutableListOf<BadgeView>()
    private var phase = 0f

    fun tick() {
        phase = (phase + 0.006f) % 1f
        badgeViews.forEachIndexed { i, v ->
            v.phase = (phase + i * 0.137f) % 1f
            v.invalidate()
        }
    }

    private fun card(): LinearLayout = LinearLayout(a).apply {
        orientation = LinearLayout.VERTICAL
        background = rounded(Ui.CARD, a.dp(22).toFloat())
        setPadding(a.dp(18), a.dp(16), a.dp(18), a.dp(16))
    }

    private fun lp(bottom: Int = 5) = LinearLayout.LayoutParams(MATCH_PARENT, WRAP_CONTENT).apply { bottomMargin = a.dp(bottom) }
    private fun dot(s: String, sp: Float, color: Int = Ui.TEXT): TextView =
        a.text(s, sp, color).apply { typeface = Widgets.dotoFace(a) }

    fun render(content: LinearLayout) {
        Achievements.check(a)
        badgeViews.clear()
        val c = a
        val xp = GameStats.xp(c)
        val lvl = GameStats.level(xp)
        val from = GameStats.xpFor(lvl)
        val to = GameStats.xpFor(lvl + 1)

        // ---- Szint
        content.addView(a.sectionTitle("Játékos-szint"))
        val hero = card()
        val top = LinearLayout(a).apply { orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL }
        val left = LinearLayout(a).apply { orientation = LinearLayout.VERTICAL }
        left.addView(a.text("SZINT", 11f, Ui.SUB, Ui.medium).apply { letterSpacing = 0.15f })
        left.addView(dot("$lvl", 54f))
        top.addView(left, LinearLayout.LayoutParams(WRAP_CONTENT, WRAP_CONTENT).apply { marginEnd = a.dp(18) })
        val right = LinearLayout(a).apply { orientation = LinearLayout.VERTICAL }
        right.addView(dot(GameStats.rank(lvl), 20f, Ui.RED))
        right.addView(a.text("$xp XP · a következő szintig ${to - xp} XP", 12.5f, Ui.SUB).apply { setPadding(0, a.dp(4), 0, a.dp(8)) })
        right.addView(DotLine(a, (xp - from).toFloat() / (to - from).coerceAtLeast(1), 0xFFEDEDED.toInt()),
            LinearLayout.LayoutParams(MATCH_PARENT, a.dp(14)))
        top.addView(right, LinearLayout.LayoutParams(0, WRAP_CONTENT, 1f))
        hero.addView(top)
        content.addView(hero, lp())

        // ---- Számok
        val plays = GameStats.totalPlays(c)
        val ms = GameStats.totalMs(c)
        val tiles = listOf(
            "$plays" to "INDÍTÁS",
            shortDuration(ms) to "A FÉNYBEN",
            "${GameStats.streak(c)}" to "NAPOS SOROZAT",
            "${Achievements.unlocked(c).size}/${Badge.entries.size}" to "KITŰZŐ"
        )
        for (pair in tiles.chunked(2)) {
            val r = LinearLayout(a).apply { orientation = LinearLayout.HORIZONTAL }
            pair.forEachIndexed { i, (v, l) ->
                val t = card().apply { setPadding(a.dp(16), a.dp(14), a.dp(16), a.dp(14)) }
                t.addView(dot(v, 26f))
                t.addView(a.text(l, 10.5f, Ui.SUB, Ui.medium).apply { letterSpacing = 0.12f })
                r.addView(t, LinearLayout.LayoutParams(0, WRAP_CONTENT, 1f).apply { if (i == 0) marginEnd = a.dp(5) })
            }
            content.addView(r, lp())
        }

        if (plays == 0) {
            content.addView(a.text("Még nincs statisztika – indíts el egy játékot vagy eszközt, és itt megjelenik minden.", 13f, Ui.SUB)
                .apply { setPadding(a.dp(8), a.dp(10), a.dp(8), 0) })
        }

        // ---- 14 nap
        content.addView(a.sectionTitle("Az elmúlt 14 nap"))
        val days = card()
        val today = GameStats.today(c)
        val dayLetters = arrayOf("H", "K", "Sz", "Cs", "P", "Sz", "V")
        val chart = DotColumns(a).apply {
            values = IntArray(14) { GameStats.dayPlays(c, today - 13 + it) }
            labels = List(14) { dayLetters[LocalDate.ofEpochDay(today - 13 + it).dayOfWeek.value - 1] }
        }
        days.addView(chart, LinearLayout.LayoutParams(MATCH_PARENT, a.dp(150)))
        val week = (0 until 7).sumOf { GameStats.dayPlays(c, today - it) }
        val prevWeek = (7 until 14).sumOf { GameStats.dayPlays(c, today - it) }
        days.addView(a.text("Ezen a héten $week indítás" + when {
            prevWeek == 0 && week > 0 -> " – az előző héten semmi, szép kezdés!"
            prevWeek > 0 -> " · " + (if (week >= prevWeek) "+" else "") + "${(week - prevWeek) * 100 / prevWeek}% az előzőhöz képest"
            else -> ""
        }, 12.5f, Ui.SUB).apply { setPadding(0, a.dp(10), 0, 0) })
        content.addView(days, lp())

        // ---- Mikor
        content.addView(a.sectionTitle("Mikor játszol"))
        val hours = card()
        hours.addView(HourDots(a).apply { values = IntArray(24) { GameStats.hour(c, it) } }, LinearLayout.LayoutParams(MATCH_PARENT, a.dp(52)))
        content.addView(hours, lp())

        // ---- Kiértékelés
        content.addView(a.sectionTitle("Kiértékelés"))
        val ev = card()
        for (line in insights(c)) ev.addView(a.text(line, 14f).apply { setPadding(0, a.dp(4), 0, a.dp(4)); setLineSpacing(0f, 1.2f) })
        content.addView(ev, lp())

        // ---- Megoszlás
        content.addView(a.sectionTitle("Mivel mennyit"))
        val share = card()
        val totalMs = ms.coerceAtLeast(1)
        val sorted = Feature.entries.sortedByDescending { GameStats.ms(c, it) }.filter { GameStats.plays(c, it) > 0 }
        if (sorted.isEmpty()) share.addView(a.text("Még üres.", 13f, Ui.SUB))
        sorted.forEachIndexed { i, f ->
            val row = LinearLayout(a).apply { orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL; setPadding(0, a.dp(5), 0, a.dp(5)) }
            row.addView(ImageView(a).apply { setImageResource(f.icon) }, LinearLayout.LayoutParams(a.dp(20), a.dp(20)).apply { marginEnd = a.dp(10) })
            row.addView(a.text(f.short, 13f), LinearLayout.LayoutParams(a.dp(78), WRAP_CONTENT))
            row.addView(DotLine(a, GameStats.ms(c, f).toFloat() / totalMs, if (i == 0) Ui.RED else 0xFFEDEDED.toInt()),
                LinearLayout.LayoutParams(0, a.dp(12), 1f))
            row.addView(a.text("${GameStats.ms(c, f) * 100 / totalMs}%", 12f, Ui.SUB).apply { gravity = Gravity.END },
                LinearLayout.LayoutParams(a.dp(40), WRAP_CONTENT))
            share.addView(row)
        }
        content.addView(share, lp())

        // ---- Kitűzők
        val got = Achievements.unlocked(c).size
        content.addView(a.sectionTitle("Kitűzők · $got / ${Badge.entries.size}"))
        val grid = card().apply { setPadding(a.dp(10), a.dp(14), a.dp(10), a.dp(10)) }
        val order = Badge.entries.sortedWith(compareByDescending<Badge> { Achievements.isUnlocked(c, it) }
            .thenByDescending { it.progress(c).toFloat() / it.goal() })
        for (chunk in order.chunked(4)) {
            val r = LinearLayout(a).apply { orientation = LinearLayout.HORIZONTAL }
            for (b in chunk) {
                val cell = LinearLayout(a).apply {
                    orientation = LinearLayout.VERTICAL
                    gravity = Gravity.CENTER_HORIZONTAL
                    setPadding(0, 0, 0, a.dp(10))
                    setOnClickListener { showBadge(b) }
                }
                val unlocked = Achievements.isUnlocked(c, b)
                val v = BadgeView(a, b).apply {
                    this.unlocked = unlocked
                    progress = b.progress(c).toFloat() / b.goal()
                }
                badgeViews += v
                cell.addView(v, LinearLayout.LayoutParams(a.dp(70), a.dp(70)))
                cell.addView(a.text(b.title, 11f, if (unlocked) Ui.TEXT else Ui.SUB).apply {
                    gravity = Gravity.CENTER; maxLines = 2; setPadding(a.dp(2), a.dp(4), a.dp(2), 0)
                }, LinearLayout.LayoutParams(MATCH_PARENT, WRAP_CONTENT))
                r.addView(cell, LinearLayout.LayoutParams(0, WRAP_CONTENT, 1f))
            }
            repeat(4 - chunk.size) { r.addView(View(a), LinearLayout.LayoutParams(0, 1, 1f)) }
            grid.addView(r)
        }
        content.addView(grid, lp())
        content.addView(a.text("Koppints egy kitűzőre a részletekért. A „Kitűzők” widget a kezdőképernyőn is mutatja őket.", 12f, Ui.SUB)
            .apply { setPadding(a.dp(8), a.dp(6), a.dp(8), 0) })

        // ---- Játékonként
        content.addView(a.sectionTitle("Játékonként"))
        for (f in Feature.entries) content.addView(featureCard(f), lp())
    }

    private fun featureCard(f: Feature): LinearLayout {
        val c = a
        val card = card()
        val head = LinearLayout(a).apply { orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL }
        head.addView(ImageView(a).apply { setImageResource(f.icon) }, LinearLayout.LayoutParams(a.dp(24), a.dp(24)).apply { marginEnd = a.dp(12) })
        head.addView(a.text(f.title, 17f), LinearLayout.LayoutParams(0, WRAP_CONTENT, 1f))
        head.addView(dot("${GameStats.plays(c, f)}×", 18f, if (GameStats.plays(c, f) > 0) Ui.TEXT else Ui.SUB))
        card.addView(head)
        val best = when (f) {
            Feature.SIMON -> "Legjobb szint: ${GameStats.bestOf(c, "simon")}/${Config.MAX_ROUNDS}"
            Feature.LOCKPICK -> "Legtöbb tüske: ${GameStats.bestOf(c, "lock")}/${Config.LOCK_PINS} · kinyitva ${GameStats.cnt(c, "lock_open")}×"
            Feature.DINO -> "Rekord: ${maxOf(GameStats.bestOf(c, "dino"), Settings.dinoBest(c))} pont · átlag ${
                if (GameStats.plays(c, f) > 0) GameStats.sumOf(c, "dino") / GameStats.plays(c, f) else 0} pont"
            Feature.BLOW -> "Kidurrantott lufi: ${Settings.blowPops(c)}"
            Feature.PET -> "A Tojás most: ${PetStore.load(c).stage.title}"
            Feature.SAFE -> "Kinyitva: ${GameStats.cnt(c, "safe_open")}× · rossz kód: ${GameStats.cnt(c, "safe_denied")}×"
            Feature.LEVEL -> "Pont vízszintes: ${GameStats.cnt(c, "level_zero")}×"
            Feature.BREATH, Feature.TIMER, Feature.LECTURE -> "Összesen ${shortDuration(GameStats.ms(c, f))}"
            else -> null
        }
        val sub = "Idő: ${shortDuration(GameStats.ms(c, f))} · utoljára: ${shortDate(GameStats.last(c, f))}" + (best?.let { "\n$it" } ?: "")
        card.addView(a.text(sub, 12.5f, Ui.SUB).apply { setPadding(0, a.dp(6), 0, a.dp(8)); setLineSpacing(0f, 1.2f) })
        val today = GameStats.today(c)
        card.addView(DotColumns(a).apply {
            rows = 4
            values = IntArray(14) { GameStats.featureDay(c, f, today - 13 + it) }
        }, LinearLayout.LayoutParams(MATCH_PARENT, a.dp(52)))
        return card
    }

    private fun showBadge(b: Badge) {
        val c = a
        val at = Achievements.unlockedAt(c, b)
        val box = LinearLayout(a).apply {
            orientation = LinearLayout.VERTICAL
            gravity = Gravity.CENTER_HORIZONTAL
            setPadding(a.dp(24), a.dp(20), a.dp(24), a.dp(8))
        }
        val v = BadgeView(a, b).apply { unlocked = at > 0; progress = b.progress(c).toFloat() / b.goal() }
        badgeViews += v
        box.addView(v, LinearLayout.LayoutParams(a.dp(150), a.dp(150)))
        box.addView(dot(b.title.uppercase(), 20f, if (at > 0) b.tier.color else Ui.TEXT).apply { gravity = Gravity.CENTER; setPadding(0, a.dp(12), 0, 0) })
        box.addView(a.text("${b.tier.title} · +${b.tier.xp} XP", 12f, Ui.SUB).apply { gravity = Gravity.CENTER })
        box.addView(a.text(b.desc, 15f).apply { gravity = Gravity.CENTER; setPadding(0, a.dp(10), 0, a.dp(6)) })
        box.addView(a.text(if (at > 0) "Megszerezve: ${shortDate(at)}" else "Haladás: ${b.progress(c)} / ${b.goal()}", 13f,
            if (at > 0) Ui.RED else Ui.SUB).apply { gravity = Gravity.CENTER })
        val d = AlertDialog.Builder(a, android.R.style.Theme_DeviceDefault_Dialog_Alert)
            .setView(box)
            .setPositiveButton("OK", null)
            .create()
        d.setOnDismissListener { badgeViews.remove(v) }
        d.show()
    }

    /** Vicces, de pontos kiértékelések a számokból. */
    private fun insights(c: Context): List<String> {
        val out = mutableListOf<String>()
        val plays = GameStats.totalPlays(c)
        if (plays == 0) return listOf("Még nincs miből kiértékelni. Kezdd egy Simonnal! 🎮")
        val fav = Feature.entries.maxByOrNull { GameStats.plays(c, it) }!!
        val favShare = GameStats.plays(c, fav) * 100 / plays
        out += "❤️ Kedvenced: ${fav.title} – az indításaid $favShare%-a."
        val longest = Feature.entries.maxByOrNull { GameStats.ms(c, it) }!!
        if (longest != fav) out += "⏱️ Időben viszont a(z) ${longest.title} nyer: ${shortDuration(GameStats.ms(c, longest))}."
        val hours = IntArray(24) { GameStats.hour(c, it) }
        val peak = hours.indices.maxByOrNull { hours[it] } ?: 0
        out += when (peak) {
            in 0..4 -> "🦉 Éjjeli bagoly vagy: a legtöbbet $peak óra körül játszol."
            in 5..8 -> "🌅 Korán kelő: reggel $peak óra a csúcsidőd."
            in 9..16 -> "☀️ Nappali játékos: $peak óra körül pörögsz a legjobban."
            else -> "🌙 Esti játékos: $peak óra a kedvenc idősávod."
        }
        val today = GameStats.today(c)
        val bestDay = (0 until 60).maxByOrNull { GameStats.dayPlays(c, today - it) } ?: 0
        val bestCount = GameStats.dayPlays(c, today - bestDay)
        if (bestCount > 1) out += "🏆 Rekordnap: ${shortDate(LocalDate.ofEpochDay(today - bestDay).atStartOfDay(java.time.ZoneId.systemDefault()).toInstant().toEpochMilli())} – $bestCount indítás."
        val simon = GameStats.bestOf(c, "simon")
        if (simon > 0) out += "🧠 Simon-memória: legjobb szinted $simon/${Config.MAX_ROUNDS}" + if (simon >= Config.MAX_ROUNDS) " – hibátlan mester!" else "."
        val dino = maxOf(GameStats.bestOf(c, "dino"), Settings.dinoBest(c))
        if (dino > 0) out += "🦖 Dínó-rekord: $dino pont" + if (dino >= 100) " – a meteor sem ér utol." else "."
        val streak = GameStats.bestStreak(c)
        if (streak >= 2) out += "🔥 Leghosszabb sorozatod: $streak nap egymás után."
        val untried = Feature.entries.filter { GameStats.plays(c, it) == 0 }
        if (untried.isNotEmpty()) out += "🧭 Még nem próbáltad: " + untried.take(3).joinToString(", ") { it.title } + (if (untried.size > 3) "…" else "") + "."
        val next = Badge.entries.filter { !Achievements.isUnlocked(c, it) }
            .maxByOrNull { it.progress(c).toFloat() / it.goal() }
        if (next != null) out += "🎯 Legközelebbi kitűző: ${next.title} (${next.progress(c)}/${next.goal()})."
        return out
    }
}
