package com.akos.glypheggs

import android.app.Activity
import android.content.Intent
import android.os.Bundle
import android.view.Gravity
import android.view.View
import android.view.ViewGroup.LayoutParams.MATCH_PARENT
import android.view.ViewGroup.LayoutParams.WRAP_CONTENT
import android.widget.FrameLayout
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView

/**
 * Indítás és leállítás – három szintű, könnyen átlátható oldal:
 *  1. Áttekintés: minden funkció egy sorban, rajta az indító mozdulat és a leállítás röviden.
 *  2. Egy funkció: fent „Indítás | Leállítás” váltó, alatta csoportosított választék.
 *  3. Érzékenység: kopogás, rázás és a Rázás-töltés rázásszáma egy helyen.
 *
 * Ha egy funkció oldaláról nyitják meg (EXTRA_FEATURE), egyből annak a részletei jönnek, és a vissza bezárja.
 */
class GesturesActivity : Activity() {

    companion object {
        const val EXTRA_FEATURE = "feature"
        const val EXTRA_SENS = "sens"
    }

    private enum class Screen { OVERVIEW, DETAIL, SENS }

    private var screen = Screen.OVERVIEW
    private var feature = Feature.SIMON
    private var stopTab = false
    private var directEntry = false
    private lateinit var scroll: ScrollView
    private lateinit var root: LinearLayout

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        darkWindow()
        root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(15), 0, dp(15), dp(28))
        }
        scroll = ScrollView(this).apply {
            setBackgroundColor(Ui.BG)
            isVerticalScrollBarEnabled = false
            addView(root, FrameLayout.LayoutParams(MATCH_PARENT, WRAP_CONTENT))
            padForSystemBars()
        }
        setContentView(scroll)

        val name = intent.getStringExtra(EXTRA_FEATURE)
        val f = Feature.entries.firstOrNull { it.name == name }
        when {
            f != null -> { feature = f; screen = Screen.DETAIL; directEntry = true }
            intent.getBooleanExtra(EXTRA_SENS, false) -> { screen = Screen.SENS; directEntry = true }
        }
        render()
    }

    override fun onResume() {
        super.onResume()
        GlyphMirror.appVisible = true
        render()
    }

    override fun onPause() {
        super.onPause()
        GlyphMirror.appVisible = false
    }

    @Deprecated("A régi vissza-kezelés elég ide")
    override fun onBackPressed() = goBack()

    private fun goBack() {
        if (screen == Screen.OVERVIEW || directEntry) finish() else go(Screen.OVERVIEW)
    }

    private fun go(s: Screen) {
        screen = s
        render()
        scroll.scrollTo(0, 0)
    }

    private fun render() {
        root.removeAllViews()
        when (screen) {
            Screen.OVERVIEW -> overview()
            Screen.DETAIL -> detail()
            Screen.SENS -> sensitivity()
        }
    }

    // ------------------------------------------------------------------ közös elemek

    private fun header(title: String, sub: String? = null) {
        val h = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
            setPadding(dp(7), dp(28), 0, dp(6))
        }
        h.addView(ImageView(this).apply {
            setImageResource(R.drawable.ic_back)
            setOnClickListener { goBack() }
        }, LinearLayout.LayoutParams(dp(24), dp(24)))
        h.addView(text(title, 26f).apply { setPadding(dp(30), 0, 0, 0) })
        root.addView(h)
        if (sub != null) root.addView(text(sub, 13f, Ui.SUB).apply {
            setPadding(dp(7), dp(10), dp(7), 0); setLineSpacing(0f, 1.2f)
        })
    }

    private fun lp(bottom: Int = 5) = LinearLayout.LayoutParams(MATCH_PARENT, WRAP_CONTENT).apply { bottomMargin = dp(bottom) }

    private fun note(s: String, color: Int = Ui.SUB) = text(s, 12.5f, color).apply {
        setPadding(dp(8), dp(6), dp(8), dp(2)); setLineSpacing(0f, 1.2f)
    }

    /** Navigációs sor: ikon, cím, alcím, jobbra nyíl. */
    private fun navRow(icon: Int?, title: String, sub: String, badge: String? = null, onClick: () -> Unit): LinearLayout {
        val row = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
            background = rounded(Ui.CARD, dp(20).toFloat())
            setPadding(dp(16), dp(14), dp(14), dp(14))
            setOnClickListener { onClick() }
        }
        if (icon != null) row.addView(ImageView(this).apply { setImageResource(icon) },
            LinearLayout.LayoutParams(dp(24), dp(24)).apply { marginEnd = dp(14) })
        val t = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        t.addView(text(title, 16.5f))
        t.addView(text(sub, 12.5f, Ui.SUB).apply { setPadding(0, dp(2), 0, 0); setLineSpacing(0f, 1.1f) })
        row.addView(t, LinearLayout.LayoutParams(0, WRAP_CONTENT, 1f))
        if (badge != null) row.addView(text(badge, 11.5f, Ui.DARK_TEXT, Ui.medium).apply {
            background = rounded(Ui.LIGHT, dp(10).toFloat()); setPadding(dp(8), dp(3), dp(8), dp(3))
        }, LinearLayout.LayoutParams(WRAP_CONTENT, WRAP_CONTENT).apply { marginStart = dp(8) })
        row.addView(text("›", 26f, Ui.SUB).apply { setPadding(dp(12), 0, dp(2), dp(3)) })
        return row
    }

    private fun pillRow(labels: List<String>, selected: Int, height: Int = 46, onPick: (Int) -> Unit): LinearLayout {
        val r = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
        labels.forEachIndexed { i, label ->
            val sel = i == selected
            r.addView(text(label, 13.5f, if (sel) Ui.DARK_TEXT else Ui.TEXT).apply {
                gravity = Gravity.CENTER
                background = rounded(if (sel) Ui.LIGHT else Ui.CARD, dp(22).toFloat())
                setOnClickListener { onPick(i) }
            }, LinearLayout.LayoutParams(0, dp(height), 1f).apply { if (i < labels.size - 1) marginEnd = dp(5) })
        }
        return r
    }

    private fun stopSummary(f: Feature): String {
        val list = StopMethod.entries.filter { it.builtInFor(f) || (it in Settings.stopMethods(this, f) && it.blockedFor(f) == null) }
        return if (list.isEmpty()) "csak gombbal" else list.joinToString(", ") { it.title }
    }

    // ------------------------------------------------------------------ 1. áttekintés

    private fun overview() {
        header("Indítás és leállítás",
            "Koppints egy funkcióra, és állítsd be, melyik mozdulat indítsa, és mivel lehessen leállítani. " +
                "Az indító mozdulatok akkor működnek, ha a főoldalon be van kapcsolva a Mozdulatfigyelés.")

        // Állapot-sáv: figyelés és a kiosztott mozdulatok száma
        val used = Feature.entries.count { Settings.trigger(this, it) != Trigger.NONE }
        val status = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
            background = rounded(Ui.BG, dp(20).toFloat(), Ui.LINE, dp(1.5f))
            setPadding(dp(16), dp(12), dp(16), dp(12))
        }
        status.addView(View(this).apply {
            background = rounded(if (SimonService.watching) Ui.RED else 0xFF5A5A5A.toInt(), dp(5).toFloat())
        }, LinearLayout.LayoutParams(dp(10), dp(10)).apply { marginEnd = dp(12) })
        status.addView(text(
            (if (SimonService.watching) "Mozdulatfigyelés: BE" else "Mozdulatfigyelés: KI") + "   ·   $used funkciónak van indító mozdulata",
            13f, Ui.TEXT), LinearLayout.LayoutParams(0, WRAP_CONTENT, 1f))
        root.addView(status, lp(0).apply { topMargin = dp(14) })

        root.addView(sectionTitle("Funkciók"))
        for (f in Feature.entries) {
            val t = Settings.trigger(this, f)
            val sub = "Indul: ${t.title}\nLeáll: ${stopSummary(f)}"
            root.addView(navRow(f.icon, f.title, sub, if (t != Trigger.NONE) "BE" else null) {
                feature = f; stopTab = false; go(Screen.DETAIL)
            }, lp())
        }

        root.addView(sectionTitle("Mindenre érvényes"))
        root.addView(navRow(R.drawable.ic_vibrate, "Érzékenység",
            "Kopogás: ${knockLabels[Settings.knockSensitivity(this)].replace("\n", " ")} · Rázás: ${shakeLabels[Settings.shakeSensitivity(this)].replace("\n", " ")} · Töltés: ${Settings.shakeFillCount(this)}×") {
            go(Screen.SENS)
        }, lp())

        root.addView(sectionTitle("Tippek"))
        root.addView(tipsCard())
    }

    // ------------------------------------------------------------------ 2. egy funkció

    private fun detail() {
        header(feature.title)

        // Összefoglaló kártya
        val sum = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
            background = rounded(Ui.CARD, dp(22).toFloat())
            setPadding(dp(18), dp(16), dp(18), dp(16))
        }
        sum.addView(ImageView(this).apply { setImageResource(feature.icon) },
            LinearLayout.LayoutParams(dp(30), dp(30)).apply { marginEnd = dp(16) })
        val st = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        st.addView(text("INDUL", 10.5f, Ui.SUB, Ui.medium))
        st.addView(text(Settings.trigger(this, feature).title, 16f))
        st.addView(text("LEÁLL", 10.5f, Ui.SUB, Ui.medium).apply { setPadding(0, dp(8), 0, 0) })
        st.addView(text(stopSummary(feature), 16f))
        sum.addView(st, LinearLayout.LayoutParams(0, WRAP_CONTENT, 1f))
        root.addView(sum, lp(0).apply { topMargin = dp(14) })

        // Indítás | Leállítás váltó
        val seg = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            background = rounded(Ui.CARD, dp(26).toFloat())
            setPadding(dp(4), dp(4), dp(4), dp(4))
        }
        listOf("Indítás", "Leállítás").forEachIndexed { i, label ->
            val sel = (i == 1) == stopTab
            seg.addView(text(label, 14.5f, if (sel) Ui.DARK_TEXT else Ui.TEXT, Ui.medium).apply {
                gravity = Gravity.CENTER
                background = if (sel) rounded(Ui.LIGHT, dp(22).toFloat()) else null
                setOnClickListener { stopTab = i == 1; render() }
            }, LinearLayout.LayoutParams(0, dp(44), 1f))
        }
        root.addView(seg, lp(0).apply { topMargin = dp(14) })

        if (stopTab) stopSection() else startSection()

        // Gyors ugrás a többi funkcióra
        root.addView(sectionTitle("Másik funkció"))
        val chips = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        for (chunk in Feature.entries.filter { it != feature }.chunked(4)) {
            val r = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
            chunk.forEachIndexed { i, f ->
                r.addView(text(f.short, 12.5f).apply {
                    gravity = Gravity.CENTER
                    background = rounded(Ui.CARD, dp(18).toFloat())
                    setOnClickListener { feature = f; render(); scroll.scrollTo(0, 0) }
                }, LinearLayout.LayoutParams(0, dp(38), 1f).apply { if (i < 3) marginEnd = dp(5) })
            }
            repeat(4 - chunk.size) { r.addView(View(this), LinearLayout.LayoutParams(0, dp(38), 1f)) }
            chips.addView(r, lp())
        }
        root.addView(chips)
    }

    private val triggerGroups = listOf(
        "Forgatás az asztalon" to listOf(Trigger.RIGHT_2, Trigger.LEFT_2, Trigger.RIGHT_LEFT, Trigger.LEFT_RIGHT, Trigger.SPIN, Trigger.FLIP_2),
        "Kopogás és rázás" to listOf(Trigger.KNOCK_2, Trigger.KNOCK_3, Trigger.SHAKE_FILL, Trigger.SHAKE, Trigger.ROLL_3),
        "Gombok" to listOf(Trigger.VOL_UP_2, Trigger.VOL_DOWN_2)
    )

    private fun startSection() {
        val current = Settings.trigger(this, feature)
        root.addView(sectionTitle("Indító mozdulat"))
        root.addView(triggerRow(Trigger.NONE, current), lp())
        for ((title, list) in triggerGroups) {
            root.addView(text(title.uppercase(), 11f, Ui.SUB, Ui.medium).apply { setPadding(dp(8), dp(16), 0, dp(8)) })
            val box = LinearLayout(this).apply {
                orientation = LinearLayout.VERTICAL
                background = rounded(Ui.CARD, dp(22).toFloat())
                setPadding(0, dp(4), 0, dp(4))
            }
            list.forEachIndexed { i, t ->
                if (i > 0) box.addView(View(this).apply { setBackgroundColor(Ui.LINE) },
                    LinearLayout.LayoutParams(MATCH_PARENT, 1).apply { marginStart = dp(18); marginEnd = dp(18) })
                box.addView(triggerRow(t, current, inGroup = true), LinearLayout.LayoutParams(MATCH_PARENT, WRAP_CONTENT))
            }
            root.addView(box, lp())
        }
        if (current.isKnock || current == Trigger.SHAKE || current == Trigger.SHAKE_FILL) {
            root.addView(navRow(R.drawable.ic_vibrate, "Érzékenység beállítása", "Ha nem érzékeli, vagy magától is indul") {
                go(Screen.SENS)
            }, lp().apply { topMargin = dp(10) })
        }
        root.addView(note("Egy mozdulat egyszerre csak egy funkciót indíthat. Ha egy máshol használt mozdulatot választasz, ott „Nincs” lesz."))
    }

    /** Egy mozdulat: a kiválasztottnál látszik a leírás is, a többinél csak a név (átláthatóbb). */
    private fun triggerRow(t: Trigger, current: Trigger, inGroup: Boolean = false): LinearLayout {
        val selected = t == current
        val owner = Settings.featureFor(this, t)?.takeIf { it != feature && t != Trigger.NONE }
        val row = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
            if (!inGroup) background = rounded(Ui.CARD, dp(20).toFloat())
            setPadding(dp(18), dp(13), dp(16), dp(13))
            setOnClickListener {
                Settings.setTrigger(this@GesturesActivity, feature, t)
                notifyService()
                render()
            }
        }
        val texts = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        texts.addView(text(t.title, 16f))
        if (selected) texts.addView(text(t.hint, 12.5f, Ui.SUB).apply { setPadding(0, dp(3), 0, 0); setLineSpacing(0f, 1.15f) })
        if (owner != null) texts.addView(text("Most: ${owner.title}", 12f, 0xFFE0857F.toInt()).apply { setPadding(0, dp(2), 0, 0) })
        row.addView(texts, LinearLayout.LayoutParams(0, WRAP_CONTENT, 1f))
        row.addView(RadioMark(this, selected), LinearLayout.LayoutParams(dp(24), dp(24)).apply { marginStart = dp(12) })
        return row
    }

    private fun stopSection() {
        root.addView(sectionTitle("Leállítás futás közben"))
        val stops = Settings.stopMethods(this, feature)
        val box = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            background = rounded(Ui.CARD, dp(22).toFloat())
            setPadding(0, dp(4), 0, dp(4))
        }
        StopMethod.entries.forEachIndexed { i, m ->
            if (i > 0) box.addView(View(this).apply { setBackgroundColor(Ui.LINE) },
                LinearLayout.LayoutParams(MATCH_PARENT, 1).apply { marginStart = dp(18); marginEnd = dp(18) })
            box.addView(stopRow(m, stops), LinearLayout.LayoutParams(MATCH_PARENT, WRAP_CONTENT))
        }
        root.addView(box, lp())
        root.addView(note("Több is bekapcsolható. Mindig működik ezen felül: a csempe, a widget, az értesítés „Leállítás” gombja és az app „Most fut” kártyája."))
    }

    private fun stopRow(m: StopMethod, current: Set<StopMethod>): LinearLayout {
        val blocked = m.blockedFor(feature)
        val builtIn = m.builtInFor(feature)
        val row = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
            setPadding(dp(18), dp(14), dp(16), dp(14))
            alpha = if (blocked != null) 0.5f else 1f
        }
        val texts = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        texts.addView(text(m.title, 16f))
        val on = builtIn || m in current
        if (on || blocked != null) {
            val sub = when {
                builtIn -> "Ennél a funkciónál magától is így működik"
                blocked != null -> "Itt nem választható: $blocked"
                else -> m.hint
            }
            texts.addView(text(sub, 12.5f, if (blocked != null) 0xFFE0857F.toInt() else Ui.SUB).apply {
                setPadding(0, dp(3), 0, 0); setLineSpacing(0f, 1.15f)
            })
        }
        row.addView(texts, LinearLayout.LayoutParams(0, WRAP_CONTENT, 1f))
        val toggle = ToggleView(this).apply {
            checked = on
            isEnabled = blocked == null && !builtIn
            onChange = { v ->
                Settings.setStopMethod(this@GesturesActivity, feature, m, v)
                render()
            }
        }
        row.addView(toggle, LinearLayout.LayoutParams(WRAP_CONTENT, WRAP_CONTENT).apply { marginStart = dp(12) })
        if (blocked == null && !builtIn) row.setOnClickListener { toggle.performClick() }
        return row
    }

    // ------------------------------------------------------------------ 3. érzékenység

    private val knockLabels = listOf("Alacsony", "Közepes", "Magas", "Nagyon\nmagas")
    private val shakeLabels = listOf("Alacsony", "Közepes", "Magas", "Nagyon\nmagas")

    private fun sensitivity() {
        header("Érzékenység", "Minden funkcióra és mozdulatra érvényes. Ha magától is elindul valami, vegyél vissza; ha nem veszi észre, emeld meg.")

        root.addView(sectionTitle("Kopogás"))
        root.addView(pillRow(knockLabels, Settings.knockSensitivity(this), 50) {
            Settings.setKnockSensitivity(this, it); notifyService(); render()
        })
        root.addView(note("Fekve kopogtass a telefon hátán vagy a kijelzőn. Nem kell sietni: két koppanás között majdnem egy másodperc is lehet."))

        root.addView(sectionTitle("Rázás"))
        root.addView(pillRow(shakeLabels, Settings.shakeSensitivity(this), 50) {
            Settings.setShakeSensitivity(this, it); notifyService(); render()
        })
        root.addView(note("Rázás-töltés, Rázás majd lerakás, Előadás, Tojás, Dínó."))

        root.addView(sectionTitle("Rázás-töltés – rázások száma"))
        val fill = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
            background = rounded(Ui.CARD, dp(20).toFloat())
            setPadding(dp(18), dp(12), dp(12), dp(12))
        }
        val ft = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        ft.addView(text("Rázások száma", 16.5f))
        ft.addView(text("Ennyi rázás tölti fel mind a 33 LED-et", 12.5f, Ui.SUB).apply { setPadding(0, dp(2), 0, 0) })
        fill.addView(ft, LinearLayout.LayoutParams(0, WRAP_CONTENT, 1f))
        fill.addView(roundBtn("−") { Settings.setShakeFillCount(this, Settings.shakeFillCount(this) - 1); render() },
            LinearLayout.LayoutParams(dp(44), dp(44)))
        fill.addView(text("${Settings.shakeFillCount(this)}×", 17f, Ui.TEXT, Ui.medium).apply { gravity = Gravity.CENTER },
            LinearLayout.LayoutParams(dp(58), WRAP_CONTENT))
        fill.addView(roundBtn("+") { Settings.setShakeFillCount(this, Settings.shakeFillCount(this) + 1); render() },
            LinearLayout.LayoutParams(dp(44), dp(44)))
        root.addView(fill)
        root.addView(note("Az első rázás ébreszti a funkciót, aztán ennyi rázással gyulladnak a LED-ek alulról felfelé. Az Előadás töltése is ezt használja."))
    }

    private fun roundBtn(label: String, onClick: () -> Unit): TextView = text(label, 22f).apply {
        gravity = Gravity.CENTER
        background = rounded(0xFF3A3A3A.toInt(), dp(22).toFloat())
        setOnClickListener { onClick() }
    }

    private fun tipsCard(): LinearLayout {
        val card = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            background = rounded(Ui.CARD, dp(22).toFloat())
            setPadding(dp(18), dp(16), dp(18), dp(16))
        }
        val tips = listOf(
            "Forgatás és megpörgetés: kijelzővel lefelé, az asztalon fekve. A negyed fordulatot nem kell pontosan eltalálni.",
            "Kopogás: fekve kopogtass a telefonon (nem az asztalon), nyugodt tempóban is jó.",
            "Rázás, majd lerakás: rázd meg néhányszor, aztán 6 mp-en belül tedd le kijelzővel lefelé.",
            "Hangerő fel / le 2×: két gyors nyomás; a hangerő utána visszaáll. Kikapcsolt képernyőnél csak akkor megy, ha épp szól valami.",
            "Lefordítás: ha a Nothing „Flip to Glyph” be van kapcsolva, zavarhatja – kapcsold ki a Glyph beállításokban.",
            "Leállítás: a bekapcsoló gomb a legbiztosabb – lefelé fekvő telefonnál egy nyomás leállítja a futó funkciót.",
            "A játékokban a kopogás vagy a rázás maga az irányítás, ezért ott nem lehet leállító parancs.",
            "Hengerítés: két kézben, fekve magad előtt (töltőport jobbra) forgasd 3-szor körbe a hosszanti tengelye körül."
        )
        for (tip in tips) card.addView(text("•  $tip", 13f, Ui.SUB).apply { setPadding(0, dp(4), 0, dp(4)); setLineSpacing(0f, 1.2f) })
        return card
    }

    private fun notifyService() {
        if (SimonService.watching) {
            startService(Intent(this, SimonService::class.java).setAction(SimonService.ACTION_REFRESH))
        }
    }
}
