package com.akos.glypheggs

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.content.Context
import android.content.Intent
import android.net.Uri
import android.os.SystemClock
import android.provider.DocumentsContract
import com.nothing.ketchum.Glyph
import kotlinx.coroutines.channels.Channel
import kotlinx.coroutines.coroutineScope
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.merge
import kotlinx.coroutines.launch
import kotlinx.coroutines.withTimeoutOrNull
import kotlin.random.Random

/** A széf 8 pozíciója a hátlapon (a kód ezekből áll). */
object SafePositions {
    const val CODE_LENGTH = 4

    val names = listOf("Kamera", "Ferde csík", "Felső ív", "Jobb oldal", "Alsó ív", "Bal oldal", "Vonal", "Pont")

    fun zones(i: Int): IntArray = when (i) {
        0 -> intArrayOf(Glyph.Code_22111.A1, Glyph.Code_22111.A2)
        1 -> intArrayOf(Glyph.Code_22111.B1)
        2 -> Zones.LEVEL
        3 -> intArrayOf(Glyph.Code_22111.C5, Glyph.Code_22111.C6)
        4 -> intArrayOf(Glyph.Code_22111.C4)
        5 -> intArrayOf(Glyph.Code_22111.C2, Glyph.Code_22111.C3)
        6 -> intArrayOf(
            Glyph.Code_22111.D1_1, Glyph.Code_22111.D1_2, Glyph.Code_22111.D1_3, Glyph.Code_22111.D1_4,
            Glyph.Code_22111.D1_5, Glyph.Code_22111.D1_6, Glyph.Code_22111.D1_7, Glyph.Code_22111.D1_8
        )
        else -> intArrayOf(Glyph.Code_22111.E1)
    }
}

/**
 * Széf: a LED-pozíciók véletlen sorrendben egyenként felvillannak. Amikor a kódod következő
 * pozíciója világít, rázd meg a telefont (vagy kopogj, ha úgy állítottad) – ezzel kiválasztod.
 * Kiválasztás után a kör elölről indul. 4 kiválasztás után ellenőriz:
 *  - jó kód: minden összevissza villog, rezeg, és megnyílik a beállított titkos dolog;
 *  - rossz kód: lassú villogás, hosszú rezgés, zárva marad.
 */
class SafeLock(
    private val context: Context,
    private val glyph: GlyphController,
    private val motion: MotionDetector,
    private val haptics: Haptics,
    private val onStatus: (String) -> Unit
) {
    /** true = kinyílt. */
    suspend fun run(): Boolean = coroutineScope {
        val inputs = Channel<Long>(Channel.CONFLATED)
        val source: Flow<Long> =
            if (Settings.safeUsesShake(context)) merge(motion.shakeEvents, GlyphMirror.taps)
            else merge(motion.knockEvents, GlyphMirror.taps)
        val collector = launch { source.collect { inputs.trySend(it) } }
        try {
            enter(inputs)
        } finally {
            collector.cancel()
        }
    }

    private suspend fun enter(inputs: Channel<Long>): Boolean {
        val code = Settings.safeCode(context)
        val how = if (Settings.safeUsesShake(context)) "rázd meg" else "kopogj"
        onStatus("Széf – amikor a kódod LED-je világít, $how")

        // Bevezető: a pozíciók körbefutnak
        for (i in 0 until 8) {
            glyph.show(SafePositions.zones(i))
            delay(70)
        }
        glyph.off()
        delay(600)
        while (inputs.tryReceive().isSuccess) Unit

        val entered = mutableListOf<Int>()
        var idleCycles = 0
        while (entered.size < SafePositions.CODE_LENGTH) {
            var picked = -1
            for (pos in (0 until 8).shuffled(Random)) {
                glyph.show(SafePositions.zones(pos))
                val hit = withTimeoutOrNull(Config.SAFE_ON_MS) { inputs.receive() }
                    ?: run {
                        glyph.off()
                        // A sötét szünet elején még elfogadja (a reakcióidő miatt)
                        withTimeoutOrNull(Config.SAFE_OFF_MS) { inputs.receive() }
                    }
                if (hit != null) {
                    picked = pos
                    break
                }
            }
            if (picked < 0) {
                idleCycles++
                if (idleCycles >= Config.SAFE_MAX_IDLE_CYCLES) {
                    DebugState.log("Széf: nem jött válasz – leáll")
                    glyph.off()
                    return false
                }
                continue
            }
            idleCycles = 0
            entered += picked
            haptics.tick()
            // Kiválasztva: gyors háromszoros villanás
            repeat(3) {
                glyph.show(SafePositions.zones(picked))
                delay(60)
                glyph.off()
                delay(60)
            }
            DebugState.log("Széf: ${entered.size}/${SafePositions.CODE_LENGTH} kiválasztva")
            delay(500)
            while (inputs.tryReceive().isSuccess) Unit
        }

        return if (entered.toIntArray().contentEquals(code)) {
            celebrate()
            true
        } else {
            denied()
            false
        }
    }

    /** Nyitva! Minden lehetséges kombinációban villog, és a telefon rezeg. */
    private suspend fun celebrate() {
        DebugState.log("Széf kinyitva!")
        haptics.win()
        val end = SystemClock.elapsedRealtime() + Config.SAFE_CELEBRATE_MS
        var step = 0
        while (SystemClock.elapsedRealtime() < end) {
            val frame = when (step % 4) {
                0 -> Zones.ALL.filter { Random.nextBoolean() }.toIntArray()
                1 -> SafePositions.zones(step / 4 % 8)
                2 -> (0 until 8).filter { Random.nextInt(3) == 0 }.flatMap { SafePositions.zones(it).toList() }.toIntArray()
                else -> Zones.ALL
            }
            glyph.show(frame)
            delay(70)
            step++
        }
        glyph.show(Zones.ALL)
        delay(600)
        glyph.off()
    }

    private suspend fun denied() {
        DebugState.log("Széf: rossz kód")
        haptics.denied()
        repeat(3) {
            glyph.show(Zones.ALL)
            delay(350)
            glyph.off()
            delay(350)
        }
    }
}

/** A széf kinyitása után megnyitja, amit beállítottál. */
object SafeOpener {
    private const val CHANNEL = "glyph_eggs_safe"

    fun open(context: Context) {
        GlyphMirror.unlockedUntil = SystemClock.elapsedRealtime() + Config.SAFE_UNLOCK_WINDOW_MS
        val intent = buildIntent(context) ?: return
        intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
        // Közvetlenül csak akkor nyithat meg valamit, ha az app látszik, vagy van
        // "megjelenés más appok felett" engedély; különben értesítésből egy koppintással.
        val canStart = GlyphMirror.appVisible || android.provider.Settings.canDrawOverlays(context)
        if (canStart) {
            try {
                context.startActivity(intent)
                return
            } catch (t: Throwable) {
                DebugState.log("Közvetlen megnyitás nem sikerült: ${t.javaClass.simpleName}")
            }
        }
        notify(context, intent)
    }

    fun buildIntent(context: Context): Intent? {
        val value = Settings.safeTargetValue(context)
        return when (Settings.safeTargetType(context)) {
            "NOTES" -> Intent(context, SecretActivity::class.java)
            "APP" -> context.packageManager.getLaunchIntentForPackage(value).also {
                if (it == null) DebugState.log("A beállított app nem található")
            }
            "URL" -> if (value.isBlank()) null else Intent(Intent.ACTION_VIEW, Uri.parse(fixUrl(value)))
            "FOLDER" -> folderIntent(value)
            else -> null
        }
    }

    private fun fixUrl(v: String): String =
        if (v.startsWith("http://") || v.startsWith("https://")) v else "https://$v"

    private fun folderIntent(treeUri: String): Intent? {
        if (treeUri.isBlank()) return null
        return try {
            val tree = Uri.parse(treeUri)
            val doc = DocumentsContract.buildDocumentUriUsingTree(tree, DocumentsContract.getTreeDocumentId(tree))
            Intent(Intent.ACTION_VIEW).apply {
                setDataAndType(doc, DocumentsContract.Document.MIME_TYPE_DIR)
                addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
            }
        } catch (t: Throwable) {
            DebugState.log("Mappa megnyitás hiba: ${t.javaClass.simpleName}")
            null
        }
    }

    private fun notify(context: Context, intent: Intent) {
        val nm = context.getSystemService(NotificationManager::class.java)
        nm.createNotificationChannel(NotificationChannel(CHANNEL, "Széf", NotificationManager.IMPORTANCE_HIGH))
        val pi = PendingIntent.getActivity(
            context, 7, intent, PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT
        )
        val n = Notification.Builder(context, CHANNEL)
            .setSmallIcon(R.drawable.ic_safe)
            .setContentTitle("A széf nyitva")
            .setContentText("Koppints a megnyitáshoz (2 percig érvényes)")
            .setContentIntent(pi)
            .setAutoCancel(true)
            .setTimeoutAfter(Config.SAFE_UNLOCK_WINDOW_MS)
            .build()
        nm.notify(7, n)
    }
}
