package com.akos.glypheggs

import android.app.Activity
import android.content.Intent
import android.os.Bundle
import android.view.Gravity
import android.view.ViewGroup.LayoutParams.MATCH_PARENT
import android.view.ViewGroup.LayoutParams.WRAP_CONTENT
import android.widget.FrameLayout
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.ScrollView

/** Részletes súgó egy funkcióhoz: mi ez, hogyan indul, hogyan használd, mit jelentenek a LED-ek. */
object FeatureInfo {
    class Section(val title: String, val lines: List<String>)
    class Page(val intro: String, val sections: List<Section>)

    private val start = Section(
        "Indítás", listOf(
            "Koppints a kártyájára a Főoldalon vagy a Játékok / Eszközök fülön.",
            "Vagy a lehúzható menü csempéjével (Beállítások → Csempék).",
            "Vagy a hozzárendelt indító mozdulattal, ha a Mozdulatfigyelés be van kapcsolva (Beállítások → Indító mozdulatok).",
            "Leállítás: ugyanaz a kártya, csempe vagy widget – vagy a beállított leállítási parancs (alapból a bekapcsoló gomb; Beállítások → Indítás és leállítás)."
        )
    )

    fun page(f: Feature): Page = when (f) {
        Feature.SIMON -> Page(
            "Klasszikus Simon Says a hátlapon: a LED-ek mutatnak egy sort, te a telefon döntésével ismétled meg.",
            listOf(
                start,
                Section("Játékmenet", listOf(
                    "Tedd le a telefont kijelzővel lefelé, a töltőport feléd nézzen.",
                    "A LED-ek háromszor körbefutnak – indul a játék.",
                    "A telefon lejátszik egy sort. Utána döntsd a telefont arra, amerre a fény villant, majd engedd vissza középre.",
                    "Minden körben az egész sort végig kell dönteni, a végén egy új iránnyal.",
                    "Rossz irány vagy 7 mp tétlenség: vége a játéknak."
                )),
                Section("Irányok", listOf(
                    "Fel (a kamera felé): a kamera körüli rész és a ferde csík.",
                    "Le (a töltőport felé): a függőleges vonal és a pont.",
                    "Balra (a kamera felőli oldal): bal felső ív és bal oldal.",
                    "Jobbra: jobb alsó ív és jobb oldal."
                )),
                Section("Szint", listOf(
                    "Minden teljesített körrel 2 LED gyullad a felső sávon (8 kör = tele).",
                    "8 kör után kb. 8 mp-ig minden villog, és rezeg a telefon."
                ))
            )
        )
        Feature.SPIN -> Page(
            "Üvegpörgetés: a fény körbefut a nagy gyűrűn, lassul, és megáll valakinél.",
            listOf(
                start,
                Section("Használat", listOf(
                    "Tedd a telefont kijelzővel lefelé az asztal közepére (15 mp-ig vár rá).",
                    "A fény 4–6 kört fut 5–7 mp alatt, a végén kattogó rezgéssel lassul.",
                    "Ahol megáll, az 5-ször villog, és 4 mp-ig égve marad – akire mutat, az a kiválasztott.",
                    "Minden irány egyforma eséllyel jön ki."
                )),
                Section("Tipp", listOf("Alapból a telefon valódi megpörgetése is elindítja (indító mozdulat: Megpörgetés)."))
            )
        )
        Feature.COMPASS -> Page(
            "Iránytű: fekve megmutatja, merre van észak.",
            listOf(
                start,
                Section("Használat", listOf(
                    "Tedd le kijelzővel lefelé egy sík felületre – a gyűrű egyszer felvillan.",
                    "Durva irány: ha észak a nagy ívek felé van, az az ív ég.",
                    "Forgasd a telefont: amikor észak a felső sávra ér, kis kattanás jelzi, és onnan egyetlen kis LED mutatja pontosan.",
                    "Felemelés után 5 mp-ig vár; ha visszateszed, folytatja."
                )),
                Section("Pontosság", listOf(
                    "Fém, laptop, hangszóró közelében téved. Ha pontatlan, emeld fel, és mozgasd párszor 8-as alakban.",
                    "A mágneses északot mutatja (Magyarországon kb. 5–6°-kal tér el a földrajzitól)."
                ))
            )
        )
        Feature.LOCKPICK -> Page(
            "Zárfeltörő: az RPG-kből ismert zárfeltörés. Időzítés kell hozzá, és most a rezgés segít.",
            listOf(
                start,
                Section("Játékmenet", listOf(
                    "Tedd le kijelzővel lefelé. A felső sávon egy fénypont csúszik ide-oda.",
                    "Valahol a közepén van egy rejtett édes pont. Amikor a fény odaér, a telefon EGY KICSIT REZZEN.",
                    "A rezzenésre kopogj a telefonon (a szimulációban az Érintés gomb is jó). A reakcióidőt figyelembe veszi.",
                    "Közel jártál: a fény és a cél közti LED-ek kétszer felvillannak – ez nem kerül életbe.",
                    "Nagyon mellé: elvész egy élet.",
                    "Talált: kattan a zár, fényhullám; jön a következő tüske, gyorsabban.",
                    "4 tüske = nyitva: nagy fényáradat és rezgés."
                )),
                Section("Mit látsz", listOf(
                    "Életek: a kamera két fele és a ferde csík (3).",
                    "Kinyitott tüskék: a függőleges vonal, tüskénként 2 LED."
                )),
                Section("Tipp", listOf("Ha a Rezgés ki van kapcsolva (Beállítások), az édes pontot nem érzed – kapcsold be."))
            )
        )
        Feature.SAFE -> Page(
            "Széf: titkos kód LED-villanásokból. Helyes kódra fényshow, rezgés, és megnyílik, amit beállítottál.",
            listOf(
                start,
                Section("Beállítás (Széf beállítása)", listOf(
                    "Kód: 4 mező, mindegyik a hátlap 8 részének egyike (Kamera, Ferde csík, Felső ív, Jobb oldal, Alsó ív, Bal oldal, Vonal, Pont).",
                    "Kiválasztás: rázás vagy kopogás.",
                    "Mi nyíljon meg: titkos jegyzet, mappa, app, weboldal vagy semmi.",
                    "Azonnali megnyitás: a \"megjelenés más appok felett\" engedéllyel rögtön nyit; enélkül értesítésre kell koppintani."
                )),
                Section("Kódbevitel", listOf(
                    "A 8 rész véletlen sorrendben egyenként felvillan.",
                    "Amikor a kódod következő része világít, rázd meg a telefont (vagy kopogj).",
                    "Rövid villanás és rezgés jelzi a választást, utána a kör újraindul.",
                    "4 választás után: jó kód → 5 mp fényshow és megnyitás; rossz kód → lassú villogás, hosszú rezgés."
                )),
                Section("Titkos jegyzet", listOf("Csak kinyitás után 2 percig nyitható, egyszer; képernyőkép nem készülhet róla."))
            )
        )
        Feature.PET -> Page(
            "Glyph Tojás: Tamagocsi, ami a hátlap LED-jein él. Kikel, nő, eszik, játszik, alszik – gondoskodj róla.",
            listOf(
                Section("Indítás", listOf(
                    "A kártyára koppintva megnyílik a saját oldala: élő LED-kép, állapot, gondozó gombok.",
                    "A LED-es gondozáshoz: a \"Tojás a LED-eken\" kapcsoló, a csempe vagy mozdulat, majd tedd le kijelzővel lefelé."
                )),
                Section("Gondozás a LED-eken", listOf(
                    "1 kopogás: simogatás · 2: etetés · 3: játék · 4: altatás / ébresztés",
                    "Rázás: fürdetés (megrázod, majd 5 mp-en belül visszateszed).",
                    "Döntés: arra néz, amerre döntöd.",
                    "Gyógyítás: csak az app oldaláról."
                )),
                Section("Mit látsz", listOf(
                    "Szemek: kamera körüli LED-ek (pislog). Antenna: ferde csík.",
                    "Boldog: ugrál a felső sávon. Elégedett: lélegzik. Szomorú: könnycsepp fut a vonalon. Beteg: alsó ív villog. Alszik: csak a pont pislákol.",
                    "Kaki: a pont ég (sok kakinál villog).",
                    "Pár mp-enként állapotjelzés a felső sávon: bal felső ív = jóllakottság, bal oldal = kedv, jobb alsó = energia, jobb oldal = tisztaság."
                )),
                Section("Élete", listOf(
                    "Tojás → 3 gondoskodás vagy 20 perc után kikel → Kicsi → 1 nap: Kamasz → 3 nap: Felnőtt.",
                    "Az idő akkor is telik, ha nem nézed. Ha sokáig elhanyagolod, beteg lesz; ha sokáig beteg, elköltözik, és új tojás jön.",
                    "Óránként ránéz, és szól, ha valami kell neki (kikapcsolható)."
                ))
            )
        )
        Feature.LEVEL -> Page(
            "Vízmérték bármilyen helyzetben: fekve, a hosszú élére állítva (vagy fekvő tájolásban falhoz tartva), illetve a töltőporton állva. A helyzetet magától felismeri.",
            listOf(
                start,
                Section("Fekve (kijelzővel lefelé)", listOf(
                    "Bal–jobb: ha nem vízszintes, a MAGASABB oldal ég (mint a buborék). Vízszintesnél a két oldalsó ív EGYSZERRE ég.",
                    "Előre–hátra: ugyanígy a kamera felőli rész vagy a vonal + pont; vízszintesnél mindkettő.",
                    "Polcok, asztalok, padló ellenőrzésére."
                )),
                Section("Hosszú élére állítva / fekvő tájolásban", listOf(
                    "Állítsd a telefont a hosszabbik oldalára, vagy tartsd fekvő tájolásban egy falhoz, lécre.",
                    "A magasabb vég ég: a kamerás vég (kamera körüli rész + ferde csík) vagy a töltőport vége (vonal + pont).",
                    "Vízszintesnél MINDKÉT vég egyszerre ég.",
                    "Képek, polcok, lécek felrakásához."
                )),
                Section("Töltőporton állva", listOf(
                    "Állítsd a telefont álló helyzetben a töltőportjára (vagy tartsd így).",
                    "A rövid oldal mentén mér: a magasabb oldal íve ég (bal vagy jobb); vízszintesnél mindkettő.",
                    "Keskeny felületekhez, párkányokhoz."
                )),
                Section("Mindegyiknél", listOf(
                    "A felső sáv mutatja az eltérést: LED-enként 0,5°. 1° alatt a sáv vége pislog (finomhangolás).",
                    "Teljesen vízszintes (0,5°-on belül): minden LED felvillan, és kicsit rezeg.",
                    "Magától kikapcsol, ha 5 percig nem mozdul; vagy a kártyával / csempével."
                )),
                Section("Kalibrálás", listOf(
                    "Helyzetenként külön kalibrálható. Tedd egy biztosan vízszintes felületre abban a helyzetben, és kopogj 2-t: ez lesz a nulla. 3 kopogás: törlés.",
                    "Kopogni fekve lehet; állított helyzetben a LED-szimuláció Érintés gombja (2× / 3×) ugyanígy működik."
                ))
            )
        )
        Feature.TIMER -> Page(
            "Időzítő: Pomodoro és más fókusz-időzítők a LED-eken, hogy ne kelljen a képernyőt nézned.",
            listOf(
                Section("Indítás", listOf(
                    "Állítsd be az Időzítő beállítása oldalon: fajta, percek, animáció.",
                    "Indítsd a kártyával, csempével vagy mozdulattal. A telefont fektesd le kijelzővel lefelé.",
                    "Felemelés nem állítja le; leállítás a kártyával, csempével vagy az értesítésből."
                )),
                Section("Fajták", TimerMode.entries.map { "${it.title}: ${it.desc}" }),
                Section("Animációk", TimerStyle.entries.map { "${it.title}: ${it.desc}" } + "Szünetekben mindig a lélegző gyűrű megy, a vonal mutatja az időt."),
                Section("Vezérlés kopogással", listOf(
                    "1 kopogás: 3 mp-re megmutatja a hátralévő időt (felső sáv) és hányadik szakasznál tartasz (vonal).",
                    "2 kopogás: szünet / folytatás (szünetben a szemek és a pont pislognak).",
                    "3 kopogás: ugrás a következő szakaszra."
                )),
                Section("Jelzések", listOf(
                    "Szakasz vége: rezgés és villogás.",
                    "Teljes kör vége: nagy ünneplés.",
                    "Az értesítésben mindig látod, mennyi van hátra."
                ))
            )
        )
        Feature.BLOW -> Page(
            "Fújós: fújj a telefon aljába, és a fény a töltőport felől felfelé száll a hátlapon – mintha belefújnál. Kilenc animáció, rekordokkal.",
            listOf(
                Section("Indítás", listOf(
                    "Koppints a kártyára (Játékok fül), a csempére vagy a widgetre: megnyílik a Fújós oldal, és a játék rögtön indul.",
                    "Az első alkalommal engedélyezd a mikrofont. A mikrofon csak a hangerőt méri, semmit nem rögzít és nem ment.",
                    "A mikrofon csak nyitott oldallal használható (az Android háttérből nem engedi), ezért a játék addig fut, amíg a Fújós oldal nyitva van; a képernyő közben nem alszik el."
                )),
                Section("Hogyan fújj", listOf(
                    "A mikrofon a telefon alján, a töltőport mellett van: oda fújj, kb. 5–15 cm-ről.",
                    "Az oldalon pontsor mutatja a fújás erejét; a hátlap képe élőben követi a LED-eket.",
                    "A beszédet és a koppanásokat kiszűri: a fújás „zúgó”, mély hangjára figyel. Az érzékenység állítható."
                )),
                Section("Animációk", BlowStyle.entries.map { "${it.title}: ${it.desc}" }),
                Section("Rekordok", listOf(
                    "A célba érős animációknál (Labda, Rakéta, Hőmérő, Gyertyák, Pitypang, Tábortűz) méri, hány mp alatt sikerült – a legjobb a listában látszik.",
                    "Siker: rezgés és villogás; a Rakétánál tűzijáték, a Gyertyáknál „kívánj valamit”."
                ))
            )
        )
        Feature.LECTURE -> Page(
            "Egyetemi előadás-időzítő: alapból 2 × 45 perc, köztük egy 15 perces szünet – a LED-ekről leolvasható, nem kell a telefont nézned. Minden beállítható: Előadás beállítása.",
            listOf(
                start,
                Section("Indítás: feltöltés", listOf(
                    "Fektesd le a telefont az asztalra, kijelzővel lefelé, majd indítsd el.",
                    "Alapból rázással töltöd: LED-ek gyulladnak a töltőport felől (a pont, a függőleges vonal), és minden rázással feljebb mennek az ívekre, a felső sávra és a kamerára. Beállítható: kopogással is tölthetsz, vagy „Azonnal” – akkor nincs töltés.",
                    "Ha mind a 33 LED ég, a felső sáv megtelik, és elindul az előadás.",
                    "A töltés erőssége állítható (kevesebb vagy több rázás kell). Ha 10 percig nem érkezik jel, magától leáll."
                )),
                Section("Az előadás (alapból 2 × 45 perc)", listOf(
                    "A felső sáv (16 kis LED) mutatja, mennyi van még hátra az egész előadásból: 2 × 45 percnél LED-enként kb. 5,6 perc, a sáv fele pontosan az első 45 perc.",
                    "A soron lévő (utolsó) LED pislog; amikor letelik, kialszik, és a következő veszi át.",
                    "Egy rész végén rezgés és háromszoros villogás jelzi – az előadás magától megy tovább a következő részre.",
                    "A részek száma (1–4) és hossza (5–180 perc) állítható."
                )),
                Section("Szünet", listOf(
                    "Alapból kétszeri rázással (kb. 3 mp-en belül) indul a szünet. Beállítható: 3× kopogás, vagy „Nincs”.",
                    "A függőleges vonal (a töltőport felőli 8 LED) mutatja, mennyi van még hátra: 15 percnél LED-enként kb. 1,9 perc, a soron lévő pislog.",
                    "A szünet alatt az előadás ideje áll, a felső sáv változatlanul mutatja a hátralévő időt.",
                    "A szünet végén rezgés és villogás jelez, és az előadás folytatódik ott, ahol abbamaradt (folytatás).",
                    "Ugyanazzal a paranccsal a szünetet előbb is befejezheted (kikapcsolható).",
                    "Alapból csak egy szünet indítható; bekapcsolható a „Több szünet”, és az „Automatikus szünet” is (a részek között magától indul)."
                )),
                Section("Vége", listOf(
                    "Ha letelt az előadás, minden LED villog és rezeg a telefon, aztán minden kikapcsol.",
                    "Az értesítésben mindig látod, hanyadik résznél tartasz és mennyi van hátra."
                )),
                Section("Tudnivalók", listOf(
                    "Leállítás: alapból a bekapcsoló gomb NEM állítja le (hogy megnézhesd az órát); a kártyával, csempével, widgetről, az értesítésből, vagy az Indítás és leállítás oldalon beállított paranccsal (bekapcsoló gomb, megfordítás) állíthatod le. A rázás, a kopogás és a felemelés itt nem választható (azok az indításra és a szünetre vannak fenntartva).",
                    "A LED-ek végig égnek, ezért ez a funkció többet fogyaszt – az Akku fülön látod, mennyit."
                ))
            )
        )
        Feature.BALANCE -> Page(
            "Egyensúly: döntéssel tartsd a fénypontot a felső sávon, miközben a szél lökdösi.",
            listOf(
                start,
                Section("Játékmenet", listOf(
                    "Tedd le kijelzővel lefelé, vagy tartsd vízszintesen a kezedben.",
                    "A felső sávon egy fénypont gurul, mint egy golyó egy deszkán: amerre lejt a telefon, arra gurul.",
                    "A szél lökdösi: ha a bal ívek égnek, balról fúj (jobbra tol), ha a jobbak, jobbról.",
                    "Ha a pont leesik a sáv végéről, elvész egy élet; a sáv szélén a pont pislogva figyelmeztet.",
                    "10 mp-enként egy LED gyullad a vonalon; ha mind a 8 ég (80 mp), nyertél.",
                    "Az idővel a szél erősödik."
                )),
                Section("Mit látsz", listOf(
                    "Életek: a kamera két fele és a ferde csík (3).",
                    "Eltelt idő: a függőleges vonal."
                ))
            )
        )
        Feature.DINO -> Page(
            "Dínófutás: a böngésző internet nélküli dínós játéka a hátlapon.",
            listOf(
                start,
                Section("Játékmenet", listOf(
                    "Kopogásos ugrásnál tedd le kijelzővel lefelé (rázással és gombokkal kézben is játszhatod). A felső sáv a pálya: a dínó a bal végén áll, jobbról akadályok jönnek.",
                    "Mivel ugorj: Dínófutás beállítása (Játékok fül) – kopogás, rázás, hangerő fel / le gomb, bekapcsoló gomb; több is bekapcsolható.",
                    "KAKTUSZ (folyamatosan égő fény): kopogj, és a dínó átugorja. Ugrás közben a dínó \"fent\" van: a sávból eltűnik, és a ferde csík + a kamera felső fele ég.",
                    "MADÁR (villogó fény, 8 pont után): NE ugorj – maradj a földön, átrepül fölötted. Ha ugrasz, nekimész.",
                    "A pálya egyre gyorsabb. 100 pontonként minden felvillan, mint az eredetiben.",
                    "Ütközésnél vége: a pontszám látszik – a vonal a tízeseket, a felső sáv az egyeseket mutatja."
                )),
                Section("Mit látsz", listOf(
                    "Dínó: a felső sáv 2. LED-je (ugráskor a ferde csík és a kamera teteje).",
                    "Futás: a pont ritmusosan pislog, mint a dínó lába.",
                    "Pontszám: 10 pontonként egy LED a függőleges vonalon."
                )),
                Section("Tipp", listOf("A kopogás fekve működik; a szimulációban az Érintés gomb ugrik."))
            )
        )
    }
}

class InfoActivity : Activity() {

    companion object {
        const val EXTRA_FEATURE = "feature"
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        darkWindow()
        val name = intent.getStringExtra(EXTRA_FEATURE)
        val f = Feature.entries.firstOrNull { it.name == name } ?: Feature.SIMON
        val page = FeatureInfo.page(f)

        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(15), 0, dp(15), dp(24))
        }
        val scroll = ScrollView(this).apply {
            setBackgroundColor(Ui.BG)
            isVerticalScrollBarEnabled = false
            addView(root, FrameLayout.LayoutParams(MATCH_PARENT, WRAP_CONTENT))
            padForSystemBars()
        }
        setContentView(scroll)

        val header = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
            setPadding(dp(7), dp(28), 0, dp(8))
        }
        header.addView(ImageView(this).apply {
            setImageResource(R.drawable.ic_back)
            setOnClickListener { finish() }
        }, LinearLayout.LayoutParams(dp(24), dp(24)))
        header.addView(text(f.title, 26f).apply { setPadding(dp(30), 0, 0, 0) })
        root.addView(header)

        root.addView(text(page.intro, 15f, Ui.TEXT).apply {
            setPadding(dp(7), dp(16), dp(7), dp(4))
            setLineSpacing(0f, 1.25f)
        })

        for (sec in page.sections) {
            root.addView(sectionTitle(sec.title))
            val card = LinearLayout(this).apply {
                orientation = LinearLayout.VERTICAL
                background = rounded(Ui.CARD, dp(22).toFloat())
                setPadding(dp(18), dp(14), dp(18), dp(14))
            }
            for (line in sec.lines) {
                card.addView(text("•  $line", 13.5f, Ui.SUB).apply {
                    setPadding(0, dp(5), 0, dp(5))
                    setLineSpacing(0f, 1.25f)
                })
            }
            root.addView(card)
        }

        // Gyors műveletek
        root.addView(sectionTitle("Gyors műveletek"))
        val startCard = FeatureCard(this, f.icon, if (f == Feature.PET) "Megnyitás" else "Indítás", f.title, false)
        startCard.setOnClickListener {
            if (f == Feature.PET) startActivity(Intent(this, PetActivity::class.java))
            else if (f == Feature.BLOW) startActivity(Intent(this, BlowActivity::class.java))
            else startForegroundService(Intent(this, SimonService::class.java).setAction(SimonService.actionFor(f)))
        }
        val gestureCard = FeatureCard(this, R.drawable.ic_gesture, "Indítás / leállítás",
            "Indul: ${Settings.trigger(this, f).title}\nLeáll: ${Settings.stopSummary(this, f)}", false)
        gestureCard.setOnClickListener {
            startActivity(Intent(this, GesturesActivity::class.java).putExtra(GesturesActivity.EXTRA_FEATURE, f.name))
        }
        root.addView(row(startCard, gestureCard, 140))
        val extra: FeatureCard? = when (f) {
            Feature.SAFE -> FeatureCard(this, R.drawable.ic_settings, "Széf beállítása", "Kód és titkos cél", false).apply {
                setOnClickListener { startActivity(Intent(this@InfoActivity, SafeActivity::class.java)) }
            }
            Feature.TIMER -> FeatureCard(this, R.drawable.ic_settings, "Időzítő beállítása", "Fajta, percek, animáció", false).apply {
                setOnClickListener { startActivity(Intent(this@InfoActivity, TimerActivity::class.java)) }
            }
            Feature.DINO -> FeatureCard(this, R.drawable.ic_settings, "Dínófutás beállítása", "Mivel ugorjon: kopogás, rázás, gombok", false).apply {
                setOnClickListener { startActivity(Intent(this@InfoActivity, DinoActivity::class.java)) }
            }
            Feature.BLOW -> FeatureCard(this, R.drawable.ic_wind, "Fújós oldal", "Animáció, érzékenység, rekordok", false).apply {
                setOnClickListener { startActivity(Intent(this@InfoActivity, BlowActivity::class.java)) }
            }
            Feature.LECTURE -> FeatureCard(this, R.drawable.ic_settings, "Előadás beállítása", "Részek, szünet, indítás, parancsok", false).apply {
                setOnClickListener { startActivity(Intent(this@InfoActivity, LectureActivity::class.java)) }
            }
            else -> null
        }
        if (extra != null) root.addView(row(extra, null, 140))
    }

    override fun onResume() {
        super.onResume()
        GlyphMirror.appVisible = true
    }

    override fun onPause() {
        super.onPause()
        GlyphMirror.appVisible = false
    }
}
