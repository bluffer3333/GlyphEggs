package com.akos.glypheggs

import android.os.SystemClock
import com.nothing.ketchum.Glyph
import kotlinx.coroutines.delay
import kotlin.math.abs
import kotlin.math.min
import kotlin.math.roundToInt
import kotlin.random.Random

/**
 * Egyensúly – ügyességi játék döntéssel.
 *
 *  - A felső sávon (C1) egy fénypont van. A telefon döntésével gurítod jobbra-balra,
 *    mint egy golyót egy deszkán.
 *  - "Szél" lökdösi a pontot. Hogy merről fúj, azt az oldalsó ívek mutatják:
 *    bal (C2, C3) vagy jobb (C5, C6) – ellen kell dönteni.
 *  - Ha a pont leesik a sáv valamelyik végéről, elvész egy élet (A1, A2, B1).
 *  - 10 mp-enként egy LED gyullad a D1 vonalon; ha mind a 8 ég (80 mp), nyertél.
 *  - Az idő múlásával a szél egyre erősebb és szeszélyesebb.
 */
class BalanceGame(
    private val glyph: GlyphController,
    private val motion: MotionDetector,
    private val haptics: Haptics
) {
    private val bar: IntArray = IntArray(16) { Zones.LEVEL[15 - it] } // 0 = bal vége, 15 = jobb vége
    private val lifeZones = intArrayOf(Glyph.Code_22111.A1, Glyph.Code_22111.A2, Glyph.Code_22111.B1)
    private val dLine = intArrayOf(
        Glyph.Code_22111.D1_1, Glyph.Code_22111.D1_2, Glyph.Code_22111.D1_3, Glyph.Code_22111.D1_4,
        Glyph.Code_22111.D1_5, Glyph.Code_22111.D1_6, Glyph.Code_22111.D1_7, Glyph.Code_22111.D1_8
    )
    private val windLeft = intArrayOf(Glyph.Code_22111.C2, Glyph.Code_22111.C3)
    private val windRight = intArrayOf(Glyph.Code_22111.C5, Glyph.Code_22111.C6)

    /** Visszaadja, hány másodpercig bírta. */
    suspend fun run(): Int {
        intro()
        var lives = Config.BALANCE_LIVES
        var pos = 7.5f
        var vel = 0f
        var wind = 0f
        var nextGust = 0L
        val start = SystemClock.elapsedRealtime()
        var last = start
        var paused = 0L
        var frame = 0

        while (true) {
            val now = SystemClock.elapsedRealtime()
            val dt = ((now - last) / 1000f).coerceIn(0.005f, 0.1f)
            last = now
            val played = now - start - paused
            val secs = (played / 1000).toInt()
            val leds = (secs / Config.BALANCE_SECONDS_PER_LED).coerceAtMost(8)
            if (leds >= 8) {
                win()
                return secs
            }

            // Szél: időnként új irány és erő; az idővel erősödik
            if (now >= nextGust) {
                val strength = min(
                    Config.BALANCE_WIND_MAX,
                    Config.BALANCE_WIND_START + secs * (Config.BALANCE_WIND_MAX - Config.BALANCE_WIND_START) / 80f
                )
                wind = (if (Random.nextBoolean()) 1f else -1f) * strength * (0.5f + Random.nextFloat() * 0.5f)
                nextGust = now + 1_500L + Random.nextLong(2_500L)
            }

            // Döntés: a jobb oldal lejjebb → a gravitáció x-e pozitív → jobbra gurul
            var tilt = motion.gravity()[0]
            if (Config.INVERT_X) tilt = -tilt
            val acc = tilt * Config.BALANCE_TILT_FORCE + wind
            vel = (vel + acc * dt) * 0.985f
            pos += vel * dt

            if (pos < -0.5f || pos > 15.5f) {
                lives--
                haptics.tick()
                DebugState.log("Leesett! Életek: $lives")
                val fallStart = SystemClock.elapsedRealtime()
                repeat(3) {
                    glyph.show(bar + dLine.take(leds))
                    delay(90)
                    glyph.off()
                    delay(90)
                }
                if (lives <= 0) {
                    lose(leds)
                    return secs
                }
                pos = 7.5f
                vel = 0f
                delay(600)
                paused += SystemClock.elapsedRealtime() - fallStart
                last = SystemClock.elapsedRealtime()
                continue
            }

            val idx = pos.roundToInt().coerceIn(0, 15)
            val lit = mutableListOf(bar[idx])
            // Vészjelzés: a sáv szélén a pont pislog
            if ((idx <= 1 || idx >= 14) && frame % 4 < 2) lit.clear()
            lit += lifeZones.take(lives)
            lit += dLine.take(leds)
            if (abs(wind) > 0.5f) lit += (if (wind < 0) windLeft else windRight).toList()
            glyph.show(lit.toIntArray())

            frame++
            delay(30)
        }
    }

    private suspend fun intro() {
        for (k in 0..7) {
            glyph.show(intArrayOf(bar[7 - k], bar[8 + k]) + lifeZones)
            delay(40)
        }
        glyph.show(intArrayOf(bar[7], bar[8]) + lifeZones)
        delay(700)
    }

    private suspend fun win() {
        DebugState.log("Egyensúly: 80 mp – nyertél!")
        haptics.win()
        repeat(10) {
            glyph.show(Zones.ALL)
            delay(130)
            glyph.off()
            delay(90)
        }
    }

    private suspend fun lose(leds: Int) {
        repeat(3) {
            glyph.show(Zones.ALL)
            delay(150)
            glyph.off()
            delay(150)
        }
        glyph.show(dLine.take(leds).toIntArray())
        delay(2500)
        glyph.off()
    }
}
