package com.akos.glypheggs

import android.app.Activity
import android.app.AlertDialog
import android.content.Intent
import android.content.pm.PackageManager
import android.net.Uri
import android.os.Bundle
import android.text.InputType
import android.view.Gravity
import android.view.ViewGroup.LayoutParams.MATCH_PARENT
import android.view.ViewGroup.LayoutParams.WRAP_CONTENT
import android.widget.EditText
import android.widget.FrameLayout
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView

/**
 * A széf beállítása: a 4 jegyű LED-kód, a kiválasztás módja (rázás / kopogás),
 * és hogy mi nyíljon meg helyes kódnál.
 */
class SafeActivity : Activity() {

    companion object {
        private const val REQ_FOLDER = 41
    }

    private val code = IntArray(SafePositions.CODE_LENGTH)
    private val slotMaps = mutableListOf<GlyphMapView>()
    private val slotLabels = mutableListOf<TextView>()
    private lateinit var shakePill: TextView
    private lateinit var knockPill: TextView
    private lateinit var targetList: LinearLayout
    private lateinit var overlayCard: FeatureCard

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        darkWindow()
        Settings.safeCode(this).copyInto(code)

        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(15), 0, dp(15), dp(24))
        }
        val scroll = ScrollView(this).apply {
            setBackgroundColor(Ui.BG)
            isVerticalScrollBarEnabled = false
            addView(root, FrameLayout.LayoutParams(MATCH_PARENT, WRAP_CONTENT))
            padForSystemBars()
        }
        setContentView(scroll)

        val header = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
            setPadding(dp(7), dp(28), 0, dp(8))
        }
        header.addView(ImageView(this).apply {
            setImageResource(R.drawable.ic_back)
            setOnClickListener { finish() }
        }, LinearLayout.LayoutParams(dp(24), dp(24)))
        header.addView(text("Széf", 26f).apply { setPadding(dp(30), 0, 0, 0) })
        root.addView(header)

        root.addView(text(
            "Indításkor a hátlap 8 része véletlen sorrendben egyenként felvillan. Amikor a kódod következő " +
                "része világít, rázd meg a telefont (vagy kopogj). 4 jó választás után a széf kinyílik.",
            13f, Ui.SUB
        ).apply { setPadding(dp(7), dp(14), dp(7), dp(6)); setLineSpacing(0f, 1.2f) })

        // --- Kód ---
        root.addView(sectionTitle("Kód (koppints egy mezőre a váltáshoz)"))
        val slots = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
        for (i in 0 until SafePositions.CODE_LENGTH) {
            val box = LinearLayout(this).apply {
                orientation = LinearLayout.VERTICAL
                gravity = Gravity.CENTER_HORIZONTAL
                background = rounded(Ui.CARD, dp(18).toFloat())
                setPadding(dp(4), dp(10), dp(4), dp(10))
                setOnClickListener {
                    code[i] = (code[i] + 1) % 8
                    Settings.setSafeCode(this@SafeActivity, code)
                    renderCode()
                }
            }
            box.addView(text("${i + 1}.", 12f, Ui.SUB))
            val map = GlyphMapView(this).apply { unlitColor = 0xFF444444.toInt() }
            slotMaps += map
            box.addView(map, LinearLayout.LayoutParams(MATCH_PARENT, dp(96)))
            val label = text("", 12f, Ui.TEXT).apply { gravity = Gravity.CENTER }
            slotLabels += label
            box.addView(label, LinearLayout.LayoutParams(MATCH_PARENT, WRAP_CONTENT))
            slots.addView(box, LinearLayout.LayoutParams(0, WRAP_CONTENT, 1f).apply {
                marginStart = dp(2.5f)
                marginEnd = dp(2.5f)
            })
        }
        root.addView(slots)

        // --- Kiválasztás módja ---
        root.addView(sectionTitle("Kiválasztás"))
        val modeRow = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
        shakePill = pill("Rázás") { Settings.setSafeUsesShake(this, true); renderMode() }
        knockPill = pill("Kopogás") { Settings.setSafeUsesShake(this, false); renderMode() }
        modeRow.addView(shakePill, LinearLayout.LayoutParams(0, dp(44), 1f).apply { marginEnd = dp(5) })
        modeRow.addView(knockPill, LinearLayout.LayoutParams(0, dp(44), 1f))
        root.addView(modeRow)

        // --- Mi nyíljon meg ---
        root.addView(sectionTitle("Mi nyíljon meg helyes kódnál"))
        targetList = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        root.addView(targetList)

        // --- Azonnali megnyitás ---
        root.addView(sectionTitle("Azonnali megnyitás"))
        overlayCard = FeatureCard(this, R.drawable.ic_bolt, "Megnyitás azonnal",
            "", true)
        val openOverlay = {
            startActivity(Intent(android.provider.Settings.ACTION_MANAGE_OVERLAY_PERMISSION, Uri.parse("package:$packageName")))
        }
        overlayCard.setOnClickListener { openOverlay() }
        overlayCard.toggle?.onChange = { openOverlay() }
        root.addView(row(overlayCard, null, 150).apply {
            // Teljes szélesség
            removeAllViews()
            addView(overlayCard, LinearLayout.LayoutParams(MATCH_PARENT, dp(150)))
        })

        // --- Kipróbálás ---
        root.addView(sectionTitle("Kipróbálás"))
        val tryCard = FeatureCard(this, R.drawable.ic_safe, "Széf indítása", "A LED-ek villogni kezdenek", false)
        tryCard.setOnClickListener {
            startForegroundService(Intent(this, SimonService::class.java).setAction(SimonService.ACTION_SAFE))
        }
        val gestureCard = FeatureCard(this, R.drawable.ic_gesture, "Indító mozdulat",
            Settings.trigger(this, Feature.SAFE).title, false)
        gestureCard.setOnClickListener {
            startActivity(Intent(this, GesturesActivity::class.java).putExtra(GesturesActivity.EXTRA_FEATURE, Feature.SAFE.name))
        }
        root.addView(row(tryCard, gestureCard, 150))

        renderCode()
        renderMode()
    }

    override fun onResume() {
        super.onResume()
        GlyphMirror.appVisible = true
        renderTargets()
        val ok = android.provider.Settings.canDrawOverlays(this)
        overlayCard.toggle?.checked = ok
        overlayCard.subtitleView.text = if (ok) "Bekapcsolva: a széf rögtön megnyitja a célt"
        else "Ki: egy értesítésre kell koppintani (engedély kell hozzá)"
    }

    override fun onPause() {
        super.onPause()
        GlyphMirror.appVisible = false
    }

    private fun pill(label: String, onClick: () -> Unit): TextView = text(label, 14f).apply {
        gravity = Gravity.CENTER
        setOnClickListener { onClick() }
    }

    private fun renderCode() {
        for (i in 0 until SafePositions.CODE_LENGTH) {
            slotMaps[i].lit = SafePositions.zones(code[i]).toSet()
            slotLabels[i].text = SafePositions.names[code[i]]
        }
    }

    private fun renderMode() {
        val shake = Settings.safeUsesShake(this)
        for ((pill, sel) in listOf(shakePill to shake, knockPill to !shake)) {
            pill.background = rounded(if (sel) Ui.LIGHT else Ui.CARD, dp(22).toFloat())
            pill.setTextColor(if (sel) Ui.DARK_TEXT else Ui.TEXT)
        }
    }

    private fun renderTargets() {
        targetList.removeAllViews()
        val type = Settings.safeTargetType(this)
        val label = Settings.safeTargetLabel(this)
        val options = listOf(
            Triple("NOTES", "Titkos jegyzetek", "Beépített, csak a széffel nyitható"),
            Triple("FOLDER", "Mappa", if (type == "FOLDER" && label.isNotEmpty()) label else "Válassz egy mappát a telefonon"),
            Triple("APP", "Alkalmazás", if (type == "APP" && label.isNotEmpty()) label else "Válassz egy appot"),
            Triple("URL", "Weboldal", if (type == "URL" && label.isNotEmpty()) label else "Adj meg egy címet"),
            Triple("NONE", "Semmi", "Csak a fényshow és a rezgés")
        )
        for ((key, title, sub) in options) {
            val row = LinearLayout(this).apply {
                orientation = LinearLayout.HORIZONTAL
                gravity = Gravity.CENTER_VERTICAL
                background = rounded(Ui.CARD, dp(20).toFloat())
                setPadding(dp(18), dp(16), dp(16), dp(16))
                setOnClickListener { chooseTarget(key) }
            }
            val texts = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
            texts.addView(text(title, 17f))
            texts.addView(text(sub, 12.5f, Ui.SUB).apply { setPadding(0, dp(2), 0, 0) })
            row.addView(texts, LinearLayout.LayoutParams(0, WRAP_CONTENT, 1f))
            row.addView(RadioMark(this, key == type), LinearLayout.LayoutParams(dp(26), dp(26)).apply { marginStart = dp(12) })
            targetList.addView(row, LinearLayout.LayoutParams(MATCH_PARENT, WRAP_CONTENT).apply { bottomMargin = dp(5) })
        }
    }

    private fun dialog() = AlertDialog.Builder(this, android.R.style.Theme_DeviceDefault_Dialog_Alert)

    private fun chooseTarget(key: String) {
        when (key) {
            "NOTES" -> { Settings.setSafeTarget(this, "NOTES", "", "Titkos jegyzetek"); renderTargets() }
            "NONE" -> { Settings.setSafeTarget(this, "NONE", "", ""); renderTargets() }
            "FOLDER" -> startActivityForResult(Intent(Intent.ACTION_OPEN_DOCUMENT_TREE), REQ_FOLDER)
            "URL" -> {
                val input = EditText(this).apply {
                    inputType = InputType.TYPE_CLASS_TEXT or InputType.TYPE_TEXT_VARIATION_URI
                    hint = "pl. youtube.com"
                    if (Settings.safeTargetType(this@SafeActivity) == "URL") setText(Settings.safeTargetValue(this@SafeActivity))
                }
                dialog().setTitle("Weboldal címe")
                    .setView(input)
                    .setPositiveButton("Mentés") { _, _ ->
                        val v = input.text.toString().trim()
                        if (v.isNotEmpty()) Settings.setSafeTarget(this, "URL", v, v)
                        renderTargets()
                    }
                    .setNegativeButton("Mégse", null)
                    .show()
            }
            "APP" -> {
                val launcher = Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_LAUNCHER)
                val apps = packageManager.queryIntentActivities(launcher, PackageManager.MATCH_ALL)
                    .map { it.loadLabel(packageManager).toString() to it.activityInfo.packageName }
                    .filter { it.second != packageName }
                    .distinctBy { it.second }
                    .sortedBy { it.first.lowercase() }
                dialog().setTitle("Melyik app nyíljon meg?")
                    .setItems(apps.map { it.first }.toTypedArray()) { _, which ->
                        val (label, pkg) = apps[which]
                        Settings.setSafeTarget(this, "APP", pkg, label)
                        renderTargets()
                    }
                    .setNegativeButton("Mégse", null)
                    .show()
            }
        }
    }

    @Deprecated("Deprecated in Java")
    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        if (requestCode != REQ_FOLDER || resultCode != RESULT_OK) return
        val uri = data?.data ?: return
        try {
            contentResolver.takePersistableUriPermission(uri, Intent.FLAG_GRANT_READ_URI_PERMISSION)
        } catch (t: Throwable) {
            DebugState.log("Mappa engedély hiba: ${t.javaClass.simpleName}")
        }
        val name = Uri.decode(uri.lastPathSegment ?: "Mappa").substringAfterLast(':').ifEmpty { "Mappa" }
        Settings.setSafeTarget(this, "FOLDER", uri.toString(), name)
        renderTargets()
    }
}
