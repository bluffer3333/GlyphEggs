package com.akos.glypheggs

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.content.Context
import android.content.Intent
import android.media.AudioFormat
import android.media.AudioRecord
import android.media.MediaRecorder
import android.os.SystemClock
import com.nothing.ketchum.Glyph
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.MutableStateFlow
import kotlin.math.ceil
import kotlin.math.log10
import kotlin.math.max
import kotlin.math.roundToInt
import kotlin.math.sqrt
import kotlin.random.Random

/** A Fújós játék animációi (a Fújós oldalon választható). */
enum class BlowStyle(val title: String, val desc: String, val timed: Boolean) {
    BALL("Labda", "Egy LED a töltőport felől: fújd felfelé végig a kamera tetejéig – ha abbahagyod, visszaesik", true),
    ROCKET("Rakéta", "Mint a labda, de csak erős fújásra indul, csóvát húz, és a tetején tűzijáték", true),
    THERMO("Hőmérő", "Alulról felfelé telik, amíg fújsz; ha abbahagyod, lassan apad. Töltsd meg egészen a tetejéig", true),
    CANDLES("Szülinapi gyertyák", "Minden LED pislákoló gyertyaláng: fújd el mindet egy lendülettel! Ha sokáig vársz, újra meggyulladnak", true),
    BALLOON("Lufi", "Fújással felfújod: a fény a vonalról az egész gyűrűre terjed. Ha túl sokáig fújod – DURR!", false),
    PINWHEEL("Szélkerék", "Három fénylapát forog a gyűrűn – minél erősebben fújsz, annál gyorsabban; tartsd csúcssebességen", false),
    BUBBLES("Buborékok", "Fújásra buborékok indulnak a töltőport felől és szállnak fel – minél erősebben, annál több", false),
    DANDELION("Pitypang", "Minden LED egy pitypangmag: fújásra leválnak, és felszállnak a kamera felé. Fújd le mindet!", true),
    FIRE("Tábortűz", "Alul parázs izzik; fújással feléleszted, a láng lobogva felcsap. Ha abbahagyod, gyorsan visszaesik – érd el vele a kamerát!", true)
}

/**
 * A fújás erőssége (0 = nincs, 1 = teljes erő). A [BlowRecorder] írja (a Fújós oldal mikrofonjából),
 * a [BlowGame] olvassa. Az [active] jelzi, hogy fut-e a mikrofon (azaz nyitva van-e a Fújós oldal).
 */
object BlowInput {
    val level = MutableStateFlow(0f)
    @Volatile var active = false
    @Volatile var lastUpdate = 0L
}

/**
 * Fújásérzékelés a mikrofonból. A fújás a mikrofonba hangos, „zúgó” zaj, sok mély összetevővel;
 * így a hangerőből (dBFS) és a mély rész arányából ismeri fel, és szűri ki a beszédet.
 * Semmit nem rögzít és nem ment: csak a hangerőt számolja.
 */
class BlowRecorder(private val context: Context) {
    private var thread: Thread? = null
    @Volatile private var running = false

    fun start(): Boolean {
        if (running) return true
        val rate = 16_000
        val minBuf = AudioRecord.getMinBufferSize(rate, AudioFormat.CHANNEL_IN_MONO, AudioFormat.ENCODING_PCM_16BIT)
        val rec = try {
            AudioRecord(MediaRecorder.AudioSource.MIC, rate, AudioFormat.CHANNEL_IN_MONO, AudioFormat.ENCODING_PCM_16BIT, max(minBuf, 4096))
        } catch (t: Throwable) {
            DebugState.log("Mikrofon nem érhető el: ${t.javaClass.simpleName}")
            return false
        }
        if (rec.state != AudioRecord.STATE_INITIALIZED) {
            DebugState.log("Mikrofon nem indult (engedély?)")
            rec.release()
            return false
        }
        running = true
        BlowInput.active = true
        thread = Thread {
            val buf = ShortArray(512) // 32 ms
            var low = 0f
            var smooth = 0f
            var loudSince = 0L
            try {
                rec.startRecording()
                while (running) {
                    val n = rec.read(buf, 0, buf.size)
                    if (n <= 0) continue
                    var sum = 0.0
                    var sumLow = 0.0
                    for (i in 0 until n) {
                        val x = buf[i] / 32768f
                        low += 0.09f * (x - low) // ≈ 250 Hz-es aluláteresztő
                        sum += x * x
                        sumLow += low * low
                    }
                    val rms = sqrt(sum / n).toFloat()
                    val rmsLow = sqrt(sumLow / n).toFloat()
                    val db = if (rms > 1e-6f) 20f * log10(rms) else -120f
                    val ratio = if (rms > 1e-6f) rmsLow / rms else 0f
                    val thr = Config.BLOW_THRESHOLD_DB[Settings.blowSensitivity(context)]
                    val now = SystemClock.elapsedRealtime()
                    val loud = db > thr && ratio > Config.BLOW_LOW_RATIO
                    if (loud) { if (loudSince == 0L) loudSince = now } else loudSince = 0L
                    // Legalább ~100 ms folyamatos zúgás kell (egy koppanás vagy egy szó eleje nem számít)
                    val target = if (loud && now - loudSince >= 100) ((db - thr) / Config.BLOW_RANGE_DB).coerceIn(0.15f, 1f) else 0f
                    // Gyors felfutás, lassabb lecsengés
                    smooth += (target - smooth) * (if (target > smooth) 0.6f else 0.25f)
                    if (smooth < 0.02f) smooth = 0f
                    BlowInput.level.value = smooth
                    BlowInput.lastUpdate = now
                }
            } catch (t: Throwable) {
                DebugState.log("Mikrofon hiba: ${t.javaClass.simpleName}")
            } finally {
                try { rec.stop() } catch (t: Throwable) { }
                rec.release()
                BlowInput.level.value = 0f
                BlowInput.active = false
            }
        }.apply { name = "glyph-blow"; start() }
        return true
    }

    fun stop() {
        running = false
        thread = null
        BlowInput.active = false
        BlowInput.level.value = 0f
    }
}

/** A Fújós oldal megnyitása a szolgáltatásból (mozdulatra / csempéről): ha lehet, közvetlenül, különben értesítésből. */
object BlowLauncher {
    private const val CHANNEL = "glyph_eggs_blow"

    fun open(context: Context) {
        val intent = Intent(context, BlowActivity::class.java).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
        if (GlyphMirror.appVisible || android.provider.Settings.canDrawOverlays(context)) {
            try {
                context.startActivity(intent)
                return
            } catch (t: Throwable) {
                DebugState.log("A Fújós oldal nem nyílt meg közvetlenül: ${t.javaClass.simpleName}")
            }
        }
        val nm = context.getSystemService(NotificationManager::class.java)
        nm.createNotificationChannel(NotificationChannel(CHANNEL, "Fújós játék", NotificationManager.IMPORTANCE_HIGH))
        val pi = PendingIntent.getActivity(context, 77, intent, PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT)
        nm.notify(
            77,
            Notification.Builder(context, CHANNEL)
                .setSmallIcon(R.drawable.ic_wind)
                .setContentTitle("Fújós")
                .setContentText("Koppints, és fújj a telefon aljába!")
                .setContentIntent(pi)
                .setAutoCancel(true)
                .build()
        )
    }
}

/**
 * A Fújós játék a LED-eken. A fújás erősségét a [BlowInput]-ból olvassa, az animációt a
 * beállításból ([Settings.blowStyle]) – az oldalon futás közben is váltható.
 */
class BlowGame(
    private val context: Context,
    private val glyph: GlyphController,
    private val haptics: Haptics,
    private val onStatus: (String) -> Unit
) {
    companion object {
        /** Az út a töltőporttól a kamera tetejéig: E1 → függőleges vonal → jobb oldali ív → felső sáv → bal felső ív → ferde csík → kamera. */
        val PATH: IntArray = (
            listOf(Glyph.Code_22111.E1) +
                listOf(
                    Glyph.Code_22111.D1_1, Glyph.Code_22111.D1_2, Glyph.Code_22111.D1_3, Glyph.Code_22111.D1_4,
                    Glyph.Code_22111.D1_5, Glyph.Code_22111.D1_6, Glyph.Code_22111.D1_7, Glyph.Code_22111.D1_8
                ) +
                listOf(Glyph.Code_22111.C5, Glyph.Code_22111.C6) +
                Zones.LEVEL.toList() +
                listOf(Glyph.Code_22111.C2, Glyph.Code_22111.B1, Glyph.Code_22111.A2, Glyph.Code_22111.A1)
            ).toIntArray()

        /** A gyűrű körbe (szélkerékhez): bal felső ív, felső sáv, jobb oldal, alul, bal oldal. */
        private val RING: IntArray = (
            listOf(Glyph.Code_22111.C2) + Zones.LEVEL.reversed() +
                listOf(Glyph.Code_22111.C6, Glyph.Code_22111.C5, Glyph.Code_22111.C4, Glyph.Code_22111.C3)
            ).toIntArray()

        /** A lufi rétegei belülről kifelé. */
        private val BALLOON: List<IntArray> = listOf(
            intArrayOf(Glyph.Code_22111.E1),
            intArrayOf(Glyph.Code_22111.D1_1, Glyph.Code_22111.D1_2),
            intArrayOf(Glyph.Code_22111.D1_3, Glyph.Code_22111.D1_4, Glyph.Code_22111.D1_5),
            intArrayOf(Glyph.Code_22111.D1_6, Glyph.Code_22111.D1_7, Glyph.Code_22111.D1_8),
            intArrayOf(Glyph.Code_22111.C4, Glyph.Code_22111.C5),
            intArrayOf(Glyph.Code_22111.C3, Glyph.Code_22111.C6),
            intArrayOf(Glyph.Code_22111.C2) + Zones.LEVEL.copyOfRange(0, 8),
            Zones.LEVEL.copyOfRange(8, 16),
            intArrayOf(Glyph.Code_22111.B1),
            intArrayOf(Glyph.Code_22111.A2, Glyph.Code_22111.A1)
        )

        /** A gyertyák kioltásának sorrendje: felülről (kamera) lefelé. */
        private val CANDLES_TOP_DOWN: IntArray = LectureTimer.FILL_ORDER.reversedArray()
    }

    private val rnd = Random(SystemClock.elapsedRealtime())

    // Állapot (stílusváltáskor nullázódik)
    private var style = Settings.blowStyle(context)
    private var pos = 0f
    private var vel = 0f
    private var amount = 0f
    private var quietMs = 0L
    private var roundStart = 0L
    private var overMs = 0L
    private var peakMs = 0L
    private val bubbles = mutableListOf<FloatArray>() // [pozíció, sebesség]
    private var bubbleAcc = 0f
    private var angle = 0f
    private var spin = 0f
    /** Pitypang: a még fent lévő magok (véletlen sorrendben fogynak). */
    private val seeds = mutableListOf<Int>()
    /** A lufi kidurrant: a következő képkockánál lejátssza a durranást. */
    private var popPending = false

    private fun reset() {
        pos = 0f; vel = 0f; amount = 0f; quietMs = 0L; roundStart = 0L; overMs = 0L; peakMs = 0L
        bubbles.clear(); bubbleAcc = 0f; angle = 0f; spin = 0f
        seeds.clear(); seeds += PATH.toList().shuffled(rnd)
        if (style == BlowStyle.CANDLES) amount = 0f
    }

    suspend fun run() {
        DebugState.log("Fújós indul: ${style.title}")
        // Intro: egy fénypont végigfut az úton
        for (z in PATH) { glyph.show(intArrayOf(z)); delay(18) }
        glyph.off()
        reset()
        var last = SystemClock.elapsedRealtime()
        var lastStatus = 0L
        while (true) {
            val now = SystemClock.elapsedRealtime()
            val dtMs = (now - last).coerceIn(1, 100)
            last = now
            val dt = dtMs / 1000f

            // Ha a Fújós oldal bezárult (nincs mikrofon), leáll
            if (!BlowInput.active && now - BlowInput.lastUpdate > Config.BLOW_IDLE_MS) {
                DebugState.log("Fújós: a mikrofon leállt – vége")
                break
            }
            val s = Settings.blowStyle(context)
            if (s != style) { style = s; reset(); DebugState.log("Fújós: ${s.title}") }
            val lv = BlowInput.level.value
            if (lv > 0.05f && roundStart == 0L) roundStart = now

            val (lit, won) = step(lv, dt, dtMs, now)
            glyph.show(lit)
            if (popPending) {
                popPending = false
                pop()
                last = SystemClock.elapsedRealtime()
                continue
            }

            if (won) {
                val ms = if (roundStart > 0) now - roundStart else 0L
                win(ms)
                reset()
                last = SystemClock.elapsedRealtime()
                continue
            }
            if (now - lastStatus > 1_000) {
                lastStatus = now
                onStatus("Fújós · ${style.title} · erő: ${(lv * 100).roundToInt()}%")
            }
            delay(30)
        }
        glyph.off()
    }

    /** Egy képkocka: mi égjen, és megnyerte-e a kört. */
    private fun step(lv: Float, dt: Float, dtMs: Long, now: Long): Pair<IntArray, Boolean> {
        val top = (PATH.size - 1).toFloat()
        return when (style) {
            BlowStyle.BALL -> {
                vel += (lv * 70f - 28f) * dt
                vel *= 0.985f
                pos += vel * dt
                if (pos <= 0f) { pos = 0f; if (vel < 0) vel = 0f }
                val i = pos.roundToInt().coerceIn(0, PATH.size - 1)
                intArrayOf(PATH[i]) to (pos >= top)
            }
            BlowStyle.ROCKET -> {
                val thrust = if (lv > 0.3f) lv * 85f else 0f
                vel += (thrust - 30f) * dt
                vel *= 0.985f
                pos += vel * dt
                if (pos <= 0f) { pos = 0f; if (vel < 0) vel = 0f }
                val i = pos.roundToInt().coerceIn(0, PATH.size - 1)
                val lit = mutableListOf(PATH[i])
                if (vel > 4f) { if (i - 1 >= 0) lit += PATH[i - 1]; if (vel > 10f && i - 2 >= 0) lit += PATH[i - 2] }
                // Gyújtás előtt a „hajtómű” pislog
                if (i == 0 && lv in 0.05f..0.3f && (now / 120) % 2 == 0L) lit += PATH[1]
                lit.toIntArray() to (pos >= top)
            }
            BlowStyle.THERMO -> {
                amount += (lv * 14f - 4f) * dt
                amount = amount.coerceIn(0f, PATH.size.toFloat())
                val n = ceil(amount).toInt().coerceIn(0, PATH.size)
                val lit = PATH.take(n).toMutableList()
                if (n == 0 && (now / 600) % 2 == 0L) lit += PATH[0]
                lit.toIntArray() to (amount >= PATH.size)
            }
            BlowStyle.CANDLES -> {
                // amount = hány gyertya aludt el (felülről)
                if (lv > 0.15f) { amount += lv * 9f * dt; quietMs = 0L }
                else { quietMs += dtMs; if (quietMs > 2_000) amount -= 3f * dt }
                amount = amount.coerceIn(0f, CANDLES_TOP_DOWN.size.toFloat())
                val out = amount.toInt()
                val lit = CANDLES_TOP_DOWN.drop(out).filter { rnd.nextFloat() > 0.04f + lv * 0.25f } // pislákolás, fújásra jobban
                lit.toIntArray() to (out >= CANDLES_TOP_DOWN.size)
            }
            BlowStyle.BALLOON -> {
                amount += (lv * 0.55f - 0.06f) * dt
                amount = amount.coerceAtLeast(0f)
                if (amount > 1f && lv > 0.1f) overMs += dtMs else overMs = (overMs - dtMs).coerceAtLeast(0L)
                val layers = (amount * BALLOON.size).toInt().coerceIn(0, BALLOON.size)
                val lit = BALLOON.take(layers).flatMap { it.toList() }.toMutableList()
                // Feszül: a külső réteg vibrál
                if (amount > 0.85f && (now / 90) % 2 == 0L && layers > 0) lit.removeAll(BALLOON[layers - 1].toList())
                if (overMs > 900) {
                    popPending = true
                    amount = 0f; overMs = 0L
                }
                lit.toIntArray() to false
            }
            BlowStyle.PINWHEEL -> {
                spin += (lv * 45f - spin * 0.7f) * dt
                angle = (angle + spin * dt) % RING.size
                val n = RING.size
                val a = angle.toInt()
                val lit = listOf(a, a + n / 3, a + 2 * n / 3).flatMap { listOf(RING[it % n], RING[(it + 1) % n]) }.toMutableList()
                if (spin > 0.5f) lit += Glyph.Code_22111.E1
                if (spin > 28f) peakMs += dtMs else peakMs = 0L
                val won = peakMs > 3_000
                if (won) peakMs = 0L
                lit.toIntArray() to won
            }
            BlowStyle.BUBBLES -> {
                bubbleAcc += lv * 10f * dt
                while (bubbleAcc >= 1f) { bubbleAcc -= 1f; bubbles += floatArrayOf(0f, 7f + rnd.nextFloat() * 12f) }
                val it = bubbles.iterator()
                val lit = mutableSetOf<Int>()
                while (it.hasNext()) {
                    val b = it.next()
                    b[0] += b[1] * dt
                    if (b[0] > top) it.remove() else lit += PATH[b[0].toInt()]
                }
                if (lit.isEmpty() && (now / 700) % 2 == 0L) lit += PATH[0]
                lit.toIntArray() to false
            }
            BlowStyle.DANDELION -> {
                // Fújásra magok válnak le (erősebben több), és repülő pontként szállnak felfelé
                bubbleAcc += lv * lv * 14f * dt
                while (bubbleAcc >= 1f && seeds.isNotEmpty()) {
                    bubbleAcc -= 1f
                    val z = seeds.removeAt(seeds.lastIndex)
                    val start = PATH.indexOf(z).coerceAtLeast(0).toFloat()
                    bubbles += floatArrayOf(start, 10f + rnd.nextFloat() * 10f)
                }
                if (seeds.isEmpty()) bubbleAcc = 0f
                val lit = seeds.toMutableSet()
                val it = bubbles.iterator()
                while (it.hasNext()) {
                    val b = it.next()
                    b[0] += b[1] * dt
                    if (b[0] > top) it.remove() else if ((now / 60) % 3 != 0L) lit += PATH[b[0].toInt()]
                }
                lit.toIntArray() to (seeds.isEmpty() && bubbles.isEmpty())
            }
            BlowStyle.FIRE -> {
                // A láng magassága: fújásra nő, magától gyorsan esik; a teteje lobog, fölötte szikrák
                amount += (lv * 22f - 9f) * dt
                amount = amount.coerceIn(1.5f, PATH.size.toFloat())
                val h = amount.toInt().coerceIn(1, PATH.size)
                val lit = mutableListOf<Int>()
                for (i in 0 until h) {
                    // Alul tömör parázs, fent egyre lobogóbb
                    val flicker = i.toFloat() / h
                    if (i < 2 || rnd.nextFloat() > flicker * 0.55f) lit += PATH[i]
                }
                if (lv > 0.3f && h + 2 < PATH.size && rnd.nextFloat() < 0.35f) lit += PATH[h + 1 + rnd.nextInt(2)]
                lit.toIntArray() to (amount >= PATH.size - 0.5f)
            }
        }
    }

    private suspend fun win(ms: Long) {
        val sec = ms / 1000.0
        DebugState.log("Fújós: ${style.title} – siker" + if (style.timed && ms > 0) " (%.1f mp)".format(sec) else "")
        if (style.timed && ms > 0) {
            val best = Settings.blowBest(context, style)
            if (best == 0L || ms < best) {
                Settings.setBlowBest(context, style, ms)
                onStatus("Fújós · ${style.title} · ÚJ REKORD: %.1f mp".format(sec))
            } else {
                onStatus("Fújós · ${style.title} · %.1f mp (rekord: %.1f mp)".format(sec, best / 1000.0))
            }
        }
        haptics.win()
        when (style) {
            BlowStyle.ROCKET -> repeat(10) {
                // Tűzijáték: véletlen villanások a gyűrűn és a kamerán
                glyph.show(IntArray(5) { RING[rnd.nextInt(RING.size)] } + Glyph.Code_22111.A1)
                delay(120)
                glyph.off()
                delay(60)
            }
            BlowStyle.CANDLES -> {
                // „Kívánj valamit!”: lassan felizzik minden
                for (z in LectureTimer.FILL_ORDER.indices) { glyph.show(LectureTimer.FILL_ORDER.copyOfRange(0, z + 1)); delay(30) }
                delay(600)
            }
            else -> repeat(4) {
                glyph.show(Zones.ALL); delay(160); glyph.off(); delay(120)
            }
        }
        glyph.off()
        delay(800)
    }

    private suspend fun pop() {
        DebugState.log("Fújós: DURR! – kidurrant a lufi")
        Settings.addBlowPop(context)
        haptics.denied()
        repeat(3) { glyph.show(Zones.ALL); delay(70); glyph.off(); delay(50) }
        // Szilánkok
        repeat(6) { glyph.show(IntArray(4) { Zones.ALL[rnd.nextInt(Zones.ALL.size)] }); delay(60) }
        glyph.off()
        delay(700)
    }
}
