package com.akos.glypheggs

import android.app.Activity
import android.app.AlertDialog
import android.content.Context
import android.content.Intent
import android.graphics.Canvas
import android.graphics.Paint
import android.graphics.RectF
import android.os.Bundle
import android.view.Gravity
import android.view.View
import android.view.ViewGroup.LayoutParams.MATCH_PARENT
import android.view.ViewGroup.LayoutParams.WRAP_CONTENT
import android.widget.FrameLayout
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView
import kotlinx.coroutines.MainScope
import kotlinx.coroutines.cancel
import kotlinx.coroutines.delay
import kotlinx.coroutines.isActive
import kotlinx.coroutines.launch

/**
 * A Glyph Tojás (Tamagocsi) oldala: élő LED-kép, állapotjelzők és gondozás.
 * Amíg ez az oldal nyitva van, a LED-es gondozás kijelzővel felfelé is működik,
 * így a képernyőn is látod, mit csinál.
 */
class PetActivity : Activity() {

    private val scope = MainScope()
    private lateinit var map: GlyphMapView
    private lateinit var title: TextView
    private lateinit var sub: TextView
    private lateinit var msg: TextView
    private lateinit var ledToggle: ToggleView
    private val stats = mutableListOf<Pair<TextView, BarView>>()
    private lateinit var notifCard: FeatureCard
    private var refresher: kotlinx.coroutines.Job? = null

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        darkWindow()
        PetAlarmReceiver.schedule(this)

        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(15), 0, dp(15), dp(24))
        }
        val scroll = ScrollView(this).apply {
            setBackgroundColor(Ui.BG)
            isVerticalScrollBarEnabled = false
            addView(root, FrameLayout.LayoutParams(MATCH_PARENT, WRAP_CONTENT))
            padForSystemBars()
        }
        setContentView(scroll)

        val header = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
            setPadding(dp(7), dp(28), 0, dp(18))
        }
        header.addView(ImageView(this).apply {
            setImageResource(R.drawable.ic_back)
            setOnClickListener { finish() }
        }, LinearLayout.LayoutParams(dp(24), dp(24)))
        header.addView(text("Glyph Tojás", 26f).apply { setPadding(dp(30), 0, 0, 0) })
        root.addView(header)

        // --- Élő kép ---
        val box = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            background = rounded(Ui.BG, dp(22).toFloat(), Ui.LINE, dp(1.5f))
            setPadding(dp(14), dp(16), dp(14), dp(16))
        }
        map = GlyphMapView(this).apply { unlitColor = 0xFF303030.toInt() }
        box.addView(map, LinearLayout.LayoutParams(MATCH_PARENT, dp(230)))
        title = text("", 22f, Ui.TEXT, Ui.light).apply { gravity = Gravity.CENTER; setPadding(0, dp(12), 0, 0) }
        sub = text("", 13f, Ui.SUB).apply { gravity = Gravity.CENTER }
        msg = text("", 13f, Ui.TEXT).apply { gravity = Gravity.CENTER; setPadding(0, dp(6), 0, 0) }
        box.addView(title, LinearLayout.LayoutParams(MATCH_PARENT, WRAP_CONTENT))
        box.addView(sub, LinearLayout.LayoutParams(MATCH_PARENT, WRAP_CONTENT))
        box.addView(msg, LinearLayout.LayoutParams(MATCH_PARENT, WRAP_CONTENT))
        root.addView(box)

        // --- LED-ek be/ki ---
        val bar = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
            background = rounded(Ui.LIGHT, dp(22).toFloat())
            setPadding(dp(20), 0, dp(16), 0)
        }
        val barTexts = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        barTexts.addView(text("Tojás a LED-eken", 17.5f, Ui.DARK_TEXT))
        barTexts.addView(text("Tedd le kijelzővel lefelé, és kopogj", 12f, 0xFF555555.toInt()))
        bar.addView(barTexts, LinearLayout.LayoutParams(0, WRAP_CONTENT, 1f))
        ledToggle = ToggleView(this).apply {
            onColor = 0xFFFFFFFF.toInt()
            onChange = { send(SimonService.ACTION_PET) }
        }
        bar.addView(ledToggle)
        bar.setOnClickListener { ledToggle.performClick() }
        root.addView(bar, LinearLayout.LayoutParams(MATCH_PARENT, dp(78)).apply { topMargin = dp(18) })

        // --- Állapot ---
        root.addView(sectionTitle("Állapot"))
        val names = listOf("Jóllakottság", "Kedv", "Energia", "Tisztaság")
        val cards = names.map { n ->
            val card = LinearLayout(this).apply {
                orientation = LinearLayout.VERTICAL
                background = rounded(Ui.CARD, dp(22).toFloat())
                setPadding(dp(16), dp(16), dp(16), dp(16))
            }
            card.addView(text(n, 13f, Ui.SUB))
            val value = text("", 24f, Ui.TEXT, Ui.light)
            card.addView(value)
            val bv = BarView(this)
            card.addView(bv, LinearLayout.LayoutParams(MATCH_PARENT, dp(8)).apply { topMargin = dp(10) })
            stats += value to bv
            card
        }
        root.addView(row(cards[0], cards[1], 120))
        root.addView(row(cards[2], cards[3], 120))

        // --- Gondozás ---
        root.addView(sectionTitle("Gondozás"))
        val icons = mapOf(
            PetAction.FEED to R.drawable.ic_food, PetAction.PLAY to R.drawable.ic_ball,
            PetAction.PET to R.drawable.ic_heart, PetAction.CLEAN to R.drawable.ic_bath,
            PetAction.SLEEP to R.drawable.ic_moon, PetAction.HEAL to R.drawable.ic_heal
        )
        val hints = mapOf(
            PetAction.FEED to "LED-en: 2 kopogás", PetAction.PLAY to "LED-en: 3 kopogás",
            PetAction.PET to "LED-en: 1 kopogás", PetAction.CLEAN to "LED-en: rázás",
            PetAction.SLEEP to "LED-en: 4 kopogás", PetAction.HEAL to "Csak innen"
        )
        val order = listOf(PetAction.FEED, PetAction.PLAY, PetAction.PET, PetAction.CLEAN, PetAction.SLEEP, PetAction.HEAL)
        val actionCards = order.map { a ->
            FeatureCard(this, icons.getValue(a), a.title, hints.getValue(a), false).apply {
                setOnClickListener {
                    msg.text = PetStore.act(this@PetActivity, a)
                    refresh()
                }
            }
        }
        root.addView(row(actionCards[0], actionCards[1], 140))
        root.addView(row(actionCards[2], actionCards[3], 140))
        root.addView(row(actionCards[4], actionCards[5], 140))

        // --- Hogyan működik ---
        root.addView(sectionTitle("Mit látsz a hátlapon"))
        val legend = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            background = rounded(Ui.CARD, dp(22).toFloat())
            setPadding(dp(18), dp(16), dp(18), dp(16))
        }
        listOf(
            "Szemek: a kamera körüli LED-ek (pislog). Antenna: a ferde csík.",
            "Boldog: a felső sávon ugrál. Elégedett: \"lélegzik\". Szomorú: könnycsepp fut a vonalon. Beteg: az alsó ív villog. Alszik: csak a pont pislákol.",
            "Kaki: a pont ég (több kakinál villog) – fürdesd meg!",
            "Pár másodpercenként a felső sáv mutatja az állapotát: bal felső ív = jóllakottság, bal oldal = kedv, jobb alsó = energia, jobb oldal = tisztaság.",
            "Tojásként billeg. Kopogással melegítheted: 3 gondoskodás vagy 20 perc után kikel.",
            "Napi rendszerességgel gondozd: 1 nap után kamasz, 3 nap után felnőtt lesz. Ha nagyon sokáig beteg, elköltözik, és új tojás jön."
        ).forEach { t ->
            legend.addView(text("•  $t", 13f, Ui.SUB).apply { setPadding(0, dp(4), 0, dp(4)); setLineSpacing(0f, 1.2f) })
        }
        root.addView(legend)

        // --- Beállítások ---
        root.addView(sectionTitle("Beállítások"))
        notifCard = FeatureCard(this, R.drawable.ic_bell, "Értesítések", "Szól, ha éhes vagy beteg", true)
        notifCard.toggle?.onChange = { on -> Settings.setPetNotifications(this, on) }
        val resetCard = FeatureCard(this, R.drawable.ic_egg, "Új tojás", "Elölről kezdés", false)
        resetCard.setOnClickListener {
            AlertDialog.Builder(this, android.R.style.Theme_DeviceDefault_Dialog_Alert)
                .setTitle("Új tojás?")
                .setMessage("A mostani Tojásod elköltözik, és új tojásból kezded.")
                .setPositiveButton("Igen") { _, _ ->
                    PetStore.reset(this)
                    msg.text = "Új tojás érkezett"
                    refresh()
                }
                .setNegativeButton("Mégse", null)
                .show()
        }
        root.addView(row(notifCard, resetCard, 140))

        scope.launch { GlyphMirror.lit.collect { map.lit = it } }
        scope.launch { GlyphMirror.mode.collect { ledToggle.checked = it == Feature.PET } }
    }

    override fun onResume() {
        super.onResume()
        GlyphMirror.appVisible = true
        GlyphMirror.simulatorOpen = true
        notifCard.toggle?.checked = Settings.petNotifications(this)
        if (PetStore.takeRanAwayNote(this)) {
            AlertDialog.Builder(this, android.R.style.Theme_DeviceDefault_Dialog_Alert)
                .setTitle("Elköltözött…")
                .setMessage("A Tojásod sokáig beteg volt, ezért elköltözött. Új tojás érkezett – gondozd jól!")
                .setPositiveButton("Rendben", null)
                .show()
        }
        refresh()
        refresher?.cancel()
        refresher = scope.launch {
            while (isActive) {
                delay(2_000)
                refresh()
            }
        }
    }

    override fun onPause() {
        super.onPause()
        GlyphMirror.appVisible = false
        GlyphMirror.simulatorOpen = false
        refresher?.cancel()
    }

    private fun refresh() {
        val s = PetStore.load(this)
        title.text = if (s.stage == PetStage.EGG) "Tojás" else "${s.stage.title} · ${s.mood.title}"
        val age = s.ageHours()
        sub.text = when {
            s.stage == PetStage.EGG -> "Melegítsd: ${s.warmth}/3 · vagy várj, magától is kikel"
            else -> {
                val ageText = if (age < 24f) "${age.toInt()} órás" else "${(age / 24f).toInt()} napos"
                ageText + (s.need()?.let { " · $it" } ?: "") + (if (s.poops > 0) " · kaki: ${s.poops}" else "")
            }
        }
        val values = listOf(s.food, s.fun_, s.energy, s.clean)
        stats.forEachIndexed { i, (t, b) ->
            t.text = "${values[i].toInt()}%"
            b.fraction = values[i] / 100f
        }
    }

    private fun send(action: String) {
        startForegroundService(Intent(this, SimonService::class.java).setAction(action))
    }

    override fun onDestroy() {
        scope.cancel()
        super.onDestroy()
    }

    /** Vékony, lekerekített állapotsáv. */
    private class BarView(context: Context) : View(context) {
        var fraction = 0f
            set(value) {
                field = value.coerceIn(0f, 1f)
                invalidate()
            }
        private val p = Paint(Paint.ANTI_ALIAS_FLAG)
        private val r = RectF()

        override fun onDraw(canvas: Canvas) {
            val h = height.toFloat()
            p.color = 0xFF3C3C3C.toInt()
            r.set(0f, 0f, width.toFloat(), h)
            canvas.drawRoundRect(r, h / 2, h / 2, p)
            p.color = when {
                fraction < 0.25f -> Ui.RED
                else -> 0xFFF1F1F1.toInt()
            }
            r.set(0f, 0f, width * fraction, h)
            if (fraction > 0f) canvas.drawRoundRect(r, h / 2, h / 2, p)
        }
    }
}
