package com.akos.glypheggs

import android.app.Activity
import android.content.Intent
import android.os.Bundle
import android.view.Gravity
import android.view.ViewGroup.LayoutParams.MATCH_PARENT
import android.view.ViewGroup.LayoutParams.WRAP_CONTENT
import android.widget.FrameLayout
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView
import kotlinx.coroutines.Job
import kotlinx.coroutines.MainScope
import kotlinx.coroutines.cancel
import kotlinx.coroutines.delay
import kotlinx.coroutines.isActive
import kotlinx.coroutines.launch

/**
 * Az Előadás-időzítő beállítása – élő előnézettel (töltés → előadás → szünet):
 *  - részek száma, egy rész és a szünet hossza,
 *  - az indítás (töltés) módja és erőssége,
 *  - a szünet parancsa, többszöri szünet, automatikus szünet, a szünet korai befejezése (folytatás).
 * Az indító mozdulat és a leállítás az „Indítás és leállítás” oldalon állítható.
 */
class LectureActivity : Activity() {

    private val scope = MainScope()
    private lateinit var preview: GlyphMapView
    private lateinit var previewLabel: TextView
    private lateinit var body: LinearLayout
    private var animJob: Job? = null

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        darkWindow()

        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(15), 0, dp(15), dp(24))
        }
        val scroll = ScrollView(this).apply {
            setBackgroundColor(Ui.BG)
            isVerticalScrollBarEnabled = false
            addView(root, FrameLayout.LayoutParams(MATCH_PARENT, WRAP_CONTENT))
            padForSystemBars()
        }
        setContentView(scroll)

        val header = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
            setPadding(dp(7), dp(28), 0, dp(18))
        }
        header.addView(ImageView(this).apply {
            setImageResource(R.drawable.ic_back)
            setOnClickListener { finish() }
        }, LinearLayout.LayoutParams(dp(24), dp(24)))
        header.addView(text("Előadás", 26f).apply { setPadding(dp(30), 0, 0, 0) })
        root.addView(header)

        // Előnézet
        val box = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            background = rounded(Ui.BG, dp(22).toFloat(), Ui.LINE, dp(1.5f))
            setPadding(dp(14), dp(16), dp(14), dp(14))
        }
        preview = GlyphMapView(this).apply { unlitColor = 0xFF303030.toInt() }
        box.addView(preview, LinearLayout.LayoutParams(MATCH_PARENT, dp(220)))
        previewLabel = text("", 13f, Ui.SUB).apply { gravity = Gravity.CENTER; setPadding(0, dp(10), 0, 0) }
        box.addView(previewLabel, LinearLayout.LayoutParams(MATCH_PARENT, WRAP_CONTENT))
        root.addView(box)

        // Indítás, súgó
        val startCard = FeatureCard(this, R.drawable.ic_lecture, "Indítás", "Tedd le kijelzővel lefelé", false)
        startCard.setOnClickListener {
            startForegroundService(Intent(this, SimonService::class.java).setAction(SimonService.ACTION_LECTURE))
        }
        val infoCard = FeatureCard(this, R.drawable.ic_info, "Hogyan működik", "Töltés, szünet, jelzések", false)
        infoCard.setOnClickListener {
            startActivity(Intent(this, InfoActivity::class.java).putExtra(InfoActivity.EXTRA_FEATURE, Feature.LECTURE.name))
        }
        root.addView(row(startCard, infoCard, 140).apply { setPadding(0, dp(14), 0, 0) })

        body = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        root.addView(body)
        render()
    }

    override fun onResume() {
        super.onResume()
        GlyphMirror.appVisible = true
        render()
        startPreview()
    }

    override fun onPause() {
        super.onPause()
        GlyphMirror.appVisible = false
        animJob?.cancel()
    }

    override fun onDestroy() {
        scope.cancel()
        super.onDestroy()
    }

    /** 16 mp-es ismétlődő bemutató: töltés → előadás a választott animációval → szünet (függőleges vonal fogy). */
    private fun startPreview() {
        animJob?.cancel()
        animJob = scope.launch {
            val bar = IntArray(16) { Zones.LEVEL[15 - it] }
            val dLine = LectureTimer.FILL_ORDER.copyOfRange(1, 9)
            var frame = 0
            while (isActive) {
                val t = frame % 160
                val style = Settings.lectureStyle(this@LectureActivity)
                val blocks = Settings.lectureBlocks(this@LectureActivity)
                val lit: Set<Int>
                val label: String
                when {
                    t < 30 -> {
                        val n = (t / 29f * LectureTimer.FILL_ORDER.size).toInt().coerceIn(0, LectureTimer.FILL_ORDER.size)
                        lit = LectureTimer.FILL_ORDER.take(n).toSet()
                        label = "1. Töltés: alulról felfelé gyulladnak a LED-ek"
                    }
                    t < 120 -> {
                        // A teljes előadás 9 mp-be sűrítve; a Takarékos 30 mp-es ritmusát is felgyorsítja
                        val done = (t - 30) / 90.0
                        val p = 1.0 - done
                        val block = (done * blocks).toInt().coerceIn(0, blocks - 1)
                        val bp = ((block + 1).toDouble() / blocks - done) * blocks
                        val simNow = if (style == LectureStyle.MINIMAL) frame * 100L * 20 else frame * 100L
                        lit = LectureTimer.frame(style, p, bp.coerceIn(0.0, 1.0), block, blocks, simNow).toSet()
                        label = "2. Előadás – ${style.title}"
                    }
                    else -> {
                        val p = (t - 120) / 40f
                        val m = ((1f - p) * 8f).toInt().coerceIn(1, 8)
                        lit = bar.take(8).toSet() + dLine.take(m - 1).toSet() + (if (frame % 10 < 5) setOf(dLine[m - 1]) else emptySet())
                        label = "3. Szünet: a függőleges vonal mutatja, mennyi van még"
                    }
                }
                preview.lit = lit
                previewLabel.text = label
                frame++
                delay(100)
            }
        }
    }

    // ------------------------------------------------------------------ építőelemek

    private fun pillBtn(label: String, onClick: () -> Unit): TextView = text(label, 22f).apply {
        gravity = Gravity.CENTER
        background = rounded(0xFF3A3A3A.toInt(), dp(22).toFloat())
        setOnClickListener { onClick() }
    }

    /** Szám-léptető: „−  érték  +”. */
    private fun stepper(title: String, sub: String, value: String, onMinus: () -> Unit, onPlus: () -> Unit): LinearLayout {
        val row = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
            background = rounded(Ui.CARD, dp(20).toFloat())
            setPadding(dp(18), dp(12), dp(12), dp(12))
        }
        val texts = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        texts.addView(text(title, 17f))
        texts.addView(text(sub, 12.5f, Ui.SUB).apply { setPadding(0, dp(2), 0, 0) })
        row.addView(texts, LinearLayout.LayoutParams(0, WRAP_CONTENT, 1f))
        row.addView(pillBtn("−", onMinus), LinearLayout.LayoutParams(dp(44), dp(44)))
        row.addView(text(value, 17f, Ui.TEXT, Ui.medium).apply { gravity = Gravity.CENTER },
            LinearLayout.LayoutParams(dp(58), WRAP_CONTENT))
        row.addView(pillBtn("+", onPlus), LinearLayout.LayoutParams(dp(44), dp(44)))
        return row
    }

    private fun optionRow(title: String, sub: String, selected: Boolean, onClick: () -> Unit): LinearLayout {
        val row = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
            background = rounded(Ui.CARD, dp(20).toFloat())
            setPadding(dp(18), dp(15), dp(16), dp(15))
            setOnClickListener { onClick() }
        }
        val texts = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        texts.addView(text(title, 17f))
        texts.addView(text(sub, 12.5f, Ui.SUB).apply { setPadding(0, dp(2), 0, 0); setLineSpacing(0f, 1.15f) })
        row.addView(texts, LinearLayout.LayoutParams(0, WRAP_CONTENT, 1f))
        row.addView(RadioMark(this, selected), LinearLayout.LayoutParams(dp(26), dp(26)).apply { marginStart = dp(12) })
        return row
    }

    private fun toggleRow(title: String, sub: String, on: Boolean, changed: (Boolean) -> Unit): LinearLayout {
        val row = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
            background = rounded(Ui.CARD, dp(20).toFloat())
            setPadding(dp(18), dp(15), dp(16), dp(15))
        }
        val texts = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        texts.addView(text(title, 17f))
        texts.addView(text(sub, 12.5f, Ui.SUB).apply { setPadding(0, dp(2), 0, 0); setLineSpacing(0f, 1.15f) })
        row.addView(texts, LinearLayout.LayoutParams(0, WRAP_CONTENT, 1f))
        val t = ToggleView(this).apply {
            checked = on
            onChange = { v -> changed(v) }
        }
        row.addView(t, LinearLayout.LayoutParams(WRAP_CONTENT, WRAP_CONTENT).apply { marginStart = dp(12) })
        row.setOnClickListener { t.performClick() }
        return row
    }

    /** Rázás érzékenysége: Alacsony / Közepes / Magas / Nagyon magas (közös beállítás). */
    private fun shakeSensRow(): LinearLayout {
        val cur = Settings.shakeSensitivity(this)
        val pills = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
        listOf("Alacsony", "Közepes", "Magas", "Nagyon\nmagas").forEachIndexed { i, label ->
            val sel = i == cur
            pills.addView(text(label, 13f, if (sel) Ui.DARK_TEXT else Ui.TEXT).apply {
                gravity = Gravity.CENTER
                background = rounded(if (sel) Ui.LIGHT else Ui.CARD, dp(22).toFloat())
                setOnClickListener {
                    Settings.setShakeSensitivity(this@LectureActivity, i)
                    notifyService()
                    render()
                }
            }, LinearLayout.LayoutParams(0, dp(48), 1f).apply { marginEnd = dp(5) })
        }
        return pills
    }

    private fun notifyService() {
        if (SimonService.watching) {
            startService(Intent(this, SimonService::class.java).setAction(SimonService.ACTION_REFRESH))
        }
    }

    private fun LinearLayout.addGap(v: android.view.View) {
        addView(v, LinearLayout.LayoutParams(MATCH_PARENT, WRAP_CONTENT).apply { bottomMargin = dp(5) })
    }

    // ------------------------------------------------------------------ felület

    private fun render() {
        val blocks = Settings.lectureBlocks(this)
        val blockMin = Settings.lectureBlockMin(this)
        val breakMin = Settings.lectureBreakMin(this)
        val start = Settings.lectureStart(this)
        val cmd = Settings.lectureBreakCmd(this)
        body.removeAllViews()

        // --- Az előadás ---
        body.addView(sectionTitle("Az előadás"))
        body.addGap(stepper("Részek száma", "Hány részből áll az előadás", "$blocks",
            { Settings.setLectureBlocks(this, blocks - 1); render() },
            { Settings.setLectureBlocks(this, blocks + 1); render() }))
        body.addGap(stepper("Egy rész hossza", "Perc", "$blockMin",
            { Settings.setLectureBlockMin(this, blockMin - 5); render() },
            { Settings.setLectureBlockMin(this, blockMin + 5); render() }))
        body.addGap(stepper("Szünet hossza", "Perc", "$breakMin",
            { Settings.setLectureBreakMin(this, if (breakMin > 5) breakMin - 5 else breakMin - 1); render() },
            { Settings.setLectureBreakMin(this, if (breakMin >= 5) breakMin + 5 else breakMin + 1); render() }))
        val total = blocks * blockMin
        body.addView(text(
            "Összesen: $blocks × $blockMin = $total perc előadás, szünet: $breakMin perc.\n" +
                "A felső sáv 16 LED-je a teljes előadást mutatja: LED-enként kb. %.1f perc, a szünetet a függőleges vonal 8 LED-je: LED-enként kb. %.1f perc."
                    .format(total / 16f, breakMin / 8f),
            12.5f, Ui.SUB
        ).apply { setPadding(dp(8), dp(6), dp(8), 0); setLineSpacing(0f, 1.2f) })

        // --- Animáció ---
        body.addView(sectionTitle("Animáció (visszaszámláló)"))
        val style = Settings.lectureStyle(this)
        for (st in LectureStyle.entries) {
            body.addGap(optionRow(st.title, st.desc, st == style) {
                Settings.setLectureStyle(this, st)
                render()
            })
        }
        body.addGap(toggleRow("Jelzés a rész vége előtt",
            "${Config.LECTURE_WARN_MIN} perccel egy rész vége előtt rezeg, és kétszer felvillan a felső sáv",
            Settings.lectureWarn(this)) { Settings.setLectureWarn(this, it) })

        // --- Indítás (töltés) ---
        body.addView(sectionTitle("Indítás módja"))
        body.addGap(toggleRow("Widgetről azonnal",
            "Widget-gombra (gyorsindító sáv vagy egygombos widget) rázás és lerakás nélkül, egyből indul az előadás",
            Settings.lectureWidgetInstant(this)) { Settings.setLectureWidgetInstant(this, it) })
        for (m in LectureStart.entries) {
            body.addGap(optionRow(m.title, m.hint, m == start) {
                Settings.setLectureStart(this, m)
                render()
            })
        }
        if (start != LectureStart.INSTANT) {
            val n = Settings.shakeFillCount(this)
            val what = if (start == LectureStart.SHAKE) "rázás" else "kopogás"
            body.addGap(stepper("Töltéshez kell", "Hány $what kell, hogy mind a 33 LED égjen", "$n×",
                { Settings.setShakeFillCount(this, n - 1); render() },
                { Settings.setShakeFillCount(this, n + 1); render() }))
            body.addView(text(
                "Ez a szám az „Indító mozdulat”-nál választható Rázás-töltésre is érvényes (Indítás és leállítás oldal).",
                12.5f, Ui.SUB
            ).apply { setPadding(dp(8), dp(6), dp(8), 0); setLineSpacing(0f, 1.2f) })
        }
        body.addView(text("Rázás érzékenysége – minél magasabb, annál gyengébb rázás is elég", 13f, Ui.SUB)
            .apply { setPadding(dp(8), dp(14), dp(8), dp(8)) })
        body.addView(shakeSensRow())

        // --- Szünet ---
        body.addView(sectionTitle("Szünet indítása"))
        for (c in BreakCommand.entries) {
            body.addGap(optionRow(c.title, c.hint, c == cmd) {
                Settings.setLectureBreakCmd(this, c)
                render()
            })
        }
        if (cmd != BreakCommand.NONE) {
            body.addGap(toggleRow("Több szünet", "Többször is indíthatsz szünetet (különben csak egyszer)",
                Settings.lectureMultiBreak(this)) { Settings.setLectureMultiBreak(this, it) })
            body.addGap(toggleRow("Folytatás előbb", "Ugyanazzal a paranccsal a szünetet előbb is befejezheted",
                Settings.lectureEarlyResume(this)) { Settings.setLectureEarlyResume(this, it) })
        }
        body.addGap(toggleRow("Automatikus szünet", "A részek között magától indul a szünet, parancs nélkül",
            Settings.lectureAutoBreak(this)) { Settings.setLectureAutoBreak(this, it) })
        body.addView(text(
            "A szünet végén az előadás magától folytatódik ott, ahol abbamaradt; közben az előadás ideje áll.",
            12.5f, Ui.SUB
        ).apply { setPadding(dp(8), dp(6), dp(8), 0); setLineSpacing(0f, 1.2f) })

        // --- Indító mozdulat, leállítás ---
        body.addView(sectionTitle("Indító mozdulat és leállítás"))
        val gest = FeatureCard(this, R.drawable.ic_gesture, "Indítás és leállítás",
            "Indul: ${Settings.trigger(this, Feature.LECTURE).title}\nLeáll: ${Settings.stopSummary(this, Feature.LECTURE)}", false)
        gest.setOnClickListener {
            startActivity(Intent(this, GesturesActivity::class.java).putExtra(GesturesActivity.EXTRA_FEATURE, Feature.LECTURE.name))
        }
        body.addView(row(gest, null, 150))
    }
}
