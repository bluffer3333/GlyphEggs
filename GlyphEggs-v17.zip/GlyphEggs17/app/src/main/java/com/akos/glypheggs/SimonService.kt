package com.akos.glypheggs

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.Service
import android.content.BroadcastReceiver
import android.content.ComponentName
import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.content.pm.ServiceInfo
import android.graphics.drawable.Icon
import android.media.AudioManager
import android.os.IBinder
import android.os.SystemClock
import android.service.quicksettings.TileService
import kotlinx.coroutines.CompletableDeferred
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.cancel
import kotlinx.coroutines.channels.Channel
import kotlinx.coroutines.coroutineScope
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.MutableSharedFlow
import kotlinx.coroutines.flow.first
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.filter
import kotlinx.coroutines.flow.map
import kotlinx.coroutines.flow.merge
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import kotlinx.coroutines.withTimeoutOrNull

/**
 * Előtérszolgáltatás (állandó értesítéssel): ez vezérli a LED-eket és a szenzorokat.
 *
 *  - Mozdulatfigyelés: ha be van kapcsolva, a beállított indító mozdulatokra
 *    ([Trigger]) elindítja a hozzájuk rendelt funkciót ([Feature]).
 *  - Simon, Pörgetés, Iránytű: csempéről, az appból vagy mozdulattal indulnak.
 *  - Ha nincs Glyph (más telefon), a funkciók akkor is futnak: a képernyőn,
 *    a szimulációs módban látszanak.
 *
 * Ha a figyelés ki van kapcsolva, a szolgáltatás csak egy feladat idejére fut.
 */
class SimonService : Service() {

    companion object {
        const val ACTION_WATCH_ON = "com.akos.glypheggs.WATCH_ON"
        const val ACTION_WATCH_OFF = "com.akos.glypheggs.WATCH_OFF"
        const val ACTION_WATCH_TOGGLE = "com.akos.glypheggs.WATCH_TOGGLE"
        const val ACTION_REFRESH = "com.akos.glypheggs.REFRESH"
        const val ACTION_START_GAME = "com.akos.glypheggs.START_GAME"
        const val ACTION_SPIN = "com.akos.glypheggs.SPIN"
        const val ACTION_COMPASS = "com.akos.glypheggs.COMPASS"
        const val ACTION_LOCKPICK = "com.akos.glypheggs.LOCKPICK"
        const val ACTION_SAFE = "com.akos.glypheggs.SAFE"
        const val ACTION_PET = "com.akos.glypheggs.PET"
        const val ACTION_LEVEL = "com.akos.glypheggs.LEVEL"
        const val ACTION_TIMER = "com.akos.glypheggs.TIMER"
        const val ACTION_BALANCE = "com.akos.glypheggs.BALANCE"
        const val ACTION_DINO = "com.akos.glypheggs.DINO"
        const val ACTION_LECTURE = "com.akos.glypheggs.LECTURE"
        const val ACTION_BLOW = "com.akos.glypheggs.BLOW"
        /** A Fújós oldalról jött: a mikrofon már fut, indulhat a játék. */
        const val SOURCE_BLOW_PAGE = "blow_page"

        fun actionFor(f: Feature): String = when (f) {
            Feature.SIMON -> ACTION_START_GAME
            Feature.SPIN -> ACTION_SPIN
            Feature.COMPASS -> ACTION_COMPASS
            Feature.LOCKPICK -> ACTION_LOCKPICK
            Feature.SAFE -> ACTION_SAFE
            Feature.PET -> ACTION_PET
            Feature.LEVEL -> ACTION_LEVEL
            Feature.TIMER -> ACTION_TIMER
            Feature.BALANCE -> ACTION_BALANCE
            Feature.DINO -> ACTION_DINO
            Feature.LECTURE -> ACTION_LECTURE
            Feature.BLOW -> ACTION_BLOW
        }
        const val ACTION_STOP = "com.akos.glypheggs.STOP"
        /** Honnan jött az indítás (pl. widget) – az Előadás widgetről azonnal, rázás nélkül indulhat. */
        const val EXTRA_SOURCE = "source"
        const val SOURCE_WIDGET = "widget"
        /** Az Előadás widget START gombja: mindig azonnal indul (rázás és lerakás nélkül). */
        const val SOURCE_INSTANT = "instant"
        /** Egy funkció indító mozdulatának figyelése be/ki (widgetről); EXTRA_FEATURE a funkció neve. */
        const val ACTION_ARM_TOGGLE = "com.akos.glypheggs.ARM_TOGGLE"
        const val EXTRA_FEATURE = "feature"
        private const val CHANNEL_ID = "glyph_eggs"
        private const val NOTIF_ID = 1

        /** Be van-e kapcsolva a mozdulatfigyelés (a csempe ebből mutatja az állapotot). */
        @Volatile
        var watching = false
            private set

        /** Fut-e most az iránytű. */
        @Volatile
        var compassOn = false
            private set

        private const val IDLE_TEXT = "Készenlét"
    }

    private val scope = CoroutineScope(SupervisorJob() + Dispatchers.Default)
    private lateinit var glyph: GlyphController
    private lateinit var motion: MotionDetector
    private lateinit var haptics: Haptics
    private var job: Job? = null

    /** Rázás-töltéssel indult: az első rázás után a LED-eket fel kell tölteni, és csak utána indul a funkció. */
    private var pendingFill = false
    private var fillEvents: Channel<Long>? = null
    private var fillCollector: Job? = null
    /** A funkció már a rázás-töltés után indult (az Előadás így kihagyja a saját töltését). */
    private var filledByTrigger = false
    /** Widgetről, azonnali indításra (rázás és lerakás nélkül) kért Előadás. */
    private var lectureInstant = false

    /** A képernyő bekapcsolása (= a bekapcsoló gomb megnyomása kikapcsolt képernyőnél). */
    private val screenOn = MutableSharedFlow<Long>(extraBufferCapacity = 4)
    /** Minden bekapcsoló-gombnyomás (a képernyő be- vagy kikapcsolása) – a Dínó ugráshoz. */
    private val powerPresses = MutableSharedFlow<Long>(extraBufferCapacity = 8)
    /** Hangerő-gombok játék közben: +1 fel, −1 le. */
    private val volumeKeys = MutableSharedFlow<Int>(extraBufferCapacity = 8)
    // Hangerő-gombos indítás: a hangerő változásából ismeri fel a gombnyomást, utána visszaállítja
    private var volCount = 0
    private var volDir = 0
    private var volStream = -1
    private var volStart = 0
    private var volFirstMs = 0L
    private var volLastMs = 0L
    @Volatile private var volRestoring = false

    private val volumeReceiver = object : BroadcastReceiver() {
        override fun onReceive(context: Context, intent: Intent) {
            if (!watching || volRestoring) return
            val active = Settings.activeTriggers(this@SimonService)
            if (Trigger.VOL_UP_2 !in active && Trigger.VOL_DOWN_2 !in active) return
            val type = intent.getIntExtra("android.media.EXTRA_VOLUME_STREAM_TYPE", -1)
            val v = intent.getIntExtra("android.media.EXTRA_VOLUME_STREAM_VALUE", -1)
            val prev = intent.getIntExtra("android.media.EXTRA_PREV_VOLUME_STREAM_VALUE", -1)
            if (v < 0 || prev < 0 || v == prev) return
            val now = SystemClock.elapsedRealtime()
            val dir = if (v > prev) 1 else -1
            // Egy gombnyomásra több hangfolyam is jelezhet (csengő, értesítés): csak az elsőt számolja
            if (volCount > 0 && type != volStream) return
            if (now - volLastMs < 120) return
            if (volCount > 0 && (dir != volDir || now - volFirstMs > Config.VOL_WINDOW_MS)) volCount = 0
            if (volCount == 0) {
                volFirstMs = now
                volDir = dir
                volStream = type
                volStart = prev
            }
            volLastMs = now
            volCount++
            if (volCount >= 2) {
                volCount = 0
                val t = if (dir > 0) Trigger.VOL_UP_2 else Trigger.VOL_DOWN_2
                if (t !in active) return
                // A hangerő vissza oda, ahol a két nyomás előtt volt
                volRestoring = true
                try {
                    getSystemService(AudioManager::class.java).setStreamVolume(volStream, volStart, 0)
                } catch (e: Throwable) {
                    DebugState.log("Hangerő visszaállítása nem sikerült")
                }
                scope.launch { delay(400); volRestoring = false }
                DebugState.log("Mozdulat felismerve: ${t.title}")
                onTrigger(t)
            }
        }
    }

    private val screenReceiver = object : BroadcastReceiver() {
        override fun onReceive(context: Context, intent: Intent) {
            val t = SystemClock.elapsedRealtime()
            if (intent.action == Intent.ACTION_SCREEN_ON) screenOn.tryEmit(t)
            powerPresses.tryEmit(t)
        }
    }

    override fun onCreate() {
        super.onCreate()
        createChannel()
        startForeground(NOTIF_ID, buildNotification(IDLE_TEXT), ServiceInfo.FOREGROUND_SERVICE_TYPE_SPECIAL_USE)
        EnergyMeter.attach(this)
        registerReceiver(screenReceiver, IntentFilter(Intent.ACTION_SCREEN_ON).apply { addAction(Intent.ACTION_SCREEN_OFF) })
        // A hangerő-változás nem védett rendszerüzenet, ezért „exportált” fogadó kell
        registerReceiver(volumeReceiver, IntentFilter("android.media.VOLUME_CHANGED_ACTION"), Context.RECEIVER_EXPORTED)

        haptics = Haptics(this)
        glyph = GlyphController(this).also { it.init() }
        motion = MotionDetector(this) { t -> onTrigger(t) }.also { it.start() }
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        when (intent?.action) {
            // Rendszer általi újraindításnál (null) a mentett beállítás dönt
            null -> setWatching(Settings.watching(this))
            ACTION_WATCH_ON -> setWatching(true)
            ACTION_WATCH_OFF -> setWatching(false)
            ACTION_WATCH_TOGGLE -> {
                val on = !Settings.watching(this)
                Settings.setWatching(this, on)
                setWatching(on)
            }
            ACTION_REFRESH -> {
                motion.setWatching(watching, Settings.activeTriggers(this))
                if (job?.isActive != true) showIdle()
                if (!watching && job?.isActive != true) stopSelf()
            }
            ACTION_START_GAME -> toggle(Feature.SIMON)
            ACTION_SPIN -> toggle(Feature.SPIN)
            ACTION_COMPASS -> toggle(Feature.COMPASS)
            ACTION_LOCKPICK -> toggle(Feature.LOCKPICK)
            ACTION_SAFE -> toggle(Feature.SAFE)
            ACTION_PET -> toggle(Feature.PET)
            ACTION_LEVEL -> toggle(Feature.LEVEL)
            ACTION_TIMER -> toggle(Feature.TIMER)
            ACTION_BALANCE -> toggle(Feature.BALANCE)
            ACTION_DINO -> toggle(Feature.DINO)
            ACTION_LECTURE -> {
                val src = intent?.getStringExtra(EXTRA_SOURCE)
                lectureInstant = src == SOURCE_INSTANT || (src == SOURCE_WIDGET && Settings.lectureWidgetInstant(this))
                toggle(Feature.LECTURE)
                lectureInstant = false
            }
            ACTION_BLOW -> toggle(Feature.BLOW)
            ACTION_ARM_TOGGLE -> {
                val f = Feature.entries.firstOrNull { it.name == intent?.getStringExtra(EXTRA_FEATURE) }
                if (f != null) toggleArmed(f)
            }
            ACTION_STOP -> {
                Settings.setWatching(this, false)
                setWatching(false)
                job?.cancel()
                stopSelf()
                return START_NOT_STICKY
            }
        }
        return START_STICKY
    }

    private fun setWatching(on: Boolean) {
        watching = on
        EnergyMeter.setWatching(on)
        val active = Settings.activeTriggers(this)
        motion.setWatching(on, active)
        refreshTiles()
        Widgets.updateBar(this)
        Widgets.updateLecture(this)
        Widgets.updateCompass(this)
        DebugState.log(
            if (on) "Mozdulatfigyelés be: " + active.joinToString { it.title }.ifEmpty { "nincs kiosztott mozdulat" }
            else "Mozdulatfigyelés kikapcsolva"
        )
        if (job?.isActive != true) {
            showIdle()
            if (!on) stopSelf()
        }
    }

    /**
     * Widget: a funkció indító mozdulatának figyelése be/ki. Bekapcsoláskor, ha a mozdulatfigyelés
     * ki volt kapcsolva, azt is bekapcsolja; kikapcsoláskor, ha a figyelést a widget kapcsolta be és
     * már semmi más nem figyel, leállítja (akkukímélés).
     */
    private fun toggleArmed(f: Feature) {
        val on = !Settings.listening(this, f)
        Settings.setArmed(this, f, on)
        if (on) {
            if (!Settings.watching(this)) {
                Settings.setWatching(this, true)
                Settings.setWatchByWidget(this, true)
            }
            setWatching(true)
        } else if (Settings.watchByWidget(this) && Settings.activeTriggers(this).isEmpty()) {
            Settings.setWatching(this, false)
            Settings.setWatchByWidget(this, false)
            setWatching(false)
        } else {
            setWatching(Settings.watching(this))
        }
        DebugState.log("${f.title}: indító mozdulat figyelése ${if (on) "be" else "ki"} (widget)")
    }

    /** Egy felismert mozdulat: a hozzá rendelt funkció indul. */
    private fun onTrigger(t: Trigger) {
        val f = Settings.featureFor(this, t) ?: return
        if (t == Trigger.SHAKE_FILL) {
            // Futó funkció közben a rázás a funkcióé (pl. az Előadás szünete), nem indít újat
            if (job?.isActive == true) return
            startWithFill(f)
            return
        }
        haptics.tick()
        toggle(f)
    }

    /** Rázás-töltés: az első rázás után a további rázásokat gyűjti, a funkció a töltés végén indul. */
    private fun startWithFill(f: Feature) {
        val ch = Channel<Long>(64)
        fillEvents = ch
        fillCollector?.cancel()
        motion.setGameMode(true) // gyors gyorsulásmérő: ettől jönnek a rázás-események
        fillCollector = scope.launch { merge(motion.shakeEvents, GlyphMirror.taps).collect { ch.trySend(it) } }
        pendingFill = true
        DebugState.log("Rázás-töltés indul: ${f.title}")
        toggle(f)
        if (job?.isActive != true) endFill()
    }

    private fun endFill() {
        pendingFill = false
        fillCollector?.cancel()
        fillCollector = null
        fillEvents = null
    }

    /** Ha ez a funkció fut, leállítja; ha nem, elindítja. */
    private fun toggle(f: Feature) {
        if (job?.isActive == true && GlyphMirror.mode.value == f) {
            DebugState.log("${f.title} leállítva")
            job?.cancel()
            return
        }
        when (f) {
            Feature.SIMON -> startGame()
            Feature.SPIN -> startSpin()
            Feature.COMPASS -> startCompass()
            Feature.LOCKPICK -> startLockPick()
            Feature.SAFE -> startSafe()
            Feature.PET -> startPet()
            Feature.LEVEL -> startLevel()
            Feature.TIMER -> startTimer()
            Feature.BALANCE -> startBalance()
            Feature.DINO -> startDino()
            Feature.LECTURE -> startLecture()
            Feature.BLOW -> startBlow()
        }
    }

    /** Megvárja, hogy kijelzővel lefelé (szimulációban felfelé is) letedd. */
    private suspend fun waitPlaced(what: String, timeoutMs: Long): Boolean {
        if (motion.faceDown.value) return true
        setStatus("Tedd le kijelzővel lefelé – $what")
        val placed = withTimeoutOrNull(timeoutMs) { motion.faceDown.first { it } } != null
        if (placed) delay(Config.SPIN_SETTLE_MS)
        return placed
    }

    private fun showIdle() {
        val text = if (watching) {
            val parts = Feature.entries.mapNotNull { f ->
                val t = Settings.trigger(this, f)
                if (t == Trigger.NONE) null else "${f.title}: ${t.title}"
            }
            if (parts.isEmpty()) "Figyel – nincs kiosztott mozdulat" else "Figyel · " + parts.joinToString(" · ")
        } else {
            IDLE_TEXT
        }
        DebugState.status.value = text
        updateNotification(text)
    }

    private fun setStatus(text: String) {
        DebugState.status.value = text
        updateNotification(text)
    }

    /** Közös keret: Glyph session megnyitása (ha lehet), a feladat futtatása, utána takarítás. */
    private fun launchWithGlyph(feature: Feature, status: String, block: suspend () -> Unit) {
        if (job?.isActive == true) {
            DebugState.log("Már fut egy funkció, előbb az fejeződjön be")
            return
        }
        job = scope.launch {
            val outer = this
            EnergyMeter.begin(feature)
            // Leállítási parancsok figyelése (bekapcsoló gomb, felemelés, …)
            val stopper = launch {
                val how = awaitStop(feature)
                DebugState.log("${feature.title} leállítva: ${how.title}")
                haptics.tick()
                outer.cancel()
            }
            // A telefon teljes áramfelvételének mérése futás közben (tájékoztató)
            val meter = launch {
                while (true) {
                    delay(Config.MEASURE_EVERY_MS)
                    EnergyMeter.measureNow(this@SimonService)?.let { EnergyMeter.addMeasured(feature, it, Config.MEASURE_EVERY_MS) }
                }
            }
            try {
                GlyphMirror.mode.value = feature
                Settings.setLastFeature(this@SimonService, feature)
                refreshTiles()
                Widgets.updateAll(this@SimonService)
                // Közvetlenül indulás után a Glyph szolgáltatásnak kell egy kis idő
                withTimeoutOrNull(2_000) { while (!glyph.connected) delay(100) }
                if (!glyph.openSession()) {
                    DebugState.log("Nincs Glyph-kapcsolat – csak a képernyőn látszik (szimuláció)")
                }
                if (pendingFill) {
                    val ch = fillEvents
                    val needed = Settings.shakeFillCount(this@SimonService)
                    setStatus("Rázd, amíg minden LED ég (0/$needed)")
                    val ok = ch != null && ShakeFill(glyph, haptics, needed).run(ch, 1) { setStatus(it) }
                    endFill()
                    if (!ok) return@launch
                    filledByTrigger = true
                }
                setStatus(status)
                block()
            } finally {
                endFill()
                stopper.cancel()
                meter.cancel()
                glyph.closeSession()
                EnergyMeter.end(feature)
                motion.setGameMode(false)
                GlyphMirror.mode.value = null
                refreshTiles()
                Widgets.updateAll(this@SimonService)
                showIdle()
                if (!watching) stopSelf()
            }
        }
    }

    /** Megvárja, hogy a beállított leállítási parancsok egyike megtörténjen, és visszaadja, melyik. */
    private suspend fun awaitStop(f: Feature): StopMethod = coroutineScope {
        var methods = Settings.stopMethods(this@SimonService, f)
        // Ha a Dínó a bekapcsoló gombbal ugrik, az nem állíthatja le egyben a játékot
        if (f == Feature.DINO && DinoJump.POWER in Settings.dinoJump(this@SimonService)) methods = methods - StopMethod.POWER
        val result = CompletableDeferred<StopMethod>()
        delay(Config.STOP_START_GRACE_MS)
        val watchers = methods.map { m ->
            launch {
                watchStop(m)
                result.complete(m)
            }
        }
        try {
            result.await()
        } finally {
            watchers.forEach { it.cancel() }
        }
    }

    private suspend fun watchStop(m: StopMethod) {
        when (m) {
            StopMethod.POWER -> screenOn.first()

            StopMethod.LIFT -> {
                // Előbb le kell tenni; utána ha 2 mp-ig nincs letéve, leáll
                motion.faceDown.first { it }
                while (true) {
                    motion.faceDown.first { !it }
                    val back = withTimeoutOrNull(Config.STOP_LIFT_MS) { motion.faceDown.first { it } }
                    if (back == null) return
                }
            }

            StopMethod.FLIP_UP -> {
                // Előbb valóban kijelzővel lefelé kell feküdnie; utána 1 mp kijelzővel felfelé
                motion.reallyDown.first { it }
                while (true) {
                    motion.faceUp.first { it }
                    if (GlyphMirror.simulatorOpen) {
                        motion.faceUp.first { !it }
                        continue
                    }
                    val turnedBack = withTimeoutOrNull(Config.STOP_FLIP_MS) { motion.faceUp.first { !it } }
                    if (turnedBack == null) return
                }
            }

            StopMethod.SHAKE -> {
                var last = 0L
                motion.shakeEvents.first { t ->
                    val hit = last != 0L && t - last <= Config.STOP_SHAKE_WINDOW_MS
                    last = t
                    hit
                }
            }

            StopMethod.KNOCK_3 -> coroutineScope {
                val ch = Channel<Long>(16)
                val c = launch { motion.knockEvents.collect { ch.trySend(it) } }
                try {
                    var n = 0
                    while (true) {
                        val t = if (n == 0) ch.receive() else withTimeoutOrNull(Config.KNOCK_MAX_GAP_MS) { ch.receive() }
                        if (t == null) {
                            if (n == 3) break
                            n = 0
                        } else {
                            n++
                        }
                    }
                } finally {
                    c.cancel()
                }
            }
        }
    }

    private fun startGame() = launchWithGlyph(Feature.SIMON, "Simon játék folyamatban") {
        motion.setGameMode(true)
        val level = SimonGame(glyph, motion, haptics).run()
        Settings.setLastLevel(this, level)
        DebugState.log("Játék vége – elért szint: $level/${Config.MAX_ROUNDS}")
    }

    private fun startSpin() = launchWithGlyph(Feature.SPIN, "Pörgetés") {
        if (!motion.faceDown.value) {
            setStatus("Tedd le kijelzővel lefelé a pörgetéshez")
            val placed = withTimeoutOrNull(Config.SPIN_PLACE_TIMEOUT_MS) { motion.faceDown.first { it } }
            if (placed == null) DebugState.log("Nem tetted le – pörgetés így is indul")
            delay(Config.SPIN_SETTLE_MS)
        }
        setStatus("Pörgetés")
        motion.setGameMode(true) // ébren tartja a telefont, és szünetelteti a mozdulatfigyelést
        SpinWheel(glyph, haptics).run()
    }

    private fun startCompass() {
        launchWithGlyph(Feature.COMPASS, "Iránytű") {
            compassOn = true
            refreshTiles()
            try {
                motion.setGameMode(true) // ébren tartja a telefont, gyorsan figyeli a felemelést
                Compass(this, glyph, motion, haptics) { text -> setStatus(text) }.run()
            } finally {
                compassOn = false
                CompassState.clear(this@SimonService)
                refreshTiles()
            }
        }
    }

    private fun startLockPick() = launchWithGlyph(Feature.LOCKPICK, "Zárfeltörő") {
        if (!waitPlaced("a zárfeltöréshez", Config.SPIN_PLACE_TIMEOUT_MS)) DebugState.log("Nem tetted le – a kopogás csak fekve működik, de a képernyős érintés igen")
        setStatus("Zárfeltörő – kopogj, amikor a fény az édes ponton jár")
        motion.setGameMode(true)
        val pins = LockPick(glyph, motion, haptics).run()
        if (pins > Settings.lockBest(this)) Settings.setLockBest(this, pins)
        DebugState.log("Zárfeltörő vége: $pins/${Config.LOCK_PINS} tüske")
    }

    private fun startSafe() = launchWithGlyph(Feature.SAFE, "Széf") {
        if (!Settings.safeUsesShake(this)) waitPlaced("a széf kopogásos kódjához", Config.SPIN_PLACE_TIMEOUT_MS)
        motion.setGameMode(true)
        val open = SafeLock(this, glyph, motion, haptics) { text -> setStatus(text) }.run()
        if (open) {
            withContext(Dispatchers.Main) { SafeOpener.open(this@SimonService) }
        }
    }

    private fun startPet() = launchWithGlyph(Feature.PET, "Glyph Tojás") {
        PetAlarmReceiver.schedule(this)
        if (!waitPlaced("a Tojás gondozásához", 20_000L)) {
            DebugState.log("Nem tetted le – a Tojás alszik tovább")
            return@launchWithGlyph
        }
        motion.setGameMode(true)
        PetSession(this, glyph, motion, haptics) { text -> setStatus(text) }.run()
    }

    private fun startLevel() = launchWithGlyph(Feature.LEVEL, "Vízmérték") {
        // Bármilyen helyzetben működik: fekve, élére állítva vagy töltőporton állva
        motion.setGameMode(true)
        LevelTool(this, glyph, motion, haptics) { text -> setStatus(text) }.run()
    }

    private fun startTimer() = launchWithGlyph(Feature.TIMER, "Időzítő") {
        waitPlaced("az időzítőhöz", 10_000L)
        motion.setGameMode(true)
        val timer = FocusTimer(this, glyph, motion, haptics) { text -> setStatus(text) }
        // Hosszú lehet: a teljes időre (+10 perc) ébren tartja a telefont
        motion.holdAwake(timer.totalMs() + 10 * 60_000L)
        timer.run()
    }

    /**
     * Fújós: a fújást a Fújós oldal mikrofonja érzékeli (háttérből a mikrofon nem használható),
     * ezért ha az oldal nincs nyitva, előbb azt nyitja meg; az oldal indítja el a játékot.
     */
    private fun startBlow() {
        if (!BlowInput.active) {
            BlowLauncher.open(this)
            return
        }
        launchWithGlyph(Feature.BLOW, "Fújós") {
            BlowGame(this, glyph, haptics) { text -> setStatus(text) }.run()
        }
    }

    private fun startLecture() {
        // Az indítás módját most kell kiolvasni: a feladat később, a háttérben fut
        val instant = lectureInstant
        startLectureJob(instant)
    }

    private fun startLectureJob(instant: Boolean) = launchWithGlyph(Feature.LECTURE, "Előadás") {
        // Widgetről azonnal: nem vár a lerakásra, és nincs rázós töltés
        if (!instant) waitPlaced("az előadás-időzítőhöz", 15_000L)
        motion.setGameMode(true)
        val prefilled = filledByTrigger || instant
        filledByTrigger = false
        if (instant) DebugState.log("Előadás: widgetről, azonnal indul (rázás nélkül)")
        val lecture = LectureTimer(this, glyph, motion, haptics, prefilled) { text -> setStatus(text) }
        // Közel két óra: a teljes időre (+15 perc) ébren tartja a processzort
        motion.holdAwake(lecture.totalMs() + 15 * 60_000L)
        lecture.run()
    }

    private fun startBalance() = launchWithGlyph(Feature.BALANCE, "Egyensúly") {
        waitPlaced("az Egyensúlyhoz (vagy tartsd vízszintesen)", 8_000L)
        setStatus("Egyensúly – döntéssel tartsd a pontot a sávon")
        motion.setGameMode(true)
        val secs = BalanceGame(glyph, motion, haptics).run()
        if (secs > Settings.balanceBest(this)) Settings.setBalanceBest(this, secs)
        DebugState.log("Egyensúly vége: $secs mp")
    }

    private fun startDino() = launchWithGlyph(Feature.DINO, "Dínófutás") {
        val jumpSet = Settings.dinoJump(this)
        // Kopogással fekve kell játszani; rázással és gombokkal kézben is jó
        if (DinoJump.KNOCK in jumpSet) waitPlaced("a Dínófutáshoz", Config.SPIN_PLACE_TIMEOUT_MS)
        val keys = if (DinoJump.VOL_UP in jumpSet || DinoJump.VOL_DOWN in jumpSet) {
            VolumeKeys(this) { dir -> volumeKeys.tryEmit(dir) }.also { it.start() }
        } else null
        try {
            val inputs = mutableListOf<Flow<Long>>()
            if (DinoJump.KNOCK in jumpSet) inputs += motion.knockEvents
            if (DinoJump.SHAKE in jumpSet) inputs += motion.shakeHits
            if (DinoJump.VOL_UP in jumpSet) inputs += volumeKeys.filter { it > 0 }.map { SystemClock.elapsedRealtime() }
            if (DinoJump.VOL_DOWN in jumpSet) inputs += volumeKeys.filter { it < 0 }.map { SystemClock.elapsedRealtime() }
            if (DinoJump.POWER in jumpSet) inputs += powerPresses
            setStatus("Dínófutás – ugrás: " + jumpSet.joinToString(", ") { it.title } + "; villogó madár fölött ne ugorj!")
            motion.setGameMode(true)
            val score = DinoGame(glyph, motion, haptics, inputs.merge()).run()
            if (score > Settings.dinoBest(this)) Settings.setDinoBest(this, score)
            DebugState.log("Dínófutás vége: $score pont")
        } finally {
            keys?.stop()
        }
    }

    override fun onDestroy() {
        try {
            unregisterReceiver(screenReceiver)
            unregisterReceiver(volumeReceiver)
        } catch (t: Throwable) {
            // nem volt regisztrálva
        }
        EnergyMeter.setWatching(false)
        EnergyMeter.flush()
        scope.cancel()
        motion.stop()
        glyph.release()
        watching = false
        compassOn = false
        GlyphMirror.mode.value = null
        refreshTiles()
        Widgets.updateAll(this)
        DebugState.status.value = "Leállítva"
        DebugState.log("Szolgáltatás leállt")
        super.onDestroy()
    }

    override fun onBind(intent: Intent?): IBinder? = null

    private fun refreshTiles() {
        for (cls in listOf(
            SimonTileService::class.java, SpinTileService::class.java, CompassTileService::class.java,
            LockTileService::class.java, SafeTileService::class.java, PetTileService::class.java,
            LevelTileService::class.java, TimerTileService::class.java, BalanceTileService::class.java,
            DinoTileService::class.java, LectureTileService::class.java
        )) {
            TileService.requestListeningState(this, ComponentName(this, cls))
        }
    }

    private fun createChannel() {
        val channel = NotificationChannel(CHANNEL_ID, "Glyph Eggs", NotificationManager.IMPORTANCE_LOW)
        getSystemService(NotificationManager::class.java).createNotificationChannel(channel)
    }

    private fun buildNotification(text: String): Notification {
        val open = PendingIntent.getActivity(
            this, 0, Intent(this, MainActivity::class.java),
            PendingIntent.FLAG_IMMUTABLE
        )
        val stop = PendingIntent.getService(
            this, 1, Intent(this, SimonService::class.java).setAction(ACTION_STOP),
            PendingIntent.FLAG_IMMUTABLE
        )
        return Notification.Builder(this, CHANNEL_ID)
            .setSmallIcon(R.drawable.ic_tile)
            .setContentTitle("Glyph Eggs")
            .setContentText(text)
            .setOngoing(true)
            .setContentIntent(open)
            .addAction(Notification.Action.Builder(null as Icon?, "Leállítás", stop).build())
            .build()
    }

    private fun updateNotification(text: String) {
        getSystemService(NotificationManager::class.java).notify(NOTIF_ID, buildNotification(text))
    }
}
