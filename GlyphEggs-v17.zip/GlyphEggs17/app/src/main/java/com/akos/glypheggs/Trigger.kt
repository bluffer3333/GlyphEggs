package com.akos.glypheggs

import android.content.Context

/** Az indítható funkciók. [game] = a Játékok fülön van, különben az Eszközök fülön. */
enum class Feature(val title: String, val short: String, val icon: Int, val game: Boolean) {
    SIMON("Glyph Simon", "Simon", R.drawable.ic_play, true),
    SPIN("Pörgetés", "Pörgetés", R.drawable.ic_spin, false),
    COMPASS("Iránytű", "Iránytű", R.drawable.ic_compass, false),
    LOCKPICK("Zárfeltörő", "Zár", R.drawable.ic_lock, true),
    SAFE("Széf", "Széf", R.drawable.ic_safe, false),
    PET("Glyph Tojás", "Tojás", R.drawable.ic_pet, true),
    LEVEL("Vízmérték", "Vízmérték", R.drawable.ic_level, false),
    TIMER("Időzítő", "Időzítő", R.drawable.ic_timer, false),
    BALANCE("Egyensúly", "Egyensúly", R.drawable.ic_balance, true),
    DINO("Dínófutás", "Dínó", R.drawable.ic_dino, true),
    LECTURE("Előadás", "Előadás", R.drawable.ic_lecture, false),
    BLOW("Fújós", "Fújós", R.drawable.ic_wind, true)
}

/**
 * Indító mozdulatok. Bármelyik bármelyik funkcióhoz rendelhető,
 * de egy mozdulat egyszerre csak egy funkcióhoz tartozhat.
 */
enum class Trigger(val title: String, val hint: String) {
    NONE("Nincs", "Csak csempével vagy az appból indul"),
    RIGHT_2("Jobbra forgatás 2×", "Fekve kétszer kb. negyed fordulat jobbra"),
    LEFT_2("Balra forgatás 2×", "Fekve kétszer kb. negyed fordulat balra"),
    RIGHT_LEFT("Jobbra, majd balra", "Fekve negyed fordulat jobbra, aztán vissza balra"),
    LEFT_RIGHT("Balra, majd jobbra", "Fekve negyed fordulat balra, aztán vissza jobbra"),
    SPIN("Megpörgetés", "Pörgesd meg az asztalon legalább egy teljes körre"),
    KNOCK_2("Kopogás 2×", "Fekve kopogtass kétszer gyorsan a telefonon"),
    KNOCK_3("Kopogás 3×", "Fekve kopogtass háromszor gyorsan a telefonon"),
    SHAKE("Rázás, majd lerakás", "Rázd meg, és 6 mp-en belül tedd le kijelzővel lefelé"),
    FLIP_2("Lefordítás 2×", "Kijelzővel felfelé → lefelé, kétszer egymás után"),
    SHAKE_FILL("Rázás-töltés", "Rázd a telefont: a LED-ek alulról (töltőport) felfelé gyulladnak, és ha mind ég, elindul a funkció. A rázások száma állítható. Ne használd együtt a „Rázás, majd lerakás” mozdulattal."),
    VOL_UP_2("Hangerő fel 2×", "Nyomd meg kétszer gyorsan a hangerő-növelő gombot. Bekapcsolt (akár zárolt) képernyőnél megy; kikapcsolt képernyőnél csak, ha épp szól valami. A hangerő utána visszaáll. Max. hangerőnél nem érzékelhető"),
    VOL_DOWN_2("Hangerő le 2×", "Nyomd meg kétszer gyorsan a hangerő-csökkentő gombot. Bekapcsolt (akár zárolt) képernyőnél megy; kikapcsolt képernyőnél csak, ha épp szól valami. A hangerő utána visszaáll. Némításnál nem érzékelhető"),
    ROLL_3("Hengerítés 3×", "Két kézben, fekvő helyzetben magad előtt (töltőport a jobb kezed felé): forgasd 3-szor körbe a hosszanti tengelye körül, mint egy sodrófát");

    /** Forgatással (giroszkóppal) felismert mozdulat-e. */
    val usesGyro: Boolean
        get() = this == RIGHT_2 || this == LEFT_2 || this == RIGHT_LEFT || this == LEFT_RIGHT || this == SPIN

    val isKnock: Boolean
        get() = this == KNOCK_2 || this == KNOCK_3
}

/**
 * Leállítási parancsok: futás közben mivel lehessen leállítani egy funkciót.
 * Funkciónként több is bekapcsolható. A csempe, a widget, az értesítés „Leállítás” gombja
 * és az app „Most fut” kártyája ezen felül mindig működik.
 */
enum class StopMethod(val title: String, val hint: String) {
    POWER("Bekapcsoló gomb", "Nyomd meg egyszer, amikor a képernyő ki van kapcsolva (lefelé fekvő telefonnál ez a megszokott). Ha épp be van kapcsolva, nyomd meg kétszer."),
    LIFT("Felemelés", "Vedd fel az asztalról, és tartsd a kezedben 2 mp-ig"),
    FLIP_UP("Megfordítás", "Fordítsd kijelzővel felfelé, és hagyd így 1 mp-ig"),
    SHAKE("Erős rázás", "Rázd meg erősen kétszer, kb. 3 mp-en belül"),
    KNOCK_3("Kopogás 3×", "Fekve kopogtass háromszor gyorsan a telefonon");

    /** Miért nem választható ennél a funkciónál (null = választható). */
    fun blockedFor(f: Feature): String? = when (this) {
        POWER -> null
        LIFT -> when (f) {
            Feature.SIMON -> "A Simonban kézben is döntheted a telefont"
            Feature.SAFE -> "A kódot kézben, rázással adod meg"
            Feature.LEVEL -> "A vízmérték élére és portra állítva is mér"
            Feature.BALANCE -> "Az Egyensúly kézben is játszható"
            Feature.LECTURE -> "Az előadás alatt időnként kézbe veszed a telefont – az nem állíthatja le"
            Feature.BLOW -> "A Fújósnál a kezedben tartod a telefont"
            else -> null
        }
        FLIP_UP -> if (f == Feature.LEVEL) "A vízmérték fekve bármelyik oldalán mér" else null
        SHAKE -> when (f) {
            Feature.SAFE -> "A Széf kódját rázással adod meg"
            Feature.PET -> "A rázás a Tojás egyik játéka"
            Feature.LECTURE -> "A rázás tölti fel az előadást, és indíthatja a szünetet"
            else -> null
        }
        KNOCK_3 -> when (f) {
            Feature.LOCKPICK, Feature.DINO -> "Ebben a játékban kopogással irányítasz"
            Feature.SAFE -> "A Széf kódja kopogással is megadható"
            Feature.PET -> "A Tojást kopogással gondozod"
            Feature.LEVEL -> "A vízmérték kopogással kalibrál"
            Feature.TIMER -> "Az időzítőt kopogással vezérled"
            Feature.LECTURE -> "A kopogás az indításra és a szünetre van fenntartva"
            else -> null
        }
    }

    /** Ezt a funkció magától is tudja (mindig be van kapcsolva). */
    fun builtInFor(f: Feature): Boolean =
        this == LIFT && (f == Feature.COMPASS || f == Feature.PET)
}

/** Az előadás-időzítő indítása (töltése): mivel kell „feltölteni”, hogy elinduljon. */
enum class LectureStart(val title: String, val hint: String) {
    SHAKE("Rázás", "Rázd a telefont: a LED-ek alulról (töltőport) felfelé gyulladnak, és ha mind ég, indul"),
    KNOCK("Kopogás", "Kopogtass az asztalon fekvő telefonon: minden kopogásra feljebb mennek a LED-ek, és ha mind ég, indul"),
    INSTANT("Azonnal", "Nincs töltés: az indítás után rögtön indul az előadás")
}

/** Az előadás közbeni szünet indítása (és, ha engedélyezett, korai befejezése). */
enum class BreakCommand(val title: String, val hint: String) {
    SHAKE("Rázás kétszer", "Rázd meg kétszer, kb. 3 mp-en belül"),
    KNOCK_3("Kopogás 3×", "Fekve kopogtass háromszor gyorsan a telefonon"),
    NONE("Nincs", "Nem indul szünet; az előadás megszakítás nélkül megy")
}

/** Mivel lehet ugrani a Dínófutásban (több is bekapcsolható). */
enum class DinoJump(val title: String, val hint: String) {
    KNOCK("Kopogás", "Kopogtass a fekvő telefonon (a kopogás érzékenysége az Indítás és leállítás oldalon állítható)"),
    SHAKE("Rázás", "Egy erős rázás / rántás – kézben is játszható"),
    VOL_UP("Hangerő fel gomb", "Nyomd meg a hangerő-növelő gombot. Kísérleti: a játék alatt a hangerő-gombok nem a hangerőt állítják"),
    VOL_DOWN("Hangerő le gomb", "Nyomd meg a hangerő-csökkentő gombot. Kísérleti: a játék alatt a hangerő-gombok nem a hangerőt állítják"),
    POWER("Bekapcsoló gomb", "Minden gombnyomás ugrás (a képernyő közben ki-be kapcsolhat). Ilyenkor a bekapcsoló gombos leállítás nem működik")
}

/** Mentett beállítások egy helyen. */
object Settings {
    private const val PREFS = "glyph_eggs"
    private const val KEY_WATCHING = "enabled"
    private const val KEY_VIBRATE = "vibrate"
    private const val KEY_KNOCK_SENS = "knock_sensitivity"
    private const val KEY_LAST_LEVEL = "last_level"

    private fun p(c: Context) = c.getSharedPreferences(PREFS, Context.MODE_PRIVATE)

    private fun key(f: Feature) = "trigger_${f.name}"

    fun defaultTrigger(f: Feature): Trigger = when (f) {
        Feature.SIMON -> Trigger.RIGHT_2
        Feature.SPIN -> Trigger.SPIN
        Feature.COMPASS -> Trigger.KNOCK_2
        Feature.LOCKPICK -> Trigger.NONE
        Feature.SAFE -> Trigger.NONE
        Feature.PET -> Trigger.NONE
        Feature.LEVEL -> Trigger.NONE
        Feature.TIMER -> Trigger.NONE
        Feature.BALANCE -> Trigger.NONE
        Feature.DINO -> Trigger.NONE
        Feature.LECTURE -> Trigger.SHAKE_FILL
        Feature.BLOW -> Trigger.NONE
    }

    fun trigger(c: Context, f: Feature): Trigger {
        val name = p(c).getString(key(f), null) ?: return defaultTrigger(f)
        return Trigger.entries.firstOrNull { it.name == name } ?: defaultTrigger(f)
    }

    /** Beállítja a mozdulatot; ha másik funkció használta, ott "Nincs" lesz. */
    fun setTrigger(c: Context, f: Feature, t: Trigger) {
        val e = p(c).edit()
        if (t != Trigger.NONE) {
            for (other in Feature.entries) {
                if (other != f && trigger(c, other) == t) e.putString(key(other), Trigger.NONE.name)
            }
        }
        e.putString(key(f), t.name)
        e.apply()
    }

    /** Melyik funkció indul erre a mozdulatra (ha van). */
    fun featureFor(c: Context, t: Trigger): Feature? =
        if (t == Trigger.NONE) null else Feature.entries.firstOrNull { trigger(c, it) == t }

    fun activeTriggers(c: Context): Set<Trigger> =
        Feature.entries.filter { armed(c, it) }.map { trigger(c, it) }.filter { it != Trigger.NONE }.toSet()

    /**
     * Élesítve van-e a funkció indító mozdulata (a widget „FIGYEL / RÁZÁS: BE-KI” gombja ezt kapcsolja).
     * Kikapcsolva a mozdulat megmarad, csak nem figyeli.
     */
    fun armed(c: Context, f: Feature): Boolean = p(c).getBoolean("armed_${f.name}", true)
    fun setArmed(c: Context, f: Feature, v: Boolean) = p(c).edit().putBoolean("armed_${f.name}", v).apply()
    /** A widget kapcsolta be a mozdulatfigyelést (így ha ott kikapcsolod, a figyelés is leállhat). */
    fun watchByWidget(c: Context): Boolean = p(c).getBoolean("watch_by_widget", false)
    fun setWatchByWidget(c: Context, v: Boolean) = p(c).edit().putBoolean("watch_by_widget", v).apply()
    /** Figyel-e most a funkció indító mozdulatára. */
    fun listening(c: Context, f: Feature): Boolean =
        watching(c) && armed(c, f) && trigger(c, f) != Trigger.NONE

    // --- Leállítási parancsok ---
    /** Alapból a bekapcsoló gomb mindenhol leállít, kivéve az Időzítőt és az Előadást (azokat hosszan futtatod, közben nézheted a telefont). */
    fun defaultStops(f: Feature): Set<StopMethod> =
        if (f == Feature.TIMER || f == Feature.LECTURE) emptySet() else setOf(StopMethod.POWER)

    fun stopMethods(c: Context, f: Feature): Set<StopMethod> {
        val raw = p(c).getString("stop_${f.name}", null) ?: return defaultStops(f)
        return raw.split(",").mapNotNull { n -> StopMethod.entries.firstOrNull { it.name == n } }
            .filter { it.blockedFor(f) == null }.toSet()
    }

    fun setStopMethod(c: Context, f: Feature, m: StopMethod, on: Boolean) {
        val cur = stopMethods(c, f).toMutableSet()
        if (on) cur += m else cur -= m
        p(c).edit().putString("stop_${f.name}", cur.joinToString(",") { it.name }).apply()
    }

    /** Rövid felsorolás a felülethez, pl. „Bekapcsoló gomb, Felemelés”. */
    fun stopSummary(c: Context, f: Feature): String {
        val list = StopMethod.entries.filter { it in stopMethods(c, f) || it.builtInFor(f) }
        return if (list.isEmpty()) "Csak csempe / widget / app" else list.joinToString(", ") { it.title }
    }

    fun watching(c: Context): Boolean = p(c).getBoolean(KEY_WATCHING, false)
    fun setWatching(c: Context, on: Boolean) = p(c).edit().putBoolean(KEY_WATCHING, on).apply()

    fun vibrate(c: Context): Boolean = p(c).getBoolean(KEY_VIBRATE, true)
    fun setVibrate(c: Context, on: Boolean) = p(c).edit().putBoolean(KEY_VIBRATE, on).apply()

    /** Rázás érzékenysége: 0 = alacsony, 1 = közepes (alap), 2 = magas, 3 = nagyon magas. */
    fun shakeSensitivity(c: Context): Int = p(c).getInt("shake_sens", 1).coerceIn(0, 3)
    fun setShakeSensitivity(c: Context, v: Int) = p(c).edit().putInt("shake_sens", v.coerceIn(0, 3)).apply()
    /** A rázás-küszöbök szorzója az érzékenység szerint. */
    fun shakeFactor(c: Context): Float = Config.SHAKE_SENS_FACTORS[shakeSensitivity(c)]

    /** 0 = alacsony, 1 = közepes, 2 = magas. */
    fun knockSensitivity(c: Context): Int = p(c).getInt(KEY_KNOCK_SENS, 1).coerceIn(0, 2)
    fun setKnockSensitivity(c: Context, v: Int) = p(c).edit().putInt(KEY_KNOCK_SENS, v.coerceIn(0, 2)).apply()

    fun lastLevel(c: Context): Int = p(c).getInt(KEY_LAST_LEVEL, -1)
    fun setLastLevel(c: Context, v: Int) = p(c).edit().putInt(KEY_LAST_LEVEL, v).apply()

    // --- Zárfeltörő ---
    fun lockBest(c: Context): Int = p(c).getInt("lock_best", 0)
    fun setLockBest(c: Context, v: Int) = p(c).edit().putInt("lock_best", v).apply()

    // --- Széf ---
    /** A kód: 4 pozíció (0–7) a [SafePositions] listából. */
    fun safeCode(c: Context): IntArray {
        val raw = p(c).getString("safe_code", null) ?: return intArrayOf(0, 3, 5, 7)
        val parts = raw.split(",").mapNotNull { it.trim().toIntOrNull() }.filter { it in 0..7 }
        return if (parts.size == SafePositions.CODE_LENGTH) parts.toIntArray() else intArrayOf(0, 3, 5, 7)
    }
    fun setSafeCode(c: Context, code: IntArray) = p(c).edit().putString("safe_code", code.joinToString(",")).apply()

    /** Mivel kell kiválasztani a villanást: true = rázás, false = kopogás. */
    fun safeUsesShake(c: Context): Boolean = p(c).getBoolean("safe_shake", true)
    fun setSafeUsesShake(c: Context, v: Boolean) = p(c).edit().putBoolean("safe_shake", v).apply()

    /** Mi nyíljon meg: NOTES (titkos jegyzetek), FOLDER, APP, URL, NONE. */
    fun safeTargetType(c: Context): String = p(c).getString("safe_target_type", null) ?: "NOTES"
    fun safeTargetValue(c: Context): String = p(c).getString("safe_target_value", null) ?: ""
    fun safeTargetLabel(c: Context): String = p(c).getString("safe_target_label", null) ?: ""
    fun setSafeTarget(c: Context, type: String, value: String, label: String) = p(c).edit()
        .putString("safe_target_type", type).putString("safe_target_value", value)
        .putString("safe_target_label", label).apply()

    fun secretNotes(c: Context): String = p(c).getString("secret_notes", null) ?: ""
    fun setSecretNotes(c: Context, v: String) = p(c).edit().putString("secret_notes", v).apply()

    // --- Glyph Tojás ---
    fun petNotifications(c: Context): Boolean = p(c).getBoolean("pet_notif", true)
    fun setPetNotifications(c: Context, v: Boolean) = p(c).edit().putBoolean("pet_notif", v).apply()

    // --- Felület: kitűzött funkciók (Főoldal) és a választott fül ---
    private val DEFAULT_PINNED = listOf(Feature.COMPASS, Feature.SPIN, Feature.SIMON, Feature.SAFE)

    fun pinned(c: Context): List<Feature> {
        val raw = p(c).getString("pinned", null) ?: return DEFAULT_PINNED
        return raw.split(",").mapNotNull { n -> Feature.entries.firstOrNull { it.name == n } }
    }
    fun setPinned(c: Context, list: List<Feature>) =
        p(c).edit().putString("pinned", list.joinToString(",") { it.name }).apply()
    fun togglePinned(c: Context, f: Feature): Boolean {
        val cur = pinned(c).toMutableList()
        val nowPinned = if (f in cur) { cur.remove(f); false } else { cur.add(f); true }
        setPinned(c, cur)
        return nowPinned
    }

    fun tab(c: Context): Int = p(c).getInt("tab", 0)
    fun setTab(c: Context, v: Int) = p(c).edit().putInt("tab", v).apply()

    // --- Vízmérték kalibráció (fokban), helyzetenként: "flat_x", "flat_y", "edge", "port" ---
    fun levelOffset(c: Context, key: String): Float = p(c).getFloat("level_$key", 0f)
    fun setLevelOffset(c: Context, key: String, v: Float) = p(c).edit().putFloat("level_$key", v).apply()

    // --- Utoljára indított funkció (a Főoldal "Újra" kártyájához) ---
    fun lastFeature(c: Context): Feature? =
        Feature.entries.firstOrNull { it.name == p(c).getString("last_feature", null) }
    fun setLastFeature(c: Context, f: Feature) = p(c).edit().putString("last_feature", f.name).apply()

    // --- Dínófutás: ugrás-bemenetek ---
    fun dinoJump(c: Context): Set<DinoJump> {
        val raw = p(c).getString("dino_jump", null) ?: return setOf(DinoJump.KNOCK)
        val set = raw.split(",").mapNotNull { n -> DinoJump.entries.firstOrNull { it.name == n } }.toSet()
        return if (set.isEmpty()) setOf(DinoJump.KNOCK) else set
    }
    fun setDinoJump(c: Context, m: DinoJump, on: Boolean) {
        val cur = dinoJump(c).toMutableSet()
        if (on) cur += m else cur -= m
        if (cur.isEmpty()) cur += DinoJump.KNOCK // legalább egy bemenet kell
        p(c).edit().putString("dino_jump", cur.joinToString(",") { it.name }).apply()
    }

    // --- Dínófutás ---
    fun dinoBest(c: Context): Int = p(c).getInt("dino_best", 0)
    fun setDinoBest(c: Context, v: Int) = p(c).edit().putInt("dino_best", v).apply()

    // --- Időzítő ---
    fun timerMode(c: Context): TimerMode =
        TimerMode.entries.firstOrNull { it.name == p(c).getString("timer_mode", null) } ?: TimerMode.POMODORO
    fun setTimerMode(c: Context, m: TimerMode) = p(c).edit().putString("timer_mode", m.name).apply()
    fun timerStyle(c: Context): TimerStyle =
        TimerStyle.entries.firstOrNull { it.name == p(c).getString("timer_style", null) } ?: TimerStyle.SAND
    fun setTimerStyle(c: Context, s: TimerStyle) = p(c).edit().putString("timer_style", s.name).apply()
    /** Az egyszeri időzítő és a homokóra hossza percben. */
    fun timerMinutes(c: Context): Int = p(c).getInt("timer_minutes", 10)
    fun setTimerMinutes(c: Context, v: Int) = p(c).edit().putInt("timer_minutes", v).apply()

    // --- Előadás ---
    /** Hány részből áll az előadás (alap: 2). */
    fun lectureBlocks(c: Context): Int = p(c).getInt("lec_blocks", 2).coerceIn(1, 4)
    fun setLectureBlocks(c: Context, v: Int) = p(c).edit().putInt("lec_blocks", v.coerceIn(1, 4)).apply()
    /** Egy rész hossza percben (alap: 45). */
    fun lectureBlockMin(c: Context): Int = p(c).getInt("lec_block_min", Config.LECTURE_BLOCK_MIN).coerceIn(5, 180)
    fun setLectureBlockMin(c: Context, v: Int) = p(c).edit().putInt("lec_block_min", v.coerceIn(5, 180)).apply()
    /** A szünet hossza percben (alap: 15). */
    fun lectureBreakMin(c: Context): Int = p(c).getInt("lec_break_min", Config.LECTURE_BREAK_MIN).coerceIn(1, 60)
    fun setLectureBreakMin(c: Context, v: Int) = p(c).edit().putInt("lec_break_min", v.coerceIn(1, 60)).apply()

    fun lectureStart(c: Context): LectureStart =
        LectureStart.entries.firstOrNull { it.name == p(c).getString("lec_start", null) } ?: LectureStart.SHAKE
    fun setLectureStart(c: Context, v: LectureStart) = p(c).edit().putString("lec_start", v.name).apply()
    /** Hány rázás (vagy kopogás) kell a LED-ek feltöltéséhez – a Rázás-töltés mozdulathoz és az Előadás töltéséhez. */
    fun shakeFillCount(c: Context): Int = p(c).getInt("shake_fill", Config.SHAKEFILL_DEFAULT).coerceIn(3, 40)
    fun setShakeFillCount(c: Context, v: Int) = p(c).edit().putInt("shake_fill", v.coerceIn(3, 40)).apply()

    fun lectureBreakCmd(c: Context): BreakCommand =
        BreakCommand.entries.firstOrNull { it.name == p(c).getString("lec_break_cmd", null) } ?: BreakCommand.SHAKE
    fun setLectureBreakCmd(c: Context, v: BreakCommand) = p(c).edit().putString("lec_break_cmd", v.name).apply()
    /** Többször is lehet szünetet indítani (különben csak egyszer). */
    fun lectureMultiBreak(c: Context): Boolean = p(c).getBoolean("lec_multi", false)
    fun setLectureMultiBreak(c: Context, v: Boolean) = p(c).edit().putBoolean("lec_multi", v).apply()
    /** A részek között magától indul a szünet. */
    fun lectureAutoBreak(c: Context): Boolean = p(c).getBoolean("lec_auto", false)
    fun setLectureAutoBreak(c: Context, v: Boolean) = p(c).edit().putBoolean("lec_auto", v).apply()
    /** A szünetet ugyanazzal a paranccsal előbb is be lehet fejezni (folytatás). */
    fun lectureEarlyResume(c: Context): Boolean = p(c).getBoolean("lec_resume", true)
    fun setLectureEarlyResume(c: Context, v: Boolean) = p(c).edit().putBoolean("lec_resume", v).apply()

    /** Az előadás visszaszámlálójának animációja. */
    fun lectureStyle(c: Context): LectureStyle =
        LectureStyle.entries.firstOrNull { it.name == p(c).getString("lec_style", null) } ?: LectureStyle.BAR
    fun setLectureStyle(c: Context, v: LectureStyle) = p(c).edit().putString("lec_style", v.name).apply()
    /** Jelezzen-e a rész vége előtt (Config.LECTURE_WARN_MIN perccel). */
    fun lectureWarn(c: Context): Boolean = p(c).getBoolean("lec_warn", true)
    fun setLectureWarn(c: Context, v: Boolean) = p(c).edit().putBoolean("lec_warn", v).apply()
    /** Widgetről (gombnyomásra) rázás nélkül, azonnal induljon. */
    fun lectureWidgetInstant(c: Context): Boolean = p(c).getBoolean("lec_widget_instant", true)
    fun setLectureWidgetInstant(c: Context, v: Boolean) = p(c).edit().putBoolean("lec_widget_instant", v).apply()

    // --- Fújós ---
    fun blowStyle(c: Context): BlowStyle =
        BlowStyle.entries.firstOrNull { it.name == p(c).getString("blow_style", null) } ?: BlowStyle.BALL
    fun setBlowStyle(c: Context, v: BlowStyle) = p(c).edit().putString("blow_style", v.name).apply()
    /** Fújás érzékenysége: 0 = alacsony … 3 = nagyon magas (alap: 1). */
    fun blowSensitivity(c: Context): Int = p(c).getInt("blow_sens", 1).coerceIn(0, 3)
    fun setBlowSensitivity(c: Context, v: Int) = p(c).edit().putInt("blow_sens", v.coerceIn(0, 3)).apply()
    /** Rekord (ms) animációnként – a célba érős módoknál. 0 = még nincs. */
    fun blowBest(c: Context, s: BlowStyle): Long = p(c).getLong("blow_best_${s.name}", 0L)
    fun setBlowBest(c: Context, s: BlowStyle, ms: Long) = p(c).edit().putLong("blow_best_${s.name}", ms).apply()
    /** Hányszor durrant ki a lufi összesen. */
    fun blowPops(c: Context): Int = p(c).getInt("blow_pops", 0)
    fun addBlowPop(c: Context) = p(c).edit().putInt("blow_pops", blowPops(c) + 1).apply()

    // --- Egyensúly ---
    fun balanceBest(c: Context): Int = p(c).getInt("balance_best", 0)
    fun setBalanceBest(c: Context, v: Int) = p(c).edit().putInt("balance_best", v).apply()
}
