package com.akos.glypheggs

import android.app.Activity
import android.content.Intent
import android.os.Bundle
import android.view.Gravity
import android.view.ViewGroup.LayoutParams.MATCH_PARENT
import android.view.ViewGroup.LayoutParams.WRAP_CONTENT
import android.widget.FrameLayout
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView
import kotlinx.coroutines.Job
import kotlinx.coroutines.MainScope
import kotlinx.coroutines.cancel
import kotlinx.coroutines.delay
import kotlinx.coroutines.isActive
import kotlinx.coroutines.launch

/** Az időzítő beállítása: fajta, percek, animáció – élő előnézettel. */
class TimerActivity : Activity() {

    private val scope = MainScope()
    private lateinit var preview: GlyphMapView
    private lateinit var previewLabel: TextView
    private lateinit var modeList: LinearLayout
    private lateinit var styleList: LinearLayout
    private lateinit var minutesBox: LinearLayout
    private val minutePills = mutableListOf<Pair<Int, TextView>>()
    private var animJob: Job? = null

    private val minuteOptions = listOf(1, 2, 3, 5, 10, 15, 20, 30, 45, 60, 90)

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        darkWindow()

        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(15), 0, dp(15), dp(24))
        }
        val scroll = ScrollView(this).apply {
            setBackgroundColor(Ui.BG)
            isVerticalScrollBarEnabled = false
            addView(root, FrameLayout.LayoutParams(MATCH_PARENT, WRAP_CONTENT))
            padForSystemBars()
        }
        setContentView(scroll)

        val header = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
            setPadding(dp(7), dp(28), 0, dp(18))
        }
        header.addView(ImageView(this).apply {
            setImageResource(R.drawable.ic_back)
            setOnClickListener { finish() }
        }, LinearLayout.LayoutParams(dp(24), dp(24)))
        header.addView(text("Időzítő", 26f).apply { setPadding(dp(30), 0, 0, 0) })
        root.addView(header)

        // Előnézet
        val box = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            background = rounded(Ui.BG, dp(22).toFloat(), Ui.LINE, dp(1.5f))
            setPadding(dp(14), dp(16), dp(14), dp(14))
        }
        preview = GlyphMapView(this).apply { unlitColor = 0xFF303030.toInt() }
        box.addView(preview, LinearLayout.LayoutParams(MATCH_PARENT, dp(220)))
        previewLabel = text("", 13f, Ui.SUB).apply { gravity = Gravity.CENTER; setPadding(0, dp(10), 0, 0) }
        box.addView(previewLabel, LinearLayout.LayoutParams(MATCH_PARENT, WRAP_CONTENT))
        root.addView(box)

        // Indítás
        val startCard = FeatureCard(this, R.drawable.ic_timer, "Indítás", "Tedd le kijelzővel lefelé", false)
        startCard.setOnClickListener {
            startForegroundService(Intent(this, SimonService::class.java).setAction(SimonService.ACTION_TIMER))
        }
        val infoCard = FeatureCard(this, R.drawable.ic_info, "Hogyan működik", "Kopogásos vezérlés, jelzések", false)
        infoCard.setOnClickListener {
            startActivity(Intent(this, InfoActivity::class.java).putExtra(InfoActivity.EXTRA_FEATURE, Feature.TIMER.name))
        }
        root.addView(row(startCard, infoCard, 140).apply { setPadding(0, dp(14), 0, 0) })

        root.addView(sectionTitle("Fajta"))
        modeList = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        root.addView(modeList)

        minutesBox = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        minutesBox.addView(sectionTitle("Hossz (perc)"))
        for (chunk in minuteOptions.chunked(4)) {
            val r = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
            for (m in chunk) {
                val t = text("$m", 15f).apply {
                    gravity = Gravity.CENTER
                    setOnClickListener {
                        Settings.setTimerMinutes(this@TimerActivity, m)
                        render()
                    }
                }
                minutePills += m to t
                r.addView(t, LinearLayout.LayoutParams(0, dp(44), 1f).apply { marginEnd = dp(5) })
            }
            // A sor kitöltése, hogy a pirulák egyforma szélesek legyenek
            repeat(4 - chunk.size) { r.addView(TextView(this), LinearLayout.LayoutParams(0, dp(44), 1f).apply { marginEnd = dp(5) }) }
            minutesBox.addView(r, LinearLayout.LayoutParams(MATCH_PARENT, WRAP_CONTENT).apply { bottomMargin = dp(5) })
        }
        root.addView(minutesBox)

        root.addView(sectionTitle("Animáció"))
        styleList = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        root.addView(styleList)

        render()
    }

    override fun onResume() {
        super.onResume()
        GlyphMirror.appVisible = true
        startPreview()
    }

    override fun onPause() {
        super.onPause()
        GlyphMirror.appVisible = false
        animJob?.cancel()
    }

    /** Az előnézet 12 mp alatt "lefuttatja" a teljes időt a választott animációval. */
    private fun startPreview() {
        animJob?.cancel()
        animJob = scope.launch {
            var frame = 0
            while (isActive) {
                val style = Settings.timerStyle(this@TimerActivity)
                val p = (frame % 120) / 120f
                preview.lit = FocusTimer.frame(style, p, frame, false).toSet()
                previewLabel.text = "${style.title} – előnézet (${(p * 100).toInt()}%)"
                frame++
                delay(100)
            }
        }
    }

    private fun optionRow(title: String, sub: String, selected: Boolean, onClick: () -> Unit): LinearLayout {
        val row = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
            background = rounded(Ui.CARD, dp(20).toFloat())
            setPadding(dp(18), dp(15), dp(16), dp(15))
            setOnClickListener { onClick() }
        }
        val texts = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        texts.addView(text(title, 17f))
        texts.addView(text(sub, 12.5f, Ui.SUB).apply { setPadding(0, dp(2), 0, 0) })
        row.addView(texts, LinearLayout.LayoutParams(0, WRAP_CONTENT, 1f))
        row.addView(RadioMark(this, selected), LinearLayout.LayoutParams(dp(26), dp(26)).apply { marginStart = dp(12) })
        return row
    }

    private fun render() {
        val mode = Settings.timerMode(this)
        val style = Settings.timerStyle(this)
        val minutes = Settings.timerMinutes(this)

        modeList.removeAllViews()
        for (m in TimerMode.entries) {
            val sub = if (m.custom) "${m.desc} · most: $minutes perc" else m.desc
            modeList.addView(optionRow(m.title, sub, m == mode) {
                Settings.setTimerMode(this, m)
                if (m == TimerMode.HOURGLASS && Settings.timerMinutes(this) > 10) Settings.setTimerMinutes(this, 3)
                if (m == TimerMode.HOURGLASS) Settings.setTimerStyle(this, TimerStyle.SAND)
                render()
            }, LinearLayout.LayoutParams(MATCH_PARENT, WRAP_CONTENT).apply { bottomMargin = dp(5) })
        }

        minutesBox.visibility = if (mode.custom) android.view.View.VISIBLE else android.view.View.GONE
        for ((m, t) in minutePills) {
            val sel = m == minutes
            t.background = rounded(if (sel) Ui.LIGHT else Ui.CARD, dp(22).toFloat())
            t.setTextColor(if (sel) Ui.DARK_TEXT else Ui.TEXT)
        }

        styleList.removeAllViews()
        for (s in TimerStyle.entries) {
            styleList.addView(optionRow(s.title, s.desc, s == style) {
                Settings.setTimerStyle(this, s)
                render()
            }, LinearLayout.LayoutParams(MATCH_PARENT, WRAP_CONTENT).apply { bottomMargin = dp(5) })
        }
    }

    override fun onDestroy() {
        scope.cancel()
        super.onDestroy()
    }
}
