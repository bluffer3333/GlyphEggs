package com.akos.glypheggs

import android.app.Activity
import android.content.Intent
import android.os.Bundle
import android.view.Gravity
import android.view.ViewGroup.LayoutParams.MATCH_PARENT
import android.view.ViewGroup.LayoutParams.WRAP_CONTENT
import android.widget.FrameLayout
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.ScrollView

/**
 * Dínófutás beállítása: mivel akarsz ugrani – kopogással, rázással, a hangerő-gombokkal vagy a
 * bekapcsoló gombbal. Több is bekapcsolható egyszerre; legalább egy mindig be van kapcsolva.
 */
class DinoActivity : Activity() {

    private lateinit var body: LinearLayout

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        darkWindow()

        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(15), 0, dp(15), dp(24))
        }
        val scroll = ScrollView(this).apply {
            setBackgroundColor(Ui.BG)
            isVerticalScrollBarEnabled = false
            addView(root, FrameLayout.LayoutParams(MATCH_PARENT, WRAP_CONTENT))
            padForSystemBars()
        }
        setContentView(scroll)

        val header = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
            setPadding(dp(7), dp(28), 0, dp(18))
        }
        header.addView(ImageView(this).apply {
            setImageResource(R.drawable.ic_back)
            setOnClickListener { finish() }
        }, LinearLayout.LayoutParams(dp(24), dp(24)))
        header.addView(text("Dínófutás", 26f).apply { setPadding(dp(30), 0, 0, 0) })
        root.addView(header)

        val startCard = FeatureCard(this, R.drawable.ic_dino, "Indítás", "Dínófutás", false)
        startCard.setOnClickListener {
            startForegroundService(Intent(this, SimonService::class.java).setAction(SimonService.ACTION_DINO))
        }
        val infoCard = FeatureCard(this, R.drawable.ic_info, "Hogyan működik", "Játékmenet, jelzések", false)
        infoCard.setOnClickListener {
            startActivity(Intent(this, InfoActivity::class.java).putExtra(InfoActivity.EXTRA_FEATURE, Feature.DINO.name))
        }
        root.addView(row(startCard, infoCard, 140))

        root.addView(sectionTitle("Mivel ugorjon a dínó?"))
        body = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        root.addView(body)
        render()
    }

    override fun onResume() {
        super.onResume()
        GlyphMirror.appVisible = true
        render()
    }

    override fun onPause() {
        super.onPause()
        GlyphMirror.appVisible = false
    }

    private fun jumpRow(m: DinoJump, on: Boolean, only: Boolean): LinearLayout {
        val row = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
            background = rounded(Ui.CARD, dp(20).toFloat())
            setPadding(dp(18), dp(15), dp(16), dp(15))
        }
        val texts = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        texts.addView(text(m.title, 17f))
        texts.addView(text(m.hint, 12.5f, Ui.SUB).apply { setPadding(0, dp(2), 0, 0); setLineSpacing(0f, 1.15f) })
        row.addView(texts, LinearLayout.LayoutParams(0, WRAP_CONTENT, 1f))
        val toggle = ToggleView(this).apply {
            checked = on
            onChange = { v ->
                Settings.setDinoJump(this@DinoActivity, m, v)
                render()
            }
        }
        row.addView(toggle, LinearLayout.LayoutParams(WRAP_CONTENT, WRAP_CONTENT).apply { marginStart = dp(12) })
        row.setOnClickListener { toggle.performClick() }
        return row
    }

    private fun render() {
        val set = Settings.dinoJump(this)
        body.removeAllViews()
        for (m in DinoJump.entries) {
            body.addView(jumpRow(m, m in set, set.size == 1 && m in set),
                LinearLayout.LayoutParams(MATCH_PARENT, WRAP_CONTENT).apply { bottomMargin = dp(5) })
        }
        body.addView(text(
            "Legalább egy bemenet mindig be van kapcsolva. Ugrani csak a földön lehet: ugrás közben a további jelek nem számítanak.",
            12.5f, Ui.SUB
        ).apply { setPadding(dp(8), dp(6), dp(8), 0); setLineSpacing(0f, 1.2f) })
        if (DinoJump.VOL_UP in set || DinoJump.VOL_DOWN in set) {
            body.addView(text(
                "Hangerő-gombok: kísérleti. A játék alatt egy médiamunkamenet kapja a gombokat, így a rendszer nem állítja a hangerőt; ha a telefonod gyártói felülete másképp kezeli, a gombok nem jutnak el a játékig – ilyenkor használd a kopogást vagy a rázást.",
                12.5f, Ui.SUB
            ).apply { setPadding(dp(8), dp(8), dp(8), 0); setLineSpacing(0f, 1.2f) })
        }
        if (DinoJump.POWER in set) {
            body.addView(text(
                "Bekapcsoló gomb: minden gombnyomás ugrás, ezért ilyenkor a „bekapcsoló gombos leállítás” a Dínónál nem működik – állítsd le a kártyával, csempével vagy az értesítésből.",
                12.5f, Ui.SUB
            ).apply { setPadding(dp(8), dp(8), dp(8), 0); setLineSpacing(0f, 1.2f) })
        }
        val gest = FeatureCard(this, R.drawable.ic_gesture, "Indítás és leállítás",
            "Indul: ${Settings.trigger(this, Feature.DINO).title}\nLeáll: ${Settings.stopSummary(this, Feature.DINO)}", false)
        gest.setOnClickListener {
            startActivity(Intent(this, GesturesActivity::class.java).putExtra(GesturesActivity.EXTRA_FEATURE, Feature.DINO.name))
        }
        body.addView(sectionTitle("Indító mozdulat és leállítás"))
        body.addView(row(gest, null, 150))
    }
}
