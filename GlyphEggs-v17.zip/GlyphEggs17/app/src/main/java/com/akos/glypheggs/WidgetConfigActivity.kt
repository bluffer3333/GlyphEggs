package com.akos.glypheggs

import android.app.Activity
import android.appwidget.AppWidgetManager
import android.content.Intent
import android.os.Bundle
import android.view.Gravity
import android.view.ViewGroup.LayoutParams.MATCH_PARENT
import android.view.ViewGroup.LayoutParams.WRAP_CONTENT
import android.widget.FrameLayout
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView

/**
 * Widget beállítása lerakáskor (és később hosszú nyomás → Átkonfigurálás):
 *  - Gyorsindító sáv: 4 funkció kiválasztása, a koppintás sorrendjében.
 *  - Egygombos widget: egy funkció kiválasztása.
 */
class WidgetConfigActivity : Activity() {

    private var widgetId = AppWidgetManager.INVALID_APPWIDGET_ID
    private var isBar = true
    private val chosen = mutableListOf<Feature>()
    private lateinit var list: LinearLayout
    private lateinit var hint: TextView

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setResult(RESULT_CANCELED)
        darkWindow()

        widgetId = intent.getIntExtra(AppWidgetManager.EXTRA_APPWIDGET_ID, AppWidgetManager.INVALID_APPWIDGET_ID)
        if (widgetId == AppWidgetManager.INVALID_APPWIDGET_ID) {
            finish()
            return
        }
        val info = AppWidgetManager.getInstance(this).getAppWidgetInfo(widgetId)
        isBar = info?.provider?.className != FeatureWidget::class.java.name
        if (isBar) chosen += Widgets.barFeatures(this, widgetId) else chosen += Widgets.singleFeature(this, widgetId)

        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(15), 0, dp(15), dp(24))
        }
        val scroll = ScrollView(this).apply {
            setBackgroundColor(Ui.BG)
            isVerticalScrollBarEnabled = false
            addView(root, FrameLayout.LayoutParams(MATCH_PARENT, WRAP_CONTENT))
            padForSystemBars()
        }
        setContentView(scroll)

        root.addView(text(if (isBar) "Gyorsindító sáv" else "Egygombos widget", 26f).apply {
            setPadding(dp(7), dp(36), 0, dp(6))
        })
        hint = text("", 13f, Ui.SUB).apply { setPadding(dp(7), 0, dp(7), dp(10)); setLineSpacing(0f, 1.2f) }
        root.addView(hint)

        list = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        root.addView(list)

        val done = text("Kész", 17f, Ui.DARK_TEXT, Ui.medium).apply {
            gravity = Gravity.CENTER
            background = rounded(Ui.LIGHT, dp(26).toFloat())
            setOnClickListener { save() }
        }
        root.addView(done, LinearLayout.LayoutParams(MATCH_PARENT, dp(56)).apply { topMargin = dp(16) })

        render()
    }

    private fun render() {
        hint.text = if (isBar) "Válassz 4 funkciót a sávra – a koppintás sorrendjében kerülnek balról jobbra. (${chosen.size}/4)"
        else "Melyik funkciót indítsa ez a gomb? Több ilyen widgetet is kitehetsz, mindegyikhez mást."
        list.removeAllViews()
        for (f in Feature.entries) {
            val idx = chosen.indexOf(f)
            val row = LinearLayout(this).apply {
                orientation = LinearLayout.HORIZONTAL
                gravity = Gravity.CENTER_VERTICAL
                background = rounded(Ui.CARD, dp(20).toFloat())
                setPadding(dp(16), dp(14), dp(16), dp(14))
                setOnClickListener { pick(f) }
            }
            row.addView(icon(f.icon))
            row.addView(text(f.title, 17f).apply { setPadding(dp(14), 0, 0, 0) }, LinearLayout.LayoutParams(0, WRAP_CONTENT, 1f))
            if (isBar && idx >= 0) {
                row.addView(text("${idx + 1}.", 15f, Ui.TEXT, Ui.medium).apply { setPadding(0, 0, dp(10), 0) })
            }
            row.addView(RadioMark(this, idx >= 0), LinearLayout.LayoutParams(dp(26), dp(26)))
            list.addView(row, LinearLayout.LayoutParams(MATCH_PARENT, WRAP_CONTENT).apply { bottomMargin = dp(5) })
        }
    }

    private fun pick(f: Feature) {
        if (isBar) {
            if (f in chosen) chosen.remove(f)
            else if (chosen.size < 4) chosen += f
        } else {
            chosen.clear()
            chosen += f
        }
        render()
    }

    private fun save() {
        if (chosen.isEmpty()) return
        if (isBar) {
            Widgets.setBarFeatures(this, widgetId, chosen)
            Widgets.updateBar(this, intArrayOf(widgetId))
        } else {
            Widgets.setSingleFeature(this, widgetId, chosen.first())
            Widgets.updateSingle(this, intArrayOf(widgetId))
        }
        setResult(RESULT_OK, Intent().putExtra(AppWidgetManager.EXTRA_APPWIDGET_ID, widgetId))
        finish()
    }
}
