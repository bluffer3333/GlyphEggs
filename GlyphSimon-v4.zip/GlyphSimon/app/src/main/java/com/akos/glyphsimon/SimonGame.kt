package com.akos.glyphsimon

import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.first
import kotlinx.coroutines.withTimeoutOrNull
import kotlin.random.Random

/**
 * A Simon Says játékmenet:
 *  1. Bevezető: a négy irány körbefut háromszor, majd minden felvillan.
 *  2. Minden körben egy új, véletlen irány kerül a sor végére.
 *  3. A telefon lejátssza a sort (az eddig eltaláltakat + az újat).
 *  4. A játékos a felvillant LED felé dönti a telefont, utána vissza középre.
 *     Jó válasznál az eltalált LED felvillan, rossznál vége a játéknak.
 *  5. Minden teljesített körrel 2 LED-del nő a C1 szintjelző (16 LED = 8 kör).
 *     Ha betelik: minden összevissza villog, és rezeg a telefon.
 */
class SimonGame(
    private val glyph: GlyphController,
    private val motion: MotionDetector,
    private val haptics: Haptics
) {
    private var level = 0

    private fun levelZones(): IntArray =
        Zones.LEVEL.copyOfRange(0, (level * Config.LEDS_PER_LEVEL).coerceAtMost(Zones.LEVEL.size))

    /** Irány-LED-ek + a szintjelző együtt (a szint mindig látszik). */
    private fun show(zones: IntArray) = glyph.show(zones + levelZones())

    /** Csak a szintjelző marad égve. */
    private fun clear() {
        val lvl = levelZones()
        if (lvl.isEmpty()) glyph.off() else glyph.show(lvl)
    }

    /** Visszaadja az elért szintet (teljesített körök száma). */
    suspend fun run(): Int {
        intro()
        val sequence = mutableListOf<Direction>()

        while (level < Config.MAX_ROUNDS) {
            sequence += nextDirection(sequence)
            delay(500)
            playSequence(sequence)

            val toAnswer = if (Config.FULL_SEQUENCE) sequence.toList() else listOf(sequence.last())
            for (expected in toAnswer) {
                val answer = waitForTilt()
                if (answer == null) {
                    DebugState.log("Lejárt az idő")
                    return fail()
                }
                if (answer != expected) {
                    DebugState.log("Rossz irány: ${answer.label} (kellett: ${expected.label})")
                    show(answer.zones())
                    delay(300)
                    return fail()
                }
                // Jó válasz: az eltalált LED felvillan
                show(expected.zones())
                delay(300)
                clear()
                waitNeutral()
            }

            levelUp()
            DebugState.log("Szint: $level/${Config.MAX_ROUNDS}")
        }

        win()
        return level
    }

    private suspend fun intro() {
        repeat(3) {
            for (d in listOf(Direction.FORWARD, Direction.RIGHT, Direction.BACK, Direction.LEFT)) {
                glyph.show(d.zones())
                delay(110)
            }
        }
        glyph.show(Zones.ALL)
        delay(400)
        glyph.off()
        delay(600)
    }

    private suspend fun playSequence(sequence: List<Direction>) {
        for (d in sequence) {
            show(d.zones())
            delay(Config.SHOW_MS)
            clear()
            delay(Config.GAP_MS)
        }
    }

    /** Az új szint két LED-je háromszor felvillan, majd égve marad. */
    private suspend fun levelUp() {
        val before = levelZones()
        level++
        val after = levelZones()
        repeat(3) {
            if (before.isEmpty()) glyph.off() else glyph.show(before)
            delay(150)
            glyph.show(after)
            delay(150)
        }
        delay(400)
    }

    /** Megvárja, hogy a telefon középen legyen, utána az első határozott dőlést. */
    private suspend fun waitForTilt(): Direction? {
        waitNeutral()
        return withTimeoutOrNull(Config.ANSWER_TIMEOUT_MS) {
            motion.tilt.first { it != null }
        }
    }

    private suspend fun waitNeutral() {
        withTimeoutOrNull(Config.ANSWER_TIMEOUT_MS) {
            motion.tilt.first { it == null }
        }
    }

    /** Véletlen irány, de háromszor egymás után ugyanaz nem jön. */
    private fun nextDirection(seq: List<Direction>): Direction {
        val options = Direction.entries.toMutableList()
        if (seq.size >= 2 && seq[seq.size - 1] == seq[seq.size - 2]) options.remove(seq.last())
        return options[Random.nextInt(options.size)]
    }

    private suspend fun fail(): Int {
        repeat(4) {
            glyph.show(Zones.ALL)
            delay(120)
            glyph.off()
            delay(120)
        }
        delay(400)
        // Az elért szint még 3 mp-ig látszik
        clear()
        delay(3000)
        glyph.off()
        return level
    }

    /** Betelt a szintjelző: kb. 8 mp-ig minden összevissza villog, a telefon rezeg. */
    private suspend fun win() {
        haptics.win()
        repeat(Config.WIN_FLASH_MS.toInt() / 80) {
            val random = Zones.ALL.filter { Random.nextBoolean() }.toIntArray()
            if (random.isEmpty()) glyph.off() else glyph.show(random)
            delay(80)
        }
        glyph.show(Zones.ALL)
        delay(1500)
        glyph.off()
    }
}
