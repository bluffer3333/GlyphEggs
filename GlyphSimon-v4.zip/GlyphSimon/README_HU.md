# Glyph Simon – Simon Says a Nothing Phone (2) LED-jeivel

## Mit csinál

1. A háttérben fut, állandó értesítéssel.
2. Tedd le a telefont kijelzővel lefelé (töltőport feléd), és forgasd el az asztalon jobbra, felülről nézve az óramutató irányába, kétszer egymás után kb. negyed fordulatot. A telefon röviden rezeg.
3. A LED-ek háromszor körbefutnak, majd elindul a játék.
4. Felvillan egy irány. Döntsd a telefont arra, aztán engedd vissza középre.
5. Ha eltaláltad, felvillan az eltalált LED. Utána a telefon lejátssza az eddigi sort és egy újat, ezt kell végigdöntened.
6. Minden teljesített körrel 2 LED-del nő a szintjelző (C1, 16 LED). 8 kör után betelik, ekkor kb. 8 másodpercig minden összevissza villog, és a telefon rezeg.
7. Rossz iránynál vagy 7 mp tétlenség után vége. Az elért szint még 3 mp-ig látszik.

Irányok kijelzővel lefelé fekvő telefonnál, töltőport feléd, kamera bal felül:

| Döntés | LED |
|---|---|
| Fel (B1 felé) | Kamera körüli gyűrű + ferde csík (A1, A2, B1) |
| Le (E1, töltőport felé) | Függőleges vonal + pont (D1_1–8, E1) |
| Balra (kamera felőli oldal) | Bal felső ív + bal függőleges darab (C2, C3) |
| Jobbra | Jobb oldali függőleges darab (C6) |
| Szintjelző | C1, 16 LED, körönként 2 |

## APK készítése

### A) Számítógépen, Android Studióval

1. Telepítsd az Android Studiót: developer.android.com/studio
2. Csomagold ki a zipet, és nyisd meg a `GlyphSimon` mappát: **File → Open**.
3. Várd meg, amíg a Gradle szinkronizál. Az első alkalommal ez letölt mindent, eltarthat pár percig.
4. **Build → Build App Bundle(s) / APK(s) → Build APK(s)**
5. Az APK itt lesz: `app/build/outputs/apk/debug/app-debug.apk`

Ha a telefon USB-n csatlakozik, bekapcsolt USB-hibakereséssel, a zöld ▶ gomb egyből fel is telepíti.

### B) Számítógép nélkül, GitHubbal

1. Hozz létre egy új, privát GitHub repót, és töltsd fel bele a mappa teljes tartalmát. A rejtett `.github` mappa is kell!
2. A feltöltés után a GitHub magától elkezdi építeni az APK-t (**Actions** fül).
3. Ha zöld pipa jelent meg, nyisd meg a futást, és lent az **Artifacts** résznél töltsd le a `glyph-simon-apk` fájlt.
4. Ez egy zip, benne az `app-debug.apk`.

### Telepítés a telefonra

1. Másold át az APK-t, és nyisd meg a telefonon.
2. Engedélyezd az "Ismeretlen forrásból származó alkalmazások telepítése" opciót annál az appnál, amivel megnyitod (pl. Fájlok).

## A Glyph engedélyezése (fontos!)

A Nothing a külső appoknak csak fejlesztői módban engedi a Glyph vezérlését:

- **Ha a telefonon Android 16 / Nothing OS 4 fut:** nem kell külön kulcs, működnie kell.
- **Ha régebbi rendszer fut:** számítógépről, USB-n kell egyszer kiadni ezt a parancsot:
  ```
  adb shell settings put global nt_glyph_interface_debug_enable 1
  ```
  Ez 48 óra után magától kikapcsol, akkor újra ki kell adni.

## Gyorsbeállítás-csempe

A felső, lehúzható menübe tehetsz egy **Glyph Simon** csempét. Egy koppintás be-, a következő kikapcsolja a háttérfigyelést. Ha világít, a telefon figyeli az indító mozdulatot.

Hozzáadás: az appban a **Csempe hozzáadása a gyorsbeállításokhoz** gomb. Vagy húzd le kétszer a felső menüt, koppints a ceruza (szerkesztés) ikonra, és húzd be a Glyph Simon csempét.

## Első indítás

1. Nyisd meg a **Glyph Simon** appot, és engedélyezd az értesítéseket.
2. Nyomd meg az **Akkumulátor-optimalizálás kikapcsolása** gombot. Enélkül a rendszer leállíthatja a háttérben.
3. Először a **Játék indítása most (teszt)** gombbal próbáld ki, nyitott apppal.
4. Nézd az **Élő szenzoradatok** részt: döntsd a telefont, és figyeld, jó irányt ír-e.
5. Ha minden rendben, nyomd meg a **Háttérfigyelés indítása** gombot.

## Hangolás

Minden beállítás az `app/src/main/java/com/akos/glyphsimon/Config.kt` fájlban van:

- `FULL_SEQUENCE`: `true` esetén a teljes sort végig kell dönteni, `false` esetén csak az újat.
- `INVERT_X` / `INVERT_Y`: ha a bal/jobb vagy az előre/hátra fordítva jön ki.
- `INVERT_TURN`: ha a jobbra forgatást nem számolja, de a balrát igen.
- `TURN_COUNT`, `TURN_TOLERANCE`, `TURN_GAP_MS`: hány forgatás kell, mennyire pontos, milyen gyors.
- `TILT_ON`: mekkora döntés számít. Kisebb szám = érzékenyebb.
- `SHOW_MS`, `ANSWER_TIMEOUT_MS`: a játék tempója.

## Ismert korlátok

- **A kód nincs telefonon kipróbálva.** A Nothing hivatalos SDK-jára épül, de az első futtatásnál számíts kisebb hangolásra.
- A Nothing leírása szerint a Glyph-et "előtérben lévő" app vezérelheti. Ha a háttérből indított játéknál nem gyulladnak ki a LED-ek, de a tesztgombbal igen, akkor ez a korlát okozza. A napló ilyenkor `openSession hiba` üzenetet mutat.
- A Nothing **Flip to Glyph** funkciója (kijelzővel lefelé fordítás) ütközhet ezzel. Ha furcsán viselkedik, kapcsold ki a Glyph beállításokban.
- A C4 és C5 ív játék közben nem világít, csak a bevezetőnél és a villogásoknál. A zónák a `Direction.kt` fájlban átírhatók.
