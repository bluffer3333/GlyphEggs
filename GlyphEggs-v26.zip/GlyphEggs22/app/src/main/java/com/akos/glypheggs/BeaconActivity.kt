package com.akos.glypheggs

import android.Manifest
import android.app.Activity
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.graphics.Canvas
import android.graphics.Paint
import android.graphics.drawable.GradientDrawable
import android.media.MediaPlayer
import android.os.Bundle
import android.os.SystemClock
import android.view.Gravity
import android.view.View
import android.view.ViewGroup.LayoutParams.MATCH_PARENT
import android.view.ViewGroup.LayoutParams.WRAP_CONTENT
import android.widget.FrameLayout
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView
import kotlinx.coroutines.Job
import kotlinx.coroutines.MainScope
import kotlinx.coroutines.cancel
import kotlinx.coroutines.delay
import kotlinx.coroutines.isActive
import kotlinx.coroutines.launch
import kotlin.math.cos
import kotlin.math.hypot
import kotlin.math.sin

/** Az alumínium / fehér téma színei (csak a Glyph Beacon oldalán és kártyáján). */
object Alu {
    const val TOP = 0xFFF5F5F3.toInt()
    const val BOTTOM = 0xFFD6D7D9.toInt()
    const val CARD = 0xFFFDFDFC.toInt()
    const val STROKE = 0xFFCFCFCF.toInt()
    const val TEXT = 0xFF111111.toInt()
    const val SUB = 0xFF6A6A6A.toInt()
    const val DOT = 0xFFBDBDBD.toInt()
    const val RED = 0xFFD71921.toInt()

    fun bg(): GradientDrawable = GradientDrawable(GradientDrawable.Orientation.TOP_BOTTOM, intArrayOf(TOP, BOTTOM))
}

/**
 * Pontmátrixos „radar”: pontrács egy körben; figyelés közben a pontok hullámban gyulladnak kifelé,
 * fütty hallatán gyorsul, riasztásnál pirosan lüktet. [phase] 0..1 körbefut (az oldal hajtja).
 */
class BeaconRadarView(context: Context) : View(context) {
    var phase = 0f
    var listening = false
    var hearing = 0f      // 0..1: mennyire hall füttyöt
    var alarming = false
    var dark = false      // sötét változat (nem használt, előkészítve)
    private val p = Paint(Paint.ANTI_ALIAS_FLAG)

    override fun onDraw(canvas: Canvas) {
        val w = width.toFloat()
        val h = height.toFloat()
        val cx = w / 2f
        val cy = h / 2f
        val r = minOf(w, h) / 2f * 0.96f
        val step = r / 9f
        val dot = step * 0.26f
        for (iy in -9..9) for (ix in -9..9) {
            val x = ix * step
            val y = iy * step
            val d = hypot(x, y)
            if (d > r) continue
            val rel = d / r
            // Kifelé futó hullám
            val wave = ((phase - rel) % 1f + 1f) % 1f
            val glow = if (listening || alarming) maxOf(0f, 1f - wave * 4f) else 0f
            val col = when {
                alarming -> blend(Alu.DOT, Alu.RED, maxOf(glow, if ((phase * 6).toInt() % 2 == 0) 0.6f else 0.2f))
                rel < 0.12f && listening -> Alu.RED
                else -> blend(Alu.DOT, Alu.TEXT, glow * (0.55f + 0.45f * hearing))
            }
            p.color = col
            canvas.drawCircle(cx + x, cy + y, dot * (1f + glow * 0.35f), p)
        }
        // Forgó „söprés” vonal pontokból
        if (listening && !alarming) {
            val a = phase * 2 * Math.PI
            p.color = Alu.RED
            for (k in 1..8) {
                val rr = r * k / 9f
                canvas.drawCircle(cx + (rr * sin(a)).toFloat(), cy - (rr * cos(a)).toFloat(), dot * 0.7f, p)
            }
        }
    }

    private fun blend(a: Int, b: Int, t: Float): Int {
        val tt = t.coerceIn(0f, 1f)
        fun ch(s: Int) = ((a shr s and 0xFF) * (1 - tt) + (b shr s and 0xFF) * tt).toInt()
        return (0xFF shl 24) or (ch(16) shl 16) or (ch(8) shl 8) or ch(0)
    }
}

/** A Főoldal kiemelt Beacon-kártyája (alumínium). */
fun Activity.beaconHero(onToggle: (Boolean) -> Unit): LinearLayout {
    val card = LinearLayout(this).apply {
        orientation = LinearLayout.HORIZONTAL
        gravity = Gravity.CENTER_VERTICAL
        background = Alu.bg().apply { cornerRadius = dp(24).toFloat(); setStroke(dp(1), Alu.STROKE) }
        setPadding(dp(16), dp(16), dp(18), dp(16))
        setOnClickListener { startActivity(Intent(this@beaconHero, BeaconActivity::class.java)) }
    }
    val radar = BeaconRadarView(this).apply { listening = Settings.beaconOn(this@beaconHero); phase = 0.35f }
    card.addView(radar, LinearLayout.LayoutParams(dp(84), dp(84)).apply { marginEnd = dp(16) })
    val texts = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
    texts.addView(text("GLYPH BEACON", 22f, Alu.TEXT).apply { typeface = Widgets.dotoFace(this@beaconHero) })
    texts.addView(text("Fütyülj, és a telefon felel", 13f, Alu.SUB).apply { setPadding(0, dp(2), 0, 0) })
    val on = Settings.beaconOn(this)
    texts.addView(text(
        when {
            !on -> "KI"
            SimonService.beaconListening -> "FIGYEL"
            else -> "BE · nyisd meg a figyeléshez"
        }, 11.5f, if (on) Alu.RED else Alu.SUB, Ui.medium).apply { setPadding(0, dp(8), 0, 0); letterSpacing = 0.12f })
    card.addView(texts, LinearLayout.LayoutParams(0, WRAP_CONTENT, 1f))
    val toggle = ToggleView(this).apply {
        checked = on
        onColor = Alu.TEXT
        knobColor = 0xFFFFFFFF.toInt()
        onChange = { v -> onToggle(v) }
    }
    card.addView(toggle)
    return card
}

/**
 * GLYPH BEACON – a telefon megkereséséhez. Fehér/alumínium téma, élő radar, betanítás, hang, beállítások.
 */
class BeaconActivity : Activity() {

    private val scope = MainScope()
    private lateinit var root: LinearLayout
    private lateinit var radar: BeaconRadarView
    private lateinit var heard: TextView
    private lateinit var meter: LinearLayout
    private lateinit var master: ToggleView
    private lateinit var masterSub: TextView
    private lateinit var alarmBtn: TextView
    private lateinit var trainBox: LinearLayout
    private var recorder: BlowRecorder? = null
    private var liveJob: Job? = null
    private var preview: MediaPlayer? = null

    // Betanítás
    private var training = false
    private val samples = mutableListOf<FloatArray>() // [közép, min, max, hossz]
    private var lastTone = ""

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        window.decorView.setBackgroundColor(Alu.TOP)
        root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(16), 0, dp(16), dp(32))
        }
        val scroll = ScrollView(this).apply {
            background = Alu.bg()
            isVerticalScrollBarEnabled = false
            addView(root, FrameLayout.LayoutParams(MATCH_PARENT, WRAP_CONTENT))
            padForSystemBars()
        }
        setContentView(scroll)
        build()
    }

    private fun card(): LinearLayout = LinearLayout(this).apply {
        orientation = LinearLayout.VERTICAL
        background = rounded(Alu.CARD, dp(24).toFloat(), Alu.STROKE, dp(1))
        setPadding(dp(18), dp(16), dp(18), dp(16))
    }

    private fun title(s: String) = text(s.uppercase(), 11.5f, Alu.SUB, Ui.medium).apply {
        letterSpacing = 0.14f
        setPadding(dp(8), dp(26), 0, dp(10))
    }

    private fun lp(bottom: Int = 6) = LinearLayout.LayoutParams(MATCH_PARENT, WRAP_CONTENT).apply { bottomMargin = dp(bottom) }

    private fun build() {
        root.removeAllViews()
        // Fejléc
        val h = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
            setPadding(dp(6), dp(28), 0, 0)
        }
        h.addView(ImageView(this).apply {
            setImageResource(R.drawable.ic_back)
            setColorFilter(Alu.TEXT)
            setOnClickListener { finish() }
        }, LinearLayout.LayoutParams(dp(24), dp(24)))
        h.addView(View(this), LinearLayout.LayoutParams(0, 1, 1f))
        h.addView(text("TELEFONKERESŐ", 11f, Alu.SUB, Ui.medium).apply { letterSpacing = 0.18f })
        root.addView(h)

        // Hős: radar + cím
        radar = BeaconRadarView(this)
        root.addView(radar, LinearLayout.LayoutParams(MATCH_PARENT, dp(250)).apply { topMargin = dp(18) })
        root.addView(text("GLYPH BEACON", 38f, Alu.TEXT).apply {
            typeface = Widgets.dotoFace(this@BeaconActivity)
            gravity = Gravity.CENTER
            setPadding(0, dp(14), 0, 0)
        }, lp(0))
        root.addView(text("Fütyülj. A telefon felel.", 15f, Alu.SUB).apply { gravity = Gravity.CENTER }, lp(0))

        // Főkapcsoló (sötét pirula a világos lapon)
        val bar = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
            background = rounded(Alu.TEXT, dp(26).toFloat())
            setPadding(dp(22), 0, dp(16), 0)
        }
        val bt = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        bt.addView(text("Figyelés", 18f, 0xFFF4F4F4.toInt()))
        masterSub = text("", 12f, 0xFFAAAAAA.toInt())
        bt.addView(masterSub)
        bar.addView(bt, LinearLayout.LayoutParams(0, WRAP_CONTENT, 1f))
        master = ToggleView(this).apply { onChange = { v -> setListening(v) } }
        bar.addView(master)
        bar.setOnClickListener { master.performClick() }
        root.addView(bar, LinearLayout.LayoutParams(MATCH_PARENT, dp(76)).apply { topMargin = dp(22) })

        // Riasztás-gomb: próba / leállítás
        alarmBtn = text("", 15f, 0xFFFFFFFF.toInt(), Ui.medium).apply {
            gravity = Gravity.CENTER
            setOnClickListener {
                if (SimonService.beaconAlarming.value) send(SimonService.ACTION_BEACON_STOP)
                else send(SimonService.ACTION_BEACON_TEST)
            }
        }
        root.addView(alarmBtn, LinearLayout.LayoutParams(MATCH_PARENT, dp(54)).apply { topMargin = dp(8) })

        // Élő hallás
        root.addView(title("Élő"))
        val live = card()
        val lr = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL }
        lr.addView(text("HALLOM", 11f, Alu.SUB, Ui.medium).apply { letterSpacing = 0.14f },
            LinearLayout.LayoutParams(0, WRAP_CONTENT, 1f))
        heard = text("—", 26f, Alu.TEXT).apply { typeface = Widgets.dotoFace(this@BeaconActivity) }
        lr.addView(heard)
        live.addView(lr)
        meter = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER }
        repeat(24) {
            meter.addView(View(this).apply { background = rounded(Alu.DOT, dp(4).toFloat()) },
                LinearLayout.LayoutParams(dp(8), dp(8)).apply { marginStart = dp(2); marginEnd = dp(2) })
        }
        live.addView(meter, lp(0).apply { topMargin = dp(12) })
        live.addView(text("Csak a hangmagasságot elemzi, semmit nem rögzít, nem ment és nem küld el.", 12f, Alu.SUB)
            .apply { setPadding(0, dp(10), 0, 0); setLineSpacing(0f, 1.2f) })
        root.addView(live, lp())

        // Betanítás
        root.addView(title("A te füttyöd"))
        trainBox = card()
        root.addView(trainBox, lp())
        renderTraining()

        // Hang
        root.addView(title("Hangeffekt"))
        val snd = card().apply { setPadding(0, dp(6), 0, dp(6)) }
        BeaconSound.entries.forEachIndexed { i, s ->
            if (i > 0) snd.addView(View(this).apply { setBackgroundColor(0xFFE6E6E6.toInt()) },
                LinearLayout.LayoutParams(MATCH_PARENT, 1).apply { marginStart = dp(18); marginEnd = dp(18) })
            val r = LinearLayout(this).apply {
                orientation = LinearLayout.HORIZONTAL
                gravity = Gravity.CENTER_VERTICAL
                setPadding(dp(18), dp(12), dp(14), dp(12))
                setOnClickListener { Settings.setBeaconSound(this@BeaconActivity, s); play(s); build() }
            }
            val t = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
            t.addView(text(s.title, 16f, Alu.TEXT))
            t.addView(text(s.desc, 12f, Alu.SUB).apply { setPadding(0, dp(2), 0, 0) })
            r.addView(t, LinearLayout.LayoutParams(0, WRAP_CONTENT, 1f))
            r.addView(text("▶", 14f, Alu.TEXT).apply {
                gravity = Gravity.CENTER
                background = rounded(0xFFEDEDED.toInt(), dp(18).toFloat())
                setOnClickListener { play(s) }
            }, LinearLayout.LayoutParams(dp(36), dp(36)).apply { marginEnd = dp(10) })
            r.addView(dotMark(s == Settings.beaconSound(this)), LinearLayout.LayoutParams(dp(22), dp(22)))
            snd.addView(r)
        }
        root.addView(snd, lp())

        // Riasztás beállításai
        root.addView(title("Riasztás"))
        val al = card().apply { setPadding(0, dp(4), 0, dp(4)) }
        al.addView(switchRow("Teljes hangerő", "Ébresztő-hangerőn szól, maximumra húzva (utána visszaáll)",
            Settings.beaconMaxVolume(this)) { Settings.setBeaconMaxVolume(this, it) })
        al.addView(View(this).apply { setBackgroundColor(0xFFE6E6E6.toInt()) },
            LinearLayout.LayoutParams(MATCH_PARENT, 1).apply { marginStart = dp(18); marginEnd = dp(18) })
        al.addView(switchRow("Teljes rezgés", "Lüktető, maximális erejű rezgés", Settings.beaconVibrate(this)) {
            Settings.setBeaconVibrate(this, it)
        })
        root.addView(al, lp())
        root.addView(text("Meddig szóljon", 13f, Alu.SUB).apply { setPadding(dp(8), dp(12), 0, dp(8)) })
        val secs = listOf(30, 60, 120, 300)
        root.addView(pills(secs.map { if (it < 60) "$it mp" else "${it / 60} perc" }, secs.indexOf(Settings.beaconSeconds(this))) {
            Settings.setBeaconSeconds(this, secs[it]); build()
        })
        root.addView(text("Érzékenység", 13f, Alu.SUB).apply { setPadding(dp(8), dp(16), 0, dp(8)) })
        root.addView(pills(listOf("Óvatos", "Normál", "Érzékeny"), Settings.beaconSens(this)) {
            Settings.setBeaconSens(this, it); Whistle.configure(this); build()
        })
        root.addView(text("Ha magától is megszólal (pl. madárcsicsergés, sípoló vízforraló), legyen óvatosabb, vagy tanítsd be a füttyöd. " +
            "Ha nem hallja meg, legyen érzékenyebb.", 12f, Alu.SUB).apply { setPadding(dp(8), dp(8), dp(8), 0); setLineSpacing(0f, 1.2f) })

        // Hogyan működik
        root.addView(title("Hogyan működik"))
        val info = card()
        for (line in listOf(
            "Kapcsold be a Figyelést, és ha nem találod a telefont, fütyülj egy hosszabbat (kb. fél–egy másodperc).",
            "A telefon minden LED-del villog (radar, SOS, stroboszkóp), teljes erővel rezeg, és robotos hangot ad.",
            "Leállítás: nyomd meg a bekapcsoló gombot, nyisd meg az appot, vagy várd ki a beállított időt.",
            "Rövid riasztás után 6 mp-ig nem figyel, hogy a saját hangjára ne induljon újra.",
            "A mikrofont az Android csak akkor engedi a háttérben, ha az app nyitva volt a bekapcsoláskor. Újraindítás után nyisd meg egyszer az appot, és újra figyel.",
            "Zsebben, táskában, párna alatt halkabban hallja – közelebbről fütyülj.",
            "Akku: a figyelés kb. ${Config.BEACON_LISTEN_MA.toInt()} mA többlet (az Akku fülön mérve, „Glyph Beacon” sorban).",
            "Ne zavarjanak módban, ha az ébresztők is tiltva vannak, a hang néma lehet – a villogás és a rezgés akkor is megy."
        )) info.addView(text("•  $line", 13f, Alu.SUB).apply { setPadding(0, dp(4), 0, dp(4)); setLineSpacing(0f, 1.2f) })
        root.addView(info, lp())
        refreshState()
    }

    private fun dotMark(sel: Boolean): View = View(this).apply {
        background = if (sel) rounded(Alu.RED, dp(11).toFloat()) else rounded(0x00000000, dp(11).toFloat(), 0xFFB0B0B0.toInt(), dp(2))
    }

    private fun switchRow(t: String, s: String, on: Boolean, change: (Boolean) -> Unit): LinearLayout {
        val r = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
            setPadding(dp(18), dp(14), dp(16), dp(14))
        }
        val tx = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        tx.addView(text(t, 16f, Alu.TEXT))
        tx.addView(text(s, 12f, Alu.SUB).apply { setPadding(0, dp(2), 0, 0) })
        r.addView(tx, LinearLayout.LayoutParams(0, WRAP_CONTENT, 1f))
        val tg = ToggleView(this).apply {
            checked = on; onColor = Alu.TEXT; knobColor = 0xFFFFFFFF.toInt()
            onChange = change
        }
        r.addView(tg)
        r.setOnClickListener { tg.performClick() }
        return r
    }

    private fun pills(labels: List<String>, sel: Int, pick: (Int) -> Unit): LinearLayout {
        val r = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
        labels.forEachIndexed { i, l ->
            val s = i == sel
            r.addView(text(l, 13.5f, if (s) 0xFFFFFFFF.toInt() else Alu.TEXT).apply {
                gravity = Gravity.CENTER
                background = if (s) rounded(Alu.TEXT, dp(22).toFloat()) else rounded(Alu.CARD, dp(22).toFloat(), Alu.STROKE, dp(1))
                setOnClickListener { pick(i) }
            }, LinearLayout.LayoutParams(0, dp(46), 1f).apply { if (i < labels.size - 1) marginEnd = dp(6) })
        }
        return r
    }

    // ------------------------------------------------------------------ betanítás

    private fun renderTraining() {
        trainBox.removeAllViews()
        val trained = Settings.beaconTrained(this)
        val head = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL }
        val ht = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        ht.addView(text(if (training) "Fütyülj!" else if (trained) "Betanítva" else "Tanítsd meg a füttyöd", 17f, Alu.TEXT))
        ht.addView(text(
            when {
                training -> "Háromszor fütyülj egy-egy hosszabbat (fél–egy mp), úgy, ahogy keresni szoktad"
                trained -> "%.1f–%.1f kHz · %.1f mp. Csak erre a füttyre felel.".format(
                    Settings.beaconMinHz(this) / 1000f, Settings.beaconMaxHz(this) / 1000f, Settings.beaconDurMs(this) / 1000f)
                else -> "Betanítás nélkül bármilyen fél másodperces füttyre felel"
            }, 12.5f, Alu.SUB).apply { setPadding(0, dp(3), 0, 0); setLineSpacing(0f, 1.15f) })
        head.addView(ht, LinearLayout.LayoutParams(0, WRAP_CONTENT, 1f))
        trainBox.addView(head)

        // Három nagy pont: a meglévő minták
        val dots = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER }
        for (i in 0 until 3) {
            val filled = if (training) i < samples.size else trained
            dots.addView(View(this).apply {
                background = if (filled) rounded(if (training) Alu.RED else Alu.TEXT, dp(14).toFloat())
                else rounded(0x00000000, dp(14).toFloat(), 0xFFB0B0B0.toInt(), dp(2))
            }, LinearLayout.LayoutParams(dp(28), dp(28)).apply { marginStart = dp(10); marginEnd = dp(10) })
        }
        trainBox.addView(dots, lp(0).apply { topMargin = dp(16); bottomMargin = dp(10) })
        if (training && lastTone.isNotEmpty()) trainBox.addView(text(lastTone, 12f, Alu.SUB).apply { gravity = Gravity.CENTER }, lp(0))

        val btns = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
        btns.addView(text(if (training) "Mégse" else if (trained) "Újratanítás" else "Betanítás", 14.5f, 0xFFFFFFFF.toInt(), Ui.medium).apply {
            gravity = Gravity.CENTER
            background = rounded(Alu.TEXT, dp(22).toFloat())
            setOnClickListener { if (training) stopTraining(false) else startTraining() }
        }, LinearLayout.LayoutParams(0, dp(46), 1f))
        if (trained && !training) {
            btns.addView(text("Törlés", 14.5f, Alu.TEXT).apply {
                gravity = Gravity.CENTER
                background = rounded(Alu.CARD, dp(22).toFloat(), Alu.STROKE, dp(1))
                setOnClickListener { Settings.clearBeaconTraining(this@BeaconActivity); Whistle.configure(this@BeaconActivity); renderTraining() }
            }, LinearLayout.LayoutParams(0, dp(46), 1f).apply { marginStart = dp(6) })
        }
        trainBox.addView(btns, lp(0).apply { topMargin = dp(10) })
    }

    private fun startTraining() {
        if (!hasMic()) { askMic(); return }
        training = true
        Whistle.training = true
        samples.clear()
        lastTone = ""
        renderTraining()
    }

    private fun stopTraining(save: Boolean) {
        if (save && samples.size >= 3) {
            val mn = samples.minOf { it[1] }
            val mx = samples.maxOf { it[2] }
            val dur = samples.map { it[3] }.average().toInt()
            Settings.setBeaconTraining(this, mn, mx, dur)
            Whistle.configure(this)
            BeaconAlarm.blip(this)
            DebugState.log("Glyph Beacon: betanítva %.0f–%.0f Hz, %d ms".format(mn, mx, dur))
        }
        training = false
        Whistle.training = false
        renderTraining()
    }

    private fun onTone(mid: Float, mn: Float, mx: Float, dur: Int) {
        if (!training) return
        if (dur < 250) {
            lastTone = "Túl rövid volt – fütyülj hosszabban"
        } else {
            samples += floatArrayOf(mid, mn, mx, dur.toFloat())
            lastTone = "%d. fütty: %.0f Hz, %.1f mp".format(samples.size, mid, dur / 1000f)
            if (samples.size >= 3) { stopTraining(true); return }
        }
        renderTraining()
    }

    // ------------------------------------------------------------------ élő rész

    override fun onResume() {
        super.onResume()
        GlyphMirror.appVisible = true
        if (SimonService.beaconAlarming.value) send(SimonService.ACTION_BEACON_STOP)
        // Ha be van kapcsolva, de a mikrofon nem fut (pl. újraindítás után): most, láthatóan, elindítható
        if (Settings.beaconOn(this) && !SimonService.beaconListening && hasMic()) send(SimonService.ACTION_BEACON_ON)
        Whistle.configure(this)
        Whistle.onTone = { mid, mn, mx, dur -> runOnUiThread { onTone(mid, mn, mx, dur) } }
        Whistle.refreshAttach()
        if (!hasMic()) askMic()
        liveJob?.cancel()
        liveJob = scope.launch {
            var ph = 0f
            var lastCheck = 0L
            while (isActive) {
                val now = SystemClock.elapsedRealtime()
                if (now - lastCheck > 500) {
                    lastCheck = now
                    ensureMic()
                    refreshState()
                }
                val hz = Whistle.pitch.value
                val alarming = SimonService.beaconAlarming.value
                ph = (ph + (if (alarming) 0.03f else if (hz > 0) 0.022f else 0.009f)) % 1f
                radar.phase = ph
                radar.listening = Settings.beaconOn(this@BeaconActivity) || training
                radar.alarming = alarming
                radar.hearing = if (hz > 0) 1f else maxOf(0f, radar.hearing - 0.05f)
                radar.invalidate()
                heard.text = if (hz > 0) "%,d HZ".format(hz.toInt()).replace(',', ' ') else "—"
                heard.setTextColor(if (hz > 0) Alu.RED else Alu.SUB)
                val n = (Whistle.level.value * 24).toInt()
                for (i in 0 until meter.childCount) {
                    meter.getChildAt(i).background = rounded(
                        when { i >= n -> Alu.DOT; hz > 0 -> Alu.RED; else -> Alu.TEXT }, dp(4).toFloat())
                }
                delay(40)
            }
        }
    }

    override fun onPause() {
        super.onPause()
        GlyphMirror.appVisible = false
        liveJob?.cancel()
        if (training) stopTraining(false)
        Whistle.onTone = null
        Whistle.refreshAttach()
        recorder?.stop()
        recorder = null
        preview?.release()
        preview = null
    }

    /** Az oldalnak saját mikrofon kell, ha a szolgáltatásé nem fut (élő kijelzés, betanítás). */
    private fun ensureMic() {
        if (!hasMic()) return
        if (SimonService.micOn) {
            recorder?.stop(); recorder = null
        } else if (recorder == null) {
            val r = BlowRecorder(this)
            if (r.start()) recorder = r
        }
    }

    private fun refreshState() {
        val on = Settings.beaconOn(this)
        master.checked = on
        masterSub.text = when {
            !hasMic() -> "Engedélyezd a mikrofont"
            !on -> "Kikapcsolva"
            SimonService.beaconListening -> "Figyel a háttérben is · " + (if (Settings.beaconTrained(this)) "a te füttyödre" else "bármilyen füttyre")
            else -> "Bekapcsolva – indul…"
        }
        val alarming = SimonService.beaconAlarming.value
        alarmBtn.text = if (alarming) "MEGVAN – LEÁLLÍTÁS" else "Próba-riasztás"
        alarmBtn.background = rounded(if (alarming) Alu.RED else 0xFF2A2A2A.toInt(), dp(27).toFloat())
    }

    private fun setListening(on: Boolean) {
        if (on && !hasMic()) {
            master.checked = false
            askMic()
            return
        }
        // A saját mikrofont elengedi, a szolgáltatás veszi át
        if (on) { recorder?.stop(); recorder = null }
        send(if (on) SimonService.ACTION_BEACON_ON else SimonService.ACTION_BEACON_OFF)
        if (on) BeaconAlarm.blip(this)
        refreshState()
    }

    private fun play(s: BeaconSound) {
        preview?.release()
        preview = try {
            MediaPlayer.create(this, s.raw)?.also { it.setOnCompletionListener { mp -> mp.release(); if (preview === mp) preview = null }; it.start() }
        } catch (t: Throwable) { null }
    }

    private fun hasMic() = checkSelfPermission(Manifest.permission.RECORD_AUDIO) == PackageManager.PERMISSION_GRANTED
    private fun askMic() = requestPermissions(arrayOf(Manifest.permission.RECORD_AUDIO), 11)

    override fun onRequestPermissionsResult(requestCode: Int, permissions: Array<String>, grantResults: IntArray) {
        if (requestCode == 11) refreshState()
    }

    private fun send(action: String) {
        val i = Intent(this, SimonService::class.java).setAction(action)
        if (action == SimonService.ACTION_BEACON_STOP || action == SimonService.ACTION_BEACON_OFF) startService(i) else startForegroundService(i)
    }

    override fun onDestroy() {
        scope.cancel()
        recorder?.stop()
        super.onDestroy()
    }
}
