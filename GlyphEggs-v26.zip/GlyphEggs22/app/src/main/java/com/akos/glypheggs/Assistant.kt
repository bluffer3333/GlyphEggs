package com.akos.glypheggs

import android.content.Context
import android.os.SystemClock
import com.nothing.ketchum.Glyph
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.withContext
import org.json.JSONArray
import org.json.JSONObject
import java.net.HttpURLConnection
import java.net.URL
import java.time.LocalDateTime
import java.time.format.DateTimeFormatter
import java.util.Locale
import kotlin.random.Random

/*
 * Hangasszisztens: beszélsz → a telefon szöveggé alakítja → Claude válaszol → a telefon felolvassa,
 * a Glyph LED-ek pedig „beszélnek” a hangra (szótagonként villannak a választott animációval).
 */

/** A beszéd LED-animációi. */
enum class TalkAnim(val title: String, val desc: String) {
    PULSE("Egyszerre", "Minden szótagra az összes LED egyszerre felvillan – mint egy hangszóró membránja"),
    ALTERNATE("Felváltva", "Kamera, gyűrű és alsó vonal felváltva, szavanként váltva"),
    WAVE("Hangerő-hullám", "Alulról felfelé töltődik a hangod erejével, mint egy VU-mérő"),
    EQUALIZER("Hangszínkép", "A 16 pontos sáv ugrál, mint egy hangszínkép-kijelző"),
    MOUTH("Száj", "A gyűrű két íve nyílik és csukódik a szótagokra, mint egy száj"),
    ORBIT("Körbe", "Fénycsóva fut körbe a gyűrűn; minden szóra lendületet kap"),
    ECHO("Visszhang", "Minden szó a kamerától indul, és hullámként fut le a töltőportig"),
    SPARK("Szikrák", "Véletlen LED-ek szikráznak – minél hangsúlyosabb, annál többen"),
    COMBO("Kombinált", "Kamera villan a szavakra, a sáv a hangerőt mutatja, a gyűrű körbejár – minden egyszerre")
}

/** Mit csinál épp az asszisztens. */
enum class TalkState(val label: String) {
    IDLE("KOPPINTS, ÉS BESZÉLJ"),
    LISTENING("HALLGATLAK…"),
    THINKING("GONDOLKODOM…"),
    SPEAKING("VÁLASZOLOK")
}

/** A beszéd eseményei az app és a LED-animáció között. */
object TalkBus {
    val state = MutableStateFlow(TalkState.IDLE)
    /** A mikrofon hangereje hallgatás közben (0..1), a felismerő adja. */
    @Volatile var micLevel = 0f
    /** Utolsó szótag-impulzus: erősség (0..1) és időpont. */
    @Volatile var pulse = 0f
    @Volatile var pulseAt = 0L
    @Volatile var words = 0

    fun syllable(strength: Float) {
        pulse = strength.coerceIn(0f, 1f)
        pulseAt = SystemClock.elapsedRealtime()
    }

    fun word() { words++ }
}

/** Utolsó válasz a widgetnek. */
object AssistantState {
    private const val PREFS = "glyph_eggs_assistant"
    private fun p(c: Context) = c.getSharedPreferences(PREFS, Context.MODE_PRIVATE)

    fun setLast(c: Context, q: String, a: String) {
        p(c).edit().putString("q", q).putString("a", a).apply()
        Widgets.updateAssistant(c)
    }
    fun lastQ(c: Context) = p(c).getString("q", null) ?: ""
    fun lastA(c: Context) = p(c).getString("a", null) ?: ""
}

/**
 * A LED-animáció a szolgáltatásban: ~30 kép/mp, a [TalkBus] állapotából és impulzusaiból számolva.
 * Hallgatás közben a hangerőt mutatja, gondolkodás közben lassan körbejár, beszédnél a választott stílus.
 */
class TalkGlyph(private val context: Context, private val glyph: GlyphController) {

    private val camera = intArrayOf(Glyph.Code_22111.A1, Glyph.Code_22111.A2, Glyph.Code_22111.B1)
    private val line = intArrayOf(
        Glyph.Code_22111.D1_1, Glyph.Code_22111.D1_2, Glyph.Code_22111.D1_3, Glyph.Code_22111.D1_4,
        Glyph.Code_22111.D1_5, Glyph.Code_22111.D1_6, Glyph.Code_22111.D1_7, Glyph.Code_22111.D1_8
    )
    private val bottom = line + Glyph.Code_22111.E1
    /** A gyűrű körbe, a bal felső saroktól az óramutató irányában. */
    private val ring = Zones.LEVEL.reversedArray() + intArrayOf(
        Glyph.Code_22111.C6, Glyph.Code_22111.C5, Glyph.Code_22111.C4, Glyph.Code_22111.C3, Glyph.Code_22111.C2
    )
    private val ringNoBar = intArrayOf(Glyph.Code_22111.C2, Glyph.Code_22111.C3, Glyph.Code_22111.C4, Glyph.Code_22111.C5, Glyph.Code_22111.C6)
    private val fill = LectureTimer.FILL_ORDER

    private var env = 0f
    private var lastPulseSeen = 0L
    private var orbit = 0f
    private var orbitSpeed = 0.15f
    private val echoes = ArrayList<Long>()
    private var lastWords = 0

    /**
     * [keepAlive] megadva (Claude app mód): addig fut, amíg igaz, és csendben egy halk „szívverés” jelzi,
     * hogy figyel; különben az IDLE állapot után 1,2 mp-cel magától befejeződik.
     */
    suspend fun run(keepAlive: (() -> Boolean)? = null) {
        var idleSince = 0L
        while (true) {
            val st = TalkBus.state.value
            val now = SystemClock.elapsedRealtime()
            if (keepAlive != null) {
                if (!keepAlive()) break
            } else if (st == TalkState.IDLE) {
                if (idleSince == 0L) idleSince = now
                if (now - idleSince > 1_200) break
            } else idleSince = 0L
            val f = frame(st, now)
            glyph.show(if (st == TalkState.IDLE && keepAlive != null && now % 2_000 < 120) intArrayOf(Glyph.Code_22111.E1) else f)
            delay(33)
        }
        glyph.off()
    }

    private fun frame(st: TalkState, now: Long): IntArray {
        // Burkológörbe: az impulzus felrántja, aztán lecseng
        if (TalkBus.pulseAt != lastPulseSeen) {
            lastPulseSeen = TalkBus.pulseAt
            env = maxOf(env, TalkBus.pulse)
            orbitSpeed = 0.35f + TalkBus.pulse * 0.4f
        }
        env *= 0.80f
        if (env < 0.03f) env = 0f
        val newWord = TalkBus.words != lastWords
        lastWords = TalkBus.words
        if (newWord) echoes += now

        return when (st) {
            TalkState.IDLE -> IntArray(0)
            TalkState.LISTENING -> {
                // Hangerőmérő a vonalon + a kamera „figyel” (lassú pislogás)
                val n = (TalkBus.micLevel * bottom.size).toInt().coerceIn(0, bottom.size)
                val lit = bottom.reversedArray().take(n).toMutableList()
                if ((now / 700) % 2 == 0L) lit += Glyph.Code_22111.A2
                lit.toIntArray()
            }
            TalkState.THINKING -> {
                // Három pontos csóva körbe a gyűrűn
                val pos = ((now / 70) % ring.size).toInt()
                intArrayOf(ring[pos], ring[(pos + ring.size - 1) % ring.size], ring[(pos + ring.size - 2) % ring.size]) +
                    (if ((now / 400) % 2 == 0L) intArrayOf(Glyph.Code_22111.E1) else IntArray(0))
            }
            TalkState.SPEAKING -> speaking(now, newWord)
        }
    }

    private fun speaking(now: Long, newWord: Boolean): IntArray {
        val e = env
        return when (Settings.talkAnim(context)) {
            TalkAnim.PULSE -> if (e > 0.25f) Zones.ALL else if (e > 0.08f) camera + ringNoBar else IntArray(0)
            TalkAnim.ALTERNATE -> {
                if (e < 0.1f) IntArray(0) else when (TalkBus.words % 3) {
                    0 -> camera
                    1 -> ring
                    else -> bottom
                }
            }
            TalkAnim.WAVE -> fill.take((e * fill.size).toInt()).toIntArray()
            TalkAnim.EQUALIZER -> {
                val n = (e * 16 * (0.75f + Random.nextFloat() * 0.25f)).toInt().coerceIn(0, 16)
                Zones.LEVEL.take(n).toIntArray() + (if (e > 0.6f) intArrayOf(Glyph.Code_22111.E1) else IntArray(0))
            }
            TalkAnim.MOUTH -> {
                // Felső ajak: C1 közepe felől kifelé; alsó ajak: az alsó ívek
                val open = (e * 8).toInt().coerceIn(0, 8)
                val upper = (0 until open).flatMap { listOf(Zones.LEVEL[7 - it], Zones.LEVEL[8 + it]) }
                val lower = if (e > 0.2f) listOf(Glyph.Code_22111.C4, Glyph.Code_22111.C5) else emptyList()
                val corners = if (e > 0.5f) listOf(Glyph.Code_22111.C3, Glyph.Code_22111.C6) else emptyList()
                (upper + lower + corners).toIntArray()
            }
            TalkAnim.ORBIT -> {
                orbit = (orbit + orbitSpeed) % ring.size
                orbitSpeed = maxOf(0.12f, orbitSpeed * 0.96f)
                val head = orbit.toInt()
                val tail = 2 + (e * 5).toInt()
                (0..tail).map { ring[(head - it + ring.size) % ring.size] }.toIntArray()
            }
            TalkAnim.ECHO -> {
                // Minden szó egy hullám a kamerától lefelé (a töltési sorrend visszafelé)
                echoes.removeAll { now - it > 900 }
                val rev = fill.reversedArray()
                echoes.flatMap { t ->
                    val pos = ((now - t) / 900f * rev.size).toInt()
                    (maxOf(0, pos - 3)..minOf(rev.size - 1, pos)).map { rev[it] }
                }.distinct().toIntArray()
            }
            TalkAnim.SPARK -> {
                val n = (e * 14).toInt()
                (0 until n).map { Zones.ALL[Random.nextInt(Zones.ALL.size)] }.distinct().toIntArray()
            }
            TalkAnim.COMBO -> {
                orbit = (orbit + orbitSpeed) % ringNoBar.size
                orbitSpeed = maxOf(0.08f, orbitSpeed * 0.95f)
                val lit = mutableListOf<Int>()
                if (newWord || e > 0.55f) lit += camera.toList()
                lit += Zones.LEVEL.take((e * 16).toInt()).toList()
                lit += ringNoBar[orbit.toInt() % ringNoBar.size]
                if (e > 0.3f) lit += Glyph.Code_22111.E1
                lit.toIntArray()
            }
        }
    }
}

/** A Claude API hívása (Messages API). Csak a beírt kulccsal, közvetlenül az Anthropic szerverére. */
object ClaudeClient {
    private const val URL_MESSAGES = "https://api.anthropic.com/v1/messages"

    private fun system(): String {
        val now = LocalDateTime.now().format(DateTimeFormatter.ofPattern("yyyy. MMMM d., EEEE, HH:mm", Locale("hu", "HU")))
        return "Te Claude vagy, az Anthropic MI-asszisztense, és most egy Nothing Phone (2) telefonon szólalsz meg a Glyph Eggs " +
            "app hangasszisztenseként. A válaszodat a telefon hangosan felolvassa, közben a hátlap Glyph LED-jei villognak a hangodra. " +
            "Ezért: válaszolj természetes, beszélt magyar nyelven, röviden (általában 1–4 mondat, hacsak nem kérnek részletesebbet). " +
            "Ne használj markdownt, felsorolásjelet, táblázatot, emojit, linket vagy kódot – csak folyó szöveget, amit jó hallgatni. " +
            "A számokat és mértékegységeket úgy írd, ahogy kimondanád. Ha valamit nem tudhatsz (pl. friss hírek, élő adatok), mondd meg őszintén. " +
            "A pontos idő most: $now."
    }

    /** [history]: (szerep, szöveg) párok, a legutolsó a felhasználó kérdése. */
    suspend fun ask(c: Context, history: List<Pair<String, String>>): String = withContext(Dispatchers.IO) {
        val key = Settings.assistantKey(c).trim()
        if (key.isEmpty()) throw IllegalStateException("Nincs megadva Claude API-kulcs – írd be a beállításoknál.")
        val msgs = JSONArray()
        for ((role, text) in history) msgs.put(JSONObject().put("role", role).put("content", text))
        val body = JSONObject()
            .put("model", Settings.assistantModel(c).id)
            .put("max_tokens", 700)
            .put("system", system())
            .put("messages", msgs)
        val conn = URL(URL_MESSAGES).openConnection() as HttpURLConnection
        try {
            conn.requestMethod = "POST"
            conn.connectTimeout = 15_000
            conn.readTimeout = 60_000
            conn.doOutput = true
            conn.setRequestProperty("content-type", "application/json")
            conn.setRequestProperty("x-api-key", key)
            conn.setRequestProperty("anthropic-version", "2023-06-01")
            conn.outputStream.use { it.write(body.toString().toByteArray(Charsets.UTF_8)) }
            val code = conn.responseCode
            val stream = if (code in 200..299) conn.inputStream else conn.errorStream
            val resp = stream?.bufferedReader(Charsets.UTF_8)?.use { it.readText() } ?: ""
            if (code !in 200..299) {
                val msg = try { JSONObject(resp).getJSONObject("error").optString("message") } catch (t: Throwable) { "" }
                throw IllegalStateException(when (code) {
                    401 -> "Hibás API-kulcs (401)."
                    429 -> "Túl sok kérés vagy elfogyott a keret (429). Próbáld kicsit később."
                    529, 503 -> "A Claude most túlterhelt ($code). Próbáld újra pár másodperc múlva."
                    else -> "Hiba ($code): $msg"
                })
            }
            val content = JSONObject(resp).getJSONArray("content")
            val sb = StringBuilder()
            for (i in 0 until content.length()) {
                val block = content.getJSONObject(i)
                if (block.optString("type") == "text") sb.append(block.optString("text"))
            }
            sb.toString().trim()
        } finally {
            conn.disconnect()
        }
    }

    /** Felolvasás előtt: a markdown-maradványok és furcsa jelek eltávolítása. */
    fun forSpeech(s: String): String = s
        .replace(Regex("[*_#`>|]"), "")
        .replace(Regex("\\[(.*?)]\\(.*?\\)"), "$1")
        .replace(Regex("\\s+"), " ")
        .trim()
}

/** Választható Claude modellek. */
enum class AssistantModel(val title: String, val desc: String, val id: String) {
    HAIKU("Haiku", "Gyors és olcsó – hangos beszélgetéshez ideális", "claude-haiku-5-5"),
    SONNET("Sonnet", "Okosabb, kicsit lassabb", "claude-sonnet-5-5")
}

/** Hány magánhangzó (≈ szótag) van egy magyar szóban. */
fun syllables(word: String): Int =
    word.lowercase().count { it in "aáeéiíoóöőuúüűy" }.coerceAtLeast(1)
