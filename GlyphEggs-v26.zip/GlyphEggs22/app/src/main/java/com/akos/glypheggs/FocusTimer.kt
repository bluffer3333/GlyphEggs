package com.akos.glypheggs

import android.content.Context
import android.os.SystemClock
import com.nothing.ketchum.Glyph
import kotlinx.coroutines.channels.Channel
import kotlinx.coroutines.coroutineScope
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.merge
import kotlinx.coroutines.launch
import kotlin.math.PI
import kotlin.math.roundToInt
import kotlin.math.sin

/** Időzítő-fajták. Az egyszeri és a homokóra hossza az appban állítható. */
enum class TimerMode(
    val title: String,
    val desc: String,
    val workMin: Int,
    val breakMin: Int,
    val longBreakMin: Int,
    val rounds: Int
) {
    POMODORO("Pomodoro", "25 perc fókusz, 5 perc szünet, 4 kör, a végén 15 perc", 25, 5, 15, 4),
    SHORT("Rövid Pomodoro", "15 perc fókusz, 3 perc szünet, 4 kör, a végén 10 perc", 15, 3, 10, 4),
    DEEP("Mély fókusz", "50 perc munka, 10 perc szünet, 3 kör, a végén 20 perc", 50, 10, 20, 3),
    RATIO("52 / 17", "52 perc munka, 17 perc szünet, 3 kör", 52, 17, 0, 3),
    SPRINT("Sprint", "10 perc hajrá, 2 perc szusszanás, 5 kör", 10, 2, 0, 5),
    SINGLE("Egyszeri időzítő", "Egy visszaszámlálás a beállított percekkel", 0, 0, 0, 1),
    HOURGLASS("Homokóra", "Rövid homokóra (pl. fogmosás, tea, társasjáték)", 0, 0, 0, 1);

    val custom: Boolean get() = this == SINGLE || this == HOURGLASS
}

/** Animációk az időzítőhöz. */
enum class TimerStyle(val title: String, val desc: String) {
    SAND("Homokóra", "Felül fogy a homok, a szem a vonalon lefelé hull, alul a töltőportnál gyűlik és megtelik"),
    BAR("Fogyó sáv", "A felső sáv LED-enként fogy; az utolsó pislog"),
    CLOCK("Óramutató", "Egy fénypont körbejár a gyűrűn, mögötte megtelik"),
    BREATH("Lélegző", "Lassú be- és kilégzés ritmusára lélegzik a gyűrű; a vonal mutatja az időt"),
    RAIN("Eső", "Cseppek hullanak véletlenszerűen, egyre sűrűbben, ahogy fogy az idő"),
    MINIMAL("Csak a vége", "Teljes sötét, csak 10 mp-enként egy apró jel – semmi nem vonja el a figyelmed")
}

/**
 * Fókusz-időzítő a LED-eken (Pomodoro és társai), hogy ne kelljen a képernyőt nézni.
 *
 * Vezérlés kopogással (fekve), vagy a szimuláció Érintés gombjával:
 *  - 1 kopogás: 3 mp-re megmutatja a hátralévő időt a felső sávon
 *  - 2 kopogás: szünet / folytatás
 *  - 3 kopogás: ugrás a következő szakaszra
 * Fókusz alatt a választott animáció fut, szünetben a gyűrű lassan lélegzik (pihenés).
 * Szakasz végén rezgés és villogás; a teljes kör végén nagy ünneplés.
 */
class FocusTimer(
    private val context: Context,
    private val glyph: GlyphController,
    private val motion: MotionDetector,
    private val haptics: Haptics,
    private val onStatus: (String) -> Unit
) {
    private class Phase(val title: String, val ms: Long, val isBreak: Boolean)

    companion object {
        private val bar: IntArray = IntArray(16) { Zones.LEVEL[15 - it] } // bal felső végétől jobbra
        private val dLine = intArrayOf(
            Glyph.Code_22111.D1_1, Glyph.Code_22111.D1_2, Glyph.Code_22111.D1_3, Glyph.Code_22111.D1_4,
            Glyph.Code_22111.D1_5, Glyph.Code_22111.D1_6, Glyph.Code_22111.D1_7, Glyph.Code_22111.D1_8
        )
        /** A gyűrű körben, felülről az óramutató irányában. */
        private val ring: IntArray = bar + intArrayOf(
            Glyph.Code_22111.C6, Glyph.Code_22111.C5, Glyph.Code_22111.C4, Glyph.Code_22111.C3, Glyph.Code_22111.C2
        )

        /** Homokóra felső része: ami a legtovább marad elöl (a kamera), a sáv jobb vége fogy először. */
        private val sandTop: IntArray = intArrayOf(Glyph.Code_22111.A1, Glyph.Code_22111.A2, Glyph.Code_22111.B1) + bar
        /** Homokóra alja: alulról (töltőport) felfelé telik. */
        private val sandBottom: IntArray = intArrayOf(Glyph.Code_22111.E1) + dLine + intArrayOf(
            Glyph.Code_22111.C4, Glyph.Code_22111.C3, Glyph.Code_22111.C5, Glyph.Code_22111.C2, Glyph.Code_22111.C6
        )
        /** A hulló szem útja: a gyűrű jobb oldalán le, majd a vonalon le a töltőportig. */
        private val grainPath: IntArray = intArrayOf(
            Glyph.Code_22111.C6, Glyph.Code_22111.C5
        ) + dLine.reversedArray() + intArrayOf(Glyph.Code_22111.E1)

        /**
         * Egy animációs kép (a beállító oldal előnézete is ezt használja).
         * [p] = eltelt rész 0..1, [frame] = 100 ms-os képkocka-számláló.
         */
        fun frame(style: TimerStyle, p: Float, frame: Int, isBreak: Boolean): IntArray {
            if (isBreak) return breath(p, frame)
            return when (style) {
                TimerStyle.SAND -> sand(p, frame)
                TimerStyle.BAR -> {
                    val n = ((1f - p) * 16f).roundToInt().coerceIn(0, 16)
                    val lit = bar.take(n).toMutableList()
                    if (n > 0 && frame % 10 < 5) lit.remove(bar[n - 1])
                    lit.toIntArray()
                }
                TimerStyle.CLOCK -> {
                    val pos = (p * ring.size).toInt().coerceIn(0, ring.size - 1)
                    val trail = ring.take(pos).toMutableList()
                    if (frame % 6 < 4) trail += ring[pos]
                    trail.toIntArray()
                }
                TimerStyle.BREATH -> breath(p, frame)
                TimerStyle.RAIN -> rain(p, frame)
                TimerStyle.MINIMAL -> if (frame % 100 == 0) intArrayOf(Glyph.Code_22111.E1) else intArrayOf()
            }
        }

        private fun sand(p: Float, frame: Int): IntArray {
            val top = ((1f - p) * sandTop.size).roundToInt().coerceIn(0, sandTop.size)
            val filled = (p * sandBottom.size).roundToInt().coerceIn(0, sandBottom.size)
            val lit = (sandTop.take(top) + sandBottom.take(filled)).toMutableList()
            // Egy szem hullik ~1,5 mp-enként, amíg van homok, és a még üres részen esik le
            if (top > 0 && filled < sandBottom.size) {
                val step = frame % 15
                if (step < grainPath.size) {
                    val z = grainPath[step]
                    if (z !in lit) lit += z
                }
            }
            return lit.toIntArray()
        }

        /** Lélegző gyűrű: 4 mp belégzés, 4 mp kilégzés; a vonal mutatja az eltelt időt. */
        private fun breath(p: Float, frame: Int): IntArray {
            val phase = (frame % 80) / 80f
            val amount = (sin(phase * 2 * PI - PI / 2) * 0.5 + 0.5).toFloat()
            val half = (amount * 8f).roundToInt()
            val lit = (0 until 16).filter { kotlin.math.abs(it - 7.5f) <= half }.map { bar[it] }.toMutableList()
            if (amount > 0.6f) lit += intArrayOf(Glyph.Code_22111.C2, Glyph.Code_22111.C6).toList()
            if (amount > 0.85f) lit += intArrayOf(Glyph.Code_22111.C3, Glyph.Code_22111.C5).toList()
            val n = (p * 8f).toInt().coerceIn(0, 8)
            lit += dLine.take(n)
            return lit.toIntArray()
        }

        /** Eső: egyre több csepp hullik a vonalon és villan a gyűrűn. */
        private fun rain(p: Float, frame: Int): IntArray {
            val lit = mutableListOf<Int>()
            val drops = 1 + (p * 4f).toInt()
            for (k in 0 until drops) {
                val offset = k * 7
                val step = (frame + offset) % 12
                if (step < 8) lit += dLine[7 - step]
                val seed = ((frame / 3 + k * 13) * 2654435761L).toInt() ushr 1
                if ((frame / 3 + k) % 3 == 0) lit += ring[seed % ring.size]
            }
            // A pont a "tócsa": a végére egyre tovább ég
            if (frame % 20 < (p * 20).toInt()) lit += Glyph.Code_22111.E1
            return lit.distinct().toIntArray()
        }
    }

    private fun phases(): List<Phase> {
        val mode = Settings.timerMode(context)
        if (mode.custom) {
            val min = Settings.timerMinutes(context).coerceIn(1, 240)
            return listOf(Phase(mode.title, min * 60_000L, false))
        }
        val list = mutableListOf<Phase>()
        for (r in 1..mode.rounds) {
            list += Phase("Fókusz $r/${mode.rounds}", mode.workMin * 60_000L, false)
            if (r < mode.rounds) list += Phase("Szünet $r/${mode.rounds - 1}", mode.breakMin * 60_000L, true)
            else if (mode.longBreakMin > 0) list += Phase("Hosszú szünet", mode.longBreakMin * 60_000L, true)
        }
        return list
    }

    fun totalMs(): Long = phases().sumOf { it.ms }

    private fun fmt(ms: Long): String {
        val s = (ms / 1000).coerceAtLeast(0)
        return "%d:%02d".format(s / 60, s % 60)
    }

    suspend fun run() = coroutineScope {
        val knocks = Channel<Long>(16)
        val collector = launch { merge(motion.knockEvents, GlyphMirror.taps).collect { knocks.trySend(it) } }
        try {
            loop(knocks)
        } finally {
            collector.cancel()
            glyph.off()
            TimerState.clear(context)
        }
    }

    private suspend fun loop(knocks: Channel<Long>) {
        val style = Settings.timerStyle(context)
        val list = phases()
        DebugState.log("Időzítő: ${Settings.timerMode(context).title}, ${list.size} szakasz, animáció: ${style.title}")

        for ((index, ph) in list.withIndex()) {
            announce(ph)
            TimerState.running(context, ph.title, SystemClock.elapsedRealtime() + ph.ms, index, list.size, ph.isBreak, ph.ms)
            var elapsed = 0L
            var last = SystemClock.elapsedRealtime()
            var paused = false
            var peekUntil = 0L
            var knockCount = 0
            var lastKnock = 0L
            var lastStatus = 0L
            var tick = 0
            var skip = false

            while (elapsed < ph.ms && !skip) {
                val now = SystemClock.elapsedRealtime()
                if (!paused) elapsed += now - last
                last = now

                while (true) {
                    knocks.tryReceive().getOrNull() ?: break
                    knockCount++
                    lastKnock = now
                }
                if (knockCount > 0 && now - lastKnock > Config.PET_KNOCK_GROUP_MS) {
                    when (knockCount) {
                        1 -> peekUntil = now + 3_000
                        2 -> {
                            paused = !paused
                            haptics.tick()
                            if (paused) TimerState.pause(context, ph.ms - elapsed)
                            else TimerState.resume(context, ph.ms - elapsed)
                            DebugState.log(if (paused) "Időzítő szünetel" else "Időzítő folytatódik")
                        }
                        else -> {
                            skip = true
                            DebugState.log("Ugrás a következő szakaszra")
                        }
                    }
                    knockCount = 0
                }

                val p = (elapsed.toFloat() / ph.ms).coerceIn(0f, 1f)
                val lit: IntArray = when {
                    paused -> if (tick % 20 < 10) intArrayOf(Glyph.Code_22111.E1, Glyph.Code_22111.A1, Glyph.Code_22111.A2) else intArrayOf()
                    now < peekUntil -> bar.take(((1f - p) * 16f).roundToInt().coerceIn(1, 16)).toIntArray() +
                        dLine.take(((index + 1) * 8 / list.size).coerceIn(1, 8))
                    else -> frame(style, p, tick, ph.isBreak)
                }
                glyph.show(lit)

                if (now - lastStatus > 15_000 || lastStatus == 0L) {
                    Widgets.updateHourglass(context)
                    lastStatus = now
                    onStatus("${ph.title} · ${fmt(ph.ms - elapsed)} van hátra" + if (paused) " (szünetel)" else "")
                }
                tick++
                delay(100)
            }

            val lastPhase = index == list.lastIndex
            if (lastPhase) finale() else phaseEnd(ph)
        }
    }

    private suspend fun announce(ph: Phase) {
        onStatus("${ph.title} · ${fmt(ph.ms)}")
        if (ph.isBreak) {
            // Szünet: lassan felgyúló gyűrű
            for (k in 0..8) {
                glyph.show((0 until 16).filter { kotlin.math.abs(it - 7.5f) <= k }.map { bar[it] }.toIntArray())
                delay(60)
            }
        } else {
            haptics.tick()
            for (z in ring) {
                glyph.show(intArrayOf(z))
                delay(20)
            }
        }
        glyph.off()
        delay(300)
    }

    private suspend fun phaseEnd(ph: Phase) {
        DebugState.log("${ph.title} vége")
        haptics.phaseEnd()
        repeat(4) {
            glyph.show(if (ph.isBreak) bar else ring)
            delay(250)
            glyph.off()
            delay(200)
        }
    }

    private suspend fun finale() {
        DebugState.log("Időzítő vége – szép munka!")
        haptics.win()
        repeat(12) { k ->
            glyph.show(if (k % 2 == 0) Zones.ALL else ring)
            delay(180)
            glyph.off()
            delay(120)
        }
        glyph.show(Zones.ALL)
        delay(800)
    }
}
