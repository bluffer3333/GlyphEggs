package com.akos.glypheggs

import android.app.PendingIntent
import android.content.Intent
import android.service.quicksettings.TileService

/** Közös segéd a csempékhez: elindítja a szolgáltatást, vagy ha a rendszer nem engedi, megnyitja az appot. */
object TileStarter {
    fun startService(tile: TileService, action: String): Boolean {
        return try {
            tile.startForegroundService(Intent(tile, SimonService::class.java).setAction(action))
            true
        } catch (e: Exception) {
            DebugState.log("Csempéről nem indult: ${e.message}")
            val open = PendingIntent.getActivity(
                tile, 0,
                Intent(tile, MainActivity::class.java).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK),
                PendingIntent.FLAG_IMMUTABLE
            )
            tile.startActivityAndCollapse(open)
            false
        }
    }
}
