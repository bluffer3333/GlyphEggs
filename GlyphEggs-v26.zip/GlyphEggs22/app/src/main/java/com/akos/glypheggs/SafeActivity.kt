package com.akos.glypheggs

import android.app.Activity
import android.app.AlertDialog
import android.content.Intent
import android.content.pm.PackageManager
import android.net.Uri
import android.os.Bundle
import android.text.InputType
import android.view.Gravity
import android.view.ViewGroup.LayoutParams.MATCH_PARENT
import android.view.ViewGroup.LayoutParams.WRAP_CONTENT
import android.widget.EditText
import android.widget.FrameLayout
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView

/**
 * A széf beállítása: a döntéses kód (3–8 irány, mint a Simonnál) és hogy mi nyíljon meg helyes kódnál.
 */
class SafeActivity : Activity() {

    companion object {
        private const val REQ_FOLDER = 41
    }

    private val code = mutableListOf<Direction>()
    private lateinit var codeBox: LinearLayout
    private lateinit var targetList: LinearLayout
    private lateinit var overlayCard: FeatureCard

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        darkWindow()
        code += Settings.safeTiltCode(this)

        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(15), 0, dp(15), dp(24))
        }
        val scroll = ScrollView(this).apply {
            background = Ui.pageBg()
            isVerticalScrollBarEnabled = false
            addView(root, FrameLayout.LayoutParams(MATCH_PARENT, WRAP_CONTENT))
            padForSystemBars()
        }
        setContentView(scroll)

        val header = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
            setPadding(dp(7), dp(28), 0, dp(8))
        }
        header.addView(ImageView(this).apply {
            setImageResource(R.drawable.ic_back)
            setOnClickListener { finish() }
        }, LinearLayout.LayoutParams(dp(24), dp(24)))
        header.addView(text("Széf", 26f).apply { setPadding(dp(30), 0, 0, 0) })
        root.addView(header)

        root.addView(text(
            "Indítsd a Széfet (kártya, csempe, widget vagy mozdulat), aztán döntsd a telefont a kódod irányaiba, " +
                "egymás után – mint a Simonnál: előre = kamera felé, hátra = töltőport felé, balra, jobbra; minden döntés után " +
                "vissza vízszintesbe. A döntés irányának LED-jei felvillannak, a felső sáv mutatja, hány lépés van meg.",
            13f, Ui.SUB
        ).apply { setPadding(dp(7), dp(14), dp(7), dp(6)); setLineSpacing(0f, 1.2f) })

        // --- Kód ---
        root.addView(sectionTitle("Kód (koppints egy lépésre az irány váltásához)"))
        codeBox = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        root.addView(codeBox)

        // --- Mi nyíljon meg ---
        root.addView(sectionTitle("Mi nyíljon meg helyes kódnál"))
        targetList = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        root.addView(targetList)

        // --- Azonnali megnyitás ---
        root.addView(sectionTitle("Azonnali megnyitás"))
        overlayCard = FeatureCard(this, R.drawable.ic_bolt, "Megnyitás azonnal",
            "", true)
        val openOverlay = {
            startActivity(Intent(android.provider.Settings.ACTION_MANAGE_OVERLAY_PERMISSION, Uri.parse("package:$packageName")))
        }
        overlayCard.setOnClickListener { openOverlay() }
        overlayCard.toggle?.onChange = { openOverlay() }
        root.addView(row(overlayCard, null, 150).apply {
            // Teljes szélesség
            removeAllViews()
            addView(overlayCard, LinearLayout.LayoutParams(MATCH_PARENT, dp(150)))
        })

        // --- Kipróbálás ---
        root.addView(sectionTitle("Kipróbálás"))
        val tryCard = FeatureCard(this, R.drawable.ic_safe, "Széf indítása", "Utána döntsd a kód irányaiba", false)
        tryCard.setOnClickListener {
            startForegroundService(Intent(this, SimonService::class.java).setAction(SimonService.ACTION_SAFE))
        }
        val gestureCard = FeatureCard(this, R.drawable.ic_gesture, "Indító mozdulat",
            Settings.trigger(this, Feature.SAFE).title, false)
        gestureCard.setOnClickListener {
            startActivity(Intent(this, GesturesActivity::class.java).putExtra(GesturesActivity.EXTRA_FEATURE, Feature.SAFE.name))
        }
        root.addView(row(tryCard, gestureCard, 150))

        renderCode()
    }

    override fun onResume() {
        super.onResume()
        GlyphMirror.appVisible = true
        renderTargets()
        val ok = android.provider.Settings.canDrawOverlays(this)
        overlayCard.toggle?.checked = ok
        overlayCard.subtitleView.text = if (ok) "Bekapcsolva: a széf rögtön megnyitja a célt"
        else "Ki: egy értesítésre kell koppintani (engedély kell hozzá)"
    }

    override fun onPause() {
        super.onPause()
        GlyphMirror.appVisible = false
    }

    private fun dirLabel(d: Direction) = when (d) {
        Direction.FORWARD -> "↑ Előre"
        Direction.BACK -> "↓ Hátra"
        Direction.LEFT -> "← Balra"
        Direction.RIGHT -> "→ Jobbra"
    }

    private fun save() = Settings.setSafeTiltCode(this, code)

    /** A kód lépései soronként 4-esével, alattuk a hossz léptetője. */
    private fun renderCode() {
        codeBox.removeAllViews()
        for (chunk in code.indices.chunked(4)) {
            val rowView = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
            for (i in chunk) {
                val box = LinearLayout(this).apply {
                    orientation = LinearLayout.VERTICAL
                    gravity = Gravity.CENTER_HORIZONTAL
                    background = rounded(Ui.CARD, dp(18).toFloat())
                    setPadding(dp(4), dp(10), dp(4), dp(10))
                    setOnClickListener {
                        val all = listOf(Direction.FORWARD, Direction.RIGHT, Direction.BACK, Direction.LEFT)
                        code[i] = all[(all.indexOf(code[i]) + 1) % all.size]
                        save()
                        renderCode()
                    }
                }
                box.addView(text("${i + 1}.", 12f, Ui.SUB))
                val map = GlyphMapView(this).apply { unlitColor = 0xFF444444.toInt(); lit = code[i].zones().toSet() }
                box.addView(map, LinearLayout.LayoutParams(MATCH_PARENT, dp(90)))
                box.addView(text(dirLabel(code[i]), 12f, Ui.TEXT).apply { gravity = Gravity.CENTER },
                    LinearLayout.LayoutParams(MATCH_PARENT, WRAP_CONTENT))
                rowView.addView(box, LinearLayout.LayoutParams(0, WRAP_CONTENT, 1f).apply {
                    marginStart = dp(2.5f); marginEnd = dp(2.5f)
                })
            }
            repeat(4 - chunk.size) {
                rowView.addView(android.view.View(this), LinearLayout.LayoutParams(0, dp(10), 1f).apply {
                    marginStart = dp(2.5f); marginEnd = dp(2.5f)
                })
            }
            codeBox.addView(rowView, LinearLayout.LayoutParams(MATCH_PARENT, WRAP_CONTENT).apply { bottomMargin = dp(5) })
        }
        // Hossz: − N +
        val len = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
            background = rounded(Ui.CARD, dp(20).toFloat())
            setPadding(dp(18), dp(10), dp(12), dp(10))
        }
        len.addView(text("A kód hossza", 16f), LinearLayout.LayoutParams(0, WRAP_CONTENT, 1f))
        fun btn(label: String, onClick: () -> Unit) = text(label, 22f).apply {
            gravity = Gravity.CENTER
            background = rounded(0xFF3A3A3A.toInt(), dp(22).toFloat())
            setOnClickListener { onClick() }
        }
        len.addView(btn("−") { if (code.size > 3) { code.removeAt(code.lastIndex); save(); renderCode() } },
            LinearLayout.LayoutParams(dp(44), dp(44)))
        len.addView(text("${code.size}", 17f, Ui.TEXT, Ui.medium).apply { gravity = Gravity.CENTER },
            LinearLayout.LayoutParams(dp(50), WRAP_CONTENT))
        len.addView(btn("+") { if (code.size < 8) { code += Direction.FORWARD; save(); renderCode() } },
            LinearLayout.LayoutParams(dp(44), dp(44)))
        codeBox.addView(len, LinearLayout.LayoutParams(MATCH_PARENT, WRAP_CONTENT).apply { topMargin = dp(5) })
    }

    private fun renderTargets() {
        targetList.removeAllViews()
        val type = Settings.safeTargetType(this)
        val label = Settings.safeTargetLabel(this)
        val options = listOf(
            Triple("NOTES", "Titkos jegyzetek", "Beépített, csak a széffel nyitható"),
            Triple("FOLDER", "Mappa", if (type == "FOLDER" && label.isNotEmpty()) label else "Válassz egy mappát a telefonon"),
            Triple("APP", "Alkalmazás", if (type == "APP" && label.isNotEmpty()) label else "Válassz egy appot"),
            Triple("URL", "Weboldal", if (type == "URL" && label.isNotEmpty()) label else "Adj meg egy címet"),
            Triple("NONE", "Semmi", "Csak a fényshow és a rezgés")
        )
        for ((key, title, sub) in options) {
            val row = LinearLayout(this).apply {
                orientation = LinearLayout.HORIZONTAL
                gravity = Gravity.CENTER_VERTICAL
                background = rounded(Ui.CARD, dp(20).toFloat())
                setPadding(dp(18), dp(16), dp(16), dp(16))
                setOnClickListener { chooseTarget(key) }
            }
            val texts = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
            texts.addView(text(title, 17f))
            texts.addView(text(sub, 12.5f, Ui.SUB).apply { setPadding(0, dp(2), 0, 0) })
            row.addView(texts, LinearLayout.LayoutParams(0, WRAP_CONTENT, 1f))
            row.addView(RadioMark(this, key == type), LinearLayout.LayoutParams(dp(26), dp(26)).apply { marginStart = dp(12) })
            targetList.addView(row, LinearLayout.LayoutParams(MATCH_PARENT, WRAP_CONTENT).apply { bottomMargin = dp(5) })
        }
    }

    private fun dialog() = AlertDialog.Builder(this, android.R.style.Theme_DeviceDefault_Dialog_Alert)

    private fun chooseTarget(key: String) {
        when (key) {
            "NOTES" -> { Settings.setSafeTarget(this, "NOTES", "", "Titkos jegyzetek"); renderTargets() }
            "NONE" -> { Settings.setSafeTarget(this, "NONE", "", ""); renderTargets() }
            "FOLDER" -> startActivityForResult(Intent(Intent.ACTION_OPEN_DOCUMENT_TREE), REQ_FOLDER)
            "URL" -> {
                val input = EditText(this).apply {
                    inputType = InputType.TYPE_CLASS_TEXT or InputType.TYPE_TEXT_VARIATION_URI
                    hint = "pl. youtube.com"
                    if (Settings.safeTargetType(this@SafeActivity) == "URL") setText(Settings.safeTargetValue(this@SafeActivity))
                }
                dialog().setTitle("Weboldal címe")
                    .setView(input)
                    .setPositiveButton("Mentés") { _, _ ->
                        val v = input.text.toString().trim()
                        if (v.isNotEmpty()) Settings.setSafeTarget(this, "URL", v, v)
                        renderTargets()
                    }
                    .setNegativeButton("Mégse", null)
                    .show()
            }
            "APP" -> {
                val launcher = Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_LAUNCHER)
                val apps = packageManager.queryIntentActivities(launcher, PackageManager.MATCH_ALL)
                    .map { it.loadLabel(packageManager).toString() to it.activityInfo.packageName }
                    .filter { it.second != packageName }
                    .distinctBy { it.second }
                    .sortedBy { it.first.lowercase() }
                dialog().setTitle("Melyik app nyíljon meg?")
                    .setItems(apps.map { it.first }.toTypedArray()) { _, which ->
                        val (label, pkg) = apps[which]
                        Settings.setSafeTarget(this, "APP", pkg, label)
                        renderTargets()
                    }
                    .setNegativeButton("Mégse", null)
                    .show()
            }
        }
    }

    @Deprecated("Deprecated in Java")
    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        if (requestCode != REQ_FOLDER || resultCode != RESULT_OK) return
        val uri = data?.data ?: return
        try {
            contentResolver.takePersistableUriPermission(uri, Intent.FLAG_GRANT_READ_URI_PERMISSION)
        } catch (t: Throwable) {
            DebugState.log("Mappa engedély hiba: ${t.javaClass.simpleName}")
        }
        val name = Uri.decode(uri.lastPathSegment ?: "Mappa").substringAfterLast(':').ifEmpty { "Mappa" }
        Settings.setSafeTarget(this, "FOLDER", uri.toString(), name)
        renderTargets()
    }
}
