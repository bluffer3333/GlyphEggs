package com.akos.glypheggs

import android.os.SystemClock
import com.nothing.ketchum.Glyph
import kotlinx.coroutines.channels.Channel
import kotlinx.coroutines.coroutineScope
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.merge
import kotlinx.coroutines.launch
import kotlinx.coroutines.withTimeoutOrNull
import kotlin.math.abs
import kotlin.math.max
import kotlin.random.Random

/**
 * Zárfeltörő (lockpicking) minijáték.
 *
 *  - A C1 sávon (16 kis LED) egy fénypont csúszik ide-oda.
 *  - Valahol a sáv közepe táján van egy rejtett "édes pont". Amikor a fény odaér, a telefon
 *    egy kicsit rezzen – abban a pillanatban kell kopognod (vagy az Érintés gombra nyomnod).
 *  - Közel jártál (1–2 LED): a pont és a cél közti LED-ek felvillannak – jelzi, hogy túl korán
 *    vagy túl későn nyomtad. Ez nem kerül életbe.
 *  - Nagyon mellé: egy élet elvész (életek: A1, A2, B1).
 *  - Talált: kattan a zár, fényáradat; jön a következő tüske, egyre gyorsabban.
 *    A kinyitott tüskéket a D1 vonal mutatja (tüskénként 2 LED).
 *  - Mind a 4 tüske nyitva: a zár kinyílik, nagy fényáradat és rezgés.
 */
class LockPick(
    private val glyph: GlyphController,
    private val motion: MotionDetector,
    private val haptics: Haptics
) {
    /** A C1 LED-jei a sáv mentén, bal felső végétől (0) a jobb oldaliig (15). */
    private val bar: IntArray = IntArray(16) { Zones.LEVEL[15 - it] }
    private val lifeZones = intArrayOf(Glyph.Code_22111.A1, Glyph.Code_22111.A2, Glyph.Code_22111.B1)
    private val dLine = intArrayOf(
        Glyph.Code_22111.D1_1, Glyph.Code_22111.D1_2, Glyph.Code_22111.D1_3, Glyph.Code_22111.D1_4,
        Glyph.Code_22111.D1_5, Glyph.Code_22111.D1_6, Glyph.Code_22111.D1_7, Glyph.Code_22111.D1_8
    )

    private var pins = 0
    private var lives = Config.LOCK_LIVES

    private fun status(): IntArray =
        lifeZones.copyOfRange(0, lives.coerceIn(0, 3)) + dLine.copyOfRange(0, (pins * 2).coerceAtMost(8))

    private fun show(zones: IntArray) = glyph.show(zones + status())

    /** Visszaadja, hány tüskét nyitott ki. */
    suspend fun run(): Int = coroutineScope {
        val inputs = Channel<Long>(Channel.CONFLATED)
        val collector = launch {
            merge(motion.knockEvents, GlyphMirror.taps).collect { inputs.trySend(it) }
        }
        try {
            play(inputs)
        } finally {
            collector.cancel()
        }
    }

    private fun drain(inputs: Channel<Long>) {
        while (inputs.tryReceive().isSuccess) Unit
    }

    private suspend fun play(inputs: Channel<Long>): Int {
        intro()
        while (pins < Config.LOCK_PINS && lives > 0) {
            val sweet = Random.nextInt(Config.LOCK_SWEET_MIN, Config.LOCK_SWEET_MAX + 1)
            val period = max(Config.LOCK_MIN_STEP_MS, Config.LOCK_START_STEP_MS - pins * Config.LOCK_STEP_FASTER_MS)
            var pos = if (Random.nextBoolean()) 0 else 15
            var dir = if (pos == 0) 1 else -1
            drain(inputs)
            DebugState.log("Zárfeltörő: ${pins + 1}. tüske")

            var done = false
            var sweetAt = 0L
            while (!done) {
                show(intArrayOf(bar[pos]))
                // Az édes ponton kis rezzenés: ilyenkor kell kopogni
                if (pos == sweet) {
                    haptics.sweetSpot()
                    sweetAt = SystemClock.elapsedRealtime()
                }
                val hit = withTimeoutOrNull(period) { inputs.receive() }
                if (hit == null) {
                    pos += dir
                    if (pos <= 0 || pos >= 15) {
                        pos = pos.coerceIn(0, 15)
                        dir = -dir
                    }
                    continue
                }
                val diff = abs(pos - sweet)
                // A rezzenésre reagálni idő kell: ha nemrég járt az édes ponton, az is talált
                val inTime = SystemClock.elapsedRealtime() - sweetAt <= Config.LOCK_REACTION_MS
                when {
                    diff == 0 || inTime -> {
                        unlockPin(sweet)
                        done = true
                    }
                    diff <= Config.LOCK_NEAR -> nearMiss(pos, sweet)
                    else -> {
                        miss()
                        if (lives <= 0) done = true
                    }
                }
                drain(inputs)
            }
        }
        if (pins >= Config.LOCK_PINS) win() else lose()
        return pins
    }

    private suspend fun intro() {
        // A sáv végigfut mindkét irányba, aztán felvillan a teljes zár
        for (i in 0 until 16) {
            glyph.show(intArrayOf(bar[i]) + lifeZones)
            delay(25)
        }
        for (i in 15 downTo 0) {
            glyph.show(intArrayOf(bar[i]) + lifeZones)
            delay(25)
        }
        glyph.show(bar + lifeZones + dLine)
        delay(300)
        show(intArrayOf())
        delay(500)
    }

    /** Talált: a zár kattan – fényhullám az édes ponttól kifelé. */
    private suspend fun unlockPin(sweet: Int) {
        haptics.result()
        pins++
        for (r in 0..15) {
            val lit = (0 until 16).filter { abs(it - sweet) <= r }.map { bar[it] }.toIntArray()
            show(lit)
            delay(18)
        }
        glyph.show(Zones.ALL)
        delay(220)
        show(intArrayOf())
        delay(450)
        DebugState.log("Kattant! Nyitva: $pins/${Config.LOCK_PINS}")
    }

    /** Közel: a pont és a cél közti rész felvillan kétszer (korán vagy későn nyomtad). */
    private suspend fun nearMiss(pos: Int, sweet: Int) {
        haptics.click()
        val from = minOf(pos, sweet)
        val to = maxOf(pos, sweet)
        // Az édes pontot magát nem mutatja, csak az irányt
        val gap = (from..to).filter { it != sweet }.map { bar[it] }.toIntArray()
        repeat(2) {
            show(gap)
            delay(90)
            show(intArrayOf())
            delay(90)
        }
        DebugState.log(if (pos < sweet) "Közel – túl korán / rossz oldalon" else "Közel – túl későn / rossz oldalon")
    }

    /** Nagyon mellé: elvész egy élet, az egész sáv megremeg. */
    private suspend fun miss() {
        haptics.tick()
        lives--
        repeat(3) {
            show(bar)
            delay(70)
            show(intArrayOf())
            delay(70)
        }
        DebugState.log("Mellé! Életek: $lives")
        delay(300)
    }

    private suspend fun win() {
        haptics.win()
        // Nagy fényáradat: hullámok a zár közepéből, majd minden villog
        repeat(4) {
            for (r in 0..8) {
                val lit = (0 until 16).filter { abs(it - 7.5f) <= r + 0.5f }.map { bar[it] }.toIntArray()
                glyph.show(lit + dLine.copyOfRange(0, r.coerceAtMost(8)))
                delay(35)
            }
        }
        repeat(10) {
            glyph.show(Zones.ALL)
            delay(120)
            glyph.off()
            delay(80)
        }
        glyph.show(Zones.ALL)
        delay(1200)
        glyph.off()
    }

    private suspend fun lose() {
        repeat(3) {
            glyph.show(Zones.ALL)
            delay(150)
            glyph.off()
            delay(150)
        }
        // Az elért eredmény még látszik
        glyph.show(dLine.copyOfRange(0, (pins * 2).coerceAtMost(8)))
        delay(2500)
        glyph.off()
    }
}
