package com.akos.glypheggs

import android.content.Context
import android.hardware.Sensor
import android.hardware.SensorEvent
import android.hardware.SensorEventListener
import android.hardware.SensorManager
import android.os.SystemClock
import com.nothing.ketchum.Glyph
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.first
import kotlinx.coroutines.withTimeoutOrNull
import kotlin.math.atan2
import kotlin.math.cos
import kotlin.math.sin

/**
 * Iránytű a nagy gyűrűn.
 *
 * Kijelzővel lefelé fekvő telefonnál a gyűrű azt a részét gyújtja ki, amerre az észak van.
 * Szögek a hátlapról (felülről) nézve, a gyűrű közepétől, 0° = a telefon teteje (kamera felőli vég),
 * óramutató irányában:
 *   C1_16 … C1_1 : 0°–90°    16 kis LED → itt egyetlen LED mutatja pontosan az északot
 *   C6           : 90°–135°   (jobb oldal)
 *   C5           : 135°–180°  (jobb alsó ív)
 *   C4           : 180°–270°  (bal alsó ív)
 *   C3           : 270°–315°  (bal oldal)
 *   C2           : 315°–360°  (bal felső ív)
 * A nagy íveken csak durván látszik az irány; forgasd a telefont, amíg az észak a C1 részre kerül.
 *
 * Addig fut, amíg fekszik. Ha felemeled, még [Config.COMPASS_LIFT_GRACE_MS] ideig vár,
 * és ha visszateszed, folytatja; különben kikapcsol.
 */
class Compass(
    private val context: Context,
    private val glyph: GlyphController,
    private val motion: MotionDetector,
    private val haptics: Haptics,
    private val onStatus: (String) -> Unit
) : SensorEventListener {

    private class Slot(val zones: IntArray, val from: Float, val to: Float, val name: String, val fine: Boolean)

    private val slots: List<Slot> = buildList {
        val step = 90f / 16
        for (i in 0 until 16) {
            val n = 16 - i // C1_16 van felül (0°), C1_1 a jobb szélen (90°)
            add(Slot(intArrayOf(Zones.LEVEL[n - 1]), i * step, (i + 1) * step, "C1_$n", true))
        }
        add(Slot(intArrayOf(Glyph.Code_22111.C6), 90f, 135f, "C6", false))
        add(Slot(intArrayOf(Glyph.Code_22111.C5), 135f, 180f, "C5", false))
        add(Slot(intArrayOf(Glyph.Code_22111.C4), 180f, 270f, "C4", false))
        add(Slot(intArrayOf(Glyph.Code_22111.C3), 270f, 315f, "C3", false))
        add(Slot(intArrayOf(Glyph.Code_22111.C2), 315f, 360f, "C2", false))
    }

    private val ring: IntArray = slots.flatMap { it.zones.toList() }.toIntArray()

    private val sm = context.getSystemService(SensorManager::class.java)
    private val sensor: Sensor? =
        sm.getDefaultSensor(Sensor.TYPE_ROTATION_VECTOR)
            ?: sm.getDefaultSensor(Sensor.TYPE_GEOMAGNETIC_ROTATION_VECTOR)

    private val rot = FloatArray(9)

    // Simított irány (szinusz/koszinusz átlag, hogy a 359°→0° átmenet ne ugorjon)
    @Volatile private var sx = 0f
    @Volatile private var sy = 0f
    @Volatile private var hasReading = false
    private var warnedAccuracy = false

    private fun norm(a: Float): Float = ((a % 360f) + 360f) % 360f

    private fun slotAt(angle: Float): Int {
        val a = norm(angle)
        val i = slots.indexOfFirst { a >= it.from && a < it.to }
        return if (i >= 0) i else slots.lastIndex
    }

    /** Az észak iránya a hátlapon, fokban (0° = telefon teteje, óramutató irányában). */
    private fun northAngle(): Float {
        val heading = Math.toDegrees(atan2(sx.toDouble(), sy.toDouble())).toFloat() + Config.COMPASS_DECLINATION
        // A telefon teteje "heading" fokkal áll északtól jobbra, így az észak tőle balra van
        return if (Config.COMPASS_INVERT) norm(heading) else norm(-heading)
    }

    override fun onSensorChanged(event: SensorEvent) {
        SensorManager.getRotationMatrixFromVector(rot, event.values)
        // A telefon "teteje" (+Y tengely) a világban: kelet = rot[1], észak = rot[4]
        val h = atan2(rot[1].toDouble(), rot[4].toDouble())
        val a = Config.COMPASS_SMOOTHING
        if (!hasReading) {
            sx = sin(h).toFloat()
            sy = cos(h).toFloat()
            hasReading = true
        } else {
            sx = a * sx + (1 - a) * sin(h).toFloat()
            sy = a * sy + (1 - a) * cos(h).toFloat()
        }
    }

    override fun onAccuracyChanged(s: Sensor?, accuracy: Int) {
        if (accuracy <= SensorManager.SENSOR_STATUS_ACCURACY_LOW && !warnedAccuracy) {
            warnedAccuracy = true
            DebugState.log("Pontatlan iránytű: emeld fel, és mozgasd párszor 8-as alakban")
        }
    }

    suspend fun run() {
        if (sensor == null) {
            DebugState.log("Nincs iránytű-szenzor a telefonban")
            return
        }

        // 1. Megvárja, hogy kijelzővel lefelé letedd
        if (!motion.faceDown.value) {
            onStatus("Tedd le kijelzővel lefelé az iránytűhöz")
            val placed = withTimeoutOrNull(Config.COMPASS_PLACE_TIMEOUT_MS) { motion.faceDown.first { it } }
            if (placed == null) {
                DebugState.log("Nem tetted le – iránytű kikapcsol")
                return
            }
        }
        delay(Config.COMPASS_SETTLE_MS)
        onStatus("Iránytű – forgasd, amíg egy kis LED mutatja az északot")

        sm.registerListener(this, sensor, SensorManager.SENSOR_DELAY_GAME)
        try {
            // Indulásjelzés: a gyűrű egyszer felvillan
            glyph.show(ring)
            delay(200)
            glyph.off()

            var current = -1
            var lastPush = 0L
            var pushed = -999f
            var wasFine = false
            var liftedSince = 0L
            val h = Config.COMPASS_HYSTERESIS

            while (true) {
                val now = SystemClock.elapsedRealtime()

                // 2. Felemelés: még vár egy kicsit, hátha visszateszed
                if (motion.faceDown.value) {
                    if (liftedSince != 0L) DebugState.log("Visszatetted – iránytű folytatódik")
                    liftedSince = 0L
                } else if (liftedSince == 0L) {
                    liftedSince = now
                    DebugState.log("Felemelted – ${Config.COMPASS_LIFT_GRACE_MS / 1000} mp múlva kikapcsol")
                } else if (now - liftedSince > Config.COMPASS_LIFT_GRACE_MS) {
                    DebugState.log("Iránytű kikapcsolva")
                    break
                }

                // 3. Kijelzés: csak akkor vált, ha már biztosan a szomszéd részben van (nem villódzik)
                if (hasReading) {
                    val a = northAngle()
                    val cand = slotAt(a)
                    val settled = slotAt(a - h) == cand && slotAt(a + h) == cand
                    // A widget 1 mp-enként (ha legalább 3°-ot fordult) megkapja a telefon tetejének irányát
                    val head = norm(-a)
                    val diff = kotlin.math.abs(((head - pushed + 540f) % 360f) - 180f)
                    if (now - lastPush > 1_000 && diff >= 3f) {
                        lastPush = now
                        pushed = head
                        CompassState.update(context, head)
                    }
                    if (cand != current && (current < 0 || settled)) {
                        current = cand
                        val slot = slots[cand]
                        glyph.show(slot.zones)
                        // Amikor az észak a pontos (C1) részre ér, kis kattanás jelzi
                        if (slot.fine && !wasFine) haptics.click()
                        wasFine = slot.fine
                        DebugState.sensor.value = "Iránytű: észak %.0f°  →  %s".format(a, slot.name)
                    }
                }
                delay(40)
            }
        } finally {
            sm.unregisterListener(this)
            glyph.off()
        }
    }
}
