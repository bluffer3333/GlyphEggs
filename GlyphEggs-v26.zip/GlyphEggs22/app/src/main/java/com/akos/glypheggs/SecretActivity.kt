package com.akos.glypheggs

import android.app.Activity
import android.os.Bundle
import android.os.SystemClock
import android.text.InputType
import android.view.Gravity
import android.view.ViewGroup.LayoutParams.MATCH_PARENT
import android.view.ViewGroup.LayoutParams.WRAP_CONTENT
import android.view.WindowManager
import android.widget.EditText
import android.widget.FrameLayout
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.ScrollView

/**
 * Titkos jegyzetek: csak a széf kinyitása után nyílik meg (2 percen belül).
 * A tartalom az app saját tárhelyén marad; képernyőkép nem készülhet róla.
 */
class SecretActivity : Activity() {

    private var editor: EditText? = null

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        window.addFlags(WindowManager.LayoutParams.FLAG_SECURE)
        darkWindow()

        if (SystemClock.elapsedRealtime() > GlyphMirror.unlockedUntil) {
            DebugState.log("Titkos jegyzet: a széf zárva")
            finish()
            return
        }
        // Egyszer használható: bezárás után újra ki kell nyitni a széfet
        GlyphMirror.unlockedUntil = 0L

        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(15), 0, dp(15), dp(24))
        }
        val scroll = ScrollView(this).apply {
            background = Ui.pageBg()
            isFillViewport = true
            addView(root, FrameLayout.LayoutParams(MATCH_PARENT, WRAP_CONTENT))
            padForSystemBars()
        }
        setContentView(scroll)

        val header = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
            setPadding(dp(7), dp(28), 0, dp(8))
        }
        header.addView(ImageView(this).apply {
            setImageResource(R.drawable.ic_back)
            setOnClickListener { finish() }
        }, LinearLayout.LayoutParams(dp(24), dp(24)))
        header.addView(text("Titkos jegyzetek", 26f).apply { setPadding(dp(30), 0, 0, 0) })
        root.addView(header)

        root.addView(text("A széf nyitva. Ide írhatsz bármit – csak a széf kódjával lehet újra megnyitni.", 13f, Ui.SUB).apply {
            setPadding(dp(7), dp(12), dp(7), dp(16))
        })

        editor = EditText(this).apply {
            setText(Settings.secretNotes(this@SecretActivity))
            setTextColor(Ui.TEXT)
            setHintTextColor(Ui.SUB)
            hint = "Titkos jegyzet…"
            textSize = 16f
            gravity = Gravity.TOP or Gravity.START
            inputType = InputType.TYPE_CLASS_TEXT or InputType.TYPE_TEXT_FLAG_MULTI_LINE
            minLines = 12
            background = rounded(Ui.CARD, dp(22).toFloat())
            setPadding(dp(18), dp(18), dp(18), dp(18))
        }
        root.addView(editor, LinearLayout.LayoutParams(MATCH_PARENT, WRAP_CONTENT))
    }

    override fun onPause() {
        super.onPause()
        editor?.let { Settings.setSecretNotes(this, it.text.toString()) }
        // Ha elhagyod, bezárul – legközelebb újra a széffel nyílik
        if (!isChangingConfigurations) finish()
    }
}
