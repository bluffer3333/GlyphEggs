package com.akos.glypheggs

import android.content.Context
import android.os.SystemClock
import com.nothing.ketchum.Glyph
import kotlinx.coroutines.delay
import kotlin.math.ceil

/** Légzésritmusok: belégzés, bent tartás, kilégzés, kint tartás (másodpercben). */
enum class BreathPattern(val title: String, val desc: String, val inhale: Float, val holdIn: Float, val exhale: Float, val holdOut: Float) {
    RELAX("4-7-8 · elalváshoz", "4 mp be, 7 mp bent tartod, 8 mp ki – lelassít, segít elaludni", 4f, 7f, 8f, 0f),
    BOX("Doboz-légzés", "4 mp be, 4 bent, 4 ki, 4 kint – fókusz, stressz ellen (katonák, sportolók is használják)", 4f, 4f, 4f, 4f),
    COHERENT("Koherens légzés", "5,5 mp be, 5,5 mp ki – percenként kb. 5,5 légzés, egyenletes nyugalom", 5.5f, 0f, 5.5f, 0f),
    CALM("Nyugtató 4-6", "4 mp be, 6 mp ki – a hosszabb kilégzés gyorsan megnyugtat", 4f, 0f, 6f, 0f),
    ENERGY("Ébresztő 4-4", "4 mp be, 4 mp ki, tartás nélkül – frissít, ha álmos vagy", 4f, 0f, 4f, 0f);

    val cycle: Float get() = inhale + holdIn + exhale + holdOut
}

/**
 * Légzésvezető a LED-eken: belégzéskor a fény a töltőport felől felfelé telik (mint a tüdő), bent
 * tartáskor áll, és a kamera lassan pislog; kilégzéskor visszahúzódik; kint tartáskor csak a pont ég.
 * Fázisváltáskor rövid rezgés jelez, így csukott szemmel, lefelé fordított telefonnal is követhető.
 * A beállított idő (1–20 perc) végén a fény lassan elhalványul.
 */
class BreathGuide(
    private val context: Context,
    private val glyph: GlyphController,
    private val haptics: Haptics,
    private val onStatus: (String) -> Unit
) {
    private val pattern = Settings.breathPattern(context)
    private val totalMs = Settings.breathMinutes(context) * 60_000L
    private val order = LectureTimer.FILL_ORDER

    fun totalMs(): Long = totalMs

    private fun fmt(ms: Long): String {
        val s = (ms / 1000).coerceAtLeast(0)
        return "%d:%02d".format(s / 60, s % 60)
    }

    suspend fun run() {
        DebugState.log("Légzés: ${pattern.title}, ${totalMs / 60_000} perc")
        // Bevezetés: egy lassú hullám fel és le
        for (n in 0..order.size step 2) { glyph.show(order.copyOfRange(0, n)); delay(25) }
        for (n in order.size downTo 0 step 2) { glyph.show(order.copyOfRange(0, n)); delay(25) }
        delay(600)

        val start = SystemClock.elapsedRealtime()
        var lastPhase = -1
        var breaths = 0
        var lastStatus = 0L
        while (true) {
            val now = SystemClock.elapsedRealtime()
            val el = now - start
            if (el >= totalMs) break
            val t = (el % (pattern.cycle * 1000).toLong()) / 1000f
            val phase: Int
            val lit: IntArray
            when {
                t < pattern.inhale -> {
                    phase = 0
                    val p = t / pattern.inhale
                    lit = order.copyOfRange(0, ceil(p * order.size).toInt().coerceIn(1, order.size))
                }
                t < pattern.inhale + pattern.holdIn -> {
                    phase = 1
                    // Bent tartás: minden ég, a kamera lassan pislog
                    val blink = ((now / 700) % 2 == 0L)
                    lit = if (blink) order else order.filter { it != Glyph.Code_22111.A1 && it != Glyph.Code_22111.A2 }.toIntArray()
                }
                t < pattern.inhale + pattern.holdIn + pattern.exhale -> {
                    phase = 2
                    val p = (t - pattern.inhale - pattern.holdIn) / pattern.exhale
                    lit = order.copyOfRange(0, ceil((1f - p) * order.size).toInt().coerceIn(0, order.size))
                }
                else -> {
                    phase = 3
                    lit = intArrayOf(Glyph.Code_22111.E1)
                }
            }
            if (phase != lastPhase) {
                when (phase) {
                    0 -> { haptics.click(); breaths++ }
                    1 -> haptics.click()
                    2 -> haptics.tick()
                    3 -> haptics.click()
                }
                lastPhase = phase
            }
            glyph.show(lit)
            if (now - lastStatus > 2_000) {
                lastStatus = now
                val name = arrayOf("Lélegezz be", "Tartsd bent", "Lélegezz ki", "Tartsd kint")[phase]
                onStatus("Légzés · $name · még ${fmt(totalMs - el)}")
            }
            delay(50)
        }
        // Vége: lassú elhalványulás, gyenge rezgés
        DebugState.log("Légzés vége – $breaths légzés")
        haptics.result()
        for (n in order.size downTo 0) { glyph.show(order.copyOfRange(0, n)); delay(60) }
        glyph.off()
    }
}
