package com.akos.glypheggs

import android.os.SystemClock
import kotlinx.coroutines.channels.Channel
import kotlinx.coroutines.delay
import kotlin.math.ceil

/**
 * Rázás-töltés: az indító mozdulat második fele. Az első rázás (a [MotionDetector] ismeri fel)
 * elindítja a szolgáltatást, ez pedig a további rázásokat számolja: minden rázással feljebb
 * gyulladnak a LED-ek alulról (E1 → függőleges vonal → ívek → felső sáv → kamera), és ha mind a
 * 33 ég, indulhat a funkció. A kellő rázások száma a [Settings.shakeFillCount]-ban állítható.
 *
 * Ha [Config.SHAKEFILL_GAP_MS]-ig nem rázzák, félbemarad: a LED-ek elalszanak, és nem indul semmi
 * (így a táskában véletlenül rázódó telefon sem indít el semmit).
 */
class ShakeFill(
    private val glyph: GlyphController,
    private val haptics: Haptics,
    private val needed: Int
) {
    private val order = LectureTimer.FILL_ORDER

    /** Hány LED ég [count] rázás után. */
    fun litFor(count: Int): Int = ceil(count.toDouble() * order.size / needed).toInt().coerceIn(0, order.size)

    /**
     * @param events a rázás-események
     * @param initial a rázások száma, amit már észleltünk (az első, ami elindította)
     * @return true, ha megtelt; false, ha félbemaradt
     */
    suspend fun run(events: Channel<Long>, initial: Int, onStatus: (String) -> Unit): Boolean {
        var count = initial
        var lastEvent = SystemClock.elapsedRealtime()
        glyph.show(order.copyOfRange(0, litFor(count).coerceAtLeast(1)))
        while (true) {
            val now = SystemClock.elapsedRealtime()
            var got = 0
            while (events.tryReceive().isSuccess) got++
            if (got > 0) {
                count += got
                lastEvent = now
                haptics.tick()
                val n = litFor(count)
                glyph.show(order.copyOfRange(0, n))
                onStatus("Rázd tovább – $count/$needed")
                if (count >= needed) break
            }
            if (now - lastEvent > Config.SHAKEFILL_GAP_MS) {
                DebugState.log("Rázás-töltés: félbemaradt ($count/$needed rázás)")
                glyph.off()
                return false
            }
            delay(50)
        }
        DebugState.log("Rázás-töltés: kész ($needed rázás)")
        glyph.show(Zones.ALL)
        haptics.result()
        delay(900)
        glyph.off()
        return true
    }
}
