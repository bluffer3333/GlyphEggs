package com.akos.glypheggs

import android.service.quicksettings.Tile
import android.service.quicksettings.TileService

/**
 * "Iránytű" csempe a lehúzható menüben:
 * koppints rá, tedd le kijelzővel lefelé, és a gyűrű mutatja az északot.
 * Ha épp fut, egy újabb koppintás kikapcsolja.
 */
class CompassTileService : TileService() {

    override fun onStartListening() {
        super.onStartListening()
        show()
    }

    override fun onClick() {
        super.onClick()
        TileStarter.startService(this, SimonService.ACTION_COMPASS)
    }

    private fun show() {
        val tile = qsTile ?: return
        val on = SimonService.compassOn
        tile.state = if (on) Tile.STATE_ACTIVE else Tile.STATE_INACTIVE
        tile.subtitle = if (on) "Fut" else "Koppints, tedd le"
        tile.updateTile()
    }
}
