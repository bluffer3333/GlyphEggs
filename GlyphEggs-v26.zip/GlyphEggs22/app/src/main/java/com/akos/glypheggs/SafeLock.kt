package com.akos.glypheggs

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.content.Context
import android.content.Intent
import android.net.Uri
import android.os.SystemClock
import android.provider.DocumentsContract
import com.nothing.ketchum.Glyph
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.first
import kotlinx.coroutines.withTimeoutOrNull
import kotlin.random.Random

/** A széf 8 pozíciója a hátlapon (a kód ezekből áll). */
object SafePositions {
    const val CODE_LENGTH = 4

    val names = listOf("Kamera", "Ferde csík", "Felső ív", "Jobb oldal", "Alsó ív", "Bal oldal", "Vonal", "Pont")

    fun zones(i: Int): IntArray = when (i) {
        0 -> intArrayOf(Glyph.Code_22111.A1, Glyph.Code_22111.A2)
        1 -> intArrayOf(Glyph.Code_22111.B1)
        2 -> Zones.LEVEL
        3 -> intArrayOf(Glyph.Code_22111.C5, Glyph.Code_22111.C6)
        4 -> intArrayOf(Glyph.Code_22111.C4)
        5 -> intArrayOf(Glyph.Code_22111.C2, Glyph.Code_22111.C3)
        6 -> intArrayOf(
            Glyph.Code_22111.D1_1, Glyph.Code_22111.D1_2, Glyph.Code_22111.D1_3, Glyph.Code_22111.D1_4,
            Glyph.Code_22111.D1_5, Glyph.Code_22111.D1_6, Glyph.Code_22111.D1_7, Glyph.Code_22111.D1_8
        )
        else -> intArrayOf(Glyph.Code_22111.E1)
    }
}

/**
 * Széf – döntéses kód: indítás után a telefont a kódod irányaiba kell dönteni, egymás után, mint a
 * Simonnál (előre = kamera felé, hátra = töltőport felé, balra, jobbra; minden döntés után vissza középre).
 * A döntés irányának LED-jei felvillannak, a felső sáv a haladást mutatja (hány lépés van meg).
 * A kód hossza 3–8 (Széf beállítása). Az összes lépés után ellenőriz:
 *  - jó kód: minden összevissza villog, rezeg, és megnyílik a beállított titkos dolog;
 *  - rossz kód: lassú villogás, hosszú rezgés, zárva marad.
 */
class SafeLock(
    private val context: Context,
    private val glyph: GlyphController,
    private val motion: MotionDetector,
    private val haptics: Haptics,
    private val onStatus: (String) -> Unit
) {
    private val bar: IntArray = IntArray(16) { Zones.LEVEL[15 - it] }

    /** true = kinyílt. */
    suspend fun run(): Boolean {
        val code = Settings.safeTiltCode(context)
        onStatus("Széf – döntsd a telefont a kódod irányaiba (${code.size} lépés)")
        // Bevezető: a négy irány körbefut
        for (d in listOf(Direction.FORWARD, Direction.RIGHT, Direction.BACK, Direction.LEFT)) {
            glyph.show(d.zones())
            delay(140)
        }
        glyph.off()
        // Előbb középre (vízszintesbe) kell kerülnie
        withTimeoutOrNull(5_000L) { motion.tilt.first { it == null } }
        delay(300)

        val entered = mutableListOf<Direction>()
        while (entered.size < code.size) {
            val progress = bar.take(16 * entered.size / code.size)
            glyph.show(progress.toIntArray())
            val d = withTimeoutOrNull(Config.SAFE_TILT_TIMEOUT_MS) { motion.tilt.first { it != null } }
            if (d == null) {
                DebugState.log("Széf: nem jött döntés – leáll")
                glyph.off()
                return false
            }
            entered += d
            haptics.tick()
            glyph.show((d.zones().toList() + progress).toIntArray())
            DebugState.log("Széf: ${entered.size}/${code.size}")
            // Vissza középre, mielőtt a következő számít
            withTimeoutOrNull(5_000L) { motion.tilt.first { it == null } }
            delay(150)
        }
        glyph.show(bar)
        delay(300)
        return if (entered == code) {
            celebrate()
            true
        } else {
            denied()
            false
        }
    }

    /** Nyitva! Minden lehetséges kombinációban villog, és a telefon rezeg. */
    private suspend fun celebrate() {
        DebugState.log("Széf kinyitva!")
        haptics.win()
        val end = SystemClock.elapsedRealtime() + Config.SAFE_CELEBRATE_MS
        var step = 0
        while (SystemClock.elapsedRealtime() < end) {
            val frame = when (step % 4) {
                0 -> Zones.ALL.filter { Random.nextBoolean() }.toIntArray()
                1 -> SafePositions.zones(step / 4 % 8)
                2 -> (0 until 8).filter { Random.nextInt(3) == 0 }.flatMap { SafePositions.zones(it).toList() }.toIntArray()
                else -> Zones.ALL
            }
            glyph.show(frame)
            delay(70)
            step++
        }
        glyph.show(Zones.ALL)
        delay(600)
        glyph.off()
    }

    private suspend fun denied() {
        DebugState.log("Széf: rossz kód")
        haptics.denied()
        repeat(3) {
            glyph.show(Zones.ALL)
            delay(350)
            glyph.off()
            delay(350)
        }
    }
}

/** A széf kinyitása után megnyitja, amit beállítottál. */
object SafeOpener {
    private const val CHANNEL = "glyph_eggs_safe"

    fun open(context: Context) {
        GlyphMirror.unlockedUntil = SystemClock.elapsedRealtime() + Config.SAFE_UNLOCK_WINDOW_MS
        val intent = buildIntent(context) ?: return
        intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
        // Közvetlenül csak akkor nyithat meg valamit, ha az app látszik, vagy van
        // "megjelenés más appok felett" engedély; különben értesítésből egy koppintással.
        val canStart = GlyphMirror.appVisible || android.provider.Settings.canDrawOverlays(context)
        if (canStart) {
            try {
                context.startActivity(intent)
                return
            } catch (t: Throwable) {
                DebugState.log("Közvetlen megnyitás nem sikerült: ${t.javaClass.simpleName}")
            }
        }
        notify(context, intent)
    }

    fun buildIntent(context: Context): Intent? {
        val value = Settings.safeTargetValue(context)
        return when (Settings.safeTargetType(context)) {
            "NOTES" -> Intent(context, SecretActivity::class.java)
            "APP" -> context.packageManager.getLaunchIntentForPackage(value).also {
                if (it == null) DebugState.log("A beállított app nem található")
            }
            "URL" -> if (value.isBlank()) null else Intent(Intent.ACTION_VIEW, Uri.parse(fixUrl(value)))
            "FOLDER" -> folderIntent(value)
            else -> null
        }
    }

    private fun fixUrl(v: String): String =
        if (v.startsWith("http://") || v.startsWith("https://")) v else "https://$v"

    private fun folderIntent(treeUri: String): Intent? {
        if (treeUri.isBlank()) return null
        return try {
            val tree = Uri.parse(treeUri)
            val doc = DocumentsContract.buildDocumentUriUsingTree(tree, DocumentsContract.getTreeDocumentId(tree))
            Intent(Intent.ACTION_VIEW).apply {
                setDataAndType(doc, DocumentsContract.Document.MIME_TYPE_DIR)
                addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
            }
        } catch (t: Throwable) {
            DebugState.log("Mappa megnyitás hiba: ${t.javaClass.simpleName}")
            null
        }
    }

    private fun notify(context: Context, intent: Intent) {
        if (!Settings.notifAssist(context)) {
            DebugState.log("Széf: a „koppints a megnyitáshoz” értesítés ki van kapcsolva – a cél nem nyílt meg")
            return
        }
        val nm = context.getSystemService(NotificationManager::class.java)
        nm.createNotificationChannel(NotificationChannel(CHANNEL, "Széf", NotificationManager.IMPORTANCE_HIGH))
        val pi = PendingIntent.getActivity(
            context, 7, intent, PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT
        )
        val n = Notification.Builder(context, CHANNEL)
            .setSmallIcon(R.drawable.ic_safe)
            .setContentTitle("A széf nyitva")
            .setContentText("Koppints a megnyitáshoz (2 percig érvényes)")
            .setContentIntent(pi)
            .setAutoCancel(true)
            .setTimeoutAfter(Config.SAFE_UNLOCK_WINDOW_MS)
            .build()
        nm.notify(7, n)
    }
}
