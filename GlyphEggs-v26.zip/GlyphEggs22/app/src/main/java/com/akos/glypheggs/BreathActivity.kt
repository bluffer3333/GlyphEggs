package com.akos.glypheggs

import android.app.Activity
import android.content.Intent
import android.os.Bundle
import android.view.Gravity
import android.view.ViewGroup.LayoutParams.MATCH_PARENT
import android.view.ViewGroup.LayoutParams.WRAP_CONTENT
import android.widget.FrameLayout
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.ScrollView

/** Légzés beállítása: ritmus és hossz, indítás. */
class BreathActivity : Activity() {

    private lateinit var body: LinearLayout

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        darkWindow()
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(15), 0, dp(15), dp(24))
        }
        val scroll = ScrollView(this).apply {
            background = Ui.pageBg()
            isVerticalScrollBarEnabled = false
            addView(root, FrameLayout.LayoutParams(MATCH_PARENT, WRAP_CONTENT))
            padForSystemBars()
        }
        setContentView(scroll)
        val header = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
            setPadding(dp(7), dp(28), 0, dp(18))
        }
        header.addView(ImageView(this).apply {
            setImageResource(R.drawable.ic_back)
            setOnClickListener { finish() }
        }, LinearLayout.LayoutParams(dp(24), dp(24)))
        header.addView(text("Légzés", 26f).apply { setPadding(dp(30), 0, 0, 0) })
        root.addView(header)

        val startCard = FeatureCard(this, R.drawable.ic_breath, "Indítás", "Kövesd a fényt", false)
        startCard.setOnClickListener {
            startForegroundService(Intent(this, SimonService::class.java).setAction(SimonService.ACTION_BREATH))
        }
        val infoCard = FeatureCard(this, R.drawable.ic_info, "Hogyan működik", "Fény, rezgés, ritmusok", false)
        infoCard.setOnClickListener {
            startActivity(Intent(this, InfoActivity::class.java).putExtra(InfoActivity.EXTRA_FEATURE, Feature.BREATH.name))
        }
        root.addView(row(startCard, infoCard, 140))
        body = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        root.addView(body)
        render()
    }

    override fun onResume() {
        super.onResume()
        GlyphMirror.appVisible = true
    }

    override fun onPause() {
        super.onPause()
        GlyphMirror.appVisible = false
    }

    private fun render() {
        body.removeAllViews()
        body.addView(sectionTitle("Ritmus"))
        val cur = Settings.breathPattern(this)
        for (p in BreathPattern.entries) {
            val row = LinearLayout(this).apply {
                orientation = LinearLayout.HORIZONTAL
                gravity = Gravity.CENTER_VERTICAL
                background = rounded(Ui.CARD, dp(20).toFloat())
                setPadding(dp(18), dp(15), dp(16), dp(15))
                setOnClickListener { Settings.setBreathPattern(this@BreathActivity, p); render() }
            }
            val texts = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
            texts.addView(text(p.title, 17f))
            texts.addView(text(p.desc, 12.5f, Ui.SUB).apply { setPadding(0, dp(2), 0, 0); setLineSpacing(0f, 1.15f) })
            row.addView(texts, LinearLayout.LayoutParams(0, WRAP_CONTENT, 1f))
            row.addView(RadioMark(this, p == cur), LinearLayout.LayoutParams(dp(26), dp(26)).apply { marginStart = dp(12) })
            body.addView(row, LinearLayout.LayoutParams(MATCH_PARENT, WRAP_CONTENT).apply { bottomMargin = dp(5) })
        }
        body.addView(sectionTitle("Hossz (perc)"))
        val mins = Settings.breathMinutes(this)
        val pills = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
        for (m in listOf(1, 3, 5, 10, 15, 20)) {
            val sel = m == mins
            pills.addView(text("$m", 15f, if (sel) Ui.DARK_TEXT else Ui.TEXT).apply {
                gravity = Gravity.CENTER
                background = rounded(if (sel) Ui.LIGHT else Ui.CARD, dp(22).toFloat())
                setOnClickListener { Settings.setBreathMinutes(this@BreathActivity, m); render() }
            }, LinearLayout.LayoutParams(0, dp(44), 1f).apply { marginEnd = dp(5) })
        }
        body.addView(pills)
    }
}
