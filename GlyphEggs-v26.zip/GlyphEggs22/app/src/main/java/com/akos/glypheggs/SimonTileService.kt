package com.akos.glypheggs

import android.content.Intent
import android.service.quicksettings.Tile
import android.service.quicksettings.TileService

/**
 * "Mozdulatfigyelés" csempe a lehúzható menüben: egy koppintással be- és kikapcsolja,
 * hogy a beállított indító mozdulatok (forgatás, kopogás, rázás…) elindítsák a funkciókat.
 */
class SimonTileService : TileService() {

    override fun onStartListening() {
        super.onStartListening()
        show(SimonService.watching)
    }

    override fun onClick() {
        super.onClick()
        val turnOn = !SimonService.watching
        Settings.setWatching(this, turnOn)

        if (turnOn) {
            if (!TileStarter.startService(this, SimonService.ACTION_WATCH_ON)) return
        } else {
            // Kikapcsolásnál csak akkor szólunk, ha fut
            try {
                startService(Intent(this, SimonService::class.java).setAction(SimonService.ACTION_WATCH_OFF))
            } catch (_: Exception) {
            }
        }
        show(turnOn)
    }

    private fun show(on: Boolean) {
        val tile = qsTile ?: return
        tile.state = if (on) Tile.STATE_ACTIVE else Tile.STATE_INACTIVE
        tile.subtitle = if (on) "Figyel" else "Ki"
        tile.updateTile()
    }
}
