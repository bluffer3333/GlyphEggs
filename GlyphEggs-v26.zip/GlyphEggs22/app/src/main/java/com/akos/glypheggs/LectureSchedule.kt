package com.akos.glypheggs

import android.app.AlarmManager
import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import java.time.LocalDate
import java.time.LocalDateTime
import java.time.ZoneId

/**
 * Heti órarend az Előadáshoz: a megadott napokon és időpontokban az előadás-időzítő magától indul
 * (azonnal, rázás és lerakás nélkül), a bejegyzés hosszával és nevével.
 *
 * Mindig csak a legközelebbi órára állít be egy pontos ébresztést; amikor az lefut (vagy az órarend
 * változik, a telefon újraindul, átállítják az órát), kiszámolja a következőt.
 */
object LectureSchedule {

    private const val PREFS = "glyph_eggs_schedule"
    private const val KEY = "entries"
    private const val REQ = 4242

    val DAYS = arrayOf("Hétfő", "Kedd", "Szerda", "Csütörtök", "Péntek", "Szombat", "Vasárnap")
    val DAYS_SHORT = arrayOf("H", "K", "Sze", "Cs", "P", "Szo", "V")

    /**
     * Egy óra az órarendben.
     * @param day 1 = hétfő … 7 = vasárnap
     * @param blocks, blockMin 0 = az Előadás beállítása szerint
     */
    data class Entry(
        val id: String,
        val day: Int,
        val hour: Int,
        val minute: Int,
        val blocks: Int,
        val blockMin: Int,
        val name: String
    ) {
        fun time() = "%d:%02d".format(hour, minute)
        fun title() = (if (name.isNotBlank()) "$name · " else "") + "${DAYS[day - 1]} ${time()}"
        fun length(c: Context): String {
            val b = if (blocks > 0) blocks else Settings.lectureBlocks(c)
            val m = if (blockMin > 0) blockMin else Settings.lectureBlockMin(c)
            return "$b × $m perc"
        }

        fun encode() = listOf(id, day, hour, minute, blocks, blockMin, name.replace("|", "/").replace("\n", " ")).joinToString("|")

        companion object {
            fun decode(s: String): Entry? {
                val p = s.split("|")
                if (p.size < 7) return null
                return try {
                    Entry(p[0], p[1].toInt().coerceIn(1, 7), p[2].toInt().coerceIn(0, 23), p[3].toInt().coerceIn(0, 59),
                        p[4].toInt().coerceIn(0, 4), p[5].toInt().coerceIn(0, 180), p[6])
                } catch (t: Throwable) {
                    null
                }
            }
        }
    }

    private fun p(c: Context) = c.getSharedPreferences(PREFS, Context.MODE_PRIVATE)

    /** Az órarend, napok és időpontok szerint sorba rendezve. */
    fun entries(c: Context): List<Entry> =
        (p(c).getString(KEY, null) ?: "").split("\n").mapNotNull { if (it.isBlank()) null else Entry.decode(it) }
            .sortedWith(compareBy({ it.day }, { it.hour }, { it.minute }))

    private fun save(c: Context, list: List<Entry>) {
        p(c).edit().putString(KEY, list.joinToString("\n") { it.encode() }).apply()
        scheduleNext(c)
    }

    fun add(c: Context, e: Entry) = save(c, entries(c) + e)
    fun remove(c: Context, id: String) = save(c, entries(c).filter { it.id != id })
    fun find(c: Context, id: String?): Entry? = if (id == null) null else entries(c).firstOrNull { it.id == id }

    fun newId(): String = System.currentTimeMillis().toString(36)

    /** A legközelebbi óra (és mikor), vagy null, ha üres az órarend vagy ki van kapcsolva. */
    fun next(c: Context): Pair<Entry, LocalDateTime>? {
        if (!Settings.lectureScheduleOn(c)) return null
        val now = LocalDateTime.now()
        var best: Pair<Entry, LocalDateTime>? = null
        for (e in entries(c)) {
            for (offset in 0..7) {
                val date = LocalDate.now().plusDays(offset.toLong())
                if (date.dayOfWeek.value != e.day) continue
                val at = date.atTime(e.hour, e.minute)
                if (!at.isAfter(now)) continue
                if (best == null || at.isBefore(best.second)) best = e to at
                break
            }
        }
        return best
    }

    /** Beállítja az ébresztést a legközelebbi órára (vagy törli, ha nincs). */
    fun scheduleNext(c: Context) {
        val am = c.getSystemService(AlarmManager::class.java)
        val n = next(c)
        val intent = Intent(c, LectureAlarmReceiver::class.java).setAction(LectureAlarmReceiver.ACTION_FIRE)
        if (n == null) {
            val old = PendingIntent.getBroadcast(c, REQ, intent, PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_NO_CREATE)
            if (old != null) am.cancel(old)
            return
        }
        val at = n.second.atZone(ZoneId.systemDefault()).toInstant().toEpochMilli()
        intent.putExtra(SimonService.EXTRA_SCHEDULE_ID, n.first.id).putExtra("at", at)
        val pi = PendingIntent.getBroadcast(c, REQ, intent, PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT)
        if (am.canScheduleExactAlarms()) {
            am.setExactAndAllowWhileIdle(AlarmManager.RTC_WAKEUP, at, pi)
        } else {
            // Pontos ébresztő nélkül is beállítja (néhány perc csúszással)
            am.setAndAllowWhileIdle(AlarmManager.RTC_WAKEUP, at, pi)
        }
        DebugState.log("Órarend: következő – ${n.first.title()}")
    }

    /** Engedélyezett-e a pontos ébresztő (különben pár percet csúszhat az indulás). */
    fun exactAllowed(c: Context): Boolean =
        c.getSystemService(AlarmManager::class.java).canScheduleExactAlarms()
}

/**
 * Az órarend ébresztője: elindítja az előadást a szolgáltatásban, és beállítja a következőt.
 * Óraátállításkor és időzóna-váltáskor csak újraszámol.
 */
class LectureAlarmReceiver : BroadcastReceiver() {

    companion object {
        const val ACTION_FIRE = "com.akos.glypheggs.SCHEDULE_FIRE"
        private const val CHANNEL = "glyph_eggs_schedule"
    }

    override fun onReceive(context: Context, intent: Intent) {
        if (intent.action != ACTION_FIRE) {
            // Óra / időzóna változott: újraszámolás
            LectureSchedule.scheduleNext(context)
            return
        }
        val id = intent.getStringExtra(SimonService.EXTRA_SCHEDULE_ID)
        val at = intent.getLongExtra("at", 0L)
        val e = LectureSchedule.find(context, id)
        val late = at > 0 && System.currentTimeMillis() - at > Config.SCHEDULE_LATE_MS
        if (e == null || late || !Settings.lectureScheduleOn(context)) {
            LectureSchedule.scheduleNext(context)
            return
        }
        val start = Intent(context, SimonService::class.java).setAction(SimonService.ACTION_LECTURE)
            .putExtra(SimonService.EXTRA_SOURCE, SimonService.SOURCE_SCHEDULE)
            .putExtra(SimonService.EXTRA_SCHEDULE_ID, e.id)
        try {
            // A pontos ébresztő feljogosít az előtér-szolgáltatás indítására a háttérből
            context.startForegroundService(start)
        } catch (t: Throwable) {
            // Ha mégsem engedi (pl. nincs pontos ébresztő): értesítés, egy koppintással indul
            DebugState.log("Órarend: az indítást a rendszer nem engedte")
            if (!Settings.notifSchedule(context)) {
                LectureSchedule.scheduleNext(context)
                return
            }
            val nm = context.getSystemService(NotificationManager::class.java)
            nm.createNotificationChannel(NotificationChannel(CHANNEL, "Órarend", NotificationManager.IMPORTANCE_HIGH))
            val pi = PendingIntent.getForegroundService(context, 4243, start,
                PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT)
            nm.notify(4243, Notification.Builder(context, CHANNEL)
                .setSmallIcon(R.drawable.ic_lecture)
                .setContentTitle("Kezdődik: ${e.title()}")
                .setContentText("Koppints, és indul az előadás-időzítő (${e.length(context)})")
                .setContentIntent(pi)
                .setAutoCancel(true)
                .build())
            LectureSchedule.scheduleNext(context)
        }
    }
}
