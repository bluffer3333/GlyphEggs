package com.akos.glypheggs

import android.app.Activity
import android.content.Intent
import android.hardware.Sensor
import android.hardware.SensorEvent
import android.hardware.SensorEventListener
import android.hardware.SensorManager
import android.os.Bundle
import android.os.SystemClock
import android.view.Gravity
import android.view.ViewGroup.LayoutParams.MATCH_PARENT
import android.view.ViewGroup.LayoutParams.WRAP_CONTENT
import android.view.WindowManager
import android.widget.LinearLayout
import android.widget.TextView
import kotlinx.coroutines.MainScope
import kotlinx.coroutines.cancel
import kotlinx.coroutines.launch

/**
 * LED-szimuláció: a képernyőn mutatja, mit csinálnak a Glyph LED-ek – bármelyik telefonon.
 * A főképernyőn a "Glyph Eggs" címre kétszer koppintva nyílik meg.
 *
 * Amíg nyitva van, a funkciók kijelzővel FELFELÉ fekvő telefonnal is működnek.
 * Ilyenkor a rajz tükrözve jelenik meg, így minden LED a valódi helyén látszik
 * (a kamera felőli oldal ott van, ahol a kamera).
 */
class SimulatorActivity : Activity(), SensorEventListener {

    private val scope = MainScope()
    private lateinit var map: GlyphMapView
    private lateinit var status: TextView
    private var sm: SensorManager? = null
    private var lastTap = 0L

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        window.decorView.setBackgroundColor(0xFF000000.toInt())
        window.addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)

        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setBackgroundColor(0xFF000000.toInt())
            setPadding(dp(16), dp(16), dp(16), dp(16))
            padForSystemBars()
        }
        setContentView(root)

        root.addView(text("LED-szimuláció", 15f, Ui.SUB, Ui.medium).apply {
            gravity = Gravity.CENTER
        }, LinearLayout.LayoutParams(MATCH_PARENT, WRAP_CONTENT))

        map = GlyphMapView(this).apply {
            unlitColor = 0xFF242424.toInt()
            setOnClickListener {
                val now = SystemClock.uptimeMillis()
                if (now - lastTap < 400) finish() else lastTap = now
            }
        }
        root.addView(map, LinearLayout.LayoutParams(MATCH_PARENT, 0, 1f).apply {
            topMargin = dp(12)
            bottomMargin = dp(12)
        })

        status = text("", 14f, Ui.TEXT).apply { gravity = Gravity.CENTER }
        root.addView(status, LinearLayout.LayoutParams(MATCH_PARENT, WRAP_CONTENT))

        // Érintés gomb: a játékokban kopogásnak számít (Zárfeltörő, Széf, Tojás)
        root.addView(text("Érintés (= kopogás)", 15f, Ui.DARK_TEXT, Ui.medium).apply {
            gravity = Gravity.CENTER
            background = rounded(Ui.LIGHT, dp(26).toFloat())
            setOnClickListener { GlyphMirror.taps.tryEmit(SystemClock.elapsedRealtime()) }
        }, LinearLayout.LayoutParams(MATCH_PARENT, dp(56)).apply { topMargin = dp(14) })

        // Gyors indítás innen is (két sorban)
        for (chunk in Feature.entries.chunked(3)) {
            val buttons = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
            for (f in chunk) {
                buttons.addView(text(f.short, 14f).apply {
                    gravity = Gravity.CENTER
                    background = rounded(Ui.CARD, dp(22).toFloat())
                    setOnClickListener {
                        startForegroundService(Intent(this@SimulatorActivity, SimonService::class.java).setAction(SimonService.actionFor(f)))
                    }
                }, LinearLayout.LayoutParams(0, dp(44), 1f).apply {
                    marginStart = dp(3)
                    marginEnd = dp(3)
                })
            }
            root.addView(buttons, LinearLayout.LayoutParams(MATCH_PARENT, WRAP_CONTENT).apply { topMargin = dp(6) })
        }

        root.addView(text("Kijelzővel felfelé is működik · koppints kétszer a rajzra a kilépéshez", 12f, Ui.SUB).apply {
            gravity = Gravity.CENTER
            setPadding(0, dp(12), 0, 0)
        }, LinearLayout.LayoutParams(MATCH_PARENT, WRAP_CONTENT))

        scope.launch { GlyphMirror.lit.collect { map.lit = it } }
        scope.launch { DebugState.status.collect { status.text = it } }
    }

    override fun onResume() {
        super.onResume()
        GlyphMirror.simulatorOpen = true
        GlyphMirror.appVisible = true
        val manager = getSystemService(SensorManager::class.java)
        sm = manager
        manager.getDefaultSensor(Sensor.TYPE_ACCELEROMETER)?.let {
            manager.registerListener(this, it, SensorManager.SENSOR_DELAY_UI)
        }
    }

    override fun onPause() {
        super.onPause()
        GlyphMirror.simulatorOpen = false
        GlyphMirror.appVisible = false
        sm?.unregisterListener(this)
    }

    /** Kijelzővel felfelé → tükrözött rajz (így a LED-ek a valódi helyükön látszanak). */
    override fun onSensorChanged(event: SensorEvent) {
        val z = event.values[2]
        if (z > 6f) map.mirrored = true
        else if (z < -6f) map.mirrored = false
    }

    override fun onAccuracyChanged(sensor: Sensor?, accuracy: Int) = Unit

    override fun onDestroy() {
        scope.cancel()
        super.onDestroy()
    }
}
