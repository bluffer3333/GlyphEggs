package com.akos.glypheggs

import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent

/** Újraindítás után automatikusan visszakapcsolja a mozdulatfigyelést, ha be volt kapcsolva. */
class BootReceiver : BroadcastReceiver() {
    override fun onReceive(context: Context, intent: Intent) {
        if (intent.action != Intent.ACTION_BOOT_COMPLETED) return
        PetAlarmReceiver.schedule(context)
        // Az órarend ébresztője újraindításkor törlődik: újra beállítja
        LectureSchedule.scheduleNext(context)
        // A fújásfigyelés (mikrofon) újraindítás után nem kapcsolható vissza a háttérből:
        // az app első megnyitásakor kapcsol vissza magától
        if (Settings.watching(context)) {
            context.startForegroundService(
                Intent(context, SimonService::class.java).setAction(SimonService.ACTION_WATCH_ON)
            )
        }
    }
}
