package com.akos.glypheggs

import android.app.Activity
import android.os.Bundle
import android.view.Gravity
import android.view.View
import android.view.ViewGroup.LayoutParams.MATCH_PARENT
import android.view.ViewGroup.LayoutParams.WRAP_CONTENT
import android.widget.FrameLayout
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.ScrollView

/**
 * A titkos menü: a neon témák. Kitűzőkkel oldódnak fel, sorban; a választott téma az egész appra
 * (háttér, kártyák neon szegéllyel, izzó címek, színes LED-kép) azonnal érvényes.
 */
class NeonActivity : Activity() {

    private lateinit var root: LinearLayout

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        darkWindow()
        root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(15), 0, dp(15), dp(30))
        }
        val scroll = ScrollView(this).apply {
            background = Ui.pageBg()
            isVerticalScrollBarEnabled = false
            addView(root, FrameLayout.LayoutParams(MATCH_PARENT, WRAP_CONTENT))
            padForSystemBars()
        }
        setContentView(scroll)
        build()
    }

    private fun build() {
        val got = Achievements.unlocked(this).size
        val h = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
            setPadding(dp(7), dp(28), 0, dp(6))
        }
        h.addView(ImageView(this).apply { setImageResource(R.drawable.ic_back); setColorFilter(Ui.TEXT); setOnClickListener { finish() } },
            LinearLayout.LayoutParams(dp(24), dp(24)))
        root.addView(h)
        val accent = Ui.neon?.a ?: 0xFFFF2BD6.toInt()
        root.addView(text("TITKOS MENÜ", 34f, Ui.TEXT).apply {
            typeface = Widgets.dotoFace(this@NeonActivity)
            setShadowLayer(26f, 0f, 0f, accent)
            setPadding(dp(7), dp(18), 0, 0)
        })
        root.addView(text("Neon témák · $got kitűződ van. Minden újabb kitűző-mérföldkő egy új témát nyit.", 13.5f, Ui.SUB)
            .apply { setPadding(dp(8), dp(6), dp(8), dp(14)); setLineSpacing(0f, 1.2f) })

        // Alap téma
        val cur = Settings.neonTheme(this)
        root.addView(baseCard(cur.isEmpty() || NeonThemes.current(this) == null), lp())
        for (t in NeonTheme.entries) root.addView(themeCard(t, t.name == cur && NeonThemes.unlocked(this, t), got), lp())
        root.addView(text("A téma az egész appra érvényes: háttér, neon szegélyek, izzó címek és a hátlap színes képe. A widgetek maradnak Nothing-feketék.",
            12f, Ui.SUB).apply { setPadding(dp(8), dp(10), dp(8), 0); setLineSpacing(0f, 1.2f) })
    }

    private fun lp() = LinearLayout.LayoutParams(MATCH_PARENT, dp(132)).apply { bottomMargin = dp(8) }

    private fun pick(name: String) {
        Settings.setNeonTheme(this, name)
        Haptics(this).result()
        recreate()
    }

    private fun baseCard(selected: Boolean): FrameLayout {
        val f = FrameLayout(this).apply {
            background = rounded(0xFF1B1B1B.toInt(), dp(24).toFloat(), if (selected) 0xFFFFFFFF.toInt() else 0xFF3A3A3A.toInt(), dp(if (selected) 2 else 1))
            setOnClickListener { pick("") }
        }
        val tx = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(dp(20), dp(18), dp(20), dp(18)) }
        tx.addView(text("NOTHING", 24f, 0xFFF1F1F1.toInt()).apply { typeface = Widgets.dotoFace(this@NeonActivity); setShadowLayer(0f, 0f, 0f, 0) })
        tx.addView(text("Az alap: fekete, fehér, egy csepp piros", 13f, 0xFFA8A8A8.toInt()))
        f.addView(tx, FrameLayout.LayoutParams(MATCH_PARENT, WRAP_CONTENT, Gravity.BOTTOM))
        if (selected) f.addView(RadioMark(this, true), FrameLayout.LayoutParams(dp(26), dp(26), Gravity.TOP or Gravity.END).apply { topMargin = dp(16); marginEnd = dp(16) })
        return f
    }

    private fun themeCard(t: NeonTheme, selected: Boolean, got: Int): FrameLayout {
        val open = NeonThemes.unlocked(this, t)
        val f = FrameLayout(this).apply {
            background = NeonBackground(t).apply { radius = dp(24).toFloat() }
            setOnClickListener { if (open) pick(t.name) }
        }
        // Keret: neon, ha nyitva (vastagabb, ha ez a kiválasztott)
        val frame = View(this).apply {
            background = rounded(0x00000000, dp(24).toFloat(), if (open) t.a else 0xFF444444.toInt(), dp(if (selected) 3f else 1.5f))
        }
        // Színminták: a két fő szín + szöveg
        val dots = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
        val cols = if (t.rainbow) RAINBOW.toList() else listOf(t.a, t.b, t.text)
        for (c in cols) dots.addView(View(this).apply { background = rounded(c, dp(7).toFloat()) },
            LinearLayout.LayoutParams(dp(14), dp(14)).apply { marginEnd = dp(6) })
        f.addView(dots, FrameLayout.LayoutParams(WRAP_CONTENT, WRAP_CONTENT, Gravity.TOP or Gravity.START).apply { topMargin = dp(18); marginStart = dp(20) })
        val tx = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(dp(20), dp(10), dp(20), dp(16)) }
        tx.addView(text(t.title.uppercase(), 26f, if (open) t.text else 0xFF8A8A8A.toInt()).apply {
            typeface = Widgets.dotoFace(this@NeonActivity)
            setShadowLayer(if (open) 22f else 0f, 0f, 0f, t.a)
        })
        tx.addView(text(if (open) t.desc else "🔒 ${t.badges} kitűző kell · most: $got", 13f, if (open) t.sub else 0xFF9A9A9A.toInt()))
        f.addView(tx, FrameLayout.LayoutParams(MATCH_PARENT, WRAP_CONTENT, Gravity.BOTTOM))
        if (!open) {
            // Zárt: elsötétítve, a felirat felül marad
            f.addView(View(this).apply { background = rounded(0xB0000000.toInt(), dp(24).toFloat()) }, 0,
                FrameLayout.LayoutParams(MATCH_PARENT, MATCH_PARENT))
        }
        f.addView(frame, FrameLayout.LayoutParams(MATCH_PARENT, MATCH_PARENT))
        if (selected) f.addView(RadioMark(this, true), FrameLayout.LayoutParams(dp(26), dp(26), Gravity.TOP or Gravity.END).apply { topMargin = dp(16); marginEnd = dp(16) })
        return f
    }
}
