package com.akos.glypheggs

import android.content.Context
import android.os.BatteryManager
import android.os.SystemClock
import com.nothing.ketchum.Glyph
import java.time.LocalDate
import kotlin.math.abs

/**
 * Fogyasztásmérő az Akku fülhöz.
 *
 * Két dolgot számol, funkciónként és naponta:
 *  1. **Becslés** (ez a fő szám): a ténylegesen égő LED-ek és a bekapcsolt szenzorok ideje,
 *     szorozva a [Config]-ban megadott áramfelvétellel (mA). LED: zónánként, abban a pillanatban,
 *     amikor ég. Szenzor + processzor: az érzékelési mód szerint (játék, kopogásfigyelés, giroszkóp…).
 *  2. **Mérés**: futás közben a telefon *teljes* áramfelvétele (BatteryManager), 5 mp-enként.
 *     Ebben a képernyő, a rádiók és minden más app is benne van – csak tájékoztató.
 *
 * Az idő a háttérfigyelésnél ("WATCH") is számít, így az is látszik, mennyibe kerül, hogy a
 * telefon a mozdulatokat figyeli.
 */
object EnergyMeter {

    const val WATCH = "WATCH"
    const val BLOW_LISTEN = "BLOW_LISTEN"
    const val BEACON = "BEACON"
    private const val PREFS = "glyph_eggs_energy"

    /** Egy sor a táblázatban (egy funkció egy időszakra). */
    class Row(
        var runs: Int = 0,
        var ms: Long = 0,
        var ledMaMs: Double = 0.0,
        var sensMaMs: Double = 0.0,
        var measMaMs: Double = 0.0,
        var measMs: Long = 0
    ) {
        val ledMah get() = ledMaMs / 3_600_000.0
        val sensMah get() = sensMaMs / 3_600_000.0
        val totalMah get() = ledMah + sensMah
        /** Becsült átlagos áramfelvétel futás közben (mA). */
        val avgMa get() = if (ms > 0) (ledMaMs + sensMaMs) / ms else 0.0
        /** A telefon mért átlagos áramfelvétele futás közben (mA), ha volt mérés. */
        val measAvgMa: Double? get() = if (measMs > 0) measMaMs / measMs else null

        fun add(o: Row) {
            runs += o.runs; ms += o.ms; ledMaMs += o.ledMaMs; sensMaMs += o.sensMaMs
            measMaMs += o.measMaMs; measMs += o.measMs
        }

        fun encode() = "$runs;$ms;$ledMaMs;$sensMaMs;$measMaMs;$measMs"

        companion object {
            fun decode(s: String?): Row {
                val p = s?.split(";") ?: return Row()
                return try {
                    Row(p[0].toInt(), p[1].toLong(), p[2].toDouble(), p[3].toDouble(), p[4].toDouble(), p[5].toLong())
                } catch (t: Throwable) {
                    Row()
                }
            }
        }
    }

    private val bigZones = setOf(
        Glyph.Code_22111.A1, Glyph.Code_22111.A2, Glyph.Code_22111.B1,
        Glyph.Code_22111.C2, Glyph.Code_22111.C3, Glyph.Code_22111.C4,
        Glyph.Code_22111.C5, Glyph.Code_22111.C6
    )

    private var app: Context? = null
    private var feature: Feature? = null
    private var featureStart = 0L
    private var watching = false
    private var ledMa = 0.0
    private var sensMa = 0.0
    private var last = 0L
    private var lastFlush = 0L
    private val pending = HashMap<String, Row>()

    private fun now() = SystemClock.elapsedRealtime()

    private fun owner(): String? = feature?.name ?: if (watching) WATCH else null

    @Synchronized
    fun attach(c: Context) {
        if (app == null) app = c.applicationContext
        if (last == 0L) last = now()
    }

    /** Az eddig eltelt időt hozzáírja a mostani "tulajdonoshoz" (futó funkció vagy háttérfigyelés). */
    private fun integrate() {
        val t = now()
        val dt = t - last
        last = t
        val o = owner() ?: return
        if (dt <= 0) return
        val r = pending.getOrPut(o) { Row() }
        r.ledMaMs += ledMa * dt
        r.sensMaMs += sensMa * dt
        if (o == WATCH) r.ms += dt
        if (t - lastFlush > 60_000L) flushLocked()
    }

    /** A most égő LED-ek (a GlyphController hívja minden változáskor). */
    @Synchronized
    fun setLed(zones: Collection<Int>) {
        integrate()
        ledMa = zones.sumOf { if (it in bigZones) Config.LED_BIG_MA else Config.LED_SMALL_MA }
    }

    /** A szenzorok + processzor becsült áramfelvétele (a MotionDetector hívja). */
    @Synchronized
    fun setSensors(ma: Double) {
        integrate()
        sensMa = ma
    }

    @Synchronized
    fun setWatching(on: Boolean) {
        integrate()
        watching = on
    }

    @Synchronized
    fun begin(f: Feature) {
        integrate()
        feature = f
        featureStart = now()
    }

    @Synchronized
    fun end(f: Feature) {
        integrate()
        if (feature == f) {
            val r = pending.getOrPut(f.name) { Row() }
            r.runs++
            r.ms += now() - featureStart
            feature = null
        }
        flushLocked()
    }

    /** Egy mérés a futó funkcióhoz: a telefon teljes árama (mA) ennyi ideig. */
    @Synchronized
    fun addMeasured(f: Feature, ma: Double, ms: Long) {
        val r = pending.getOrPut(f.name) { Row() }
        r.measMaMs += ma * ms
        r.measMs += ms
    }

    /**
     * Külön mért tétel (pl. „BLOW_LISTEN” = fújásfigyelés): [ma] áram [ms] ideig, a saját sorába.
     * A táblázatban külön sorként jelenik meg.
     */
    @Synchronized
    fun addExtra(key: String, ma: Double, ms: Long) {
        val r = pending.getOrPut(key) { Row() }
        r.sensMaMs += ma * ms
        r.ms += ms
        if (now() - lastFlush > 60_000L) flushLocked()
    }

    /** Becsült áramfelvétel most (mA): LED + szenzorok. */
    @Synchronized
    fun liveMa(): Double = ledMa + sensMa

    @Synchronized
    fun liveLedMa(): Double = ledMa

    @Synchronized
    fun flush() {
        integrate()
        flushLocked()
    }

    private fun flushLocked() {
        val c = app ?: return
        lastFlush = now()
        if (pending.isEmpty()) return
        val prefs = c.getSharedPreferences(PREFS, Context.MODE_PRIVATE)
        val day = LocalDate.now().toString()
        val e = prefs.edit()
        for ((k, r) in pending) {
            val key = "$day|$k"
            val old = Row.decode(prefs.getString(key, null))
            old.add(r)
            e.putString(key, old.encode())
        }
        // Régi napok törlése
        val oldest = LocalDate.now().minusDays(Config.ENERGY_KEEP_DAYS.toLong()).toString()
        for (key in prefs.all.keys) {
            if (key.substringBefore("|") < oldest) e.remove(key)
        }
        e.apply()
        pending.clear()
    }

    /** Az utolsó [days] nap összesítése kulcsonként (funkciónév vagy [WATCH]). */
    fun load(c: Context, days: Int): Map<String, Row> {
        attach(c)
        flush()
        val prefs = c.getSharedPreferences(PREFS, Context.MODE_PRIVATE)
        val from = LocalDate.now().minusDays((days - 1).toLong()).toString()
        val out = HashMap<String, Row>()
        for ((key, value) in prefs.all) {
            val day = key.substringBefore("|", "")
            val k = key.substringAfter("|", "")
            if (day.isEmpty() || k.isEmpty() || day < from) continue
            out.getOrPut(k) { Row() }.add(Row.decode(value as? String))
        }
        return out
    }

    @Synchronized
    fun reset(c: Context) {
        pending.clear()
        c.getSharedPreferences(PREFS, Context.MODE_PRIVATE).edit().clear().apply()
    }

    /** Az akku kapacitása mAh-ban: a töltésszámlálóból, ha a telefon megadja, különben 4700. */
    fun batteryMah(c: Context): Double {
        return try {
            val bm = c.getSystemService(BatteryManager::class.java)
            val counter = bm.getIntProperty(BatteryManager.BATTERY_PROPERTY_CHARGE_COUNTER) // µAh
            val pct = bm.getIntProperty(BatteryManager.BATTERY_PROPERTY_CAPACITY)
            if (counter > 0 && pct in 5..100) {
                val mah = counter / 1000.0 / (pct / 100.0)
                if (mah in 1500.0..10000.0) mah else Config.BATTERY_MAH_DEFAULT
            } else Config.BATTERY_MAH_DEFAULT
        } catch (t: Throwable) {
            Config.BATTERY_MAH_DEFAULT
        }
    }

    /** A telefon teljes áramfelvétele most (mA), vagy null, ha tölt, vagy nem olvasható. */
    fun measureNow(c: Context): Double? {
        return try {
            val bm = c.getSystemService(BatteryManager::class.java)
            if (bm.isCharging) return null
            val v = bm.getIntProperty(BatteryManager.BATTERY_PROPERTY_CURRENT_NOW)
            if (v == 0 || v == Int.MIN_VALUE) return null
            val a = abs(v.toDouble())
            // A szabvány µA, de van telefon, amelyik mA-t ad
            if (a > 10_000) a / 1000.0 else a
        } catch (t: Throwable) {
            null
        }
    }
}
