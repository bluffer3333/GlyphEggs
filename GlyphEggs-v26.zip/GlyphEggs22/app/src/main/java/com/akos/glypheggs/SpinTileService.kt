package com.akos.glypheggs

import android.service.quicksettings.Tile
import android.service.quicksettings.TileService

/**
 * "Pörgetés" csempe a lehúzható menüben:
 * koppints rá, tedd le a telefont kijelzővel lefelé, és a fény körbefut, majd kiválaszt valakit.
 */
class SpinTileService : TileService() {

    override fun onStartListening() {
        super.onStartListening()
        val tile = qsTile ?: return
        tile.state = Tile.STATE_INACTIVE
        tile.subtitle = "Koppints, tedd le"
        tile.updateTile()
    }

    override fun onClick() {
        super.onClick()
        TileStarter.startService(this, SimonService.ACTION_SPIN)
    }
}
