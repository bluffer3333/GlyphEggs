package com.akos.glypheggs

import android.content.Context
import android.os.SystemClock
import com.nothing.ketchum.Glyph
import kotlinx.coroutines.channels.Channel
import kotlinx.coroutines.coroutineScope
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.merge
import kotlinx.coroutines.launch
import kotlin.math.roundToInt
import kotlin.random.Random

/**
 * A Glyph Tojás "élőben" a hátlap LED-jein.
 *
 * Mit látsz:
 *  - Szemek: A1 + A2 (pislog). Antenna: B1 (ha vidám vagy már nagyobb).
 *  - Test a C1 sávon: boldogan ugrál, elégedetten "lélegzik", szomorúan a D1-en könnycsepp fut,
 *    betegen a C4 villog, alváskor csak az E1 pislákol (zzz).
 *  - Kaki: az E1 pont ég (2 vagy több kakinál villog).
 *  - Pár másodpercenként megmutatja az állapotát a C1 sávon, jelölővel:
 *    C2 = jóllakottság, C3 = kedv, C5 = energia, C6 = tisztaság.
 *  - Tojásként a gyűrű billeg; ha kikel, nagy fényáradat.
 *
 * Gondozás (fekve, kijelzővel lefelé):
 *  - 1 kopogás = simogatás, 2 = etetés, 3 = játék, 4 = altatás/ébresztés
 *  - rázás = fürdetés (felemelve megrázod, aztán vissza)
 *  - döntéssel "körülnéz" arra, amerre döntöd
 *  - az appból minden gondozás elérhető (gyógyítás is)
 * Felemelés után 5 mp-cel, vagy 3 perc tétlenség után elköszön és kikapcsol.
 */
class PetSession(
    private val context: Context,
    private val glyph: GlyphController,
    private val motion: MotionDetector,
    private val haptics: Haptics,
    private val onStatus: (String) -> Unit
) {
    private sealed class Ev {
        object Knock : Ev()
        object Shake : Ev()
        class Action(val a: PetAction) : Ev()
    }

    private val bar: IntArray = IntArray(16) { Zones.LEVEL[15 - it] } // bal felső végétől jobbra
    private val eyes = intArrayOf(Glyph.Code_22111.A1, Glyph.Code_22111.A2)
    private val antenna = Glyph.Code_22111.B1
    private val dLine = intArrayOf(
        Glyph.Code_22111.D1_1, Glyph.Code_22111.D1_2, Glyph.Code_22111.D1_3, Glyph.Code_22111.D1_4,
        Glyph.Code_22111.D1_5, Glyph.Code_22111.D1_6, Glyph.Code_22111.D1_7, Glyph.Code_22111.D1_8
    )
    private val ring: IntArray = bar + intArrayOf(
        Glyph.Code_22111.C6, Glyph.Code_22111.C5, Glyph.Code_22111.C4, Glyph.Code_22111.C3, Glyph.Code_22111.C2
    )
    private val statMarkers = intArrayOf(Glyph.Code_22111.C2, Glyph.Code_22111.C3, Glyph.Code_22111.C5, Glyph.Code_22111.C6)

    private var state: PetState = PetStore.load(context)

    suspend fun run() = coroutineScope {
        val events = Channel<Ev>(16)
        val jobs = listOf(
            launch { merge(motion.knockEvents, GlyphMirror.taps).collect { events.trySend(Ev.Knock) } },
            launch { motion.shakeEvents.collect { events.trySend(Ev.Shake) } },
            launch { PetStore.actions.collect { events.trySend(Ev.Action(it)) } }
        )
        try {
            loop(events)
        } finally {
            jobs.forEach { it.cancel() }
            glyph.off()
        }
    }

    private fun status() {
        val s = state
        val txt = if (s.stage == PetStage.EGG) "Glyph Tojás – még tojás (kopogj, hogy melegedjen)"
        else "Glyph Tojás – ${s.stage.title}, ${s.mood.title.lowercase()}" + (s.need()?.let { " · $it" } ?: "")
        onStatus(txt)
    }

    private suspend fun loop(events: Channel<Ev>) {
        greet()
        status()
        var lastInput = SystemClock.elapsedRealtime()
        var liftedSince = 0L
        var knockCount = 0
        var lastKnock = 0L
        var lastReload = lastInput
        var frame = 0

        while (true) {
            val now = SystemClock.elapsedRealtime()

            // Kilépés: felemelve maradt, vagy rég nem foglalkoztál vele
            if (motion.faceDown.value) {
                liftedSince = 0L
            } else if (liftedSince == 0L) {
                liftedSince = now
            } else if (now - liftedSince > Config.PET_LIFT_GRACE_MS) {
                break
            }
            if (now - lastInput > Config.PET_SESSION_IDLE_MS) break

            // Bemenetek
            val ev = events.tryReceive().getOrNull()
            when (ev) {
                is Ev.Knock -> {
                    knockCount++
                    lastKnock = now
                    lastInput = now
                }
                is Ev.Shake -> {
                    lastInput = now
                    act(PetAction.CLEAN)
                }
                is Ev.Action -> {
                    lastInput = now
                    state = PetStore.load(context)
                    animate(ev.a)
                    status()
                }
                null -> Unit
            }
            if (knockCount > 0 && now - lastKnock > Config.PET_KNOCK_GROUP_MS) {
                val n = knockCount.coerceAtMost(4)
                knockCount = 0
                PetAction.entries.firstOrNull { it.knocks == n }?.let { act(it) }
            }

            if (now - lastReload > 5_000) {
                state = PetStore.load(context)
                lastReload = now
                status()
            }

            drawIdle(frame++)
            delay(80)
        }
        bye()
    }

    /** Művelet a LED-es gondozásból: alkalmazza, majd lejátssza az animációt. */
    private suspend fun act(a: PetAction) {
        val wasEgg = state.stage == PetStage.EGG
        val msg = PetStore.act(context, a, notifySession = false)
        DebugState.log("Tojás: ${a.title} – $msg")
        state = PetStore.load(context)
        if (wasEgg) {
            if (state.stage != PetStage.EGG) hatchAnim() else warmAnim()
        } else {
            animate(a)
        }
        status()
    }

    // ------------------------------------------------------------------ nyugalmi animáció

    private fun tri(t: Int, max: Int): Int {
        if (max <= 0) return 0
        val p = t % (2 * max)
        return if (p <= max) p else 2 * max - p
    }

    private fun drawIdle(frame: Int) {
        val s = state
        val lit = mutableListOf<Int>()

        if (s.stage == PetStage.EGG) {
            // A tojás billeg: hol a bal, hol a jobb fele ég
            val left = (frame / 8) % 2 == 0
            lit += if (left) listOf(Glyph.Code_22111.C2, Glyph.Code_22111.C3, Glyph.Code_22111.C4) + bar.take(8)
            else listOf(Glyph.Code_22111.C6, Glyph.Code_22111.C5, Glyph.Code_22111.C4) + bar.drop(8)
            glyph.show(lit.toIntArray())
            return
        }

        if (s.asleep) {
            if ((frame / 10) % 2 == 0) lit += Glyph.Code_22111.E1
            lit += dLine[0]
            glyph.show(lit.toIntArray())
            return
        }

        // Pár másodpercenként: állapotjelző (jelölő + sáv a C1-en)
        val cycle = frame % 110
        if (cycle >= 70) {
            val i = (cycle - 70) / 10
            val v = when (i) { 0 -> s.food; 1 -> s.fun_; 2 -> s.energy; else -> s.clean }
            val n = (v / 100f * 16f).roundToInt().coerceIn(if (v > 0f) 1 else 0, 16)
            lit += statMarkers[i]
            lit += bar.take(n)
            lit += eyes.toList()
            glyph.show(lit.toIntArray())
            return
        }

        // Szemek, pislogással
        val blink = frame % 45 < 2
        when {
            s.mood == PetMood.SAD -> if (!blink) lit += Glyph.Code_22111.A2
            s.mood == PetMood.SICK -> if ((frame / 6) % 2 == 0) lit += eyes.toList()
            !blink -> lit += eyes.toList()
        }
        if (s.mood == PetMood.HAPPY || s.stage.ordinal >= PetStage.TEEN.ordinal) lit += antenna

        // Test
        val size = when (s.stage) {
            PetStage.BABY -> 2
            PetStage.TEEN -> 3
            else -> 4
        }
        when (s.mood) {
            PetMood.HAPPY -> {
                val pos = tri(frame, 16 - size)
                for (k in 0 until size) lit += bar[pos + k]
            }
            PetMood.OK -> {
                val r = tri(frame / 2, 7)
                for (k in 0 until 16) if (kotlin.math.abs(k - 7.5f) <= r + 0.5f) lit += bar[k]
            }
            PetMood.SAD -> {
                for (k in 6 until 6 + size) lit += bar[k]
                lit += dLine[7 - (frame / 2) % 8] // könnycsepp
            }
            PetMood.SICK -> {
                for (k in 6 until 6 + size) lit += bar[k]
                if ((frame / 4) % 2 == 0) lit += Glyph.Code_22111.C4
            }
            PetMood.SLEEP -> Unit
        }

        // Döntés: "körülnéz" arra
        motion.tilt.value?.let { lit += it.zones().toList() }

        // Kaki az E1-en
        if (s.poops > 0 && (s.poops < 2 || (frame / 5) % 2 == 0)) lit += Glyph.Code_22111.E1

        glyph.show(lit.distinct().toIntArray())
    }

    // ------------------------------------------------------------------ animációk

    private suspend fun greet() {
        glyph.show(intArrayOf(Glyph.Code_22111.A2))
        delay(200)
        glyph.show(eyes)
        delay(250)
        for (z in ring) {
            glyph.show(eyes + z)
            delay(25)
        }
        glyph.show(eyes)
        delay(300)
    }

    private suspend fun bye() {
        glyph.show(eyes)
        delay(300)
        glyph.show(intArrayOf(Glyph.Code_22111.A2))
        delay(250)
        glyph.off()
        DebugState.log("A Tojás elköszönt")
    }

    private suspend fun animate(a: PetAction) {
        when (a) {
            PetAction.PET -> {
                haptics.purr()
                // Szívecske: a sáv két végéből középre telik
                for (k in 0..8) {
                    val l = (0 until 16).filter { it < k || it >= 16 - k }.map { bar[it] }
                    glyph.show((l + Glyph.Code_22111.A1).toIntArray())
                    delay(45)
                }
                repeat(2) {
                    glyph.show(bar + eyes)
                    delay(150)
                    glyph.show(eyes)
                    delay(100)
                }
            }
            PetAction.FEED -> {
                haptics.munch()
                // A falat felfelé megy a vonalon, a szájba
                repeat(2) {
                    glyph.show(intArrayOf(Glyph.Code_22111.E1) + eyes)
                    delay(80)
                    for (d in dLine) {
                        glyph.show(intArrayOf(d) + eyes)
                        delay(45)
                    }
                    glyph.show(intArrayOf(Glyph.Code_22111.C4) + eyes)
                    delay(120)
                }
                glyph.show(ring + eyes)
                delay(250)
            }
            PetAction.PLAY -> {
                // Labda kergetés a gyűrűn
                repeat(2) {
                    haptics.click()
                    for (z in ring) {
                        glyph.show(intArrayOf(z) + eyes + antenna)
                        delay(28)
                    }
                }
                repeat(3) {
                    glyph.show(ring + eyes + antenna)
                    delay(90)
                    glyph.show(eyes + antenna)
                    delay(90)
                }
            }
            PetAction.CLEAN -> {
                haptics.tick()
                // Fentről lefelé "lemossa"
                val rows = listOf(
                    eyes + antenna,
                    bar,
                    intArrayOf(Glyph.Code_22111.C2, Glyph.Code_22111.C6),
                    intArrayOf(Glyph.Code_22111.C3, Glyph.Code_22111.C5),
                    intArrayOf(Glyph.Code_22111.C4)
                ) + dLine.reversed().map { intArrayOf(it) } + listOf(intArrayOf(Glyph.Code_22111.E1))
                for (r in rows) {
                    glyph.show(r)
                    delay(60)
                }
                // Csillogás
                repeat(8) {
                    glyph.show(bar.filter { Random.nextInt(3) == 0 }.toIntArray() + eyes)
                    delay(70)
                }
            }
            PetAction.SLEEP -> {
                if (state.asleep) {
                    // Elalszik: alulról felfelé kialszanak a fények
                    val all = ring + eyes + antenna
                    for (k in all.size downTo 0) {
                        glyph.show(all.copyOfRange(0, k))
                        delay(30)
                    }
                } else {
                    haptics.tick()
                    glyph.show(eyes)
                    delay(200)
                    glyph.show(ring + eyes + antenna)
                    delay(300)
                }
            }
            PetAction.HEAL -> {
                repeat(3) {
                    glyph.show(intArrayOf(Glyph.Code_22111.C4, Glyph.Code_22111.E1) + eyes)
                    delay(150)
                    glyph.show(eyes)
                    delay(120)
                }
                glyph.show(Zones.ALL)
                delay(300)
            }
        }
    }

    private suspend fun warmAnim() {
        haptics.purr()
        repeat(2) {
            glyph.show(ring)
            delay(180)
            glyph.off()
            delay(120)
        }
    }

    /** Kikelés: repedések, aztán fényáradat. */
    private suspend fun hatchAnim() {
        repeat(10) {
            glyph.show(ring.filter { Random.nextInt(4) == 0 }.toIntArray())
            delay(90)
        }
        haptics.result()
        repeat(6) {
            glyph.show(Zones.ALL)
            delay(110)
            glyph.off()
            delay(70)
        }
        glyph.show(eyes)
        delay(500)
        DebugState.log("Kikelt a Glyph Tojás!")
    }
}
