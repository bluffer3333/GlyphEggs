package com.akos.glypheggs

import android.content.Context
import android.graphics.Canvas
import android.graphics.Paint
import android.graphics.Path
import android.graphics.RectF
import android.view.View
import com.nothing.ketchum.Glyph

/**
 * A Phone (2) hátlapjának Glyph-rajza, mind a 33 zónával.
 * A [lit] zónák világítanak, a többi halványan látszik.
 * [mirrored] = tükrözve rajzol (kijelzővel felfelé fekvő telefonnál így látszik a valós helyén).
 * [idleAllOn] = ha semmi sem ég, az egész rajz világos (mint a Nothing beállításaiban).
 */
class GlyphMapView(context: Context) : View(context) {

    var lit: Set<Int> = emptySet()
        set(value) {
            field = value
            invalidate()
        }

    var mirrored = false
        set(value) {
            if (field != value) {
                field = value
                invalidate()
            }
        }

    var idleAllOn = false
        set(value) {
            field = value
            invalidate()
        }

    /** Fut-e valamelyik funkció (ilyenkor a kialudt pillanatokban sem vált vissza "minden világos"-ra). */
    var active = false
        set(value) {
            field = value
            invalidate()
        }

    var unlitColor = 0xFF3A3A3A.toInt()

    private sealed class Shape(val zone: Int, val round: Boolean) {
        class Arc(zone: Int, val from: Float, val to: Float, round: Boolean) : Shape(zone, round)
        class Line(zone: Int, val x1: Float, val y1: Float, val x2: Float, val y2: Float, round: Boolean) : Shape(zone, round)
        class Curve(zone: Int, val path: Path) : Shape(zone, true)
        class Dot(zone: Int, val x: Float, val y: Float, val r: Float) : Shape(zone, true)
    }

    // A rajz koordinátái egy 160 × 270-es "vásznon"; a gyűrű közepe (80, 132)
    private val cx = 80f
    private val cy = 132f
    private val r = 55.5f
    private val ringOval = RectF(cx - r, cy - r, cx + r, cy + r)

    private val shapes: List<Shape> = buildList {
        // A1: kamera körüli rész felső fele, A2: alsó fele
        add(Shape.Curve(Glyph.Code_22111.A1, Path().apply {
            moveTo(30f, 50f)
            lineTo(30f, 28f)
            arcTo(RectF(30f, 16f, 54f, 40f), 180f, 180f, false)
            lineTo(54f, 34f)
        }))
        add(Shape.Curve(Glyph.Code_22111.A2, Path().apply {
            moveTo(54f, 42f)
            lineTo(54f, 58f)
            arcTo(RectF(30f, 46f, 54f, 70f), 0f, 180f, false)
            lineTo(30f, 56f)
        }))
        // B1: ferde csík
        add(Shape.Line(Glyph.Code_22111.B1, 118f, 22f, 94f, 52f, true))

        // C1: 16 kis LED; C1_16 a bal felső végén, C1_1 a jobb oldalon
        val c1 = intArrayOf(
            Glyph.Code_22111.C1_16, Glyph.Code_22111.C1_15, Glyph.Code_22111.C1_14, Glyph.Code_22111.C1_13,
            Glyph.Code_22111.C1_12, Glyph.Code_22111.C1_11, Glyph.Code_22111.C1_10, Glyph.Code_22111.C1_9,
            Glyph.Code_22111.C1_8, Glyph.Code_22111.C1_7, Glyph.Code_22111.C1_6, Glyph.Code_22111.C1_5,
            Glyph.Code_22111.C1_4, Glyph.Code_22111.C1_3, Glyph.Code_22111.C1_2, Glyph.Code_22111.C1_1
        )
        val start = -17f
        val end = 55f
        val step = (end - start) / 16f
        c1.forEachIndexed { i, z ->
            add(Shape.Arc(z, start + i * step + 0.4f, start + (i + 1) * step - 0.4f, false))
        }
        add(Shape.Arc(Glyph.Code_22111.C6, 85f, 100f, true))
        add(Shape.Arc(Glyph.Code_22111.C5, 120f, 152f, true))
        add(Shape.Arc(Glyph.Code_22111.C4, 175f, 235f, true))
        add(Shape.Arc(Glyph.Code_22111.C3, 260f, 280f, true))
        add(Shape.Arc(Glyph.Code_22111.C2, 300f, 325f, true))

        // D1: függőleges vonal, D1_1 alul
        val d = intArrayOf(
            Glyph.Code_22111.D1_1, Glyph.Code_22111.D1_2, Glyph.Code_22111.D1_3, Glyph.Code_22111.D1_4,
            Glyph.Code_22111.D1_5, Glyph.Code_22111.D1_6, Glyph.Code_22111.D1_7, Glyph.Code_22111.D1_8
        )
        val top = 204f
        val bottom = 232f
        val seg = (bottom - top) / 8f
        d.forEachIndexed { i, z ->
            val y2 = bottom - i * seg
            add(Shape.Line(z, 80f, y2 - 0.3f, 80f, y2 - seg + 0.3f, false))
        }
        // E1: pont
        add(Shape.Dot(Glyph.Code_22111.E1, 80f, 248f, 2.8f))
    }

    private val stroke = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        style = Paint.Style.STROKE
        strokeWidth = 5f
        strokeJoin = Paint.Join.ROUND
    }
    private val fill = Paint(Paint.ANTI_ALIAS_FLAG).apply { style = Paint.Style.FILL }

    override fun onDraw(canvas: Canvas) {
        super.onDraw(canvas)
        val s = minOf(width / 160f, height / 270f)
        if (s <= 0f) return
        canvas.save()
        canvas.translate((width - 160f * s) / 2f, (height - 270f * s) / 2f)
        canvas.scale(s, s)
        if (mirrored) canvas.scale(-1f, 1f, 80f, 0f)

        val idle = idleAllOn && lit.isEmpty() && !active
        // 1. halvány alap (vagy világos, ha nyugalomban minden "ég")
        for (sh in shapes) {
            val t = Ui.neon
            val color = when {
                idle && sh.zone == Glyph.Code_22111.E1 -> t?.b ?: 0xFFD71921.toInt()
                idle -> neonColor(sh.zone) ?: 0xFFEDEDED.toInt()
                else -> t?.unlit ?: unlitColor
            }
            draw(canvas, sh, color, 5f, 255)
        }
        // 2. világító zónák: halvány fényudvar + fehér mag
        if (!idle) {
            for (sh in shapes) {
                if (sh.zone !in lit) continue
                val nc = neonColor(sh.zone)
                if (nc != null) {
                    // Neon: széles, színes fényudvar + színes mag
                    draw(canvas, sh, nc, 16f, 45)
                    draw(canvas, sh, nc, 10f, 90)
                    draw(canvas, sh, nc, 5.5f, 255)
                } else {
                    draw(canvas, sh, 0xFFFFFFFF.toInt(), 11f, 50)
                    draw(canvas, sh, 0xFFFFFFFF.toInt(), 5.5f, 255)
                }
            }
        }
        canvas.restore()
    }

    /** Neon témában a zóna színe (felváltva a két fő szín, szivárványban körbe). */
    private fun neonColor(zone: Int): Int? {
        val t = Ui.neon ?: return null
        return if (t.rainbow) RAINBOW[Math.floorMod(zone, RAINBOW.size)] else if (zone % 3 == 0) t.b else t.a
    }

    private fun draw(canvas: Canvas, sh: Shape, color: Int, width: Float, alpha: Int) {
        stroke.color = color
        stroke.alpha = alpha
        stroke.strokeWidth = width
        stroke.strokeCap = if (sh.round) Paint.Cap.ROUND else Paint.Cap.BUTT
        when (sh) {
            // A rajz szöge 0° = felül, az Android ívé 0° = jobbra
            is Shape.Arc -> canvas.drawArc(ringOval, sh.from - 90f, sh.to - sh.from, false, stroke)
            is Shape.Line -> canvas.drawLine(sh.x1, sh.y1, sh.x2, sh.y2, stroke)
            is Shape.Curve -> canvas.drawPath(sh.path, stroke)
            is Shape.Dot -> {
                fill.color = color
                fill.alpha = alpha
                canvas.drawCircle(sh.x, sh.y, sh.r * width / 5f, fill)
            }
        }
    }
}
