package com.akos.glypheggs

import android.content.Context
import android.os.SystemClock
import com.nothing.ketchum.Glyph
import kotlinx.coroutines.channels.Channel
import kotlinx.coroutines.coroutineScope
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.merge
import kotlinx.coroutines.launch
import kotlin.math.abs
import kotlin.math.atan2
import kotlin.math.max
import kotlin.math.roundToInt

/**
 * Vízmérték a hátlapon – bármilyen helyzetben. A helyzetet magától felismeri:
 *
 *  - FEKVE (kijelzővel lefelé a felületen): két irányt mér.
 *      bal–jobb: a magasabb oldal ég (bal: C2, C3 / jobb: C5, C6); vízszintesnél MINDKETTŐ ég.
 *      előre–hátra: a kamera felőli rész (A1, A2, B1) vagy a vonal + pont (D1, E1); vízszintesnél mindkettő.
 *  - HOSSZÚ ÉLÉRE ÁLLÍTVA (vagy fekvő tájolásban a kezedben, falhoz tartva): a telefon hossza mentén mér.
 *      a magasabb vég ég (kamerás vég: A1, A2, B1 / töltőport vége: D1, E1); vízszintesnél mindkét vég ég.
 *  - TÖLTŐPORTON ÁLLVA (álló tájolásban): a rövid oldal mentén mér.
 *      a magasabb oldal ég (bal / jobb ív); vízszintesnél mindkettő.
 *
 *  - A felső sáv (C1) mutatja az eltérést: LED-enként 0,5°; 1° alatt a vége pislog.
 *  - Teljesen vízszintes (0,5°-on belül): minden LED felvillan, és kicsit rezeg.
 *  - Kalibrálás az adott helyzetben: 2 kopogás = ez a nulla, 3 kopogás = törlés.
 *    (Kopogás csak fekve működik; állítva a képernyős Érintés gombbal is lehet.)
 *  - Magától kikapcsol, ha 5 percig nem mozdul; különben a kártyával / csempével állítható le.
 */
class LevelTool(
    private val context: Context,
    private val glyph: GlyphController,
    private val motion: MotionDetector,
    private val haptics: Haptics,
    private val onStatus: (String) -> Unit
) {
    private enum class Pose(val title: String) {
        FLAT("fekve"),
        EDGE("hosszú élére állítva"),
        PORT("töltőporton állva")
    }

    private val left = intArrayOf(Glyph.Code_22111.C2, Glyph.Code_22111.C3)
    private val right = intArrayOf(Glyph.Code_22111.C5, Glyph.Code_22111.C6)
    private val front = intArrayOf(Glyph.Code_22111.A1, Glyph.Code_22111.A2, Glyph.Code_22111.B1)
    private val back = intArrayOf(
        Glyph.Code_22111.D1_1, Glyph.Code_22111.D1_2, Glyph.Code_22111.D1_3, Glyph.Code_22111.D1_4,
        Glyph.Code_22111.D1_5, Glyph.Code_22111.D1_6, Glyph.Code_22111.D1_7, Glyph.Code_22111.D1_8,
        Glyph.Code_22111.E1
    )
    private val bar: IntArray = IntArray(16) { Zones.LEVEL[15 - it] }

    suspend fun run() = coroutineScope {
        val knocks = Channel<Long>(16)
        val collector = launch { merge(motion.knockEvents, GlyphMirror.taps).collect { knocks.trySend(it) } }
        try {
            loop(knocks)
        } finally {
            collector.cancel()
            glyph.off()
            LevelState.clear(context)
        }
    }

    private fun deg(a: Float, b: Float): Float =
        Math.toDegrees(atan2(a.toDouble(), max(abs(b), 0.1f).toDouble())).toFloat()

    /** Melyik tengely mutat lefelé a legjobban – hiszterézissel, hogy ne ugráljon. */
    private fun detectPose(g: FloatArray, current: Pose?): Pose {
        val ax = abs(g[0])
        val ay = abs(g[1])
        val az = abs(g[2])
        val best = when {
            az >= ax && az >= ay -> Pose.FLAT
            ax >= ay -> Pose.EDGE
            else -> Pose.PORT
        }
        if (current == null || best == current) return best
        // Csak akkor vált, ha az új tengely egyértelműen erősebb (kb. 55° fölött)
        val strength = when (best) {
            Pose.FLAT -> az
            Pose.EDGE -> ax
            Pose.PORT -> ay
        }
        return if (strength > 8.0f) best else current
    }

    private suspend fun loop(knocks: Channel<Long>) {
        glyph.show(left + right)
        delay(200)
        glyph.show(front + back)
        delay(200)
        glyph.off()

        var pose: Pose? = null
        var s0 = 0f
        var s1 = 0f
        var first = true
        var wasLevel = false
        var knockCount = 0
        var lastKnock = 0L
        var lastStatus = 0L
        var lastMove = SystemClock.elapsedRealtime()
        var prevG = motion.gravity()
        var frame = 0
        var lastWidget = 0L
        var wA0 = 999f
        var wA1 = 999f
        var wAll = false
        var wPose = ""

        while (true) {
            val now = SystemClock.elapsedRealtime()
            val g = motion.gravity()

            // Tétlenség: ha 5 percig nem mozdul, kikapcsol
            val moved = abs(g[0] - prevG[0]) + abs(g[1] - prevG[1]) + abs(g[2] - prevG[2]) > 0.35f
            if (moved) {
                lastMove = now
                prevG = g
            }
            if (now - lastMove > Config.LEVEL_IDLE_MS) {
                DebugState.log("Vízmérték: 5 perce nem mozdult – kikapcsol")
                break
            }

            val newPose = detectPose(g, pose)
            if (newPose != pose) {
                pose = newPose
                first = true
                DebugState.log("Vízmérték: ${newPose.title}")
            }

            // Nyers szögek a helyzet szerint (a leginkább lefelé mutató tengelyhez képest)
            val (r0, r1) = when (newPose) {
                Pose.FLAT -> deg(g[0], g[2]) to deg(g[1], g[2])
                Pose.EDGE -> deg(g[1], g[0]) to 0f
                Pose.PORT -> deg(g[0], g[1]) to 0f
            }
            if (first) { s0 = r0; s1 = r1; first = false } else { s0 = 0.85f * s0 + 0.15f * r0; s1 = 0.85f * s1 + 0.15f * r1 }

            val keys = when (newPose) {
                Pose.FLAT -> listOf("flat_x", "flat_y")
                Pose.EDGE -> listOf("edge", "")
                Pose.PORT -> listOf("port", "")
            }
            val a0 = s0 - Settings.levelOffset(context, keys[0])
            val a1 = if (newPose == Pose.FLAT) s1 - Settings.levelOffset(context, keys[1]) else 0f

            // Kopogás / Érintés: kalibrálás az adott helyzetben
            while (true) {
                knocks.tryReceive().getOrNull() ?: break
                knockCount++
                lastKnock = now
            }
            if (knockCount > 0 && now - lastKnock > Config.PET_KNOCK_GROUP_MS) {
                when (knockCount) {
                    2 -> {
                        Settings.setLevelOffset(context, keys[0], s0)
                        if (newPose == Pose.FLAT) Settings.setLevelOffset(context, keys[1], s1)
                        DebugState.log("Vízmérték: kalibrálva (${newPose.title})")
                        haptics.result()
                        repeat(2) { glyph.show(Zones.ALL); delay(120); glyph.off(); delay(120) }
                    }
                    3 -> {
                        Settings.setLevelOffset(context, keys[0], 0f)
                        if (newPose == Pose.FLAT) Settings.setLevelOffset(context, keys[1], 0f)
                        DebugState.log("Vízmérték: kalibrálás törölve (${newPose.title})")
                        haptics.tick()
                    }
                }
                knockCount = 0
            }

            val tol = Config.LEVEL_TOLERANCE_DEG
            val lit = mutableListOf<Int>()
            val level0 = abs(a0) < tol
            val level1 = newPose != Pose.FLAT || abs(a1) < tol
            when (newPose) {
                Pose.FLAT -> {
                    // x < 0 → a kamera felőli (bal) oldal van lejjebb → a jobb a magasabb
                    lit += if (level0) (left + right).toList() else if (a0 < 0) right.toList() else left.toList()
                    // y < 0 → a kamerás vég van lejjebb → a töltőport vége a magasabb
                    lit += if (level1) (front + back).toList() else if (a1 < 0) back.toList() else front.toList()
                }
                Pose.EDGE -> {
                    // A telefon hossza mentén: melyik vég van magasabban
                    lit += if (level0) (front + back).toList() else if (a0 < 0) back.toList() else front.toList()
                }
                Pose.PORT -> {
                    // A rövid oldal mentén: melyik oldal van magasabban
                    lit += if (level0) (left + right).toList() else if (a0 < 0) right.toList() else left.toList()
                }
            }

            val all = level0 && level1
            if (all) {
                if (!wasLevel) haptics.level()
                glyph.show(Zones.ALL)
            } else {
                val dev = max(abs(a0), abs(a1))
                val n = (dev / Config.LEVEL_DEG_PER_LED).roundToInt().coerceIn(1, 16)
                lit += bar.take(n)
                if (dev < 1f && frame % 4 < 2) lit.remove(bar[n - 1])
                glyph.show(lit.distinct().toIntArray())
            }
            wasLevel = all

            // Widget: legfeljebb 3× másodpercenként, ha legalább 0,1°-ot változott
            if (now - lastWidget > 330 && (abs(a0 - wA0) >= 0.1f || abs(a1 - wA1) >= 0.1f || all != wAll || newPose.name != wPose)) {
                lastWidget = now
                wA0 = a0; wA1 = a1; wAll = all; wPose = newPose.name
                LevelState.update(context, newPose.name, newPose.title, a0, a1, all)
            }

            if (now - lastStatus > 400) {
                lastStatus = now
                onStatus(
                    when {
                        all -> "Vízmérték (${newPose.title}) – VÍZSZINTES"
                        newPose == Pose.FLAT -> "Vízmérték (fekve) – bal/jobb %.1f°, előre/hátra %.1f°".format(a0, a1)
                        else -> "Vízmérték (${newPose.title}) – %.1f°".format(a0)
                    }
                )
            }
            frame++
            delay(50)
        }
    }
}
