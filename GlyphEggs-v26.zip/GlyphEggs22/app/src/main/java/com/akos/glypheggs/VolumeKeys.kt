package com.akos.glypheggs

import android.content.Context
import android.media.VolumeProvider
import android.media.session.MediaSession
import android.media.session.PlaybackState

/**
 * A hangerő-gombok elkapása kikapcsolt képernyőnél is: egy aktív médiamunkamenet (MediaSession)
 * távoli hangerő-szabályozóval megkapja a gombnyomásokat, így a rendszer nem a hangerőt állítja.
 * Engedély nem kell. Kísérleti: nem minden Android-változat / gyártói felület irányítja így a gombokat.
 *
 * @param onKey +1 = hangerő fel, −1 = hangerő le
 */
class VolumeKeys(private val context: Context, private val onKey: (Int) -> Unit) {

    private var session: MediaSession? = null

    fun start() {
        if (session != null) return
        try {
            val s = MediaSession(context, "GlyphEggsKeys")
            s.setPlaybackState(
                PlaybackState.Builder()
                    .setState(PlaybackState.STATE_PLAYING, 0L, 1f)
                    .build()
            )
            s.setPlaybackToRemote(object : VolumeProvider(VOLUME_CONTROL_RELATIVE, 100, 50) {
                override fun onAdjustVolume(direction: Int) {
                    if (direction != 0) onKey(direction)
                }
            })
            s.isActive = true
            session = s
            DebugState.log("Hangerő-gombok figyelése bekapcsolva")
        } catch (t: Throwable) {
            DebugState.log("Hangerő-gombok: nem sikerült (${t.javaClass.simpleName})")
        }
    }

    fun stop() {
        try {
            session?.isActive = false
            session?.release()
        } catch (t: Throwable) {
            // nincs teendő
        }
        session = null
    }
}
