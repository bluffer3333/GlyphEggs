package com.akos.glypheggs

import android.app.Activity
import android.content.Context
import android.content.Intent
import android.media.AudioAttributes
import android.media.AudioManager
import android.media.AudioPlaybackConfiguration
import android.media.audiofx.Visualizer
import android.net.Uri
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.os.SystemClock
import kotlin.math.sqrt

/*
 * AI app mód: a beszélgetés egy telepített AI-appban (Claude, ChatGPT, Gemini, …), a saját fiókoddal megy
 * (nem kell API-kulcs), a Glyph Eggs pedig csak „hallgatja”, mikor szól a telefon, és a LED-eken animálja a hangot.
 * Semmit nem rögzít és nem küld el: csak a lejátszott hang erejét méri.
 */
/** Ismert AI-appok – ami telepítve van, az elöl jelenik meg a választóban. Bármelyik más app is választható. */
enum class KnownAi(val title: String, val pkg: String) {
    CLAUDE("Claude", "com.anthropic.claude"),
    CHATGPT("ChatGPT", "com.openai.chatgpt"),
    GEMINI("Gemini", "com.google.android.apps.bard"),
    COPILOT("Copilot", "com.microsoft.copilot"),
    PERPLEXITY("Perplexity", "ai.perplexity.app.android"),
    GROK("Grok", "ai.x.grok"),
    DEEPSEEK("DeepSeek", "com.deepseek.chat"),
    LECHAT("Le Chat (Mistral)", "ai.mistral.chat"),
    META("Meta AI", "com.facebook.stella")
}

/**
 * A választott AI-app (alapból a Claude) megnyitása és az AI mód indítása. A beszélgetés abban az appban,
 * a saját fiókoddal megy; a Glyph Eggs csak a telefonon szóló hangot követi a LED-eken.
 */
object ClaudeLink {
    fun pkg(c: Context): String = Settings.aiPackage(c)
    fun name(c: Context): String = Settings.aiName(c)

    fun installed(c: Context, p: String = pkg(c)): Boolean = c.packageManager.getLaunchIntentForPackage(p) != null

    /** A telepített ismert AI-appok. */
    fun installedKnown(c: Context): List<KnownAi> = KnownAi.entries.filter { installed(c, it.pkg) }

    /** Megnyitja a választott AI-appot; ha nincs telepítve, a Play Áruházat. */
    fun open(c: Context): Boolean {
        val i = c.packageManager.getLaunchIntentForPackage(pkg(c))
        return try {
            if (i != null) {
                c.startActivity(i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
                true
            } else {
                c.startActivity(Intent(Intent.ACTION_VIEW, Uri.parse("market://details?id=${pkg(c)}")).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
                false
            }
        } catch (t: Throwable) {
            false
        }
    }

    /** Csak a LED-követés (pl. ha a Geminit a bekapcsoló gombbal hívod elő). */
    fun startLeds(a: Context) {
        try {
            a.startForegroundService(Intent(a, SimonService::class.java).setAction(SimonService.ACTION_CLAUDE_VOICE))
        } catch (t: Throwable) { }
    }

    /** AI mód indítása: LED-követés be, aztán az AI-app előre. */
    fun start(a: Activity) {
        startLeds(a)
        open(a)
    }
}

/**
 * A telefonon épp szóló hang követése.
 *  1. Visualizer a teljes kimeneten (ha a rendszer engedi): valódi hangerő → szótagpontos villogás.
 *  2. Ha nem engedi, vagy hívás-útvonalon szól: a lejátszások listájából tudja, hogy SZÓL-e valami,
 *     és ilyenkor beszédszerű ütemet ad.
 */
class SoundFollower(private val context: Context) {

    @Volatile var level = 0f
        private set
    @Volatile var lastLoud = 0L
        private set
    @Volatile var playing = false
        private set
    @Volatile var visualOk = false
        private set
    @Volatile private var lastNonSilent = 0L

    private var vis: Visualizer? = null
    private val am = context.getSystemService(AudioManager::class.java)

    private val playbackCb = object : AudioManager.AudioPlaybackCallback() {
        override fun onPlaybackConfigChanged(configs: MutableList<AudioPlaybackConfiguration>?) {
            playing = isSpeechLike(configs)
        }
    }

    private fun isSpeechLike(configs: List<AudioPlaybackConfiguration>?): Boolean =
        configs?.any {
            when (it.audioAttributes.usage) {
                AudioAttributes.USAGE_MEDIA, AudioAttributes.USAGE_ASSISTANT, AudioAttributes.USAGE_VOICE_COMMUNICATION,
                AudioAttributes.USAGE_ASSISTANCE_ACCESSIBILITY, AudioAttributes.USAGE_UNKNOWN -> true
                else -> false
            }
        } == true

    fun start() {
        try {
            am.registerAudioPlaybackCallback(playbackCb, Handler(Looper.getMainLooper()))
            playing = isSpeechLike(am.activePlaybackConfigurations)
        } catch (t: Throwable) { }
        try {
            val v = Visualizer(0)
            v.captureSize = Visualizer.getCaptureSizeRange()[0].coerceAtLeast(128)
            v.setDataCaptureListener(object : Visualizer.OnDataCaptureListener {
                override fun onWaveFormDataCapture(visualizer: Visualizer?, waveform: ByteArray?, samplingRate: Int) {
                    if (waveform == null || waveform.isEmpty()) return
                    var sum = 0.0
                    for (b in waveform) {
                        val x = ((b.toInt() and 0xFF) - 128) / 128.0
                        sum += x * x
                    }
                    val rms = sqrt(sum / waveform.size).toFloat()
                    val now = SystemClock.elapsedRealtime()
                    if (rms > 0.004f) lastNonSilent = now
                    level = (rms * 4.5f).coerceIn(0f, 1f)
                    if (level > 0.08f) lastLoud = now
                }
                override fun onFftDataCapture(visualizer: Visualizer?, fft: ByteArray?, samplingRate: Int) {}
            }, Visualizer.getMaxCaptureRate(), true, false)
            v.enabled = true
            vis = v
            visualOk = true
        } catch (t: Throwable) {
            visualOk = false
            DebugState.log("AI mód: a hanghullám nem olvasható – ütemre villog, amíg szól")
        }
    }

    /** Valódi hangerőt ad-e most a Visualizer (nem néma, miközben valami szól). */
    fun realLevel(): Boolean = visualOk && SystemClock.elapsedRealtime() - lastNonSilent < 1_500

    fun stop() {
        try { am.unregisterAudioPlaybackCallback(playbackCb) } catch (t: Throwable) { }
        try { vis?.enabled = false; vis?.release() } catch (t: Throwable) { }
        vis = null
        level = 0f
        playing = false
    }
}

/**
 * Átlátszó indító: a widgetről elindítja az AI módot, és előre hozza a választott AI-appot.
 * (Másik app megnyitásához egy saját Activity kell köztes lépésként.)
 */
class ClaudeLaunchActivity : Activity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        ClaudeLink.start(this)
        finish()
    }
}
