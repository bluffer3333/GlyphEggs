package com.akos.glypheggs

import android.service.quicksettings.Tile
import android.service.quicksettings.TileService

/**
 * Közös csempe egy funkcióhoz: koppintásra elindul, ha fut, újabb koppintásra leáll.
 * A csempe világít, amíg a funkció fut.
 */
abstract class FeatureTileService(
    private val feature: Feature,
    private val idleSubtitle: String
) : TileService() {

    override fun onStartListening() {
        super.onStartListening()
        val tile = qsTile ?: return
        val running = GlyphMirror.mode.value == feature
        tile.state = if (running) Tile.STATE_ACTIVE else Tile.STATE_INACTIVE
        tile.subtitle = if (running) "Fut – koppints a leállításhoz" else idleSubtitle
        tile.updateTile()
    }

    override fun onClick() {
        super.onClick()
        TileStarter.startService(this, SimonService.actionFor(feature))
    }
}

/** "Zárfeltörő" csempe. */
class LockTileService : FeatureTileService(Feature.LOCKPICK, "Tedd le, kopogj")

/** "Széf" csempe. */
class SafeTileService : FeatureTileService(Feature.SAFE, "Döntsd be a kódot")

/** "Glyph Tojás" csempe. */
class PetTileService : FeatureTileService(Feature.PET, "Gondozás a LED-eken")

/** "Vízmérték" csempe. */
class LevelTileService : FeatureTileService(Feature.LEVEL, "Fekve, élére vagy portra állítva")

/** "Időzítő" csempe. */
class TimerTileService : FeatureTileService(Feature.TIMER, "Fókusz a LED-eken")

/** "Légzés" csempe. */
class BreathTileService : FeatureTileService(Feature.BREATH, "Légzésvezető a LED-eken")

/** "Dínófutás" csempe. */
class DinoTileService : FeatureTileService(Feature.DINO, "Kopogj az ugráshoz")

/** "Fújós" csempe: a Fújós oldalt nyitja (ott fut a mikrofon), ha fut, leállítja. */
class BlowTileService : FeatureTileService(Feature.BLOW, "Fújj a telefonba") {
    override fun onClick() {
        if (GlyphMirror.mode.value == Feature.BLOW) {
            TileStarter.startService(this, SimonService.ACTION_BLOW)
            return
        }
        val pi = android.app.PendingIntent.getActivity(
            this, 78,
            android.content.Intent(this, BlowActivity::class.java).addFlags(android.content.Intent.FLAG_ACTIVITY_NEW_TASK),
            android.app.PendingIntent.FLAG_IMMUTABLE or android.app.PendingIntent.FLAG_UPDATE_CURRENT
        )
        startActivityAndCollapse(pi)
    }
}

/** "Előadás" csempe. */
class LectureTileService : FeatureTileService(Feature.LECTURE, "2 × 45 perc, rázd fel")
