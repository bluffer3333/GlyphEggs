package com.akos.glypheggs

import android.os.SystemClock
import com.nothing.ketchum.Glyph
import kotlinx.coroutines.delay
import kotlin.math.pow
import kotlin.random.Random

/**
 * Üvegpörgető / szerencsekerék a nagy gyűrűn.
 *
 * A fénypont körbefut a gyűrűn, lassul, és megáll valahol – akire mutat, azt választotta.
 * Szögek a telefon hátuljáról nézve (kijelzővel lefelé fekve), 0° = felül, óramutató irányában:
 *   C1_16 … C1_1 : 0°–90°   (jobb felső negyed, 16 kis LED)
 *   C6           : 90°–144° (jobb oldal)
 *   C5           : 144°–198° (jobb alsó ív)
 *   C4           : 198°–252° (bal alsó ív)
 *   C3           : 252°–306° (bal oldal)
 *   C2           : 306°–360° (bal felső ív)
 * A cél szöget egyenletesen sorsolja 0–360° között, így minden irány egyforma eséllyel jön ki,
 * akkor is, ha a C1 apró LED-jei sűrűbbek.
 */
class SpinWheel(
    private val glyph: GlyphController,
    private val haptics: Haptics
) {
    private data class Slot(val zone: Int, val from: Float, val to: Float, val name: String)

    private val slots: List<Slot> = buildList {
        val step = 90f / 16
        // C1_16 van felül (0°), C1_1 a jobb szélen (90°)
        val c1 = intArrayOf(
            Glyph.Code_22111.C1_16, Glyph.Code_22111.C1_15, Glyph.Code_22111.C1_14,
            Glyph.Code_22111.C1_13, Glyph.Code_22111.C1_12, Glyph.Code_22111.C1_11,
            Glyph.Code_22111.C1_10, Glyph.Code_22111.C1_9, Glyph.Code_22111.C1_8,
            Glyph.Code_22111.C1_7, Glyph.Code_22111.C1_6, Glyph.Code_22111.C1_5,
            Glyph.Code_22111.C1_4, Glyph.Code_22111.C1_3, Glyph.Code_22111.C1_2,
            Glyph.Code_22111.C1_1
        )
        c1.forEachIndexed { i, z -> add(Slot(z, i * step, (i + 1) * step, "C1_${16 - i}")) }
        add(Slot(Glyph.Code_22111.C6, 90f, 144f, "C6"))
        add(Slot(Glyph.Code_22111.C5, 144f, 198f, "C5"))
        add(Slot(Glyph.Code_22111.C4, 198f, 252f, "C4"))
        add(Slot(Glyph.Code_22111.C3, 252f, 306f, "C3"))
        add(Slot(Glyph.Code_22111.C2, 306f, 360f, "C2"))
    }

    private val ring: IntArray = slots.map { it.zone }.toIntArray()

    private fun norm(a: Float): Float = ((a % 360f) + 360f) % 360f

    private fun slotAt(angle: Float): Int {
        val a = norm(angle)
        val i = slots.indexOfFirst { a >= it.from && a < it.to }
        return if (i >= 0) i else slots.lastIndex
    }

    /** A "mutató": az adott szög körüli ~12°-os sáv LED-jei (a C1-en így 2–3 kis LED ég, nem csak egy). */
    private fun pointer(angle: Float): IntArray =
        listOf(angle - Config.SPIN_POINTER_HALF_WIDTH, angle, angle + Config.SPIN_POINTER_HALF_WIDTH)
            .map { slots[slotAt(it)].zone }
            .distinct()
            .toIntArray()

    /** Lefuttat egy pörgetést, és visszaadja, hol állt meg (pl. "C5"). */
    suspend fun run(): String {
        // Rövid bevezető: a gyűrű egyszer felvillan
        glyph.show(ring)
        delay(200)
        glyph.off()
        delay(250)

        val target = Random.nextFloat() * 360f
        val turns = Random.nextInt(Config.SPIN_MIN_TURNS, Config.SPIN_MAX_TURNS + 1)
        val start = Random.nextFloat() * 360f
        // A teljes elfordulás úgy, hogy pontosan a célnál álljon meg
        val total = turns * 360f + norm(target - start)
        val duration = Random.nextLong(Config.SPIN_MIN_MS, Config.SPIN_MAX_MS + 1)

        val t0 = SystemClock.uptimeMillis()
        var lastSlot = -1
        while (true) {
            val u = ((SystemClock.uptimeMillis() - t0).toFloat() / duration).coerceAtMost(1f)
            // Lassuló mozgás (ease-out): az elején gyors, a végén kúszik
            val eased = 1f - (1f - u).pow(Config.SPIN_EASE_POWER)
            val angle = start + total * eased
            val slot = slotAt(angle)
            if (slot != lastSlot) {
                glyph.show(pointer(angle))
                // A végén kis "kattogó" rezgés, mint egy szerencsekeréken
                if (u > 0.55f) haptics.click()
                lastSlot = slot
            }
            if (u >= 1f) break
            delay(16)
        }

        // Megállt: a kiválasztott hely villog, a telefon rezeg, aztán égve marad
        val final = pointer(start + total)
        val winner = slots[slotAt(start + total)].name
        DebugState.log("A pörgetés itt állt meg: $winner")
        haptics.result()
        repeat(5) {
            glyph.off()
            delay(140)
            glyph.show(final)
            delay(180)
        }
        delay(Config.SPIN_HOLD_MS)
        glyph.off()
        return winner
    }
}
