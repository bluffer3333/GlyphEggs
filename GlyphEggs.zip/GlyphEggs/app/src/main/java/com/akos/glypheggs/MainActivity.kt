package com.akos.glypheggs

import android.Manifest
import android.app.Activity
import android.app.StatusBarManager
import android.content.ComponentName
import android.content.Intent
import android.content.pm.PackageManager
import android.graphics.Typeface
import android.graphics.drawable.Icon
import android.net.Uri
import android.os.Bundle
import android.os.PowerManager
import android.provider.Settings
import android.widget.Button
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView
import kotlinx.coroutines.MainScope
import kotlinx.coroutines.cancel
import kotlinx.coroutines.launch

/** Egyszerű vezérlőképernyő: indítás, leállítás, tesztjáték és élő szenzoradatok. */
class MainActivity : Activity() {

    companion object {
        const val PREFS = "glyph_eggs"
        const val KEY_ENABLED = "enabled"
    }

    private val scope = MainScope()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        val pad = (16 * resources.displayMetrics.density).toInt()
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(pad, pad, pad, pad)
        }

        val status = TextView(this).apply { textSize = 18f; setTypeface(typeface, Typeface.BOLD) }
        val sensor = TextView(this).apply { textSize = 15f; typeface = Typeface.MONOSPACE; setPadding(0, pad, 0, pad) }
        val log = TextView(this).apply { textSize = 13f; typeface = Typeface.MONOSPACE }

        fun section(text: String) = TextView(this).apply {
            this.text = "\n$text"
            textSize = 16f
            setTypeface(typeface, Typeface.BOLD)
        }

        fun button(text: String, onClick: () -> Unit) = Button(this).apply {
            this.text = text
            isAllCaps = false
            setOnClickListener { onClick() }
        }

        root.addView(status)
        root.addView(section("Glyph Simon"))
        root.addView(button("Simon-figyelés bekapcsolása") { startWatching() })
        root.addView(button("Simon-figyelés kikapcsolása") { stopWatching() })
        root.addView(button("Simon indítása most (teszt)") { send(SimonService.ACTION_START_GAME) })
        root.addView(section("Üvegpörgetés"))
        root.addView(button("Pörgetés most (tedd le kijelzővel lefelé)") { send(SimonService.ACTION_SPIN) })
        root.addView(section("Beállítás"))
        root.addView(button("Akkumulátor-optimalizálás kikapcsolása") { askBatteryExemption() })
        root.addView(button("Simon csempe hozzáadása a lehúzható menühöz") {
            addTile(SimonTileService::class.java, "Glyph Simon", R.drawable.ic_tile)
        })
        root.addView(button("Pörgetés csempe hozzáadása a lehúzható menühöz") {
            addTile(SpinTileService::class.java, "Pörgetés", R.drawable.ic_spin)
        })
        root.addView(TextView(this).apply { text = "\nÉlő szenzoradatok"; setTypeface(typeface, Typeface.BOLD) })
        root.addView(sensor)
        root.addView(TextView(this).apply { text = "Napló"; setTypeface(typeface, Typeface.BOLD) })
        root.addView(log)

        setContentView(ScrollView(this).apply { addView(root) })

        scope.launch { DebugState.status.collect { status.text = it } }
        scope.launch { DebugState.sensor.collect { sensor.text = it } }
        scope.launch { DebugState.log.collect { log.text = it.reversed().joinToString("\n") } }

        if (checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED) {
            requestPermissions(arrayOf(Manifest.permission.POST_NOTIFICATIONS), 1)
        }
    }

    private fun startWatching() {
        getSharedPreferences(PREFS, MODE_PRIVATE).edit().putBoolean(KEY_ENABLED, true).apply()
        send(SimonService.ACTION_WATCH_ON)
    }

    /** Csak a figyelést kapcsolja ki; egy épp futó pörgetést nem szakít meg. */
    private fun stopWatching() {
        getSharedPreferences(PREFS, MODE_PRIVATE).edit().putBoolean(KEY_ENABLED, false).apply()
        if (SimonService.watching) {
            startService(Intent(this, SimonService::class.java).setAction(SimonService.ACTION_WATCH_OFF))
        }
    }

    private fun askBatteryExemption() {
        val pm = getSystemService(PowerManager::class.java)
        if (pm.isIgnoringBatteryOptimizations(packageName)) {
            DebugState.log("Az akkumulátor-optimalizálás már ki van kapcsolva")
            return
        }
        startActivity(
            Intent(Settings.ACTION_REQUEST_IGNORE_BATTERY_OPTIMIZATIONS, Uri.parse("package:$packageName"))
        )
    }

    private fun send(action: String) {
        startForegroundService(Intent(this, SimonService::class.java).setAction(action))
    }

    private fun addTile(cls: Class<*>, label: String, icon: Int) {
        getSystemService(StatusBarManager::class.java).requestAddTileService(
            ComponentName(this, cls),
            label,
            Icon.createWithResource(this, icon),
            mainExecutor
        ) { result -> DebugState.log("$label csempe hozzáadása: $result") }
    }

    override fun onDestroy() {
        scope.cancel()
        super.onDestroy()
    }
}
