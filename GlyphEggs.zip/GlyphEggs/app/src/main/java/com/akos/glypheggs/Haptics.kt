package com.akos.glypheggs

import android.content.Context
import android.os.VibrationEffect
import android.os.VibratorManager

/** Rezgések: indító jelzés, győzelem, pörgetés kattogása és eredménye. */
class Haptics(context: Context) {
    private val vibrator = context.getSystemService(VibratorManager::class.java).defaultVibrator

    fun tick() {
        vibrator.vibrate(VibrationEffect.createOneShot(80, VibrationEffect.DEFAULT_AMPLITUDE))
    }

    /** Nagyon rövid kattanás a pörgetés lassuló szakaszában. */
    fun click() {
        vibrator.vibrate(VibrationEffect.createPredefined(VibrationEffect.EFFECT_TICK))
    }

    /** A pörgetés megállt. */
    fun result() {
        vibrator.vibrate(VibrationEffect.createWaveform(longArrayOf(0, 120, 80, 120, 80, 400), -1))
    }

    /** Kb. 8 másodperces győzelmi rezgés: lüktető ütemek, a végén egy hosszú. */
    fun win() {
        val pattern = mutableListOf(0L)
        repeat(13) { pattern += listOf(400L, 150L) }
        pattern += 900L
        vibrator.vibrate(VibrationEffect.createWaveform(pattern.toLongArray(), -1))
    }
}
