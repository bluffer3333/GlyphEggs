package com.akos.glypheggs

import android.content.Context
import android.content.Intent
import android.service.quicksettings.Tile
import android.service.quicksettings.TileService

/**
 * "Glyph Simon" csempe a lehúzható menüben:
 * egy koppintással be- és kikapcsolja a Simon indító mozdulat figyelését.
 */
class SimonTileService : TileService() {

    override fun onStartListening() {
        super.onStartListening()
        show(SimonService.watching)
    }

    override fun onClick() {
        super.onClick()
        val turnOn = !SimonService.watching
        getSharedPreferences(MainActivity.PREFS, Context.MODE_PRIVATE)
            .edit().putBoolean(MainActivity.KEY_ENABLED, turnOn).apply()

        val action = if (turnOn) SimonService.ACTION_WATCH_ON else SimonService.ACTION_WATCH_OFF
        if (turnOn) {
            if (!TileStarter.startService(this, action)) return
        } else {
            // Kikapcsolásnál csak akkor szólunk, ha fut
            try {
                startService(Intent(this, SimonService::class.java).setAction(action))
            } catch (_: Exception) {
            }
        }
        show(turnOn)
    }

    private fun show(on: Boolean) {
        val tile = qsTile ?: return
        tile.state = if (on) Tile.STATE_ACTIVE else Tile.STATE_INACTIVE
        tile.subtitle = if (on) "Figyel" else "Ki"
        tile.updateTile()
    }
}
