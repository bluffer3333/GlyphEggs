package com.akos.glypheggs

import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent

/** Újraindítás után automatikusan elindítja a figyelést, ha be volt kapcsolva. */
class BootReceiver : BroadcastReceiver() {
    override fun onReceive(context: Context, intent: Intent) {
        if (intent.action != Intent.ACTION_BOOT_COMPLETED) return
        val enabled = context.getSharedPreferences(MainActivity.PREFS, Context.MODE_PRIVATE)
            .getBoolean(MainActivity.KEY_ENABLED, false)
        if (enabled) {
            context.startForegroundService(
                Intent(context, SimonService::class.java).setAction(SimonService.ACTION_WATCH_ON)
            )
        }
    }
}
