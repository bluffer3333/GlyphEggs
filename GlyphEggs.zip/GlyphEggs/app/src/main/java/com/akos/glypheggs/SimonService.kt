package com.akos.glypheggs

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.Service
import android.content.ComponentName
import android.content.Intent
import android.content.pm.ServiceInfo
import android.graphics.drawable.Icon
import android.os.IBinder
import android.service.quicksettings.TileService
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.cancel
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.first
import kotlinx.coroutines.launch
import kotlinx.coroutines.withTimeoutOrNull

/**
 * Előtérszolgáltatás (állandó értesítéssel), ez vezérli a LED-eket mindkét játéknál:
 *  - Simon: ha a figyelés be van kapcsolva, az indító mozdulatra (2x jobbra forgatás) indul.
 *  - Pörgetés: a csempéről vagy az appból indul; megvárja, hogy kijelzővel lefelé letedd.
 * Ha a figyelés ki van kapcsolva, a szolgáltatás csak a pörgetés idejére fut, utána leáll.
 */
class SimonService : Service() {

    companion object {
        const val ACTION_WATCH_ON = "com.akos.glypheggs.WATCH_ON"
        const val ACTION_WATCH_OFF = "com.akos.glypheggs.WATCH_OFF"
        const val ACTION_START_GAME = "com.akos.glypheggs.START_GAME"
        const val ACTION_SPIN = "com.akos.glypheggs.SPIN"
        const val ACTION_STOP = "com.akos.glypheggs.STOP"
        private const val CHANNEL_ID = "glyph_eggs"
        private const val NOTIF_ID = 1

        /** Be van-e kapcsolva a Simon-figyelés (a csempe ebből mutatja az állapotot). */
        @Volatile
        var watching = false
            private set

        private const val WATCH_TEXT = "Simon figyel – kijelzővel lefelé forgasd 2x jobbra"
        private const val IDLE_TEXT = "Készenlét"
    }

    private val scope = CoroutineScope(SupervisorJob() + Dispatchers.Default)
    private lateinit var glyph: GlyphController
    private lateinit var motion: MotionDetector
    private lateinit var haptics: Haptics
    private var job: Job? = null

    override fun onCreate() {
        super.onCreate()
        createChannel()
        startForeground(NOTIF_ID, buildNotification(IDLE_TEXT), ServiceInfo.FOREGROUND_SERVICE_TYPE_SPECIAL_USE)

        haptics = Haptics(this)
        glyph = GlyphController(this).also { it.init() }
        motion = MotionDetector(this) {
            haptics.tick()
            startGame()
        }.also { it.start() }
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        when (intent?.action) {
            // Rendszer általi újraindításnál (null) a mentett beállítás dönt
            null -> setWatching(
                getSharedPreferences(MainActivity.PREFS, MODE_PRIVATE).getBoolean(MainActivity.KEY_ENABLED, false)
            )
            ACTION_WATCH_ON -> setWatching(true)
            ACTION_WATCH_OFF -> setWatching(false)
            ACTION_START_GAME -> startGame()
            ACTION_SPIN -> startSpin()
            ACTION_STOP -> {
                setWatching(false)
                getSharedPreferences(MainActivity.PREFS, MODE_PRIVATE).edit()
                    .putBoolean(MainActivity.KEY_ENABLED, false).apply()
                job?.cancel()
                stopSelf()
                return START_NOT_STICKY
            }
        }
        return START_STICKY
    }

    private fun setWatching(on: Boolean) {
        watching = on
        motion.setWatching(on)
        refreshTiles()
        DebugState.log(if (on) "Simon-figyelés bekapcsolva" else "Simon-figyelés kikapcsolva")
        if (job?.isActive != true) {
            showIdle()
            if (!on) stopSelf()
        }
    }

    private fun showIdle() {
        val text = if (watching) WATCH_TEXT else IDLE_TEXT
        DebugState.status.value = text
        updateNotification(text)
    }

    /** Közös keret: Glyph session megnyitása, a feladat futtatása, utána takarítás. */
    private fun launchWithGlyph(status: String, block: suspend () -> Unit) {
        if (job?.isActive == true) {
            DebugState.log("Már fut egy játék, előbb az fejeződjön be")
            return
        }
        job = scope.launch {
            try {
                // Közvetlenül indulás után a Glyph szolgáltatásnak kell egy kis idő
                withTimeoutOrNull(3_000) { while (!glyph.connected) delay(100) }
                if (!glyph.openSession()) {
                    DebugState.log("Nem sikerült megnyitni a Glyph sessiont")
                    return@launch
                }
                DebugState.status.value = status
                updateNotification(status)
                block()
            } finally {
                glyph.closeSession()
                motion.setGameMode(false)
                showIdle()
                if (!watching) stopSelf()
            }
        }
    }

    private fun startGame() = launchWithGlyph("Simon játék folyamatban") {
        motion.setGameMode(true)
        val level = SimonGame(glyph, motion, haptics).run()
        DebugState.log("Játék vége – elért szint: $level/${Config.MAX_ROUNDS}")
    }

    private fun startSpin() = launchWithGlyph("Pörgetés") {
        if (!motion.faceDown.value) {
            DebugState.status.value = "Tedd le kijelzővel lefelé a pörgetéshez"
            updateNotification("Tedd le kijelzővel lefelé a pörgetéshez")
            val placed = withTimeoutOrNull(Config.SPIN_PLACE_TIMEOUT_MS) { motion.faceDown.first { it } }
            if (placed == null) DebugState.log("Nem tetted le – pörgetés így is indul")
            delay(Config.SPIN_SETTLE_MS)
        }
        DebugState.status.value = "Pörgetés"
        updateNotification("Pörgetés")
        motion.setGameMode(true) // ébren tartja a telefont, és szünetelteti a Simon-figyelést
        SpinWheel(glyph, haptics).run()
    }

    override fun onDestroy() {
        scope.cancel()
        motion.stop()
        glyph.release()
        watching = false
        refreshTiles()
        DebugState.status.value = "Leállítva"
        DebugState.log("Szolgáltatás leállt")
        super.onDestroy()
    }

    override fun onBind(intent: Intent?): IBinder? = null

    private fun refreshTiles() {
        TileService.requestListeningState(this, ComponentName(this, SimonTileService::class.java))
    }

    private fun createChannel() {
        val channel = NotificationChannel(CHANNEL_ID, "Glyph Eggs", NotificationManager.IMPORTANCE_LOW)
        getSystemService(NotificationManager::class.java).createNotificationChannel(channel)
    }

    private fun buildNotification(text: String): Notification {
        val open = PendingIntent.getActivity(
            this, 0, Intent(this, MainActivity::class.java),
            PendingIntent.FLAG_IMMUTABLE
        )
        val stop = PendingIntent.getService(
            this, 1, Intent(this, SimonService::class.java).setAction(ACTION_STOP),
            PendingIntent.FLAG_IMMUTABLE
        )
        return Notification.Builder(this, CHANNEL_ID)
            .setSmallIcon(R.drawable.ic_tile)
            .setContentTitle("Glyph Eggs")
            .setContentText(text)
            .setOngoing(true)
            .setContentIntent(open)
            .addAction(Notification.Action.Builder(null as Icon?, "Leállítás", stop).build())
            .build()
    }

    private fun updateNotification(text: String) {
        getSystemService(NotificationManager::class.java).notify(NOTIF_ID, buildNotification(text))
    }
}
