package com.akos.glypheggs

import android.service.quicksettings.Tile
import android.service.quicksettings.TileService

/**
 * Közös csempe egy funkcióhoz: koppintásra elindul, ha fut, újabb koppintásra leáll.
 * A csempe világít, amíg a funkció fut.
 */
abstract class FeatureTileService(
    private val feature: Feature,
    private val idleSubtitle: String
) : TileService() {

    override fun onStartListening() {
        super.onStartListening()
        val tile = qsTile ?: return
        val running = GlyphMirror.mode.value == feature
        tile.state = if (running) Tile.STATE_ACTIVE else Tile.STATE_INACTIVE
        tile.subtitle = if (running) "Fut – koppints a leállításhoz" else idleSubtitle
        tile.updateTile()
    }

    override fun onClick() {
        super.onClick()
        TileStarter.startService(this, SimonService.actionFor(feature))
    }
}

/** "Zárfeltörő" csempe. */
class LockTileService : FeatureTileService(Feature.LOCKPICK, "Tedd le, kopogj")

/** "Széf" csempe. */
class SafeTileService : FeatureTileService(Feature.SAFE, "Rázd be a kódot")

/** "Glyph Tojás" csempe. */
class PetTileService : FeatureTileService(Feature.PET, "Gondozás a LED-eken")

/** "Vízmérték" csempe. */
class LevelTileService : FeatureTileService(Feature.LEVEL, "Fektesd le a felületre")

/** "Időzítő" csempe. */
class TimerTileService : FeatureTileService(Feature.TIMER, "Fókusz a LED-eken")

/** "Egyensúly" csempe. */
class BalanceTileService : FeatureTileService(Feature.BALANCE, "Dönts, ne essen le")
