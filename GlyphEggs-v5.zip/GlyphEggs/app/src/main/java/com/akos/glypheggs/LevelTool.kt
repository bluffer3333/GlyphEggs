package com.akos.glypheggs

import android.content.Context
import android.os.SystemClock
import com.nothing.ketchum.Glyph
import kotlinx.coroutines.channels.Channel
import kotlinx.coroutines.coroutineScope
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.merge
import kotlinx.coroutines.launch
import kotlin.math.abs
import kotlin.math.atan2
import kotlin.math.max
import kotlin.math.roundToInt

/**
 * Vízmérték a hátlapon. Tedd a telefont kijelzővel lefelé a felületre.
 *
 *  - Bal–jobb irány: ha nem vízszintes, a MAGASABB oldal ég (mint a buborék):
 *    bal (C2, C3) vagy jobb (C5, C6). Ha vízszintes: MINDKÉT oldal egyszerre ég.
 *  - Előre–hátra irány: ugyanígy a kamera felőli rész (A1, A2, B1) vagy a vonal + pont (D1, E1);
 *    vízszintesnél mindkettő ég.
 *  - A felső sáv (C1) mutatja, mennyire tér el: LED-enként 0,5°.
 *  - Ha mindkét irányban vízszintes: minden LED felvillan, és kis rezgés jelzi.
 *  - 2 kopogás: a mostani helyzet legyen a "nulla" (kalibrálás). 3 kopogás: kalibrálás törlése.
 * Felemelés után 5 mp-cel kikapcsol.
 */
class LevelTool(
    private val context: Context,
    private val glyph: GlyphController,
    private val motion: MotionDetector,
    private val haptics: Haptics,
    private val onStatus: (String) -> Unit
) {
    private val left = intArrayOf(Glyph.Code_22111.C2, Glyph.Code_22111.C3)
    private val right = intArrayOf(Glyph.Code_22111.C5, Glyph.Code_22111.C6)
    private val front = intArrayOf(Glyph.Code_22111.A1, Glyph.Code_22111.A2, Glyph.Code_22111.B1)
    private val back = intArrayOf(
        Glyph.Code_22111.D1_1, Glyph.Code_22111.D1_2, Glyph.Code_22111.D1_3, Glyph.Code_22111.D1_4,
        Glyph.Code_22111.D1_5, Glyph.Code_22111.D1_6, Glyph.Code_22111.D1_7, Glyph.Code_22111.D1_8,
        Glyph.Code_22111.E1
    )
    private val bar: IntArray = IntArray(16) { Zones.LEVEL[15 - it] }

    suspend fun run() = coroutineScope {
        val knocks = Channel<Long>(16)
        val collector = launch { merge(motion.knockEvents, GlyphMirror.taps).collect { knocks.trySend(it) } }
        try {
            loop(knocks)
        } finally {
            collector.cancel()
            glyph.off()
        }
    }

    private fun angles(): Pair<Float, Float> {
        val g = motion.gravity()
        val z = max(abs(g[2]), 0.1f)
        val ax = Math.toDegrees(atan2(g[0].toDouble(), z.toDouble())).toFloat()
        val ay = Math.toDegrees(atan2(g[1].toDouble(), z.toDouble())).toFloat()
        return ax to ay
    }

    private suspend fun loop(knocks: Channel<Long>) {
        // Bevezető
        glyph.show(left + right)
        delay(200)
        glyph.show(front + back)
        delay(200)
        glyph.off()

        var sx = 0f
        var sy = 0f
        var first = true
        var wasLevel = false
        var liftedSince = 0L
        var knockCount = 0
        var lastKnock = 0L
        var lastStatus = 0L
        var frame = 0

        while (true) {
            val now = SystemClock.elapsedRealtime()
            if (motion.faceDown.value) liftedSince = 0L
            else if (liftedSince == 0L) liftedSince = now
            else if (now - liftedSince > Config.COMPASS_LIFT_GRACE_MS) break

            // Simítás: a vízmértéknek nyugodt kijelzés kell
            val (rx, ry) = angles()
            if (first) { sx = rx; sy = ry; first = false } else { sx = 0.85f * sx + 0.15f * rx; sy = 0.85f * sy + 0.15f * ry }
            val x = sx - Settings.levelOffsetX(context)
            val y = sy - Settings.levelOffsetY(context)

            // Kopogás: kalibrálás
            while (true) {
                knocks.tryReceive().getOrNull() ?: break
                knockCount++
                lastKnock = now
            }
            if (knockCount > 0 && now - lastKnock > Config.PET_KNOCK_GROUP_MS) {
                when (knockCount) {
                    2 -> {
                        Settings.setLevelOffset(context, sx, sy)
                        DebugState.log("Vízmérték: kalibrálva (ez a nulla)")
                        haptics.result()
                        repeat(2) { glyph.show(Zones.ALL); delay(120); glyph.off(); delay(120) }
                    }
                    3 -> {
                        Settings.setLevelOffset(context, 0f, 0f)
                        DebugState.log("Vízmérték: kalibrálás törölve")
                        haptics.tick()
                    }
                }
                knockCount = 0
            }

            val tol = Config.LEVEL_TOLERANCE_DEG
            val levelX = abs(x) < tol
            val levelY = abs(y) < tol
            val lit = mutableListOf<Int>()
            // A tengelyek a telefonhoz kötöttek: x < 0 → a kamera felőli (bal) oldal van lejjebb
            lit += if (levelX) (left + right).toList() else if (x < 0) right.toList() else left.toList()
            lit += if (levelY) (front + back).toList() else if (y < 0) back.toList() else front.toList()

            val both = levelX && levelY
            if (both) {
                if (!wasLevel) haptics.level()
                glyph.show(Zones.ALL)
            } else {
                val dev = max(abs(x), abs(y))
                val n = (dev / Config.LEVEL_DEG_PER_LED).roundToInt().coerceIn(1, 16)
                lit += bar.take(n)
                // Közel a vízszinteshez (1° alatt) a sáv vége pislog, hogy lásd a finomhangolást
                if (dev < 1f && frame % 4 < 2) lit.remove(bar[n - 1])
                glyph.show(lit.distinct().toIntArray())
            }
            wasLevel = both

            if (now - lastStatus > 400) {
                lastStatus = now
                onStatus(if (both) "Vízmérték – VÍZSZINTES" else "Vízmérték – bal/jobb %.1f°, előre/hátra %.1f°".format(x, y))
            }
            frame++
            delay(50)
        }
    }
}
