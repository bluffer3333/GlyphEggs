package com.akos.glypheggs

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.content.Context
import android.content.Intent
import android.graphics.Canvas
import android.graphics.ColorFilter
import android.graphics.LinearGradient
import android.graphics.Paint
import android.graphics.Path
import android.graphics.PixelFormat
import android.graphics.RadialGradient
import android.graphics.Shader
import android.graphics.drawable.Drawable

/*
 * Titkos neon témák. Kitűzőkkel oldódnak fel, sorban; az első után megjelenik a titkos menü
 * (Stat fül és Beállítások). Titkos gomb: a Főoldalon a hátlap képét 10 mp-ig nyomva tartva mind feloldódik.
 */
enum class NeonTheme(
    val title: String,
    val desc: String,
    val top: Int, val bottom: Int,
    val card: Int, val line: Int,
    val a: Int, val b: Int,
    val text: Int, val sub: Int, val unlit: Int,
    val deco: String,
    /** Ennyi kitűző kell a feloldáshoz. */
    val badges: Int
) {
    NIGHT_CITY("Night City", "Cyberpunk · magenta × cián", 0xFF2A0840.toInt(), 0xFF05000B.toInt(),
        0xE6140626.toInt(), 0xFF3A1E5A.toInt(), 0xFFFF2BD6.toInt(), 0xFF00F0FF.toInt(), 0xFFFBE9FF.toInt(), 0xFFB48AD0.toInt(), 0xFF2A1840.toInt(), "scan", 6),
    SYNTHWAVE("Synthwave", "80-as évek naplemente", 0xFF120428.toInt(), 0xFFFF6A5C.toInt(),
        0xD9180630.toInt(), 0xFF4A2370.toInt(), 0xFFFF6AC1.toInt(), 0xFFFFD36C.toInt(), 0xFFFFF2FB.toInt(), 0xFFD8A6E8.toInt(), 0xFF3B1A5C.toInt(), "grid", 8),
    TOXIC("Toxic", "Savzöld · radioaktív", 0xFF13240A.toInt(), 0xFF020302.toInt(),
        0xE60A1208.toInt(), 0xFF24361A.toInt(), 0xFFB6FF00.toInt(), 0xFFE8FF6A.toInt(), 0xFFEFFFD6.toInt(), 0xFF8FAE6A.toInt(), 0xFF1D2A14.toInt(), "hazard", 10),
    GRID_RUNNER("Grid Runner", "Tron-kék · lézerrács", 0xFF01040A.toInt(), 0xFF031226.toInt(),
        0xE6020E1E.toInt(), 0xFF0E2C44.toInt(), 0xFF00D9FF.toInt(), 0xFFFF9A1F.toInt(), 0xFFE3F8FF.toInt(), 0xFF6FA6C4.toInt(), 0xFF0D2236.toInt(), "tron", 12),
    ULTRAVIOLET("Ultraviolet", "Nothing-piros × UV-lila", 0xFF2A0A4A.toInt(), 0xFF050309.toInt(),
        0xE6120820.toInt(), 0xFF2E1D48.toInt(), 0xFFFF1F3D.toInt(), 0xFF9D5CFF.toInt(), 0xFFF6EEFF.toInt(), 0xFFA58BC9.toInt(), 0xFF24183A.toInt(), "uv", 14),
    VAPORWAVE("Vaporwave", "Pasztell neon · menta × rózsa", 0xFF2B1B4D.toInt(), 0xFF1F5B6B.toInt(),
        0xCC281846.toInt(), 0xFF5A4580.toInt(), 0xFFFF9CE3.toInt(), 0xFF7DFCD9.toInt(), 0xFFFFF6FD.toInt(), 0xFFCBB5E6.toInt(), 0xFF4A3A6C.toInt(), "sun", 16),
    ARCADE("Arcade RGB", "Szivárvány · játékterem", 0xFF1A1A1A.toInt(), 0xFF060606.toInt(),
        0xF0101010.toInt(), 0xFF2A2A2A.toInt(), 0xFFFF3B3B.toInt(), 0xFF3BFF8A.toInt(), 0xFFFFFFFF.toInt(), 0xFF9A9A9A.toInt(), 0xFF222222.toInt(), "rgb", 19),
    /** Glyph Focus-jutalom: mind az 5 Focus-kitűző kell hozzá (nem a kitűzők száma). */
    ZEN("Zen", "Minimalista · tus, papír és moha", 0xFF19191C.toInt(), 0xFF0E0E10.toInt(),
        0xF21C1C20.toInt(), 0xFF2E2E33.toInt(), 0xFFA3B18A.toInt(), 0xFFE9E4D8.toInt(), 0xFFE9E4D8.toInt(), 0xFF8C887D.toInt(), 0xFF2A2A2E.toInt(),
        "zen", -2),
    /** Morze-jutalom: mind az 5 Morze-kitűző kell hozzá. Borostyán képcső, pont-vonás minta. */
    TELEGRAPH("Távíró", "Borostyán képcső · pont-vonás minta", 0xFF140D06.toInt(), 0xFF050302.toInt(),
        0xEB140E08.toInt(), 0xFF3A2A14.toInt(), 0xFFFFB000.toInt(), 0xFFFF6A00.toInt(), 0xFFFFE2A8.toInt(), 0xFFB08A50.toInt(), 0xFF2A1E10.toInt(),
        "morse", -3),
    /** Ritka: 25 kitűző. Technoparti – forgó hipnotikus spirál, ütemre lüktető, billegő felület. */
    HYPNO("Hypno Rave", "Technoparti · forgó spirál, ütemre lüktet minden", 0xFF0A0014.toInt(), 0xFF000000.toInt(),
        0xD90A0018.toInt(), 0xFF3A1A5A.toInt(), 0xFFFF00E5.toInt(), 0xFF00FFF0.toInt(), 0xFFFFFFFF.toInt(), 0xFFC8B6FF.toInt(), 0xFF2A1A40.toInt(),
        "hypno", 25),
    /** Ritka: 30 kitűző. Nyugtalanító – suttogások, szemek és árnyak a látótér szélén, megváltozó betűk. */
    WHISPER("Suttogás", "Nyugtalanító · valami figyel a látótered szélén", 0xFF101012.toInt(), 0xFF050506.toInt(),
        0xE0101012.toInt(), 0xFF2A2A30.toInt(), 0xFFD8D2C4.toInt(), 0xFF8A1C1C.toInt(), 0xFFD9D6CF.toInt(), 0xFF7C7A75.toInt(), 0xFF222226.toInt(),
        "whisper", 30),
    /** Rave: stroboszkóp, lézerek, 150 BPM – ERŐS VILLOGÁS (bekapcsoláskor figyelmeztet). 15 kitűző. */
    RAVE("Strobe Rave", "Stroboszkóp · lézerek · 150 BPM · ⚠️ erős villogás", 0xFF000000.toInt(), 0xFF000000.toInt(),
        0xCC05000A.toInt(), 0xFF00FF66.toInt(), 0xFF00FF66.toInt(), 0xFFFF00CC.toInt(), 0xFFFFFFFF.toInt(), 0xFFCFCFCF.toInt(), 0xFF202020.toInt(),
        "rave", 15),
    /** Halloween: brutális horror – lüktető vér, tekergő csápok, véreres szemgolyók. Halloweenkor szabad, máskor 20 kitűző. */
    HALLOWEEN("Halloween", "Horror · csápok, véreres szemek, csöpögő vér", 0xFF1A0000.toInt(), 0xFF000000.toInt(),
        0xE0100002.toInt(), 0xFF4A0008.toInt(), 0xFFFF1A1A.toInt(), 0xFFB3001B.toInt(), 0xFFFFE6E6.toInt(), 0xFFB07070.toInt(), 0xFF2A0A0A.toInt(),
        "halloween", 20),
    /** Az utolsó, legnehezebb: MINDEN kitűző kell hozzá. Sérült textúrák, szakadó képernyő, RGB-csúszás. */
    GLITCH("C0RRUPTED", "Glitch · sérült textúrák · a legritkább", 0xFF101014.toInt(), 0xFF050507.toInt(),
        0xE6101014.toInt(), 0xFF26262E.toInt(), 0xFF00FFD5.toInt(), 0xFFFF0040.toInt(), 0xFFE8E8E8.toInt(), 0xFF8A8A99.toInt(), 0xFF22222A.toInt(),
        "glitch", -1);

    val rainbow: Boolean get() = this == ARCADE
    val glitch: Boolean get() = this == GLITCH
    val zen: Boolean get() = this == ZEN
    val hypno: Boolean get() = this == HYPNO
    val whisper: Boolean get() = this == WHISPER
    val halloween: Boolean get() = this == HALLOWEEN
    val rave: Boolean get() = this == RAVE
    /** Külön jutalom-téma: a feltétele egy kitűzőcsoport (nem a kitűzők száma). */
    val reward: List<Badge>? get() = when (this) { ZEN -> DETOX_BADGES; TELEGRAPH -> MORSE_BADGES; else -> null }
    /** Hány kitűző kell (a C0RRUPTED-hez mind, bármennyi is van). */
    val need: Int get() = if (badges == -1) Badge.entries.size else reward?.size ?: badges
}

/** A Távíró témához szükséges Morze-kitűzők. */
val MORSE_BADGES = listOf(Badge.MORSE_FIRST, Badge.MORSE_FAST, Badge.MORSE_25, Badge.MORSE_STREAK, Badge.MORSE_100)

/** A Zen témához szükséges Focus-kitűzők. */
val DETOX_BADGES = listOf(Badge.DETOX_FIRST, Badge.DETOX_60, Badge.DETOX_GOALS, Badge.DETOX_3H, Badge.DETOX_10H)

val RAINBOW = intArrayOf(0xFFFF3B3B.toInt(), 0xFFFF9F1A.toInt(), 0xFFFFE11A.toInt(), 0xFF3BFF8A.toInt(),
    0xFF1AD9FF.toInt(), 0xFF5B6BFF.toInt(), 0xFFD23BFF.toInt())

object NeonThemes {
    private const val CHANNEL = "glyph_eggs_badges"

    /** Feloldva-e: elég kitűző, vagy a titkos gomb mindet feloldotta. */
    fun unlocked(c: Context, t: NeonTheme): Boolean =
        Settings.neonCheat(c) || (Achievements.unlocked(c).size >= MENU_AT && (have(c, t) >= t.need || (t == NeonTheme.HALLOWEEN && halloweenSeason())))

    /** Halloween-időszak: október 20. – november 3. (ilyenkor a Halloween téma kitűzők nélkül is szabad). */
    fun halloweenSeason(): Boolean {
        val d = java.time.LocalDate.now()
        return (d.monthValue == 10 && d.dayOfMonth >= 20) || (d.monthValue == 11 && d.dayOfMonth <= 3)
    }

    /** Ennyi kitűző után nyílik meg a titkos menü (és az első téma). */
    const val MENU_AT = 6

    /** Hány megvan a feltételből (a Zen-nél a Focus-kitűzők, máshol az összes kitűző). */
    fun have(c: Context, t: NeonTheme): Int =
        t.reward?.count { Achievements.isUnlocked(c, it) } ?: Achievements.unlocked(c).size

    /** Zárt téma felirata. */
    fun lockText(c: Context, t: NeonTheme): String =
        if (t.zen) "🔒 Mind az 5 Focus-kitűző kell · most: ${have(c, t)}"
        else if (t == NeonTheme.TELEGRAPH) "🔒 Mind az 5 Morze-kitűző kell · most: ${have(c, t)}"
        else if (t == NeonTheme.HALLOWEEN) "🎃 Okt. 20 – nov. 3. között szabad, máskor ${t.need} kitűző · most: ${have(c, t)}"
        else "🔒 ${t.need} kitűző kell · most: ${have(c, t)}"

    fun unlockedList(c: Context) = NeonTheme.entries.filter { unlocked(c, it) }

    /** Látszik-e már a titkos menü. */
    fun menuVisible(c: Context) = unlockedList(c).isNotEmpty()

    fun current(c: Context): NeonTheme? =
        NeonTheme.entries.firstOrNull { it.name == Settings.neonTheme(c) }?.takeIf { unlocked(c, it) }

    /** Új kitűző után: ha új téma oldódott fel, értesít (egyszer). */
    fun checkNew(c: Context) {
        val list = unlockedList(c)
        val n = list.size
        val seen = Settings.themesSeen(c)
        if (n <= seen) return
        Settings.setThemesSeen(c, n)
        val known = Settings.themesKnown(c)
        val t = list.firstOrNull { it.name !in known } ?: list.last()
        Settings.setThemesKnown(c, list.map { it.name }.toSet())
        if (!Settings.notifBadges(c)) return
        try {
            val nm = c.getSystemService(NotificationManager::class.java)
            nm.createNotificationChannel(NotificationChannel(CHANNEL, "Kitűzők", NotificationManager.IMPORTANCE_DEFAULT))
            val open = PendingIntent.getActivity(c, 5300, Intent(c, NeonActivity::class.java).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK),
                PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT)
            nm.notify(5300, Notification.Builder(c, CHANNEL)
                .setSmallIcon(R.drawable.ic_trophy)
                .setContentTitle(if (seen == 0) "🔓 Titkos menü feloldva!" else "🔓 Új neon téma: ${t.title}")
                .setContentText(if (seen == 0) "Első neon témád: ${t.title}. Stat fül → Titkos menü" else t.desc)
                .setContentIntent(open)
                .setAutoCancel(true)
                .build())
        } catch (e: Throwable) { }
    }
}

/**
 * A neon háttér: színátmenet + a téma díszítése (rács a horizonton, képcső-csíkok, figyelmeztető csík,
 * napkorong, UV-derengés). A görgetett tartalom mögött áll.
 */
class NeonBackground(private val t: NeonTheme) : Drawable() {
    private val p = Paint(Paint.ANTI_ALIAS_FLAG)
    /** Lekerekítés (kártyákon); 0 = teljes oldal. */
    var radius = 0f
    private val clip = Path()

    override fun draw(canvas: Canvas) {
        val w = bounds.width().toFloat()
        val h = bounds.height().toFloat()
        canvas.save()
        canvas.translate(bounds.left.toFloat(), bounds.top.toFloat())
        if (radius > 0f) {
            clip.reset()
            clip.addRoundRect(android.graphics.RectF(0f, 0f, w, h), radius, radius, Path.Direction.CW)
            canvas.clipPath(clip)
        }
        paint(canvas, w, h)
        canvas.restore()
    }

    private fun paint(canvas: Canvas, w: Float, h: Float) {
        p.shader = LinearGradient(0f, 0f, 0f, h, t.top, t.bottom, Shader.TileMode.CLAMP)
        canvas.drawRect(0f, 0f, w, h, p)
        p.shader = null
        if (t.deco == "glitch") { GlitchFx.paintBackground(canvas, w, h, t); return }
        if (t.deco == "hypno") { HypnoFx.paintBackground(canvas, w, h); return }
        if (t.deco == "whisper") { WhisperFx.paintBackground(canvas, w, h); return }
        if (t.deco == "halloween") { HorrorFx.paintBackground(canvas, w, h); return }
        if (t.deco == "rave") { RaveFx.paintBackground(canvas, w, h); return }
        when (t.deco) {
            "scan", "rgb" -> {
                // Képcső-csíkozás + két színes derengés
                p.shader = RadialGradient(w * 0.85f, 0f, w * 0.9f, (t.a and 0xFFFFFF) or 0x40000000, 0, Shader.TileMode.CLAMP)
                canvas.drawRect(0f, 0f, w, h, p)
                p.shader = RadialGradient(w * 0.1f, h * 0.85f, w * 0.8f, (t.b and 0xFFFFFF) or 0x26000000, 0, Shader.TileMode.CLAMP)
                canvas.drawRect(0f, 0f, w, h, p)
                p.shader = null
                p.color = 0x0AFFFFFF
                var y = 0f
                while (y < h) { canvas.drawRect(0f, y, w, y + 2f, p); y += 6f }
            }
            "grid", "tron" -> {
                // Napkorong (synthwave) és perspektivikus rács a képernyő alján
                if (t.deco == "grid") {
                    p.shader = RadialGradient(w / 2, h * 0.72f, w * 0.45f, 0x66FFD36C, 0, Shader.TileMode.CLAMP)
                    canvas.drawRect(0f, 0f, w, h, p)
                    p.shader = null
                }
                p.color = (t.a and 0xFFFFFF) or 0x66000000
                p.strokeWidth = 2.5f
                val horizon = h * 0.70f
                val cx = w / 2
                for (i in -12..12) canvas.drawLine(cx + i * w * 0.04f, horizon, cx + i * w * 0.45f, h, p)
                var k = 0
                while (k < 14) {
                    val f = k / 14f
                    val y = horizon + (h - horizon) * f * f
                    canvas.drawLine(0f, y, w, y, p)
                    k++
                }
            }
            "hazard" -> {
                p.shader = RadialGradient(w * 0.2f, h * 0.1f, w, (t.a and 0xFFFFFF) or 0x30000000, 0, Shader.TileMode.CLAMP)
                canvas.drawRect(0f, 0f, w, h, p)
                p.shader = null
                // Sárga-fekete csíkok alul
                val sh = 34f
                p.color = t.a
                val path = Path()
                var x = -sh
                while (x < w + sh) {
                    path.reset()
                    path.moveTo(x, h)
                    path.lineTo(x + sh, h - sh)
                    path.lineTo(x + sh * 2, h - sh)
                    path.lineTo(x + sh, h)
                    path.close()
                    canvas.drawPath(path, p)
                    x += sh * 2
                }
            }
            "sun" -> {
                p.shader = RadialGradient(w * 1.05f, h * 0.25f, w * 0.75f, (t.a and 0xFFFFFF) or 0x55000000, 0, Shader.TileMode.CLAMP)
                canvas.drawRect(0f, 0f, w, h, p)
                p.shader = RadialGradient(0f, h, w, (t.b and 0xFFFFFF) or 0x40000000, 0, Shader.TileMode.CLAMP)
                canvas.drawRect(0f, 0f, w, h, p)
                p.shader = null
            }
            "morse" -> {
                // Borostyán képcső: sorokban halvány pont-vonás minta (valódi morzeszavak), csíkozás, sarokárnyék
                val words = listOf("SOS", "GLYPH", "EGGS", "CQ", "NOTHING", "73", "QRV", "HELLO")
                val step = w / 34f
                var row = 0
                var y = step * 2
                while (y < h) {
                    val w0 = words[row % words.size]
                    val strip = MorseCode.strip("$w0 ${words[(row + 3) % words.size]}")
                    var x = -((row * 7) % 13) * step
                    var i = 0
                    p.color = (t.a and 0xFFFFFF) or (if (row % 3 == 0) 0x24000000 else 0x14000000)
                    while (x < w) {
                        if (strip[i % strip.size]) canvas.drawRect(x, y, x + step * 0.8f, y + step * 0.32f, p)
                        x += step; i++
                    }
                    y += step * 2.2f; row++
                }
                p.color = 0x10000000
                var yy = 0f
                while (yy < h) { canvas.drawRect(0f, yy, w, yy + 2f, p); yy += 4f }
                p.shader = RadialGradient(w / 2, h / 2, h * 0.75f, 0x00000000, 0x99000000.toInt(), Shader.TileMode.CLAMP)
                canvas.drawRect(0f, 0f, w, h, p)
                p.shader = null
            }
            "zen" -> {
                // Ensō: egyetlen ecsetvonásos kör, halványan; alul gereblyézett homok hullámai
                val cx = w * 0.62f; val cy = h * 0.30f; val r = w * 0.42f
                p.style = Paint.Style.STROKE
                p.strokeCap = Paint.Cap.ROUND
                val steps = 64
                for (i in 0 until steps) {
                    val a0 = -100.0 + i * (330.0 / steps)
                    val a1 = a0 + 330.0 / steps + 0.8
                    val f = i / steps.toFloat()
                    p.strokeWidth = w * (0.035f * (1f - f) + 0.006f)
                    p.color = (t.text and 0xFFFFFF) or ((0x16 + (0x10 * (1f - f)).toInt()) shl 24)
                    val x0 = cx + r * Math.cos(Math.toRadians(a0)).toFloat(); val y0 = cy + r * Math.sin(Math.toRadians(a0)).toFloat()
                    val x1 = cx + r * Math.cos(Math.toRadians(a1)).toFloat(); val y1 = cy + r * Math.sin(Math.toRadians(a1)).toFloat()
                    canvas.drawLine(x0, y0, x1, y1, p)
                }
                p.strokeWidth = 1.5f
                p.color = (t.a and 0xFFFFFF) or 0x1C000000
                var k = 0
                while (k < 9) {
                    val base = h * 0.80f + k * h * 0.022f
                    val path = Path()
                    path.moveTo(0f, base)
                    var x = 0f
                    while (x <= w) {
                        path.lineTo(x, base + (Math.sin((x / w) * Math.PI * 2 + k * 0.4) * h * 0.006).toFloat())
                        x += w / 40f
                    }
                    canvas.drawPath(path, p)
                    k++
                }
                p.style = Paint.Style.FILL
            }
            "uv" -> {
                p.shader = RadialGradient(w / 2, h, h * 0.45f, (t.b and 0xFFFFFF) or 0x55000000, 0, Shader.TileMode.CLAMP)
                canvas.drawRect(0f, 0f, w, h, p)
                p.shader = null
            }
        }
    }

    override fun setAlpha(alpha: Int) {}
    override fun setColorFilter(colorFilter: ColorFilter?) {}
    @Deprecated("Drawable API")
    override fun getOpacity(): Int = PixelFormat.OPAQUE
}


/**
 * A C0RRUPTED téma „sérülése”. Nyugodt szakaszok és rövid kitörések váltják egymást: kitöréskor
 * a háttéren színes szakadások, pixelblokkok, zaj; a felület kártyái megrándulnak (vízszintes csúszás,
 * villanás), felül egy fedőréteg szakadásvonalakat rajzol. Minden szöveg RGB-csúszott árnyékot kap.
 */
object GlitchFx {
    private val rnd = java.util.Random()
    @Volatile var burst = false
    private var seed = 1L
    private val p = Paint()

    fun paintBackground(canvas: Canvas, w: Float, h: Float, t: NeonTheme) {
        p.shader = LinearGradient(0f, 0f, 0f, h, t.top, t.bottom, Shader.TileMode.CLAMP)
        canvas.drawRect(0f, 0f, w, h, p)
        p.shader = null
        val r = java.util.Random(seed)
        // Állandó finom zaj és képcső-csíkok
        p.color = 0x0DFFFFFF
        var y = 0f
        while (y < h) { canvas.drawRect(0f, y, w, y + 2f, p); y += 5f }
        repeat(if (burst) 260 else 90) {
            p.color = when (r.nextInt(5)) { 0 -> (t.a and 0xFFFFFF) or 0x30000000; 1 -> (t.b and 0xFFFFFF) or 0x30000000; else -> 0x14FFFFFF }
            val x = r.nextFloat() * w; val yy = r.nextFloat() * h; val s = 2f + r.nextInt(5)
            canvas.drawRect(x, yy, x + s, yy + s, p)
        }
        // Sérült blokkok és szakadások (kitöréskor sok, nyugalomban pár halvány)
        val blocks = if (burst) 9 + r.nextInt(8) else 2
        repeat(blocks) {
            val bw = w * (0.1f + r.nextFloat() * 0.6f); val bh = 6f + r.nextFloat() * (if (burst) 90f else 30f)
            val bx = r.nextFloat() * w - bw * 0.2f; val by = r.nextFloat() * h
            val cell = 8f + r.nextInt(10)
            var cx = bx
            while (cx < bx + bw) {
                var cy = by
                while (cy < by + bh) {
                    val k = r.nextInt(6)
                    p.color = when (k) {
                        0 -> (t.a and 0xFFFFFF) or ((if (burst) 0x90 else 0x30) shl 24)
                        1 -> (t.b and 0xFFFFFF) or ((if (burst) 0x90 else 0x30) shl 24)
                        2 -> 0x30FFFFFF
                        else -> 0x00000000
                    }
                    canvas.drawRect(cx, cy, cx + cell, cy + cell, p)
                    cy += cell
                }
                cx += cell
            }
        }
        val lines = if (burst) 6 + r.nextInt(6) else 1
        repeat(lines) {
            p.color = if (r.nextBoolean()) t.a else t.b
            val ly = r.nextFloat() * h
            canvas.drawRect(0f, ly, w, ly + 1f + r.nextInt(3), p)
        }
    }

    /** Új „sérülésminta” (minden kitörés-képkockánál más). */
    fun reshuffle() { seed = rnd.nextLong() }

    /**
     * Rákapcsolja a hatást egy oldalra: a háttér újrarajzolása kitörésekkor, a kártyák megrándítása,
     * és egy fedőréteg a szakadásokhoz. Magától leáll, ha az oldal eltűnik.
     */
    fun attach(activity: android.app.Activity) {
        val content = activity.findViewById<android.view.ViewGroup>(android.R.id.content) ?: return
        val overlay = GlitchOverlay(activity)
        content.addView(overlay, android.view.ViewGroup.LayoutParams(-1, -1))
        val handler = android.os.Handler(android.os.Looper.getMainLooper())
        val shifted = ArrayList<android.view.View>()
        val tick = object : Runnable {
            var framesLeft = 0
            override fun run() {
                if (!overlay.isAttachedToWindow) return
                // Visszaállítás
                for (v in shifted) { v.translationX = 0f; v.alpha = 1f }
                shifted.clear()
                if (overlay.windowVisibility != android.view.View.VISIBLE) {
                    handler.postDelayed(this, 1_000); return
                }
                if (framesLeft == 0 && rnd.nextInt(100) < 22) framesLeft = 2 + rnd.nextInt(5)
                burst = framesLeft > 0
                if (burst) {
                    framesLeft--
                    reshuffle()
                    // Néhány kártya / sor megrándul
                    val pool = ArrayList<android.view.View>()
                    collect(content, pool, 0)
                    repeat(1 + rnd.nextInt(4)) {
                        if (pool.isEmpty()) return@repeat
                        val v = pool[rnd.nextInt(pool.size)]
                        v.translationX = (rnd.nextInt(41) - 20) * activity.resources.displayMetrics.density
                        if (rnd.nextInt(3) == 0) v.alpha = 0.55f + rnd.nextFloat() * 0.3f
                        shifted += v
                    }
                    activity.window.decorView.background?.invalidateSelf()
                    content.getChildAt(0)?.background?.invalidateSelf()
                } else if (rnd.nextInt(6) == 0) {
                    reshuffle()
                    content.getChildAt(0)?.background?.invalidateSelf()
                }
                overlay.invalidate()
                handler.postDelayed(this, if (burst) 55L + rnd.nextInt(60) else 380L + rnd.nextInt(900))
            }
        }
        handler.postDelayed(tick, 800)
    }

    private fun collect(g: android.view.ViewGroup, out: ArrayList<android.view.View>, depth: Int) {
        for (i in 0 until g.childCount) {
            val v = g.getChildAt(i)
            if (v is GlitchOverlay) continue
            if (depth >= 2 && v.height in 30..900) out += v
            if (v is android.view.ViewGroup && depth < 4) collect(v, out, depth + 1)
        }
    }
}

/** Átlátszó fedőréteg: kitöréskor vízszintes szakadásokat és színcsíkokat rajzol a tartalom fölé. */
class GlitchOverlay(context: Context) : android.view.View(context) {
    private val p = Paint()
    private val rnd = java.util.Random()
    override fun onDraw(canvas: Canvas) {
        if (!GlitchFx.burst) return
        val w = width.toFloat()
        val h = height.toFloat()
        repeat(2 + rnd.nextInt(5)) {
            val y = rnd.nextFloat() * h
            val bh = 2f + rnd.nextFloat() * 26f
            p.color = when (rnd.nextInt(3)) { 0 -> 0x5500FFD5; 1 -> 0x55FF0040; else -> 0x40FFFFFF }
            val x = rnd.nextFloat() * w * 0.5f
            canvas.drawRect(x, y, x + w * (0.3f + rnd.nextFloat() * 0.7f), y + bh, p)
        }
        repeat(rnd.nextInt(3)) {
            val y = rnd.nextFloat() * h
            p.color = 0xCC000000.toInt()
            canvas.drawRect(0f, y, w, y + 3f + rnd.nextFloat() * 10f, p)
        }
    }
}


/**
 * HYPNO RAVE – technoparti. A háttéren forgó hipnotikus spirál (váltakozó színes cikkek), lüktető
 * koncentrikus körök, a színek körbejárnak a szivárványon. 128 BPM-es ütemre a kártyák lüktetnek és
 * billegnek. Csak amíg az oldal látszik; villódzó stroboszkóp nincs (fényérzékenyeknek is kíméletes).
 */
object HypnoFx {
    const val BPM = 128.0
    private val p = Paint(Paint.ANTI_ALIAS_FLAG)
    private val box = android.graphics.RectF()

    /** HSV → szín (h: 0..360). */
    fun hsv(h: Float, s: Float, v: Float): Int {
        val hh = ((h % 360f) + 360f) % 360f / 60f
        val i = hh.toInt(); val f = hh - i
        val pp = v * (1 - s); val q = v * (1 - s * f); val tt = v * (1 - s * (1 - f))
        val (r, g, b) = when (i) { 0 -> Triple(v, tt, pp); 1 -> Triple(q, v, pp); 2 -> Triple(pp, v, tt); 3 -> Triple(pp, q, v); 4 -> Triple(tt, pp, v); else -> Triple(v, pp, q) }
        return (0xFF shl 24) or ((r * 255).toInt() shl 16) or ((g * 255).toInt() shl 8) or (b * 255).toInt()
    }

    /** 0..1 – hol tartunk az ütemben (0 = a dobütés pillanata). */
    fun beatPhase(): Float {
        val ms = 60_000.0 / BPM
        return ((System.currentTimeMillis() % ms.toLong()) / ms).toFloat()
    }

    fun paintBackground(canvas: Canvas, w: Float, h: Float) {
        val t = System.currentTimeMillis() / 1000f
        val beat = beatPhase()
        val kick = (1f - beat).let { it * it }   // a dobütéskor 1, utána gyorsan lecseng
        p.shader = null
        p.style = Paint.Style.FILL
        p.color = 0xFF000000.toInt()
        canvas.drawRect(0f, 0f, w, h, p)
        val cx = w / 2
        val cy = h * 0.42f
        val big = Math.hypot(w.toDouble(), h.toDouble()).toFloat()
        // Forgó spirál-cikkek (a cikkek csavarodnak: kívül jobban elfordulnak)
        val n = 18
        val rot = (t * 40f) % 360f
        val hue = (t * 35f) % 360f
        for (ring in 0 until 6) {
            val r = big * (1f - ring / 6f)
            box.set(cx - r, cy - r, cx + r, cy + r)
            val twist = ring * 9f + (if (ring % 2 == 0) rot else -rot * 0.7f)
            for (k in 0 until n) {
                p.color = if (k % 2 == 0) hsv(hue + ring * 25f + k * 6f, 1f, 0.55f + 0.25f * kick)
                else hsv(hue + 180f + ring * 25f, 0.9f, 0.06f + 0.05f * kick)
                canvas.drawArc(box, twist + k * (360f / n), 360f / n + 0.5f, true, p)
            }
        }
        // Lüktető, kifelé futó körök
        p.style = Paint.Style.STROKE
        for (i in 0 until 7) {
            val ph = ((t * 0.9f + i / 7f) % 1f)
            val r = ph * big * 0.6f * (1f + 0.06f * kick)
            p.strokeWidth = 6f + 18f * (1f - ph)
            p.color = (hsv(hue + i * 50f, 1f, 1f) and 0xFFFFFF) or (((1f - ph) * 120).toInt() shl 24)
            canvas.drawCircle(cx, cy, r, p)
        }
        p.style = Paint.Style.FILL
        // Sötét fátyol, hogy a felület olvasható maradjon + középső „szem”
        p.color = 0x99000000.toInt()
        canvas.drawRect(0f, 0f, w, h, p)
        p.color = hsv(hue + 90f, 1f, 1f)
        canvas.drawCircle(cx, cy, 10f + 14f * kick, p)
    }

    /** Rákapcsolja a mozgást egy oldalra: háttér-animáció és ütemre lüktető, billegő kártyák. */
    fun attach(activity: android.app.Activity) {
        val content = activity.findViewById<android.view.ViewGroup>(android.R.id.content) ?: return
        val handler = android.os.Handler(android.os.Looper.getMainLooper())
        val tick = object : Runnable {
            var pool: List<android.view.View> = emptyList()
            var poolAt = 0L
            override fun run() {
                val root = content.getChildAt(0) ?: return
                if (!root.isAttachedToWindow) return
                if (root.windowVisibility != android.view.View.VISIBLE) { handler.postDelayed(this, 500); return }
                activity.window.decorView.background?.invalidateSelf()
                root.background?.invalidateSelf()
                val now = System.currentTimeMillis()
                if (now - poolAt > 2_000) { poolAt = now; pool = cards(content) }
                val beat = beatPhase()
                val kick = (1f - beat).let { it * it }
                val sway = Math.sin(now / 1000.0 * Math.PI * BPM / 120.0).toFloat()
                pool.forEachIndexed { i, v ->
                    val dir = if (i % 2 == 0) 1f else -1f
                    v.rotation = sway * 1.6f * dir
                    val sc = 1f + 0.022f * kick
                    v.scaleX = sc; v.scaleY = sc
                }
                handler.postDelayed(this, 40)
            }
        }
        handler.postDelayed(tick, 300)
    }

    /** A „kártyák”: a görgetett tartalom közepes méretű elemei. */
    private fun cards(g: android.view.ViewGroup): List<android.view.View> {
        val out = ArrayList<android.view.View>()
        fun walk(v: android.view.ViewGroup, depth: Int) {
            for (i in 0 until v.childCount) {
                val c = v.getChildAt(i)
                if (depth >= 2 && c.height in 60..1400 && c.width > 120) out += c
                if (c is android.view.ViewGroup && depth < 3) walk(c, depth + 1)
            }
        }
        walk(g, 0)
        return out
    }
}
