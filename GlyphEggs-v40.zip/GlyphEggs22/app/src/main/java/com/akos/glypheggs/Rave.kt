package com.akos.glypheggs

import android.app.Activity
import android.content.Context
import android.graphics.Canvas
import android.graphics.Paint
import android.os.Handler
import android.os.Looper
import android.view.MotionEvent
import android.view.View
import android.view.ViewGroup
import android.widget.FrameLayout
import kotlin.math.cos
import kotlin.math.sin

/**
 * STROBE RAVE – a legvadabb téma. 150 BPM: minden ütésre teljes képernyős színvillanás, közte 16-od
 * stroboszkóp, forgó lézernyalábok a sarkokból, neonrács, ütemre ugráló és dőlő kártyák, váltakozó színek.
 *
 * ⚠️ ERŐS VILLOGÁS: fényérzékeny epilepsziát válthat ki. Bekapcsoláskor figyelmeztet; a képernyő jobb felső
 * sarkába koppintva bármikor azonnal „lenyugszik” (a villogás leáll, a téma marad, csak nyugodt).
 */
object RaveFx {
    const val BPM = 150.0
    private val p = Paint(Paint.ANTI_ALIAS_FLAG)
    val COLORS = intArrayOf(0xFFFF00CC.toInt(), 0xFF00FF66.toInt(), 0xFF00E5FF.toInt(), 0xFFFFF200.toInt(),
        0xFFFF3B00.toInt(), 0xFF7A00FF.toInt(), 0xFFFFFFFF.toInt())

    /** Lenyugtatva: a téma marad, de nem villog (a sarokra koppintva). */
    @Volatile var calm = false

    private fun beatLen() = 60_000.0 / BPM
    /** Hányadik 16-od hang, és azon belül hol tartunk (0..1). */
    private fun sixteenth(): Pair<Long, Float> {
        val ms = System.currentTimeMillis().toDouble()
        val step = beatLen() / 4
        return (ms / step).toLong() to ((ms % step) / step).toFloat()
    }

    fun color(i: Long): Int = COLORS[((i * 2654435761L) ushr 7).toInt().let { Math.floorMod(it, COLORS.size) }]

    /** 0..1: a dobütés ereje (minden negyed elején 1, gyorsan lecseng). */
    fun kick(): Float {
        val ms = System.currentTimeMillis().toDouble()
        val ph = ((ms % beatLen()) / beatLen()).toFloat()
        return (1f - ph).let { it * it * it }
    }

    fun paintBackground(c: Canvas, w: Float, h: Float) {
        val t = System.currentTimeMillis() / 1000f
        val (n, ph) = sixteenth()
        p.style = Paint.Style.FILL
        // alap: fekete, ütésre színes villanás (lenyugtatva csak halk színátúszás)
        p.color = 0xFF000000.toInt(); c.drawRect(0f, 0f, w, h, p)
        if (calm) {
            p.color = (color(n / 16) and 0xFFFFFF) or 0x30000000
            c.drawRect(0f, 0f, w, h, p)
        } else if (ph < 0.5f) {
            val onBeat = n % 4 == 0L
            p.color = (color(n) and 0xFFFFFF) or (if (onBeat) 0xFF000000.toInt() else 0x90000000.toInt())
            c.drawRect(0f, 0f, w, h, p)
        }
        // neonrács a „padlón”
        p.style = Paint.Style.STROKE
        p.strokeWidth = 2f
        val hz = h * 0.62f
        p.color = (color(n / 4) and 0xFFFFFF) or 0x90000000.toInt()
        for (k in -10..10) c.drawLine(w / 2f, hz, w / 2f + k * w * 0.22f, h, p)
        val scroll = (t * 1.6f) % 1f
        for (k in 0 until 10) {
            val f = ((k + scroll) / 10f); val y = hz + (h - hz) * f * f
            c.drawLine(0f, y, w, y, p)
        }
        // lézerek a felső sarkokból
        lasers(c, w, h, t, n)
        p.style = Paint.Style.FILL
    }

    fun lasers(c: Canvas, w: Float, h: Float, t: Float, n: Long) {
        p.style = Paint.Style.STROKE
        for (side in 0..1) {
            val ox = if (side == 0) 0f else w
            for (k in 0 until 5) {
                val a = (if (side == 0) 0.25f else 2.9f) + sin(t * (1.3f + k * 0.37f) + k + side) * 0.7f
                val col = color(n / 2 + k + side * 3)
                p.strokeWidth = 10f; p.color = (col and 0xFFFFFF) or 0x40000000
                c.drawLine(ox, 0f, ox + cos(a) * h * 1.6f, sin(a) * h * 1.6f, p)
                p.strokeWidth = 3f; p.color = (col and 0xFFFFFF) or 0xE0000000.toInt()
                c.drawLine(ox, 0f, ox + cos(a) * h * 1.6f, sin(a) * h * 1.6f, p)
            }
        }
        p.style = Paint.Style.FILL
    }

    /** Ráköti a bulit egy oldalra: felső villanó réteg (az érintések átmennek), ugráló kártyák. */
    fun attach(activity: Activity) {
        val decor = activity.window.decorView as? FrameLayout ?: return
        val content = activity.findViewById<ViewGroup>(android.R.id.content) ?: return
        val overlay = StrobeOverlay(activity)
        decor.addView(overlay, FrameLayout.LayoutParams(FrameLayout.LayoutParams.MATCH_PARENT, FrameLayout.LayoutParams.MATCH_PARENT))
        val handler = Handler(Looper.getMainLooper())
        val tick = object : Runnable {
            var pool: List<View> = emptyList()
            var poolAt = 0L
            override fun run() {
                val root = content.getChildAt(0) ?: return
                if (!root.isAttachedToWindow) return
                if (root.windowVisibility != View.VISIBLE) { handler.postDelayed(this, 500); return }
                activity.window.decorView.background?.invalidateSelf()
                root.background?.invalidateSelf()
                overlay.invalidate()
                val now = System.currentTimeMillis()
                if (now - poolAt > 2_000) { poolAt = now; pool = cards(content) }
                val k = if (calm) 0f else kick()
                val (n, _) = sixteenth()
                pool.forEachIndexed { i, v ->
                    val sc = 1f + 0.05f * k
                    v.scaleX = sc; v.scaleY = sc
                    v.rotation = if (calm) 0f else (if ((n + i) % 2 == 0L) 1f else -1f) * 2.2f * k
                    v.translationX = if (calm) 0f else (if (i % 2 == 0) 1f else -1f) * 6f * k
                }
                handler.postDelayed(this, 25)
            }
        }
        handler.postDelayed(tick, 200)
    }

    private fun cards(g: ViewGroup): List<View> {
        val out = ArrayList<View>()
        fun walk(v: ViewGroup, depth: Int) {
            for (i in 0 until v.childCount) {
                val c = v.getChildAt(i)
                if (depth >= 2 && c.height in 60..1400 && c.width > 120) out += c
                if (c is ViewGroup && depth < 3) walk(c, depth + 1)
            }
        }
        walk(g, 0)
        return out
    }

    /** A tartalom FÖLÖTTI villanó réteg: fél-átlátszó strobe + lézerek; a jobb felső sarok = lenyugtatás. */
    class StrobeOverlay(context: Context) : View(context) {
        private val q = Paint(Paint.ANTI_ALIAS_FLAG)
        override fun onDraw(c: Canvas) {
            val w = width.toFloat(); val h = height.toFloat()
            val (n, ph) = sixteenth()
            if (!calm) {
                if (ph < 0.35f) {
                    q.color = (color(n + 3) and 0xFFFFFF) or (if (n % 4 == 0L) 0x8C000000.toInt() else 0x46000000)
                    c.drawRect(0f, 0f, w, h, q)
                }
                lasers(c, w, h, System.currentTimeMillis() / 1000f, n)
            }
            // sarok-gomb: lenyugtatás / újra buli
            val d = resources.displayMetrics.density
            q.color = 0xAA000000.toInt(); c.drawCircle(w - 30f * d, 70f * d, 20f * d, q)
            q.color = if (calm) 0xFF00FF66.toInt() else 0xFFFFFFFF.toInt()
            q.textSize = 20f * d; q.textAlign = Paint.Align.CENTER
            c.drawText(if (calm) "⚡" else "Ⅱ", w - 30f * d, 77f * d, q)
        }

        override fun onTouchEvent(e: MotionEvent): Boolean {
            val d = resources.displayMetrics.density
            val hit = Math.hypot((e.x - (width - 30f * d)).toDouble(), (e.y - 70f * d).toDouble()) < 28f * d
            if (!hit) return false
            if (e.action == MotionEvent.ACTION_DOWN) { calm = !calm; invalidate() }
            return true
        }
    }
}
