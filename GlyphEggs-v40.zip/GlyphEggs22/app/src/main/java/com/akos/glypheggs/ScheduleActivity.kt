package com.akos.glypheggs

import android.app.Activity
import android.app.AlertDialog
import android.app.TimePickerDialog
import android.content.Context
import android.graphics.Canvas
import android.graphics.Paint
import android.graphics.RectF
import android.os.Bundle
import android.text.InputType
import android.view.Gravity
import android.view.MotionEvent
import android.view.View
import android.view.ViewGroup.LayoutParams.MATCH_PARENT
import android.view.ViewGroup.LayoutParams.WRAP_CONTENT
import android.widget.EditText
import android.widget.FrameLayout
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView
import java.time.LocalDateTime

/**
 * ÓRAREND – naptár nézet. Heti rács (hétfő–péntek, igény szerint hétvégével), az órák színes blokkok
 * a kezdés és a hossz szerint. Üres helyre koppintva oda kerül egy új óra (a koppintás napjával és
 * negyedórára kerekített idejével), egy órára koppintva szerkeszthető vagy törölhető.
 */
class ScheduleActivity : Activity() {

    private lateinit var root: LinearLayout
    private lateinit var cal: WeekCalendarView
    private lateinit var info: TextView
    private var weekend = false

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        darkWindow()
        root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(12), 0, dp(12), dp(28))
        }
        val scroll = ScrollView(this).apply {
            background = Ui.pageBg()
            isVerticalScrollBarEnabled = false
            addView(root, FrameLayout.LayoutParams(MATCH_PARENT, WRAP_CONTENT))
            padForSystemBars()
        }
        setContentView(scroll)
        weekend = LectureSchedule.entries(this).any { it.day >= 6 }
        build()
    }

    private fun build() {
        root.removeAllViews()
        val h = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
            setPadding(dp(10), dp(28), dp(4), dp(14))
        }
        h.addView(ImageView(this).apply { setImageResource(R.drawable.ic_back); setColorFilter(Ui.TEXT); setOnClickListener { finish() } },
            LinearLayout.LayoutParams(dp(24), dp(24)))
        h.addView(text("Órarend", 26f).apply { setPadding(dp(26), 0, 0, 0) }, LinearLayout.LayoutParams(0, WRAP_CONTENT, 1f))
        // Órarend szerint indul – kapcsoló
        val on = Settings.lectureScheduleOn(this)
        h.addView(text(if (on) "● BE" else "○ KI", 13f, if (on) Ui.DARK_TEXT else Ui.TEXT, Ui.medium).apply {
            gravity = Gravity.CENTER
            background = rounded(if (on) Ui.LIGHT else Ui.CARD, dp(18).toFloat())
            setOnClickListener {
                Settings.setLectureScheduleOn(this@ScheduleActivity, !on)
                LectureSchedule.scheduleNext(this@ScheduleActivity)
                Widgets.updateLecture(this@ScheduleActivity)
                build()
            }
        }, LinearLayout.LayoutParams(dp(74), dp(36)))
        root.addView(h)

        // Hétvége kapcsoló + tipp
        val bar = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL }
        bar.addView(text("Koppints egy üres helyre: oda kerül az új óra. Egy órára koppintva szerkesztheted.", 12f, Ui.SUB)
            .apply { setPadding(dp(8), 0, dp(8), 0); setLineSpacing(0f, 1.15f) }, LinearLayout.LayoutParams(0, WRAP_CONTENT, 1f))
        bar.addView(text(if (weekend) "Hétvége ✓" else "Hétvége", 12.5f, if (weekend) Ui.DARK_TEXT else Ui.TEXT, Ui.medium).apply {
            gravity = Gravity.CENTER
            background = rounded(if (weekend) Ui.LIGHT else Ui.CARD, dp(16).toFloat())
            setOnClickListener { weekend = !weekend; build() }
        }, LinearLayout.LayoutParams(dp(92), dp(32)))
        root.addView(bar, LinearLayout.LayoutParams(MATCH_PARENT, WRAP_CONTENT).apply { bottomMargin = dp(10) })

        cal = WeekCalendarView(this, weekend).apply {
            onEmpty = { day, h, m -> editor(null, day, h, m) }
            onEntry = { e -> editor(e, e.day, e.hour, e.minute) }
        }
        root.addView(cal, LinearLayout.LayoutParams(MATCH_PARENT, cal.wantedHeight()))

        info = text("", 12.5f, Ui.SUB).apply { setPadding(dp(8), dp(12), dp(8), 0); setLineSpacing(0f, 1.2f) }
        root.addView(info)
        val add = text("＋  Új óra", 16f, Ui.DARK_TEXT, Ui.medium).apply {
            gravity = Gravity.CENTER
            background = rounded(Ui.LIGHT, dp(26).toFloat())
            setOnClickListener {
                val now = LocalDateTime.now()
                editor(null, now.dayOfWeek.value.coerceAtMost(if (weekend) 7 else 5), 8, 0)
            }
        }
        root.addView(add, LinearLayout.LayoutParams(MATCH_PARENT, dp(52)).apply { topMargin = dp(12) })
        refreshInfo()
    }

    private fun refreshInfo() {
        val next = LectureSchedule.next(this)
        val n = LectureSchedule.entries(this).size
        info.text = when {
            n == 0 -> "Még üres az órarend."
            !Settings.lectureScheduleOn(this) -> "$n óra · az automatikus indulás ki van kapcsolva (jobb felső gomb)."
            next == null -> "$n óra · nincs következő."
            else -> "$n óra · következő: ${next.first.title()} (${next.first.length(this)})"
        } + (if (n > 0 && !LectureSchedule.exactAllowed(this)) "\nA pontos ébresztő nincs engedélyezve: az indulás néhány percet csúszhat." else "")
    }

    private fun changed() {
        cal.reload()
        Widgets.updateLecture(this)
        refreshInfo()
    }

    // ------------------------------------------------------------------ szerkesztő

    private val LENGTHS = listOf(0 to 0, 1 to 45, 2 to 45, 3 to 45, 1 to 60, 2 to 60, 1 to 90, 1 to 30)

    /** Új óra (e == null) vagy meglévő szerkesztése – egyetlen ablakban: név, nap, kezdés, hossz. */
    private fun editor(e: LectureSchedule.Entry?, day0: Int, h0: Int, m0: Int) {
        var day = day0
        var hh = h0
        var mm = m0
        var len = LENGTHS.indexOfFirst { it.first == (e?.blocks ?: 0) && it.second == (e?.blockMin ?: 0) }.coerceAtLeast(0)

        val box = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(dp(20), dp(8), dp(20), 0) }
        val name = EditText(this).apply {
            hint = "Tárgy neve (pl. Matek)"
            setText(e?.name ?: "")
            setSingleLine(true)
            inputType = InputType.TYPE_CLASS_TEXT or InputType.TYPE_TEXT_FLAG_CAP_SENTENCES
            setTextColor(Ui.TEXT); setHintTextColor(0xFF6A6A6A.toInt())
        }
        box.addView(name)

        fun label(s: String) = text(s, 12f, Ui.SUB).apply { setPadding(0, dp(12), 0, dp(6)) }
        box.addView(label("Nap"))
        val days = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
        fun renderDays() {
            days.removeAllViews()
            for (d in 1..7) {
                val sel = d == day
                days.addView(text(LectureSchedule.DAYS_SHORT[d - 1], 13f, if (sel) Ui.DARK_TEXT else Ui.TEXT, Ui.medium).apply {
                    gravity = Gravity.CENTER
                    background = rounded(if (sel) Ui.LIGHT else Ui.CARD, dp(14).toFloat())
                    setOnClickListener { day = d; renderDays() }
                }, LinearLayout.LayoutParams(0, dp(36), 1f).apply { if (d < 7) marginEnd = dp(4) })
            }
        }
        renderDays()
        box.addView(days)

        box.addView(label("Kezdés"))
        val time = text("", 22f, Ui.TEXT).apply {
            typeface = Widgets.dotoFace(this@ScheduleActivity)
            gravity = Gravity.CENTER
            background = rounded(Ui.CARD, dp(16).toFloat())
        }
        fun renderTime() { time.text = "%d:%02d".format(hh, mm) }
        renderTime()
        time.setOnClickListener {
            TimePickerDialog(this, android.R.style.Theme_DeviceDefault_Dialog_Alert, { _, a, b -> hh = a; mm = b; renderTime() }, hh, mm, true).show()
        }
        box.addView(time, LinearLayout.LayoutParams(MATCH_PARENT, dp(48)))

        box.addView(label("Hossz"))
        val lens = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        fun renderLens() {
            lens.removeAllViews()
            for (row in LENGTHS.indices.chunked(4)) {
                val r = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
                for (i in row) {
                    val (b, m) = LENGTHS[i]
                    val sel = i == len
                    r.addView(text(if (b == 0) "Alap" else "$b×$m", 12.5f, if (sel) Ui.DARK_TEXT else Ui.TEXT, Ui.medium).apply {
                        gravity = Gravity.CENTER
                        background = rounded(if (sel) Ui.LIGHT else Ui.CARD, dp(14).toFloat())
                        setOnClickListener { len = i; renderLens() }
                    }, LinearLayout.LayoutParams(0, dp(36), 1f).apply { if (i % 4 != 3) marginEnd = dp(4); bottomMargin = dp(4) })
                }
                lens.addView(r)
            }
        }
        renderLens()
        box.addView(lens)
        box.addView(text("Alap = az Előadás beállítása szerint (${Settings.lectureBlocks(this)} × ${Settings.lectureBlockMin(this)} perc)", 11.5f, Ui.SUB)
            .apply { setPadding(0, dp(4), 0, 0) })

        val dlg = AlertDialog.Builder(this, android.R.style.Theme_DeviceDefault_Dialog_Alert)
            .setTitle(if (e == null) "Új óra" else "Óra szerkesztése")
            .setView(ScrollView(this).apply { addView(box) })
            .setPositiveButton("Mentés") { _, _ ->
                val (b, m) = LENGTHS[len]
                val entry = LectureSchedule.Entry(e?.id ?: LectureSchedule.newId(), day, hh, mm, b, m, name.text.toString().trim())
                if (e == null) LectureSchedule.add(this, entry) else LectureSchedule.update(this, entry)
                if (day >= 6 && !weekend) { weekend = true; build() } else changed()
            }
            .setNegativeButton("Mégse", null)
        if (e != null) dlg.setNeutralButton("Törlés") { _, _ -> LectureSchedule.remove(this, e.id); changed() }
        dlg.show()
    }
}

/**
 * A heti rács: bal oldalt az órák, felül a napok; a mai nap kiemelve, piros „most” vonallal.
 * A blokkok színe a tárgy nevéből jön (ugyanaz a tárgy mindig ugyanolyan színű).
 */
class WeekCalendarView(context: Context, private val weekend: Boolean) : View(context) {
    var onEmpty: ((Int, Int, Int) -> Unit)? = null
    var onEntry: ((LectureSchedule.Entry) -> Unit)? = null

    private val d = resources.displayMetrics.density
    private val days = if (weekend) 7 else 5
    private val gutter = 38f * d
    private val head = 34f * d
    private val hourH = 54f * d
    private var entries = LectureSchedule.entries(context)
    private var fromH = 7
    private var toH = 20
    private val p = Paint(Paint.ANTI_ALIAS_FLAG)
    private val tp = Paint(Paint.ANTI_ALIAS_FLAG)
    private val r = RectF()
    private val boxes = ArrayList<Pair<RectF, LectureSchedule.Entry>>()

    private val COLORS = intArrayOf(0xFFD71921.toInt(), 0xFF3A86FF.toInt(), 0xFF06D6A0.toInt(), 0xFFFFB703.toInt(),
        0xFF8338EC.toInt(), 0xFFFF6B9A.toInt(), 0xFF00B4D8.toInt(), 0xFFF77F00.toInt())

    init { range() }

    private fun range() {
        fromH = 7; toH = 20
        for (e in entries) {
            fromH = minOf(fromH, e.hour)
            val end = e.hour + (e.minute + durMin(e)) / 60 + 1
            toH = maxOf(toH, minOf(24, end))
        }
    }

    fun wantedHeight(): Int = (head + (toH - fromH) * hourH + 6f * d).toInt()

    fun reload() {
        entries = LectureSchedule.entries(context)
        val oldH = wantedHeight()
        range()
        if (wantedHeight() != oldH) { layoutParams = layoutParams.apply { height = wantedHeight() }; requestLayout() }
        invalidate()
    }

    /** Az óra teljes hossza percben (részek + közöttük a szünetek). */
    private fun durMin(e: LectureSchedule.Entry): Int {
        val b = if (e.blocks > 0) e.blocks else Settings.lectureBlocks(context)
        val m = if (e.blockMin > 0) e.blockMin else Settings.lectureBlockMin(context)
        return b * m + (b - 1).coerceAtLeast(0) * Settings.lectureBreakMin(context)
    }

    private fun colW() = (width - gutter) / days
    private fun yOf(h: Int, m: Int) = head + ((h - fromH) + m / 60f) * hourH

    override fun onDraw(c: Canvas) {
        val w = width.toFloat()
        val cw = colW()
        val now = LocalDateTime.now()
        val today = now.dayOfWeek.value
        // háttér-kártya
        p.color = Ui.CARD; r.set(0f, 0f, w, height.toFloat()); c.drawRoundRect(r, 18f * d, 18f * d, p)
        // mai oszlop kiemelése
        if (today <= days) {
            p.color = 0x14FFFFFF; r.set(gutter + (today - 1) * cw, 0f, gutter + today * cw, height.toFloat()); c.drawRect(r, p)
        }
        // nap-fejléc
        tp.textAlign = Paint.Align.CENTER; tp.textSize = 12.5f * d
        for (i in 0 until days) {
            val cx = gutter + cw * (i + 0.5f)
            val isToday = i + 1 == today
            if (isToday) { p.color = Ui.RED; c.drawCircle(cx, head / 2f, 13f * d, p) }
            tp.color = if (isToday) 0xFFFFFFFF.toInt() else Ui.SUB
            tp.isFakeBoldText = isToday
            c.drawText(LectureSchedule.DAYS_SHORT[i], cx, head / 2f + 4.5f * d, tp)
        }
        tp.isFakeBoldText = false
        // óra-vonalak és címkék
        tp.textAlign = Paint.Align.RIGHT; tp.textSize = 10.5f * d; tp.color = Ui.SUB
        for (h in fromH..toH) {
            val y = yOf(h, 0)
            p.color = 0x22FFFFFF
            c.drawRect(gutter, y, w - 6f * d, y + 1f, p)
            if (h < toH) c.drawText("$h:00", gutter - 6f * d, y + 4f * d, tp)
        }
        // oszlopvonalak (pontozott)
        p.color = 0x18FFFFFF
        for (i in 1 until days) { val x = gutter + i * cw; var y = head; while (y < height) { c.drawCircle(x, y, 1f * d, p); y += 6f * d } }

        // órák
        boxes.clear()
        tp.textAlign = Paint.Align.LEFT
        for (e in entries) {
            if (e.day > days) continue
            val x0 = gutter + (e.day - 1) * cw + 2f * d
            val y0 = yOf(e.hour, e.minute) + 1f * d
            val y1 = (y0 + durMin(e) / 60f * hourH - 2f * d).coerceAtLeast(y0 + 22f * d)
            val col = COLORS[Math.floorMod((e.name.ifBlank { "óra" }).hashCode(), COLORS.size)]
            r.set(x0, y0, x0 + cw - 4f * d, y1)
            p.color = (col and 0xFFFFFF) or 0x38000000; c.drawRoundRect(r, 8f * d, 8f * d, p)
            p.color = col; c.drawRoundRect(RectF(r.left, r.top, r.left + 3.5f * d, r.bottom), 2f * d, 2f * d, p)
            c.save(); c.clipRect(r)
            tp.color = 0xFFFFFFFF.toInt(); tp.textSize = 11.5f * d; tp.isFakeBoldText = true
            c.drawText(e.name.ifBlank { "Óra" }, r.left + 7f * d, r.top + 14f * d, tp)
            tp.isFakeBoldText = false; tp.textSize = 10f * d; tp.color = 0xCCFFFFFF.toInt()
            c.drawText(e.time(), r.left + 7f * d, r.top + 27f * d, tp)
            c.restore()
            boxes += RectF(r) to e
        }
        // „most” vonal
        if (today <= days && now.hour in fromH until toH) {
            val y = yOf(now.hour, now.minute)
            p.color = Ui.RED
            c.drawRect(gutter + (today - 1) * cw, y - 1f * d, gutter + today * cw, y + 1f * d, p)
            c.drawCircle(gutter + (today - 1) * cw, y, 4f * d, p)
        }
    }

    override fun onTouchEvent(e: MotionEvent): Boolean {
        if (e.action == MotionEvent.ACTION_DOWN) return true
        if (e.action != MotionEvent.ACTION_UP) return true
        boxes.firstOrNull { it.first.contains(e.x, e.y) }?.let { onEntry?.invoke(it.second); return true }
        if (e.x < gutter || e.y < head) return true
        val day = ((e.x - gutter) / colW()).toInt() + 1
        val mins = ((e.y - head) / hourH * 60f).toInt() + fromH * 60
        val q = (mins / 15) * 15
        onEmpty?.invoke(day.coerceIn(1, days), (q / 60).coerceIn(0, 23), q % 60)
        return true
    }
}
