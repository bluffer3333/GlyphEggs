package com.akos.glypheggs

import android.app.PendingIntent
import android.appwidget.AppWidgetManager
import android.appwidget.AppWidgetProvider
import android.content.BroadcastReceiver
import android.content.ComponentName
import android.content.Context
import android.content.Intent
import android.graphics.Bitmap
import android.graphics.Canvas
import android.graphics.Paint
import android.os.SystemClock
import android.view.View
import android.widget.RemoteViews
import com.nothing.ketchum.Glyph

/**
 * Az időzítő állapota a widgethez (mentve, hogy a widget akkor is lássa, ha az app újraindult).
 */
object TimerState {
    private const val PREFS = "glyph_eggs_timer"

    private fun p(c: Context) = c.getSharedPreferences(PREFS, Context.MODE_PRIVATE)

    fun running(c: Context, title: String, endElapsed: Long, index: Int, count: Int, isBreak: Boolean) {
        p(c).edit().putBoolean("active", true).putBoolean("paused", false).putString("title", title)
            .putLong("end", endElapsed).putInt("index", index).putInt("count", count)
            .putBoolean("break", isBreak).apply()
        Widgets.updateTimer(c)
    }

    fun pause(c: Context, remainingMs: Long) {
        p(c).edit().putBoolean("paused", true).putLong("remaining", remainingMs).apply()
        Widgets.updateTimer(c)
    }

    fun resume(c: Context, remainingMs: Long) {
        p(c).edit().putBoolean("paused", false).putLong("end", SystemClock.elapsedRealtime() + remainingMs).apply()
        Widgets.updateTimer(c)
    }

    fun clear(c: Context) {
        p(c).edit().putBoolean("active", false).apply()
        Widgets.updateTimer(c)
    }

    fun active(c: Context) = p(c).getBoolean("active", false)
    fun paused(c: Context) = p(c).getBoolean("paused", false)
    fun title(c: Context) = p(c).getString("title", null) ?: ""
    fun end(c: Context) = p(c).getLong("end", 0L)
    fun remaining(c: Context) = p(c).getLong("remaining", 0L)
    fun isBreak(c: Context) = p(c).getBoolean("break", false)
}

/**
 * Az Előadás állapota a widgethez: fázis (töltés / előadás / szünet), a végek időpontja
 * (SystemClock.elapsedRealtime, ahogy a Chronometer várja), és hány LED ég a felső sávon.
 */
object LectureState {
    private const val PREFS = "glyph_eggs_lecture"
    private fun p(c: Context) = c.getSharedPreferences(PREFS, Context.MODE_PRIVATE)

    fun fill(c: Context) {
        p(c).edit().putString("phase", "FILL").apply()
        Widgets.updateLecture(c)
    }

    fun lecture(c: Context, block: Int, blocks: Int, blockEnd: Long, totalEnd: Long, leds: Int, ring: Int) {
        p(c).edit().putString("phase", "LECTURE").putInt("block", block).putInt("blocks", blocks)
            .putLong("blockEnd", blockEnd).putLong("totalEnd", totalEnd).putInt("leds", leds).putInt("ring", ring).apply()
        Widgets.updateLecture(c)
    }

    fun inBreak(c: Context, nextBlock: Int, blocks: Int, breakEnd: Long, lectureLeft: Long, leds: Int, breakLeds: Int, ring: Int) {
        p(c).edit().putString("phase", "BREAK").putInt("block", nextBlock).putInt("blocks", blocks)
            .putLong("breakEnd", breakEnd).putLong("lectureLeft", lectureLeft).putInt("leds", leds)
            .putInt("breakLeds", breakLeds).putInt("ring", ring).apply()
        Widgets.updateLecture(c)
    }

    fun clear(c: Context) {
        p(c).edit().putString("phase", "").apply()
        Widgets.updateLecture(c)
    }

    fun phase(c: Context): String = p(c).getString("phase", null) ?: ""
    fun block(c: Context) = p(c).getInt("block", 0)
    fun blocks(c: Context) = p(c).getInt("blocks", 2)
    fun blockEnd(c: Context) = p(c).getLong("blockEnd", 0L)
    fun totalEnd(c: Context) = p(c).getLong("totalEnd", 0L)
    fun breakEnd(c: Context) = p(c).getLong("breakEnd", 0L)
    fun lectureLeft(c: Context) = p(c).getLong("lectureLeft", 0L)
    fun leds(c: Context) = p(c).getInt("leds", 16)
    fun breakLeds(c: Context) = p(c).getInt("breakLeds", 8)
    /** Hány pont ég a kerek widget körén (a [RING_DOTS]-ból). */
    fun ring(c: Context) = p(c).getInt("ring", RING_DOTS)

    /** A kerek widget körén ennyi pont van. */
    const val RING_DOTS = 48
}

/** Az iránytű iránya a widgethez (a telefon tetejének iránya fokban, 0° = észak). */
object CompassState {
    private const val PREFS = "glyph_eggs_compass"
    private fun p(c: Context) = c.getSharedPreferences(PREFS, Context.MODE_PRIVATE)

    fun update(c: Context, heading: Float) {
        p(c).edit().putBoolean("has", true).putFloat("heading", heading).apply()
        Widgets.updateCompass(c)
    }

    fun clear(c: Context) {
        p(c).edit().putBoolean("has", false).apply()
        Widgets.updateCompass(c)
    }

    fun heading(c: Context): Float? = if (p(c).getBoolean("has", false)) p(c).getFloat("heading", 0f) else null

    /** Égtáj a fokból: É, ÉK, K, DK, D, DNy, Ny, ÉNy. */
    fun cardinal(deg: Float): String {
        val names = arrayOf("É", "ÉK", "K", "DK", "D", "DNY", "NY", "ÉNY")
        return names[(((deg + 22.5f) % 360f + 360f) % 360f / 45f).toInt() % 8]
    }
}

/** A widgetek kirajzolása és frissítése egy helyen. */
object Widgets {
    private const val PREFS = "glyph_eggs_widgets"
    private const val DARK = 0xFF111111.toInt()
    private const val LIGHT = 0xFFEEEEEE.toInt()

    private fun p(c: Context) = c.getSharedPreferences(PREFS, Context.MODE_PRIVATE)

    // --- widgetenkénti beállítás ---
    fun barFeatures(c: Context, id: Int): List<Feature> {
        val raw = p(c).getString("bar_$id", null)
        val list = raw?.split(",")?.mapNotNull { n -> Feature.entries.firstOrNull { it.name == n } }
        return (list ?: (Settings.pinned(c) + Feature.entries).distinct()).take(4)
    }
    fun setBarFeatures(c: Context, id: Int, list: List<Feature>) =
        p(c).edit().putString("bar_$id", list.joinToString(",") { it.name }).apply()

    fun singleFeature(c: Context, id: Int): Feature =
        Feature.entries.firstOrNull { it.name == p(c).getString("single_$id", null) } ?: Feature.SPIN
    fun setSingleFeature(c: Context, id: Int, f: Feature) = p(c).edit().putString("single_$id", f.name).apply()

    fun forget(c: Context, ids: IntArray) {
        val e = p(c).edit()
        for (id in ids) { e.remove("bar_$id"); e.remove("single_$id") }
        e.apply()
    }

    // --- frissítés ---
    private fun ids(c: Context, cls: Class<*>): IntArray =
        AppWidgetManager.getInstance(c).getAppWidgetIds(ComponentName(c, cls))

    fun updateAll(c: Context) {
        updateBar(c)
        updateSingle(c)
        updatePet(c)
        updateTimer(c)
        updateLecture(c)
        updateCompass(c)
    }

    fun updateLecture(c: Context, ids: IntArray = ids(c, LectureWidget::class.java)) {
        updateLectureRing(c)
        if (ids.isEmpty()) return
        val m = AppWidgetManager.getInstance(c)
        val views = lectureViews(c)
        for (id in ids) m.updateAppWidget(id, views)
    }

    fun updateLectureRing(c: Context, ids: IntArray = ids(c, LectureRingWidget::class.java)) {
        if (ids.isEmpty()) return
        val m = AppWidgetManager.getInstance(c)
        val views = lectureRingViews(c)
        for (id in ids) m.updateAppWidget(id, views)
    }

    fun updateCompass(c: Context, ids: IntArray = ids(c, CompassWidget::class.java)) {
        if (ids.isEmpty()) return
        val m = AppWidgetManager.getInstance(c)
        val views = compassViews(c)
        for (id in ids) m.updateAppWidget(id, views)
    }

    fun updateBar(c: Context, ids: IntArray = ids(c, QuickBarWidget::class.java)) {
        val m = AppWidgetManager.getInstance(c)
        for (id in ids) m.updateAppWidget(id, barViews(c, id))
    }

    fun updateSingle(c: Context, ids: IntArray = ids(c, FeatureWidget::class.java)) {
        val m = AppWidgetManager.getInstance(c)
        for (id in ids) m.updateAppWidget(id, singleViews(c, id))
    }

    fun updatePet(c: Context, ids: IntArray = ids(c, PetWidget::class.java)) {
        if (ids.isEmpty()) return
        val m = AppWidgetManager.getInstance(c)
        val views = petViews(c)
        for (id in ids) m.updateAppWidget(id, views)
    }

    fun updateTimer(c: Context, ids: IntArray = ids(c, TimerWidget::class.java)) {
        if (ids.isEmpty()) return
        val m = AppWidgetManager.getInstance(c)
        val views = timerViews(c)
        for (id in ids) m.updateAppWidget(id, views)
    }

    // --- kattintások ---
    private fun serviceIntent(c: Context, action: String, req: Int, fromWidget: Boolean = false): PendingIntent =
        PendingIntent.getForegroundService(
            c, req, Intent(c, SimonService::class.java).setAction(action).apply {
                if (fromWidget) putExtra(SimonService.EXTRA_SOURCE, SimonService.SOURCE_WIDGET)
            },
            PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT
        )

    private fun activityIntent(c: Context, cls: Class<*>, req: Int): PendingIntent =
        PendingIntent.getActivity(
            c, req, Intent(c, cls).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK),
            PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT
        )

    /** A Tojás vagy a funkció indítása: a Tojás a saját oldalát nyitja, a többi a szolgáltatást. */
    private fun featureIntent(c: Context, f: Feature, req: Int): PendingIntent =
        if (f == Feature.PET) activityIntent(c, PetActivity::class.java, req)
        else if (f == Feature.BLOW) activityIntent(c, BlowActivity::class.java, req)
        else serviceIntent(c, SimonService.actionFor(f), req, fromWidget = true)

    private fun sourceIntent(c: Context, action: String, req: Int, src: String): PendingIntent =
        PendingIntent.getForegroundService(
            c, req, Intent(c, SimonService::class.java).setAction(action).putExtra(SimonService.EXTRA_SOURCE, src),
            PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT
        )

    /** A widget figyelés-gombja: ha nincs indító mozdulat, a beállítást nyitja; különben be/ki kapcsolja. */
    private fun armIntent(c: Context, f: Feature, req: Int): PendingIntent =
        if (Settings.trigger(c, f) == Trigger.NONE) {
            PendingIntent.getActivity(
                c, req,
                Intent(c, GesturesActivity::class.java).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                    .putExtra(GesturesActivity.EXTRA_FEATURE, f.name),
                PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT
            )
        } else {
            PendingIntent.getForegroundService(
                c, req,
                Intent(c, SimonService::class.java).setAction(SimonService.ACTION_ARM_TOGGLE)
                    .putExtra(SimonService.EXTRA_FEATURE, f.name),
                PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT
            )
        }

    private fun petActionIntent(c: Context, a: PetAction): PendingIntent =
        PendingIntent.getBroadcast(
            c, 500 + a.ordinal,
            Intent(c, WidgetActionReceiver::class.java).setAction(WidgetActionReceiver.ACTION_PET).putExtra("act", a.name),
            PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT
        )

    // --- nézetek ---
    private val slotRoot = intArrayOf(R.id.slot0, R.id.slot1, R.id.slot2, R.id.slot3)
    private val slotBg = intArrayOf(R.id.slot0_bg, R.id.slot1_bg, R.id.slot2_bg, R.id.slot3_bg)
    private val slotIcon = intArrayOf(R.id.slot0_icon, R.id.slot1_icon, R.id.slot2_icon, R.id.slot3_icon)
    private val slotLabel = intArrayOf(R.id.slot0_label, R.id.slot1_label, R.id.slot2_label, R.id.slot3_label)

    private fun barViews(c: Context, id: Int): RemoteViews {
        val v = RemoteViews(c.packageName, R.layout.widget_bar)
        val mode = GlyphMirror.mode.value
        val watching = Settings.watching(c)
        v.setTextViewText(R.id.bar_status, if (mode != null) "${mode.title} fut · koppints a leállításhoz" else "Készenlét")
        v.setTextViewText(R.id.bar_watch, if (watching) "FIGYEL BE" else "FIGYEL KI")
        v.setViewVisibility(R.id.bar_dot, if (mode != null) View.VISIBLE else View.GONE)
        v.setInt(R.id.bar_watch, "setBackgroundResource", if (watching) R.drawable.widget_pill_on else R.drawable.widget_pill)
        v.setTextColor(R.id.bar_watch, if (watching) DARK else LIGHT)
        v.setOnClickPendingIntent(R.id.bar_watch, serviceIntent(c, SimonService.ACTION_WATCH_TOGGLE, id * 10 + 9))
        v.setOnClickPendingIntent(R.id.bar_title, activityIntent(c, MainActivity::class.java, id * 10 + 8))

        val list = barFeatures(c, id)
        for (i in 0 until 4) {
            val f = list.getOrNull(i)
            if (f == null) {
                v.setViewVisibility(slotRoot[i], View.INVISIBLE)
                continue
            }
            v.setViewVisibility(slotRoot[i], View.VISIBLE)
            val on = mode == f
            v.setImageViewResource(slotIcon[i], f.icon)
            v.setInt(slotIcon[i], "setColorFilter", if (on) DARK else LIGHT)
            v.setInt(slotBg[i], "setBackgroundResource", if (on) R.drawable.widget_btn_on else R.drawable.widget_btn)
            v.setTextViewText(slotLabel[i], if (on) "FUT" else f.short.uppercase())
            v.setOnClickPendingIntent(slotRoot[i], featureIntent(c, f, id * 10 + i))
        }
        return v
    }

    private fun singleViews(c: Context, id: Int): RemoteViews {
        val v = RemoteViews(c.packageName, R.layout.widget_feature)
        val f = singleFeature(c, id)
        val on = GlyphMirror.mode.value == f
        v.setImageViewResource(R.id.f_icon, f.icon)
        v.setInt(R.id.f_icon, "setColorFilter", if (on) DARK else LIGHT)
        v.setInt(R.id.f_bg, "setBackgroundResource", if (on) R.drawable.widget_btn_on else R.drawable.widget_btn)
        v.setTextViewText(R.id.f_label, f.short.uppercase())
        v.setViewVisibility(R.id.f_dot, if (on) View.VISIBLE else View.GONE)
        v.setOnClickPendingIntent(R.id.f_root, featureIntent(c, f, 20_000 + id))
        return v
    }

    /** A Tojás "portréja" a Glyph-rajzon: szemek, antenna, test a hangulat szerint. */
    fun petZones(s: PetState): Set<Int> {
        val c1: IntArray = IntArray(16) { Zones.LEVEL[15 - it] }
        val z = mutableSetOf<Int>()
        if (s.stage == PetStage.EGG) {
            z += c1.toList()
            z += listOf(Glyph.Code_22111.C2, Glyph.Code_22111.C3, Glyph.Code_22111.C4, Glyph.Code_22111.C5, Glyph.Code_22111.C6)
            return z
        }
        if (s.mood != PetMood.SLEEP) z += listOf(Glyph.Code_22111.A1, Glyph.Code_22111.A2)
        if (s.mood == PetMood.HAPPY || s.stage.ordinal >= PetStage.TEEN.ordinal) z += Glyph.Code_22111.B1
        val size = when (s.stage) { PetStage.BABY -> 2; PetStage.TEEN -> 3; else -> 4 }
        when (s.mood) {
            PetMood.HAPPY -> { for (k in 0 until size + 2) z += c1[7 - size / 2 + k - 1]; z += Glyph.Code_22111.C2; z += Glyph.Code_22111.C6 }
            PetMood.OK -> for (k in 0 until size) z += c1[7 - size / 2 + k]
            PetMood.SAD -> { for (k in 0 until size) z += c1[7 - size / 2 + k]; z += Glyph.Code_22111.D1_6; z += Glyph.Code_22111.D1_3 }
            PetMood.SICK -> { for (k in 0 until size) z += c1[7 - size / 2 + k]; z += Glyph.Code_22111.C4 }
            PetMood.SLEEP -> { z += Glyph.Code_22111.D1_1 }
        }
        if (s.poops > 0 || s.mood == PetMood.SLEEP) z += Glyph.Code_22111.E1
        return z
    }

    /** A Glyph-rajz képpé alakítva (a widget nem tud saját nézetet rajzolni). */
    fun glyphBitmap(c: Context, lit: Set<Int>, sizePx: Int, idleAllOn: Boolean = false): Bitmap {
        val view = GlyphMapView(c).apply {
            unlitColor = 0xFF2E2E2E.toInt()
            this.idleAllOn = idleAllOn
            this.lit = lit
        }
        val spec = View.MeasureSpec.makeMeasureSpec(sizePx, View.MeasureSpec.EXACTLY)
        view.measure(spec, spec)
        view.layout(0, 0, sizePx, sizePx)
        val bmp = Bitmap.createBitmap(sizePx, sizePx, Bitmap.Config.ARGB_8888)
        view.draw(Canvas(bmp))
        return bmp
    }

    private fun petViews(c: Context): RemoteViews {
        val v = RemoteViews(c.packageName, R.layout.widget_pet)
        val s = PetStore.load(c)
        v.setImageViewBitmap(R.id.pet_image, glyphBitmap(c, petZones(s), 260))
        v.setTextViewText(R.id.pet_title, (if (s.stage == PetStage.EGG) "Tojás" else "${s.stage.title} · ${s.mood.title}").uppercase())
        val need = s.need()
        v.setTextViewText(
            R.id.pet_sub,
            when {
                s.stage == PetStage.EGG -> "Melegítsd: ${s.warmth}/3 gondoskodás"
                need != null -> "Most: $need"
                else -> "Minden rendben"
            }
        )
        // Állapotok pontsorként (10 pont); 30% alatt piros, mint a Nothing figyelmeztetései
        fun bar(id: Int, value: Float) {
            val n = Math.round(value / 10f).coerceIn(0, 10)
            v.setImageViewBitmap(id, dotBar(n, 10, if (value < 30f) 0xFFD71921.toInt() else 0xFFF4F4F4.toInt()))
        }
        bar(R.id.pet_bar_food, s.food.toFloat())
        bar(R.id.pet_bar_fun, s.fun_.toFloat())
        bar(R.id.pet_bar_energy, s.energy.toFloat())
        bar(R.id.pet_bar_clean, s.clean.toFloat())
        v.setOnClickPendingIntent(R.id.pet_btn_feed, petActionIntent(c, PetAction.FEED))
        v.setOnClickPendingIntent(R.id.pet_btn_play, petActionIntent(c, PetAction.PLAY))
        v.setOnClickPendingIntent(R.id.pet_btn_pet, petActionIntent(c, PetAction.PET))
        v.setOnClickPendingIntent(R.id.pet_btn_clean, petActionIntent(c, PetAction.CLEAN))
        v.setOnClickPendingIntent(R.id.pet_image, activityIntent(c, PetActivity::class.java, 600))
        v.setOnClickPendingIntent(R.id.pet_title, activityIntent(c, PetActivity::class.java, 601))
        return v
    }

    private fun fmt(ms: Long): String {
        val sec = (ms / 1000).coerceAtLeast(0)
        return "%d:%02d".format(sec / 60, sec % 60)
    }

    private fun timerViews(c: Context): RemoteViews {
        val v = RemoteViews(c.packageName, R.layout.widget_timer)
        val mode = Settings.timerMode(c)
        val style = Settings.timerStyle(c)
        val running = TimerState.active(c) && GlyphMirror.mode.value == Feature.TIMER
        if (running) {
            val paused = TimerState.paused(c)
            v.setTextViewText(R.id.t_title, (TimerState.title(c) + if (paused) " · szünetel" else "").uppercase())
            v.setViewVisibility(R.id.t_chrono, View.VISIBLE)
            v.setViewVisibility(R.id.t_time, View.GONE)
            if (paused) {
                v.setChronometer(R.id.t_chrono, SystemClock.elapsedRealtime() + TimerState.remaining(c), null, false)
            } else {
                v.setChronometer(R.id.t_chrono, TimerState.end(c), null, true)
            }
            v.setChronometerCountDown(R.id.t_chrono, true)
            v.setImageViewResource(R.id.t_btn_icon, R.drawable.ic_stop)
            v.setTextViewText(R.id.t_hint, if (TimerState.isBreak(c)) "Pihenj – a gyűrű lélegzik" else "Fókusz – a LED-ek mutatják az időt")
        } else {
            val minutes = if (mode.custom) Settings.timerMinutes(c) else mode.workMin
            v.setTextViewText(R.id.t_title, "${mode.title} · ${style.title}".uppercase())
            v.setViewVisibility(R.id.t_chrono, View.GONE)
            v.setViewVisibility(R.id.t_time, View.VISIBLE)
            v.setTextViewText(R.id.t_time, fmt(minutes * 60_000L))
            v.setImageViewResource(R.id.t_btn_icon, R.drawable.ic_play)
            v.setTextViewText(R.id.t_hint, "Koppints az órára a beállításhoz")
        }
        v.setOnClickPendingIntent(R.id.t_btn, serviceIntent(c, SimonService.ACTION_TIMER, 700))
        v.setOnClickPendingIntent(R.id.t_root, activityIntent(c, TimerActivity::class.java, 701))
        return v
    }

    // --- pontmátrixos rajzok ---

    /** Pontsor: [lit] világos pont a [total]-ból, a többi halvány (mint a LED-sáv). */
    fun dotBar(lit: Int, total: Int, color: Int = 0xFFF4F4F4.toInt()): Bitmap {
        val step = 26
        val r = 8f
        val bmp = Bitmap.createBitmap(step * total, 24, Bitmap.Config.ARGB_8888)
        val cv = Canvas(bmp)
        val p = Paint(Paint.ANTI_ALIAS_FLAG)
        for (i in 0 until total) {
            p.color = if (i < lit) color else 0xFF333333.toInt()
            cv.drawCircle(i * step + 12f, 12f, r, p)
        }
        return bmp
    }

    /**
     * Pontmátrixos iránytű-rózsa: 24 pontból álló gyűrű; ha van irány, piros pont mutatja az északot
     * (a telefon tetejéhez képest), és pontsor vezet felé a középből.
     */
    fun compassRose(heading: Float?, size: Int = 240): Bitmap {
        val bmp = Bitmap.createBitmap(size, size, Bitmap.Config.ARGB_8888)
        val cv = Canvas(bmp)
        val p = Paint(Paint.ANTI_ALIAS_FLAG)
        val c = size / 2f
        val ringR = size * 0.42f
        val north = if (heading != null) Math.toRadians((-heading).toDouble()) else null
        for (k in 0 until 24) {
            val ang = Math.toRadians(k * 15.0)
            val x = c + ringR * Math.sin(ang).toFloat()
            val y = c - ringR * Math.cos(ang).toFloat()
            p.color = if (heading == null) 0xFF3A3A3A.toInt() else if (k % 6 == 0) 0xFF9A9A9A.toInt() else 0xFF4A4A4A.toInt()
            cv.drawCircle(x, y, size * 0.022f, p)
        }
        // Felső jel: a telefon teteje
        p.color = 0xFFEEEEEE.toInt()
        cv.drawCircle(c, c - ringR - size * 0.0f, size * 0.03f, p)
        if (north != null) {
            for (j in 1..4) {
                val rr = ringR * j / 5f
                p.color = 0xFFF4F4F4.toInt()
                cv.drawCircle(c + rr * Math.sin(north).toFloat(), c - rr * Math.cos(north).toFloat(), size * 0.025f, p)
            }
            p.color = 0xFFD71921.toInt()
            cv.drawCircle(c + ringR * Math.sin(north).toFloat(), c - ringR * Math.cos(north).toFloat(), size * 0.05f, p)
        }
        p.color = 0xFF6E6E6E.toInt()
        cv.drawCircle(c, c, size * 0.025f, p)
        return bmp
    }

    /**
     * Pontokból álló kör: [lit] világos (vagy [color]) pont felülről az óramutató irányában, a többi halvány.
     */
    fun dotRing(lit: Int, total: Int = LectureState.RING_DOTS, color: Int = 0xFFF4F4F4.toInt(), size: Int = 360): Bitmap {
        val bmp = Bitmap.createBitmap(size, size, Bitmap.Config.ARGB_8888)
        val cv = Canvas(bmp)
        val p = Paint(Paint.ANTI_ALIAS_FLAG)
        val c = size / 2f
        val r = size * 0.45f
        val dot = size * 0.021f
        for (k in 0 until total) {
            val ang = Math.toRadians(k * 360.0 / total)
            p.color = if (k < lit) color else 0xFF2E2E2E.toInt()
            cv.drawCircle(c + r * Math.sin(ang).toFloat(), c - r * Math.cos(ang).toFloat(), dot, p)
        }
        return bmp
    }

    // --- Kerek Előadás widget ---

    private fun lectureRingViews(c: Context): RemoteViews {
        val v = RemoteViews(c.packageName, R.layout.widget_lecture_ring)
        val running = GlyphMirror.mode.value == Feature.LECTURE
        val phase = if (running) LectureState.phase(c) else ""
        when (phase) {
            "LECTURE" -> {
                v.setImageViewBitmap(R.id.r_ring, dotRing(LectureState.ring(c)))
                v.setViewVisibility(R.id.r_big, View.GONE)
                v.setViewVisibility(R.id.r_chrono, View.VISIBLE)
                v.setChronometer(R.id.r_chrono, LectureState.totalEnd(c), null, true)
                v.setChronometerCountDown(R.id.r_chrono, true)
                v.setTextViewText(R.id.r_label, "${LectureState.block(c) + 1}/${LectureState.blocks(c)}. RÉSZ")
            }
            "BREAK" -> {
                v.setImageViewBitmap(R.id.r_ring, dotRing(LectureState.ring(c), color = 0xFFD71921.toInt()))
                v.setViewVisibility(R.id.r_big, View.GONE)
                v.setViewVisibility(R.id.r_chrono, View.VISIBLE)
                v.setChronometer(R.id.r_chrono, LectureState.breakEnd(c), null, true)
                v.setChronometerCountDown(R.id.r_chrono, true)
                v.setTextViewText(R.id.r_label, "SZÜNET")
            }
            "FILL" -> {
                v.setImageViewBitmap(R.id.r_ring, dotRing(0))
                v.setViewVisibility(R.id.r_chrono, View.GONE)
                v.setViewVisibility(R.id.r_big, View.VISIBLE)
                v.setTextViewText(R.id.r_big, "RÁZD!")
                v.setTextViewText(R.id.r_label, "TÖLTÉS")
            }
            else -> {
                v.setImageViewBitmap(R.id.r_ring, dotRing(0))
                v.setViewVisibility(R.id.r_chrono, View.GONE)
                v.setViewVisibility(R.id.r_big, View.VISIBLE)
                v.setTextViewText(R.id.r_big, if (running) "INDUL" else "START")
                v.setTextViewText(R.id.r_label, "${Settings.lectureBlocks(c)}×${Settings.lectureBlockMin(c)}")
            }
        }
        // Koppintás: ha nem fut, azonnal indul (rázás és lerakás nélkül); ha fut, az Előadás oldala nyílik
        // (onnan, a csempéről vagy a nagy widgetről állíthatod le – így egy véletlen érintés nem állítja le)
        v.setOnClickPendingIntent(
            android.R.id.background,
            if (running) activityIntent(c, LectureActivity::class.java, 852)
            else sourceIntent(c, SimonService.ACTION_LECTURE, 851, SimonService.SOURCE_INSTANT)
        )
        return v
    }

    // --- Előadás widget ---

    private fun lectureViews(c: Context): RemoteViews {
        val v = RemoteViews(c.packageName, R.layout.widget_lecture)
        val running = GlyphMirror.mode.value == Feature.LECTURE
        val phase = if (running) LectureState.phase(c) else ""
        val blocks = Settings.lectureBlocks(c)
        val blockMin = Settings.lectureBlockMin(c)
        val breakMin = Settings.lectureBreakMin(c)
        val now = SystemClock.elapsedRealtime()

        when (phase) {
            "LECTURE" -> {
                val b = LectureState.block(c)
                v.setTextViewText(R.id.l_status, "${b + 1}/${LectureState.blocks(c)}. RÉSZ")
                v.setViewVisibility(R.id.l_big, View.GONE)
                v.setViewVisibility(R.id.l_chrono, View.VISIBLE)
                v.setChronometer(R.id.l_chrono, LectureState.blockEnd(c), null, true)
                v.setChronometerCountDown(R.id.l_chrono, true)
                v.setViewVisibility(R.id.l_total, View.VISIBLE)
                v.setChronometer(R.id.l_total, LectureState.totalEnd(c), "Összesen még %s", true)
                v.setChronometerCountDown(R.id.l_total, true)
                v.setImageViewBitmap(R.id.l_bar, dotBar(LectureState.leds(c), 16))
                val cmd = Settings.lectureBreakCmd(c)
                v.setTextViewText(R.id.l_sub, if (cmd == BreakCommand.NONE) "Szünet: nincs parancs" else "Szünet: ${cmd.title.lowercase()}")
            }
            "BREAK" -> {
                v.setTextViewText(R.id.l_status, "SZÜNET")
                v.setViewVisibility(R.id.l_big, View.GONE)
                v.setViewVisibility(R.id.l_chrono, View.VISIBLE)
                v.setChronometer(R.id.l_chrono, LectureState.breakEnd(c), null, true)
                v.setChronometerCountDown(R.id.l_chrono, true)
                v.setViewVisibility(R.id.l_total, View.VISIBLE)
                // Az előadás ideje a szünet alatt áll: álló számláló
                v.setChronometer(R.id.l_total, now + LectureState.lectureLeft(c), "Utána: ${LectureState.block(c) + 1}. rész · még %s", false)
                v.setChronometerCountDown(R.id.l_total, true)
                v.setImageViewBitmap(R.id.l_bar, dotBar(LectureState.breakLeds(c), 8, 0xFFD71921.toInt()))
                v.setTextViewText(R.id.l_sub, if (Settings.lectureEarlyResume(c)) "Előbb folytatod: ${Settings.lectureBreakCmd(c).title.lowercase()}" else "A szünet végén magától folytatódik")
            }
            "FILL" -> {
                v.setTextViewText(R.id.l_status, "TÖLTÉS")
                v.setViewVisibility(R.id.l_chrono, View.GONE)
                v.setViewVisibility(R.id.l_total, View.GONE)
                v.setViewVisibility(R.id.l_big, View.VISIBLE)
                v.setTextViewText(R.id.l_big, "RÁZD!")
                v.setTextColor(R.id.l_big, 0xFFF4F4F4.toInt())
                v.setImageViewBitmap(R.id.l_bar, dotBar(0, 16))
                v.setTextViewText(R.id.l_sub, "Rázd, amíg minden LED ég – utána indul")
            }
            else -> {
                // Nem fut: nincs visszaszámlálás, csak a beállítás
                v.setTextViewText(R.id.l_status, "$blocks×$blockMin · $breakMin")
                v.setViewVisibility(R.id.l_chrono, View.GONE)
                v.setViewVisibility(R.id.l_total, View.GONE)
                v.setViewVisibility(R.id.l_big, View.VISIBLE)
                v.setTextViewText(R.id.l_big, if (running) "INDUL" else "KÉSZ")
                v.setTextColor(R.id.l_big, if (running) 0xFFF4F4F4.toInt() else 0xFF6E6E6E.toInt())
                v.setImageViewBitmap(R.id.l_bar, dotBar(0, 16))
                v.setTextViewText(R.id.l_sub,
                    if (Settings.listening(c, Feature.LECTURE)) "${Settings.trigger(c, Feature.LECTURE).title}, vagy START"
                    else "Nyomd meg: START – azonnal indul")
            }
        }

        // Figyelés gomb
        val trig = Settings.trigger(c, Feature.LECTURE)
        val listening = Settings.listening(c, Feature.LECTURE)
        val label = when {
            trig == Trigger.NONE -> "MOZDULAT…"
            trig == Trigger.SHAKE_FILL -> if (listening) "RÁZÁS: BE" else "RÁZÁS: KI"
            else -> if (listening) "FIGYEL: BE" else "FIGYEL: KI"
        }
        v.setTextViewText(R.id.l_watch, label)
        v.setInt(R.id.l_watch, "setBackgroundResource", if (listening) R.drawable.widget_dot_pill_on else R.drawable.widget_dot_pill)
        v.setTextColor(R.id.l_watch, if (listening) DARK else LIGHT)
        v.setOnClickPendingIntent(R.id.l_watch, armIntent(c, Feature.LECTURE, 800))

        // Start / Stop
        v.setTextViewText(R.id.l_btn, if (running) "STOP" else "START")
        v.setInt(R.id.l_btn, "setBackgroundResource", if (running) R.drawable.widget_dot_pill_red else R.drawable.widget_dot_pill_on)
        v.setTextColor(R.id.l_btn, if (running) LIGHT else DARK)
        v.setOnClickPendingIntent(R.id.l_btn, sourceIntent(c, SimonService.ACTION_LECTURE, 801, SimonService.SOURCE_INSTANT))
        v.setOnClickPendingIntent(android.R.id.background, activityIntent(c, LectureActivity::class.java, 802))
        return v
    }

    // --- Iránytű widget ---

    private fun compassViews(c: Context): RemoteViews {
        val v = RemoteViews(c.packageName, R.layout.widget_compass)
        val running = GlyphMirror.mode.value == Feature.COMPASS
        val heading = if (running) CompassState.heading(c) else null
        v.setImageViewBitmap(R.id.c_rose, compassRose(heading))
        when {
            heading != null -> {
                v.setTextViewText(R.id.c_big, "%d° %s".format(heading.toInt(), CompassState.cardinal(heading)))
                v.setTextColor(R.id.c_big, 0xFFF4F4F4.toInt())
                v.setTextViewText(R.id.c_sub, "A telefon teteje · piros pont = észak")
            }
            running -> {
                v.setTextViewText(R.id.c_big, "KERES")
                v.setTextColor(R.id.c_big, 0xFFF4F4F4.toInt())
                v.setTextViewText(R.id.c_sub, "Tedd le kijelzővel lefelé")
            }
            else -> {
                v.setTextViewText(R.id.c_big, "KÉSZ")
                v.setTextColor(R.id.c_big, 0xFF6E6E6E.toInt())
                v.setTextViewText(R.id.c_sub,
                    if (Settings.listening(c, Feature.COMPASS)) "${Settings.trigger(c, Feature.COMPASS).title}, vagy START"
                    else "Tedd le, és nyomd meg: START")
            }
        }
        val trig = Settings.trigger(c, Feature.COMPASS)
        val listening = Settings.listening(c, Feature.COMPASS)
        v.setTextViewText(R.id.c_watch, when {
            trig == Trigger.NONE -> "MOZDULAT…"
            listening -> "FIGYEL BE"
            else -> "FIGYEL KI"
        })
        v.setInt(R.id.c_watch, "setBackgroundResource", if (listening) R.drawable.widget_dot_pill_on else R.drawable.widget_dot_pill)
        v.setTextColor(R.id.c_watch, if (listening) DARK else LIGHT)
        v.setOnClickPendingIntent(R.id.c_watch, armIntent(c, Feature.COMPASS, 900))
        v.setTextViewText(R.id.c_btn, if (running) "STOP" else "START")
        v.setInt(R.id.c_btn, "setBackgroundResource", if (running) R.drawable.widget_dot_pill_red else R.drawable.widget_dot_pill_on)
        v.setTextColor(R.id.c_btn, if (running) LIGHT else DARK)
        v.setOnClickPendingIntent(R.id.c_btn, serviceIntent(c, SimonService.ACTION_COMPASS, 901, fromWidget = true))
        v.setOnClickPendingIntent(android.R.id.background, PendingIntent.getActivity(
            c, 902,
            Intent(c, InfoActivity::class.java).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                .putExtra(InfoActivity.EXTRA_FEATURE, Feature.COMPASS.name),
            PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT
        ))
        return v
    }
}

/** Gyorsindító sáv: 4 választható funkció + Mozdulatfigyelés kapcsoló. */
class QuickBarWidget : AppWidgetProvider() {
    override fun onUpdate(context: Context, manager: AppWidgetManager, ids: IntArray) = Widgets.updateBar(context, ids)
    override fun onDeleted(context: Context, ids: IntArray) = Widgets.forget(context, ids)
}

/** Egygombos widget egy választott funkcióhoz. */
class FeatureWidget : AppWidgetProvider() {
    override fun onUpdate(context: Context, manager: AppWidgetManager, ids: IntArray) = Widgets.updateSingle(context, ids)
    override fun onDeleted(context: Context, ids: IntArray) = Widgets.forget(context, ids)
}

/** Glyph Tojás: portré, állapotsávok, gyors gondozás. */
class PetWidget : AppWidgetProvider() {
    override fun onUpdate(context: Context, manager: AppWidgetManager, ids: IntArray) = Widgets.updatePet(context, ids)
}

/** Előadás: rázásfigyelés be/ki, azonnali indítás, hátralévő idő és szünet (pontmátrixos). */
class LectureWidget : AppWidgetProvider() {
    override fun onUpdate(context: Context, manager: AppWidgetManager, ids: IntArray) = Widgets.updateLecture(context, ids)
}

/** Kerek Előadás: pontokból álló kör, koppintásra indul; a kör és a közepe mutatja a hátralévő időt. */
class LectureRingWidget : AppWidgetProvider() {
    override fun onUpdate(context: Context, manager: AppWidgetManager, ids: IntArray) = Widgets.updateLectureRing(context, ids)
}

/** Iránytű: figyelés be/ki, indítás, élő irány (pontmátrixos). */
class CompassWidget : AppWidgetProvider() {
    override fun onUpdate(context: Context, manager: AppWidgetManager, ids: IntArray) = Widgets.updateCompass(context, ids)
}

/** Időzítő: visszaszámlálás, indítás / leállítás. */
class TimerWidget : AppWidgetProvider() {
    override fun onUpdate(context: Context, manager: AppWidgetManager, ids: IntArray) = Widgets.updateTimer(context, ids)
}

/** Widget-gombok, amikhez nem kell a szolgáltatás (Tojás gondozása). */
class WidgetActionReceiver : BroadcastReceiver() {
    companion object {
        const val ACTION_PET = "com.akos.glypheggs.WIDGET_PET"
    }

    override fun onReceive(context: Context, intent: Intent) {
        if (intent.action != ACTION_PET) return
        val a = PetAction.entries.firstOrNull { it.name == intent.getStringExtra("act") } ?: return
        val msg = PetStore.act(context, a)
        DebugState.log("Tojás (widget): ${a.title} – $msg")
        Widgets.updatePet(context)
    }
}
