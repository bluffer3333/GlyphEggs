package com.akos.glypheggs

import android.Manifest
import android.app.Activity
import android.app.AlertDialog
import android.app.StatusBarManager
import android.content.ComponentName
import android.content.Intent
import android.content.pm.PackageManager
import android.graphics.Typeface
import android.graphics.drawable.Icon
import android.net.Uri
import android.os.Bundle
import android.os.PowerManager
import android.os.SystemClock
import android.provider.Settings as AndroidSettings
import android.view.Gravity
import android.view.ViewGroup.LayoutParams.MATCH_PARENT
import android.view.ViewGroup.LayoutParams.WRAP_CONTENT
import android.view.View
import android.widget.FrameLayout
import android.widget.HorizontalScrollView
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView
import android.widget.Toast
import kotlinx.coroutines.Job
import kotlinx.coroutines.MainScope
import kotlinx.coroutines.cancel
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch

/**
 * Főképernyő a Nothing Glyph Interface beállításainak stílusában, fülekkel:
 *  - Főoldal: a kitűzött funkciók (testreszabható; hosszú nyomás = kitűzés / levétel)
 *  - Játékok: Simon, Zárfeltörő, Glyph Tojás, Egyensúly
 *  - Eszközök: Pörgetés, Iránytű, Széf, Vízmérték, Időzítő
 *  - Akku: mennyit fogyaszt az app – funkciónként, táblázatban, becsléssel és méréssel
 *  - Beállítások: indítás és leállítás, csempék, háttérfutás, rezgés, diagnosztika
 * A LED-szimuláció a Beállítások fülön van (vagy dupla koppintás a "Glyph Eggs" címre).
 */
class MainActivity : Activity() {

    private val scope = MainScope()

    private lateinit var preview: GlyphMapView
    private lateinit var modeLabel: TextView
    private lateinit var statusText: TextView
    private lateinit var runningCard: FeatureCard
    private lateinit var againCard: FeatureCard
    private lateinit var watchToggle: ToggleView
    private lateinit var watchSub: TextView
    private lateinit var content: LinearLayout
    private val tabViews = mutableListOf<TextView>()
    private val cards = mutableMapOf<Feature, FeatureCard>()
    private var sensorText: TextView? = null
    private var logText: TextView? = null
    private var lastTitleTap = 0L
    private var energyDays = 1
    private var liveJob: Job? = null

    private val tabNames = listOf("Főoldal", "Játékok", "Eszközök", "Akku", "Beállítások")

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        darkWindow()
        PetAlarmReceiver.schedule(this)

        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(15), 0, dp(15), dp(24))
        }
        val scroll = ScrollView(this).apply {
            setBackgroundColor(Ui.BG)
            isVerticalScrollBarEnabled = false
            addView(root, FrameLayout.LayoutParams(MATCH_PARENT, WRAP_CONTENT))
            padForSystemBars()
        }
        setContentView(scroll)

        // --- Cím (dupla koppintás → szimuláció) ---
        root.addView(text("Glyph Eggs", 35f, Ui.TEXT, Ui.light).apply {
            setPadding(dp(7), dp(56), 0, 0)
            setOnClickListener {
                val now = SystemClock.uptimeMillis()
                if (now - lastTitleTap < 400) {
                    lastTitleTap = 0L
                    startActivity(Intent(this@MainActivity, SimulatorActivity::class.java))
                } else {
                    lastTitleTap = now
                }
            }
        })
        statusText = text("", 13f, Ui.SUB).apply { setPadding(dp(8), dp(4), dp(8), dp(20)) }
        root.addView(statusText)

        // --- Felső rész: élő Glyph-kép + "most fut" + szimuláció ---
        root.addView(buildTop(), LinearLayout.LayoutParams(MATCH_PARENT, dp(300)))

        // --- Mozdulatfigyelés ---
        root.addView(buildWatchBar(), LinearLayout.LayoutParams(MATCH_PARENT, dp(78)).apply { topMargin = dp(16) })

        // --- Fülek ---
        val tabs = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
        tabNames.forEachIndexed { i, name ->
            val t = text(name, 12.5f).apply {
                maxLines = 1
                gravity = Gravity.CENTER
                setOnClickListener {
                    Settings.setTab(this@MainActivity, i)
                    renderTab()
                }
            }
            tabViews += t
            tabs.addView(t, LinearLayout.LayoutParams(0, dp(42), 1f).apply {
                marginStart = dp(2)
                marginEnd = dp(2)
            })
        }
        root.addView(tabs, LinearLayout.LayoutParams(MATCH_PARENT, WRAP_CONTENT).apply { topMargin = dp(18) })

        content = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        root.addView(content, LinearLayout.LayoutParams(MATCH_PARENT, WRAP_CONTENT))

        // --- Élő adatok ---
        scope.launch { GlyphMirror.lit.collect { preview.lit = it } }
        scope.launch { GlyphMirror.mode.collect { updateMode(it) } }
        scope.launch { DebugState.status.collect { statusText.text = it } }
        scope.launch { DebugState.sensor.collect { sensorText?.text = it } }
        scope.launch { DebugState.log.collect { lines -> logText?.text = lines.takeLast(8).reversed().joinToString("\n") } }

        if (checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED) {
            requestPermissions(arrayOf(Manifest.permission.POST_NOTIFICATIONS), 1)
        }
    }

    override fun onResume() {
        super.onResume()
        GlyphMirror.appVisible = true
        // Ha be volt kapcsolva a figyelés, de a rendszer leállította, újraindítjuk
        if (Settings.watching(this) && !SimonService.watching) send(SimonService.ACTION_WATCH_ON)
        val on = Settings.watching(this)
        watchToggle.checked = on
        watchSub.text = watchText(on)
        renderTab()
    }

    override fun onPause() {
        super.onPause()
        GlyphMirror.appVisible = false
        liveJob?.cancel()
    }

    // ------------------------------------------------------------------ felső rész

    private fun buildTop(): LinearLayout {
        val top = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }

        val previewBox = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            background = rounded(Ui.BG, dp(22).toFloat(), Ui.LINE, dp(1.5f))
            setPadding(dp(10), dp(14), dp(10), dp(10))
        }
        preview = GlyphMapView(this).apply { idleAllOn = true }
        previewBox.addView(preview, LinearLayout.LayoutParams(MATCH_PARENT, 0, 1f))
        val pill = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
            background = rounded(Ui.CARD, dp(18).toFloat())
            setPadding(dp(4), 0, dp(8), 0)
        }
        val dot = FrameLayout(this).apply { background = rounded(0xFFE8E8E8.toInt(), dp(14).toFloat()) }
        dot.addView(ImageView(this).apply { setImageResource(R.drawable.ic_glyph_small) },
            FrameLayout.LayoutParams(dp(16), dp(16), Gravity.CENTER))
        pill.addView(dot, LinearLayout.LayoutParams(dp(28), dp(28)))
        modeLabel = text("Készenlét", 12f, Ui.SUB).apply { setPadding(dp(10), 0, 0, 0) }
        pill.addView(modeLabel)
        previewBox.addView(pill, LinearLayout.LayoutParams(MATCH_PARENT, dp(36)).apply { topMargin = dp(8) })

        val right = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        runningCard = FeatureCard(this, R.drawable.ic_bolt, "Most fut", "Semmi", false)
        runningCard.setOnClickListener {
            val m = GlyphMirror.mode.value
            if (m != null) send(SimonService.actionFor(m))
        }
        // "Újra": az utoljára használt funkció egy koppintással
        againCard = FeatureCard(this, R.drawable.ic_spin, "Újra", "", false)
        againCard.setOnClickListener { Settings.lastFeature(this)?.let { openFeature(it) } }
        right.addView(runningCard, LinearLayout.LayoutParams(MATCH_PARENT, 0, 1f).apply { bottomMargin = dp(2.5f) })
        right.addView(againCard, LinearLayout.LayoutParams(MATCH_PARENT, 0, 1f).apply { topMargin = dp(2.5f) })

        top.addView(previewBox, LinearLayout.LayoutParams(0, MATCH_PARENT, 1f).apply { marginEnd = dp(2.5f) })
        top.addView(right, LinearLayout.LayoutParams(0, MATCH_PARENT, 1f).apply { marginStart = dp(2.5f) })
        return top
    }

    private fun watchText(on: Boolean) =
        if (on) "Bekapcsolva · a mozdulatok indítják a funkciókat" else "Kikapcsolva · csak kártyával és csempével"

    private fun buildWatchBar(): LinearLayout {
        val bar = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
            background = rounded(Ui.LIGHT, dp(22).toFloat())
            setPadding(dp(20), 0, dp(16), 0)
        }
        val texts = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        texts.addView(text("Mozdulatfigyelés", 17.5f, Ui.DARK_TEXT))
        watchSub = text("", 12f, 0xFF555555.toInt())
        texts.addView(watchSub)
        bar.addView(texts, LinearLayout.LayoutParams(0, WRAP_CONTENT, 1f))
        watchToggle = ToggleView(this).apply {
            onColor = 0xFFFFFFFF.toInt()
            onChange = { on -> setWatching(on) }
        }
        bar.addView(watchToggle)
        bar.setOnClickListener { watchToggle.performClick() }
        return bar
    }

    // ------------------------------------------------------------------ fülek

    private fun renderTab() {
        val tab = Settings.tab(this).coerceIn(0, tabNames.size - 1)
        tabViews.forEachIndexed { i, t ->
            val sel = i == tab
            t.background = rounded(if (sel) Ui.LIGHT else Ui.CARD, dp(21).toFloat())
            t.setTextColor(if (sel) Ui.DARK_TEXT else Ui.TEXT)
        }
        content.removeAllViews()
        liveJob?.cancel()
        liveJob = null
        cards.clear()
        sensorText = null
        logText = null
        when (tab) {
            0 -> renderHome()
            1 -> renderFeatures(Feature.entries.filter { it.game }, "Játékok")
            2 -> renderTools()
            3 -> renderEnergy()
            else -> renderSettings()
        }
        updateMode(GlyphMirror.mode.value)
    }

    private fun addGrid(list: List<FeatureCard>, heightDp: Int = 160) {
        for (pair in list.chunked(2)) content.addView(row(pair[0], pair.getOrNull(1), heightDp))
    }

    private fun renderHome() {
        val pinned = Settings.pinned(this)
        content.addView(sectionTitle("Kitűzött funkciók"))
        val list = pinned.map { featureCard(it) }.toMutableList()
        list += FeatureCard(this, R.drawable.ic_settings, "Testreszabás", "Mi legyen a Főoldalon", false).apply {
            setOnClickListener { customizeHome() }
        }
        addGrid(list)
        content.addView(text("Tipp: bármelyik kártyát hosszan nyomva kitűzheted vagy leveheted. Az „i” gomb részletes súgót nyit.",
            12.5f, Ui.SUB).apply { setPadding(dp(8), dp(10), dp(8), 0); setLineSpacing(0f, 1.2f) })
    }

    private fun renderFeatures(list: List<Feature>, title: String) {
        content.addView(sectionTitle(title))
        addGrid(list.map { featureCard(it) })
    }

    private fun renderTools() {
        content.addView(sectionTitle("Eszközök"))
        addGrid(Feature.entries.filter { !it.game }.map { featureCard(it) })
        content.addView(sectionTitle("Eszközök beállítása"))
        val safeSetup = FeatureCard(this, R.drawable.ic_settings, "Széf beállítása", "Kód és titkos cél", false)
        safeSetup.setOnClickListener { startActivity(Intent(this, SafeActivity::class.java)) }
        val timerSetup = FeatureCard(this, R.drawable.ic_settings, "Időzítő beállítása", "Fajta, percek, animáció", false)
        timerSetup.setOnClickListener { startActivity(Intent(this, TimerActivity::class.java)) }
        content.addView(row(safeSetup, timerSetup, 150))
    }

    private fun renderSettings() {
        content.addView(sectionTitle("Indítás és leállítás"))
        val g = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            background = rounded(Ui.CARD, dp(22).toFloat())
            setPadding(dp(16), dp(18), dp(16), dp(16))
            setOnClickListener { openGestures(Feature.SIMON) }
        }
        g.addView(icon(R.drawable.ic_gesture))
        g.addView(text("Mi indít és mi állít le", 19f).apply { setPadding(0, dp(18), 0, dp(8)) })
        g.addView(text(Feature.entries.joinToString("\n") { f ->
            "${f.title}:  ${Settings.trigger(this, f).title}  ·  leáll: ${Settings.stopSummary(this, f)}"
        }, 13.5f, Ui.SUB).apply { setLineSpacing(0f, 1.35f) })
        g.addView(text("Koppints a módosításhoz", 12f, Ui.SUB).apply { setPadding(0, dp(10), 0, 0) })
        content.addView(g)

        content.addView(sectionTitle("Rendszer"))
        val tilesCard = FeatureCard(this, R.drawable.ic_tiles, "Csempék", "Válaszd ki, mi kerüljön a lehúzható menübe", false)
        tilesCard.setOnClickListener { chooseTiles() }
        val pm = getSystemService(PowerManager::class.java)
        val exempt = pm.isIgnoringBatteryOptimizations(packageName)
        val batteryCard = FeatureCard(this, R.drawable.ic_battery, "Háttérfutás",
            if (exempt) "Akkuoptimalizálás kikapcsolva" else "Koppints: ne állítsa le a rendszer", true)
        batteryCard.toggle?.checked = exempt
        batteryCard.setOnClickListener { askBatteryExemption() }
        batteryCard.toggle?.onChange = { askBatteryExemption() }
        content.addView(row(tilesCard, batteryCard, 160))
        val vibrateCard = FeatureCard(this, R.drawable.ic_vibrate, "Rezgés", "Visszajelzés, édes pont, győzelem", true)
        vibrateCard.toggle?.checked = Settings.vibrate(this)
        vibrateCard.toggle?.onChange = { on -> Settings.setVibrate(this, on) }
        val simCard = FeatureCard(this, R.drawable.ic_eye, "LED-szimuláció", "A LED-ek a képernyőn", false)
        simCard.setOnClickListener { startActivity(Intent(this, SimulatorActivity::class.java)) }
        content.addView(row(vibrateCard, simCard, 160))
        val widgetCard = FeatureCard(this, R.drawable.ic_tiles, "Widgetek", "Kezdőképernyőre: sáv, egy gomb, Tojás, Időzítő", false)
        widgetCard.setOnClickListener { chooseWidget() }
        content.addView(row(widgetCard, null, 160))

        content.addView(sectionTitle("Diagnosztika"))
        val card = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            background = rounded(Ui.CARD, dp(22).toFloat())
            setPadding(dp(16), dp(18), dp(16), dp(16))
        }
        card.addView(icon(R.drawable.ic_pulse))
        card.addView(text("Élő szenzoradatok", 19f).apply { setPadding(0, dp(18), 0, dp(10)) })
        val s = monoBox().also { it.text = DebugState.sensor.value }
        sensorText = s
        card.addView(s)
        card.addView(text("Napló", 15f).apply { setPadding(0, dp(16), 0, dp(8)) })
        val l = monoBox().also { it.text = DebugState.log.value.takeLast(8).reversed().joinToString("\n") }
        logText = l
        card.addView(l)
        content.addView(card)

        val note = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            setPadding(dp(9), dp(24), dp(9), dp(12))
        }
        note.addView(icon(R.drawable.ic_info, 22))
        note.addView(text(
            "A villogó Glyph-animációk nem biztonságosak epilepsziások és más fényérzékeny állapotban lévők számára.\n\n" +
                "Tipp: koppints kétszer a „Glyph Eggs” címre, és a képernyőn is látod, mit csinálnak a LED-ek.",
            12.5f, Ui.SUB
        ).apply { setPadding(dp(12), 0, 0, 0); setLineSpacing(0f, 1.2f) })
        content.addView(note)
    }

    // ------------------------------------------------------------------ Akku fül

    private fun mah(v: Double): String = when {
        v <= 0.0 -> "–"
        v < 0.01 -> "<0,01"
        v < 10 -> "%.2f".format(v)
        else -> "%.1f".format(v)
    }

    private fun pct(v: Double): String = when {
        v <= 0.0 -> "–"
        v < 0.01 -> "<0,01%"
        else -> "%.2f%%".format(v)
    }

    private fun dur(ms: Long): String {
        if (ms <= 0) return "–"
        val s = ms / 1000
        return when {
            s < 60 -> "$s mp"
            s < 3600 -> "${s / 60} p ${s % 60} mp"
            else -> "${s / 3600} ó ${(s % 3600) / 60} p"
        }
    }

    private fun keyTitle(k: String): String =
        if (k == EnergyMeter.WATCH) "Háttérfigyelés" else Feature.entries.firstOrNull { it.name == k }?.title ?: k

    private fun renderEnergy() {
        val data = EnergyMeter.load(this, energyDays)
        val cap = EnergyMeter.batteryMah(this)
        val keys = Feature.entries.map { it.name } + EnergyMeter.WATCH
        val rows = keys.map { it to (data[it] ?: EnergyMeter.Row()) }
        val total = EnergyMeter.Row().also { t -> rows.forEach { t.add(it.second) } }
        val periodName = when (energyDays) { 1 -> "ma"; 7 -> "az elmúlt 7 napban"; else -> "az elmúlt 30 napban" }

        content.addView(sectionTitle("Fogyasztás"))

        // Időszak
        val pills = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
        for ((days, label) in listOf(1 to "Ma", 7 to "7 nap", 30 to "30 nap")) {
            val sel = days == energyDays
            pills.addView(text(label, 14f, if (sel) Ui.DARK_TEXT else Ui.TEXT).apply {
                gravity = Gravity.CENTER
                background = rounded(if (sel) Ui.LIGHT else Ui.CARD, dp(22).toFloat())
                setOnClickListener {
                    energyDays = days
                    renderTab()
                }
            }, LinearLayout.LayoutParams(0, dp(44), 1f).apply { marginEnd = dp(5) })
        }
        content.addView(pills)

        // Összesítő
        val sum = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            background = rounded(Ui.CARD, dp(22).toFloat())
            setPadding(dp(18), dp(18), dp(18), dp(18))
        }
        sum.addView(icon(R.drawable.ic_battery))
        sum.addView(text("≈ ${mah(total.totalMah)} mAh", 34f, Ui.TEXT, Ui.light).apply { setPadding(0, dp(14), 0, 0) })
        sum.addView(text("Az akku ${pct(total.totalMah / cap * 100)}-a $periodName · ${dur(total.ms)} működés · akku: ${cap.toInt()} mAh",
            13f, Ui.SUB).apply { setPadding(0, dp(2), 0, dp(14)); setLineSpacing(0f, 1.2f) })
        val led = rows.sumOf { it.second.ledMah }
        val sens = rows.filter { it.first != EnergyMeter.WATCH }.sumOf { it.second.sensMah }
        val watch = data[EnergyMeter.WATCH]?.totalMah ?: 0.0
        val stats = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
        for ((label, v) in listOf("LED-ek" to led, "Szenzor + CPU" to sens, "Háttérfigyelés" to watch)) {
            val col = LinearLayout(this).apply {
                orientation = LinearLayout.VERTICAL
                background = rounded(0xFF242424.toInt(), dp(14).toFloat())
                setPadding(dp(10), dp(10), dp(8), dp(10))
            }
            col.addView(text("${mah(v)} mAh", 15f, Ui.TEXT, Ui.medium))
            col.addView(text(label, 11.5f, Ui.SUB))
            stats.addView(col, LinearLayout.LayoutParams(0, WRAP_CONTENT, 1f).apply { marginEnd = dp(5) })
        }
        sum.addView(stats)
        content.addView(sum, LinearLayout.LayoutParams(MATCH_PARENT, WRAP_CONTENT).apply { topMargin = dp(10) })

        // Élő
        content.addView(sectionTitle("Most"))
        val live = text("–", 13.5f, Ui.SUB).apply {
            background = rounded(Ui.CARD, dp(22).toFloat())
            setPadding(dp(18), dp(16), dp(18), dp(16))
            setLineSpacing(0f, 1.3f)
        }
        content.addView(live)
        liveJob = scope.launch {
            while (true) {
                val mode = GlyphMirror.mode.value
                val est = EnergyMeter.liveMa()
                val ledNow = EnergyMeter.liveLedMa()
                val measured = EnergyMeter.measureNow(this@MainActivity)
                val head = when {
                    mode != null -> "${mode.title} fut"
                    SimonService.watching -> "Háttérfigyelés (semmi nem fut)"
                    else -> "Semmi nem fut, a figyelés ki van kapcsolva"
                }
                live.text = head + "\n" +
                    "Becsült: %.1f mA  (LED %.1f + szenzor/CPU %.1f)".format(est, ledNow, est - ledNow) +
                    (if (est > 0) "  ·  óránként ≈ %.2f%% akku".format(est / cap * 100) else "") + "\n" +
                    (if (measured != null) "A telefon most összesen: %.0f mA (képernyővel, mindennel)".format(measured)
                    else "A telefon mért árama most nem olvasható (pl. tölt)")
                delay(1000)
            }
        }

        // Arányok
        val used = rows.filter { it.second.totalMah > 0 }.sortedByDescending { it.second.totalMah }
        if (used.isNotEmpty()) {
            content.addView(sectionTitle("Mi fogyasztott a legtöbbet"))
            val box = LinearLayout(this).apply {
                orientation = LinearLayout.VERTICAL
                background = rounded(Ui.CARD, dp(22).toFloat())
                setPadding(dp(18), dp(14), dp(18), dp(14))
            }
            val max = used.first().second.totalMah
            for ((k, r) in used) {
                val line = LinearLayout(this).apply {
                    orientation = LinearLayout.HORIZONTAL
                    gravity = Gravity.CENTER_VERTICAL
                    setPadding(0, dp(5), 0, dp(5))
                }
                line.addView(text(keyTitle(k), 13f), LinearLayout.LayoutParams(dp(112), WRAP_CONTENT))
                val track = FrameLayout(this).apply { background = rounded(0xFF3A3A3A.toInt(), dp(4).toFloat()) }
                val frac = (r.totalMah / max).toFloat().coerceIn(0.03f, 1f)
                val barRow = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
                barRow.addView(View(this).apply {
                    background = rounded(if (k == used.first().first) Ui.RED else Ui.LIGHT, dp(4).toFloat())
                }, LinearLayout.LayoutParams(0, MATCH_PARENT, frac))
                barRow.addView(View(this), LinearLayout.LayoutParams(0, MATCH_PARENT, 1f - frac + 0.0001f))
                track.addView(barRow, FrameLayout.LayoutParams(MATCH_PARENT, MATCH_PARENT))
                line.addView(track, LinearLayout.LayoutParams(0, dp(8), 1f))
                line.addView(text("${mah(r.totalMah)} mAh", 12.5f, Ui.SUB).apply { gravity = Gravity.END },
                    LinearLayout.LayoutParams(dp(78), WRAP_CONTENT))
                box.addView(line)
            }
            content.addView(box)
        }

        // Táblázat
        content.addView(sectionTitle("Táblázat"))
        val cols = listOf(
            "Funkció" to 118, "Indítás" to 58, "Idő" to 84, "LED mAh" to 70, "Szenzor+CPU mAh" to 118,
            "Össz. mAh" to 78, "Akku %" to 66, "Átl. mA" to 64, "Telefon mért mA" to 116
        )
        val table = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(14), dp(10), dp(14), dp(10))
        }
        fun tableRow(values: List<String>, header: Boolean = false, bold: Boolean = false, shade: Boolean = false) {
            val r = LinearLayout(this).apply {
                orientation = LinearLayout.HORIZONTAL
                gravity = Gravity.CENTER_VERTICAL
                setPadding(0, dp(9), 0, dp(9))
                if (shade) background = rounded(0xFF333333.toInt(), dp(10).toFloat())
            }
            values.forEachIndexed { i, v ->
                r.addView(text(v, if (header) 11.5f else 13f, if (header) Ui.SUB else Ui.TEXT,
                    if (bold || header) Ui.medium else Ui.regular).apply {
                    gravity = if (i == 0) Gravity.START else Gravity.END
                    setPadding(dp(6), 0, dp(6), 0)
                    maxLines = 1
                }, LinearLayout.LayoutParams(dp(cols[i].second), WRAP_CONTENT))
            }
            table.addView(r)
            if (!shade) table.addView(View(this).apply { setBackgroundColor(Ui.LINE) },
                LinearLayout.LayoutParams(MATCH_PARENT, 1))
        }
        fun cells(title: String, r: EnergyMeter.Row): List<String> = listOf(
            title,
            if (r.runs > 0) "${r.runs}" else "–",
            dur(r.ms),
            mah(r.ledMah),
            mah(r.sensMah),
            mah(r.totalMah),
            pct(r.totalMah / cap * 100),
            if (r.ms > 0) "%.1f".format(r.avgMa) else "–",
            r.measAvgMa?.let { "%.0f".format(it) } ?: "–"
        )
        tableRow(cols.map { it.first }, header = true)
        for ((k, r) in rows) tableRow(cells(keyTitle(k), r))
        tableRow(cells("Összesen", total).toMutableList().also { it[8] = "" }, bold = true, shade = true)
        val hs = HorizontalScrollView(this).apply {
            isHorizontalScrollBarEnabled = false
            background = rounded(Ui.CARD, dp(22).toFloat())
            addView(table)
        }
        content.addView(hs)
        content.addView(text("← A táblázat oldalra görgethető →", 11.5f, Ui.SUB).apply {
            gravity = Gravity.CENTER
            setPadding(0, dp(6), 0, 0)
        })

        // Magyarázat
        content.addView(sectionTitle("Hogyan számol?"))
        val how = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            background = rounded(Ui.CARD, dp(22).toFloat())
            setPadding(dp(18), dp(14), dp(18), dp(14))
        }
        for (line in listOf(
            "Becslés: minden pillanatban összeadja az épp égő LED-eket és a bekapcsolt szenzorokat, és megszorozza az időtartammal.",
            "LED: nagy zóna (kamera, ferde csík, ívek) ≈ ${Config.LED_BIG_MA.toInt()} mA, kis LED (felső sáv, függőleges vonal, pont) ≈ ${Config.LED_SMALL_MA.toInt()} mA. Az összes LED egyszerre ≈ 170 mA.",
            "Szenzor + CPU: játék közben ≈ ${Config.SENSOR_GAME_MA.toInt()} mA, kopogásfigyelés ≈ ${Config.SENSOR_KNOCK_MA.toInt()} mA, giroszkóp ≈ ${Config.SENSOR_GYRO_MA.toInt()} mA, alap készenlét ≈ ${Config.SENSOR_LOW_MA} mA.",
            "Akku %: a becsült mAh az akku kapacitásához képest (${cap.toInt()} mAh – a telefon töltésszámlálójából, ha megadja).",
            "Telefon mért mA: futás közben 5 mp-enként leolvasott teljes áramfelvétel. Ebben a képernyő, a rádiók és minden más app is benne van, ezért nagyobb – tájékoztató érték. Töltés közben nem mér.",
            "A becsült értékek tájékoztatók: a valódi LED-áram a fényerőtől és a telefon beállításaitól is függ (a Config.kt-ban hangolható)."
        )) {
            how.addView(text("•  $line", 12.5f, Ui.SUB).apply { setPadding(0, dp(4), 0, dp(4)); setLineSpacing(0f, 1.2f) })
        }
        content.addView(how)

        val reset = FeatureCard(this, R.drawable.ic_stop, "Statisztika törlése", "Minden mért és becsült adat", false)
        reset.setOnClickListener {
            AlertDialog.Builder(this, android.R.style.Theme_DeviceDefault_Dialog_Alert)
                .setTitle("Törlöd a fogyasztási statisztikát?")
                .setPositiveButton("Törlés") { _, _ ->
                    EnergyMeter.reset(this)
                    renderTab()
                }
                .setNegativeButton("Mégse", null)
                .show()
        }
        content.addView(row(reset, null, 130).apply { (layoutParams as LinearLayout.LayoutParams).topMargin = dp(10) })
    }

    private fun monoBox(): TextView = text("–", 11f, 0xFFCFCFCF.toInt(), Typeface.MONOSPACE).apply {
        background = rounded(0xFF242424.toInt(), dp(12).toFloat())
        setPadding(dp(12), dp(10), dp(12), dp(10))
        setLineSpacing(0f, 1.25f)
    }

    // ------------------------------------------------------------------ funkció-kártyák

    private fun featureCard(f: Feature): FeatureCard {
        val card = FeatureCard(this, f.icon, f.title, subtitle(f, GlyphMirror.mode.value), false)
        card.addInfo { openInfo(f) }
        card.setOnClickListener { openFeature(f) }
        card.setOnLongClickListener {
            val pinned = Settings.togglePinned(this, f)
            Toast.makeText(this, if (pinned) "${f.title} kitűzve a Főoldalra" else "${f.title} levéve a Főoldalról", Toast.LENGTH_SHORT).show()
            if (Settings.tab(this) == 0) renderTab()
            true
        }
        cards[f] = card
        return card
    }

    private fun subtitle(f: Feature, mode: Feature?): String {
        if (mode == f) return "Fut · koppints a leállításhoz"
        return when (f) {
            Feature.SIMON -> {
                val lvl = Settings.lastLevel(this)
                if (lvl < 0) "Dönts a fény után" else "Legutóbb: $lvl/${Config.MAX_ROUNDS} szint"
            }
            Feature.SPIN -> "Koppints, tedd le"
            Feature.COMPASS -> "Északkeresés fekve"
            Feature.LOCKPICK -> {
                val best = Settings.lockBest(this)
                if (best > 0) "Legjobb: $best/${Config.LOCK_PINS} · kopogj a rezzenésre" else "Kopogj, amikor rezzen"
            }
            Feature.SAFE -> "Rázd be a titkos kódot"
            Feature.PET -> {
                val pet = PetStore.load(this)
                if (pet.stage == PetStage.EGG) "Még tojás – gondozd!"
                else "${pet.stage.title}, ${pet.mood.title.lowercase()}" + (pet.need()?.let { " · $it" } ?: "")
            }
            Feature.LEVEL -> "Fekve, élére vagy portra állítva"
            Feature.TIMER -> {
                val m = Settings.timerMode(this)
                (if (m.custom) "${m.title}, ${Settings.timerMinutes(this)} perc" else m.title) + " · ${Settings.timerStyle(this).title}"
            }
            Feature.BALANCE -> {
                val best = Settings.balanceBest(this)
                if (best > 0) "Legjobb: $best mp · dönts!" else "Tartsd a pontot döntéssel"
            }
            Feature.DINO -> {
                val best = Settings.dinoBest(this)
                if (best > 0) "Rekord: $best · kopogj = ugrás" else "Kopogj = ugrás, madár fölött ne!"
            }
        }
    }

    private fun openFeature(f: Feature) {
        if (f == Feature.PET) startActivity(Intent(this, PetActivity::class.java))
        else send(SimonService.actionFor(f))
    }

    private fun openInfo(f: Feature) {
        startActivity(Intent(this, InfoActivity::class.java).putExtra(InfoActivity.EXTRA_FEATURE, f.name))
    }

    private fun customizeHome() {
        val all = Feature.entries
        val pinned = Settings.pinned(this)
        val checked = BooleanArray(all.size) { all[it] in pinned }
        AlertDialog.Builder(this, android.R.style.Theme_DeviceDefault_Dialog_Alert)
            .setTitle("Mi legyen a Főoldalon?")
            .setMultiChoiceItems(all.map { it.title }.toTypedArray(), checked) { _, which, isChecked -> checked[which] = isChecked }
            .setPositiveButton("Mentés") { _, _ ->
                Settings.setPinned(this, all.filterIndexed { i, _ -> checked[i] })
                renderTab()
            }
            .setNegativeButton("Mégse", null)
            .show()
    }

    private fun updateMode(mode: Feature?) {
        preview.active = mode != null
        modeLabel.text = mode?.title ?: "Készenlét"
        modeLabel.setTextColor(if (mode != null) Ui.TEXT else Ui.SUB)
        modeLabel.typeface = if (mode != null) Ui.medium else Ui.regular
        runningCard.subtitleView.text = if (mode != null) "${mode.title} · koppints a leállításhoz" else "Semmi"
        val last = Settings.lastFeature(this)
        againCard.subtitleView.text = last?.title ?: "Még semmit nem indítottál"
        for ((f, card) in cards) card.subtitleView.text = subtitle(f, mode)
    }

    // ------------------------------------------------------------------ műveletek

    private fun setWatching(on: Boolean) {
        Settings.setWatching(this, on)
        if (on) {
            send(SimonService.ACTION_WATCH_ON)
        } else if (SimonService.watching) {
            startService(Intent(this, SimonService::class.java).setAction(SimonService.ACTION_WATCH_OFF))
        }
        watchSub.text = watchText(on)
    }

    private fun send(action: String) {
        startForegroundService(Intent(this, SimonService::class.java).setAction(action))
    }

    private fun openGestures(f: Feature) {
        startActivity(Intent(this, GesturesActivity::class.java).putExtra(GesturesActivity.EXTRA_FEATURE, f.name))
    }

    private fun askBatteryExemption() {
        val pm = getSystemService(PowerManager::class.java)
        if (pm.isIgnoringBatteryOptimizations(packageName)) {
            DebugState.log("Az akkumulátor-optimalizálás már ki van kapcsolva")
            return
        }
        startActivity(
            Intent(AndroidSettings.ACTION_REQUEST_IGNORE_BATTERY_OPTIMIZATIONS, Uri.parse("package:$packageName"))
        )
    }

    private data class TileInfo(val cls: Class<*>, val label: String, val icon: Int)

    private fun tileList() = listOf(
        TileInfo(SimonTileService::class.java, "Glyph figyelés", R.drawable.ic_tile),
        TileInfo(SpinTileService::class.java, "Pörgetés", R.drawable.ic_spin),
        TileInfo(CompassTileService::class.java, "Iránytű", R.drawable.ic_compass),
        TileInfo(LockTileService::class.java, "Zárfeltörő", R.drawable.ic_lock),
        TileInfo(SafeTileService::class.java, "Széf", R.drawable.ic_safe),
        TileInfo(PetTileService::class.java, "Glyph Tojás", R.drawable.ic_pet),
        TileInfo(LevelTileService::class.java, "Vízmérték", R.drawable.ic_level),
        TileInfo(TimerTileService::class.java, "Időzítő", R.drawable.ic_timer),
        TileInfo(BalanceTileService::class.java, "Egyensúly", R.drawable.ic_balance),
        TileInfo(DinoTileService::class.java, "Dínófutás", R.drawable.ic_dino)
    )

    /** Csempeválasztó: a kijelölteket egymás után kéri fel a lehúzható menübe. */
    private fun chooseTiles() {
        val all = tileList()
        val checked = BooleanArray(all.size) { it < 3 }
        AlertDialog.Builder(this, android.R.style.Theme_DeviceDefault_Dialog_Alert)
            .setTitle("Mely csempék kerüljenek a lehúzható menübe?")
            .setMultiChoiceItems(all.map { it.label }.toTypedArray(), checked) { _, which, isChecked -> checked[which] = isChecked }
            .setPositiveButton("Hozzáadás") { _, _ -> addTiles(all.filterIndexed { i, _ -> checked[i] }) }
            .setNegativeButton("Mégse", null)
            .show()
    }

    /** Widget kitétele a kezdőképernyőre közvetlenül az appból (ha az indító engedi). */
    private fun chooseWidget() {
        val options = listOf(
            "Gyorsindító sáv (4 funkció + figyelés)" to QuickBarWidget::class.java,
            "Egygombos funkció" to FeatureWidget::class.java,
            "Glyph Tojás" to PetWidget::class.java,
            "Időzítő" to TimerWidget::class.java
        )
        AlertDialog.Builder(this, android.R.style.Theme_DeviceDefault_Dialog_Alert)
            .setTitle("Melyik widgetet tegyem ki?")
            .setItems(options.map { it.first }.toTypedArray()) { _, which ->
                val mgr = android.appwidget.AppWidgetManager.getInstance(this)
                if (mgr.isRequestPinAppWidgetSupported) {
                    mgr.requestPinAppWidget(ComponentName(this, options[which].second), null, null)
                } else {
                    Toast.makeText(this, "Az indító nem támogatja: tartsd nyomva a kezdőképernyőt → Widgetek → Glyph Eggs", Toast.LENGTH_LONG).show()
                }
            }
            .setNegativeButton("Mégse", null)
            .show()
    }

    private fun addTiles(list: List<TileInfo>) {
        if (list.isEmpty()) return
        val t = list.first()
        getSystemService(StatusBarManager::class.java).requestAddTileService(
            ComponentName(this, t.cls),
            t.label,
            Icon.createWithResource(this, t.icon),
            mainExecutor
        ) { result ->
            DebugState.log("${t.label} csempe: $result")
            addTiles(list.drop(1))
        }
    }

    override fun onDestroy() {
        scope.cancel()
        super.onDestroy()
    }
}
