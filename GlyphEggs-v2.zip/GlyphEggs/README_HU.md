# Glyph Eggs – játékok a Nothing Phone (2) LED-jeivel

Két játék és egy iránytű egy appban, mindhárom a lehúzható menü csempéjéről is indítható.

## 1. Glyph Simon

1. Kapcsold be a **Glyph Simon** csempét (vagy az appban: Simon-figyelés bekapcsolása).
2. Tedd le a telefont kijelzővel lefelé (töltőport feléd), és forgasd jobbra kétszer kb. negyed fordulatot. A telefon röviden rezeg.
3. Felvillan egy irány: döntsd arra, majd vissza középre. Minden körben az egész sort kell végigdönteni.
4. Minden teljesített körrel 2 LED-del nő a C1 szintjelző. 8 kör után kb. 8 mp-ig minden villog és rezeg.

| Döntés | LED |
|---|---|
| Fel (B1 felé) | A1, A2, B1 |
| Le (E1 felé) | D1_1–8, E1 |
| Balra (kamera felőli oldal) | C2, C3 |
| Jobbra | C5, C6 |
| Szintjelző | C1_1–16, körönként 2 |

## 2. Üvegpörgetés

1. Koppints a **Pörgetés** csempére (vagy az appban: Pörgetés most).
2. Tedd le a telefont kijelzővel lefelé az asztal közepére. Max. 15 mp-ig vár rá.
3. A fény körbefut a nagy gyűrűn, lassul, a végén kattogva rezeg, és megáll. Akire mutat, az a kiválasztott.
4. A kiválasztott hely villog, a telefon rezeg, és pár másodpercig égve marad.

A célt fok szerint egyenletesen sorsolja, így minden irány egyforma eséllyel jön ki.

## 3. Iránytű

1. Koppints az **Iránytű** csempére (vagy az appban: Iránytű be/ki).
2. Tedd le a telefont kijelzővel lefelé egy sík felületre. A gyűrű egyszer felvillan.
3. Amíg az észak a nagy ívek valamelyikénél van (C2–C6), az az ív ég – ez a durva irány.
4. Forgasd a telefont az asztalon. Amikor az észak a C1 részre, a 16 kis LED közé ér, kis kattanás jelzi, és onnan **egyetlen LED** mutatja pontosan az északot.
5. Addig fut, amíg fekszik. Ha felemeled, még 5 mp-ig vár: ha visszateszed, folytatja, különben kikapcsol. A csempére koppintva is kikapcsolhatod.

Tipp: fémtárgyak, laptop, hangszóró közelében az iránytű téved. Ha pontatlan, emeld fel, és mozgasd a telefont párszor 8-as alakban.

## Csempék hozzáadása

Az appban a **csempe hozzáadása** gombok. Vagy húzd le kétszer a felső menüt, koppints a ceruza ikonra, és húzd be a Glyph Simon, a Pörgetés és az Iránytű csempét.

## APK készítése GitHubon

1. Töltsd fel a zipet egy repóba (Add file → Upload files). Egyszerre csak egy zip legyen a repóban.
2. A `.github/workflows/build.yml` legyen az, ami a beszélgetésben szerepel (bármilyen nevű zippel működik).
3. Az Actions fülön a zöld futás alján, az Artifacts résznél töltsd le az APK-t.

Telepítés előtt töröld a régi **Glyph Simon** appot, mert a Glyph Eggs már tartalmazza, és a kettő zavarná egymást.

## Glyph engedélyezése

- **Android 16 / Nothing OS 4:** nincs teendő.
- **Régebbi rendszer:** USB-n egyszer ki kell adni: `adb shell settings put global nt_glyph_interface_debug_enable 1` (48 óránként lejár).

## Hangolás

Minden beállítás az `app/src/main/java/com/akos/glypheggs/Config.kt` fájlban van:

- Simon: `FULL_SEQUENCE`, `TURN_COUNT`, `TILT_ON`, `INVERT_X` / `INVERT_Y` / `INVERT_TURN`, `SHOW_MS`, `GAP_MS`, `WIN_FLASH_MS`
- Iránytű: `COMPASS_DECLINATION` (földrajzi északhoz kb. 5.5), `COMPASS_INVERT` (ha tükrözve mutat), `COMPASS_LIFT_GRACE_MS` (felemelés utáni várakozás), `COMPASS_SMOOTHING`
- Pörgetés: `SPIN_MIN_MS` / `SPIN_MAX_MS` (hossz), `SPIN_MIN_TURNS` / `SPIN_MAX_TURNS` (körök), `SPIN_EASE_POWER` (lassulás), `SPIN_HOLD_MS` (mennyi ideig ég az eredmény)
