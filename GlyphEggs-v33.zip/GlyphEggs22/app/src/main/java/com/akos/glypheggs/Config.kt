package com.akos.glypheggs

/**
 * Minden hangolható érték egy helyen.
 * Ha valami nem úgy működik a telefonon, ahogy szeretnéd, általában itt kell állítani.
 */
object Config {
    // --- Játékszabály ---
    /** true = klasszikus Simon Says: minden körben a teljes sort végig kell dönteni.
     *  false = csak a legújabb LED irányát kell eltalálni. */
    const val FULL_SEQUENCE = true
    /** Ennyi LED gyullad ki a C1 szintjelzőn körönként. */
    const val LEDS_PER_LEVEL = 2
    /** 16 LED / 2 = 8 kör, ekkor betelik a szintjelző és nyersz. */
    const val MAX_ROUNDS = 16 / LEDS_PER_LEVEL

    // --- Indító mozdulatok (bármelyik funkcióhoz, az appban állítható) ---
    /** |gravitáció z| ennél nagyobb → vízszintesen fekszik (m/s², max 9.81). */
    const val FLAT_Z = 8.0f
    /** Lerakás/mozdítás után ennyi ideig marad ébren a processzor a forgatások figyeléséhez. */
    const val KEEP_AWAKE_MS = 10 * 60 * 1000L
    /** Ha a jobbra forgatást balra forgatásnak érzékeli, állítsd true-ra. */
    const val INVERT_TURN = false
    /** Forgatás kezdete / vége (rad/s szögsebesség). */
    const val MOVE_START_RAD_S = 0.6f
    const val MOVE_STOP_RAD_S = 0.3f
    /** Ennyi nyugalom után zárul le egy forgatás. */
    const val MOVE_END_MS = 250L
    /** Egy "negyed fordulat" ennyi fok között számít (pontatlanul is jó). */
    const val TURN_MIN_DEG = 55f
    const val TURN_MAX_DEG = 200f
    /** Megpörgetés: legalább ennyi fok egy lendületből. */
    const val SPIN_GESTURE_DEG = 300f
    /** Két forgatás között legfeljebb ennyi idő telhet el. */
    const val TURN_GAP_MS = 4_000L
    /** Egy felismert mozdulat után ennyi ideig nem figyel újat. */
    const val GESTURE_COOLDOWN_MS = 4_000L

    /** Kopogás küszöbe (m/s²) érzékenység szerint: alacsony, közepes, magas, nagyon magas. */
    val KNOCK_THRESHOLDS = floatArrayOf(2.6f, 1.6f, 1.0f, 0.65f)
    /** Két kopogás között legalább / legfeljebb ennyi idő. */
    const val KNOCK_MIN_GAP_MS = 90L
    const val KNOCK_MAX_GAP_MS = 900L
    /** Lerakás után ennyi ideig nem figyel kopogást (a lerakás is "koppan"). */
    const val KNOCK_SETTLE_MS = 1_000L

    /** Rázás: ekkora gyorsulás-csúcsokból ennyi kell, ennyi időn belül. */
    const val SHAKE_THRESHOLD = 11f
    const val SHAKE_PEAKS = 4
    const val SHAKE_WINDOW_MS = 1_200L
    /** Rázás után ennyi időd van lerakni kijelzővel lefelé. */
    const val SHAKE_PLACE_MS = 6_000L

    /** Játék közbeni rázás (Széf, Tojás): ekkora csúcsokból ennyi, ennyi időn belül. */
    const val GAME_SHAKE_THRESHOLD = 9f
    const val GAME_SHAKE_PEAKS = 2
    const val GAME_SHAKE_WINDOW_MS = 600L
    /** Két rázás-esemény között legalább ennyi idő. */
    const val GAME_SHAKE_REFRACTORY_MS = 800L

    /**
     * Rázás érzékenysége (Indítás és leállítás oldal, Előadás beállítása): ezzel szorozza a rázás-
     * küszöböket. Alacsony, Közepes (alap), Magas, Nagyon magas. Kisebb szám = gyengébb rázás is elég.
     */
    val SHAKE_SENS_FACTORS = floatArrayOf(1.3f, 1.0f, 0.75f, 0.55f)
    /** Az Előadás „rész vége előtti” figyelmeztetése ennyi perccel a rész vége előtt jön. */
    const val LECTURE_WARN_MIN = 5

    /** Hengerítés: ennyi teljes kör a hosszanti tengely körül, ennyi időn belül. */
    const val ROLL_TURNS = 3
    const val ROLL_WINDOW_MS = 10_000L
    /** 0.85 = elég a 3 kör 85%-a (kb. 2,5 kör), mert az első pillanat elveszhet. */
    const val ROLL_TOLERANCE = 0.85f
    /** Kézben ekkora mozgás kapcsolja be a giroszkópot, és ennyi ideig marad bekapcsolva. */
    const val ROLL_WAKE_ACCEL = 1.5f
    const val ROLL_AWAKE_MS = 10_000L

    /** Lefordítás 2×: a két lefordításnak ennyi időn belül kell meglennie. */
    const val FLIP_WINDOW_MS = 5_000L

    // --- Döntés felismerése ---
    /** Ekkora oldalirányú gravitációs komponens felett számít döntésnek (~21°). */
    const val TILT_ON = 3.5f
    /** Ez alá kell visszaengedni, hogy "középen" legyen. */
    const val TILT_OFF = 1.5f
    /** Ha a bal/jobb vagy előre/hátra fordítva jön ki, ezeket állítsd true-ra. */
    const val INVERT_X = false
    const val INVERT_Y = false

    // --- Időzítés ---
    /** Mennyi ideig ég egy irány a sor lejátszásakor. */
    const val SHOW_MS = 300L
    /** Szünet két irány között a lejátszásnál. */
    const val GAP_MS = 150L
    const val ANSWER_TIMEOUT_MS = 7_000L
    /** Győzelmi villogás hossza (a rezgés is kb. ennyi). */
    const val WIN_FLASH_MS = 8_000L

    // --- Pörgetés (üvegpörgető) ---
    /** Ennyi teljes kört fut legalább / legfeljebb, mielőtt megáll. */
    const val SPIN_MIN_TURNS = 4
    const val SPIN_MAX_TURNS = 6
    /** A pörgetés hossza (véletlenszerűen e kettő között). */
    const val SPIN_MIN_MS = 5_000L
    const val SPIN_MAX_MS = 7_000L
    /** Mennyire lassul a végén: nagyobb szám = hirtelenebb lassulás, hosszabb "kúszás". */
    const val SPIN_EASE_POWER = 3f
    /** A fénypont szélessége (fokban, mindkét irányba). */
    const val SPIN_POINTER_HALF_WIDTH = 6f
    /** Megállás után ennyi ideig marad égve a kiválasztott hely. */
    const val SPIN_HOLD_MS = 4_000L
    /** Csempe után ennyi ideig vár, hogy letedd kijelzővel lefelé. */
    const val SPIN_PLACE_TIMEOUT_MS = 15_000L
    /** Lerakás után ennyit vár, hogy megnyugodjon a telefon. */
    const val SPIN_SETTLE_MS = 700L

    // --- Iránytű ---
    /** Csempe után ennyi ideig vár, hogy letedd kijelzővel lefelé. */
    const val COMPASS_PLACE_TIMEOUT_MS = 20_000L
    /** Lerakás után ennyit vár, mielőtt mutatni kezd. */
    const val COMPASS_SETTLE_MS = 500L
    /** Felemelés után ennyi ideig vár; ha addig visszateszed, folytatja. */
    const val COMPASS_LIFT_GRACE_MS = 5_000L
    /** Simítás 0–1 között: nagyobb = nyugodtabb, de lassabban követ. */
    const val COMPASS_SMOOTHING = 0.85f
    /** Ennyi fokkal kell átérni a szomszéd részbe, hogy váltson (villódzás ellen). */
    const val COMPASS_HYSTERESIS = 1.2f
    /** Mágneses elhajlás fokban. 0 = mágneses észak; Magyarországon a földrajzi északhoz kb. 5.5. */
    const val COMPASS_DECLINATION = 0f
    /** Ha az észak tükrözve jön ki (pl. keletet mutat nyugat helyett), állítsd true-ra. */
    const val COMPASS_INVERT = false

    // --- Zárfeltörő ---
    /** Ennyi tüskét kell kinyitni. */
    const val LOCK_PINS = 4
    /** Életek (A1, A2, B1 mutatja). */
    const val LOCK_LIVES = 3
    /** Az édes pont helye a C1 sáv közepe táján (0–15 között). */
    const val LOCK_SWEET_MIN = 5
    const val LOCK_SWEET_MAX = 10
    /** Ennyi LED-en belül "közel" (nem vesz el életet). */
    const val LOCK_NEAR = 2
    /** A fénypont sebessége: LED-enként ennyi ms, tüskénként gyorsul, de legfeljebb eddig. */
    const val LOCK_START_STEP_MS = 140L
    const val LOCK_STEP_FASTER_MS = 18L
    const val LOCK_MIN_STEP_MS = 65L
    /** A rezzenés után ennyi ideig még találatnak számít a kopogás (reakcióidő). */
    const val LOCK_REACTION_MS = 280L

    // --- Széf ---
    /** Egy pozíció ennyi ideig világít, utána ennyi sötét szünet. */
    const val SAFE_ON_MS = 850L
    const val SAFE_OFF_MS = 250L
    /** Ennyi teljes kör után válasz nélkül feladja. */
    const val SAFE_MAX_IDLE_CYCLES = 4
    /** Nyitáskor ennyi ideig villog minden. */
    const val SAFE_CELEBRATE_MS = 5_000L
    /** Döntéses széf: ennyi ideig vár egy-egy döntésre, utána leáll. */
    const val SAFE_TILT_TIMEOUT_MS = 15_000L
    /** Kinyitás után eddig nyitható meg a titkos jegyzet (ms). */
    const val SAFE_UNLOCK_WINDOW_MS = 120_000L

    // --- Glyph Tojás ---
    /** A LED-es gondozás ennyi tétlenség után magától leáll. */
    const val PET_SESSION_IDLE_MS = 180_000L
    /** Felemelés után ennyi ideig vár, mielőtt leáll. */
    const val PET_LIFT_GRACE_MS = 5_000L
    /** A kopogás-sorozat ennyi szünettel zárul (1 = simogatás, 2 = etetés, 3 = játék, 4 = altatás). */
    const val PET_KNOCK_GROUP_MS = 900L

    // --- Vízmérték ---
    /** Ennyi fokon belül számít vízszintesnek. */
    const val LEVEL_TOLERANCE_DEG = 0.5f
    /** A felső sávon egy LED ennyi fok eltérést jelent. */
    const val LEVEL_DEG_PER_LED = 0.5f
    /** Ha ennyi ideig nem mozdul, a vízmérték kikapcsol. */
    const val LEVEL_IDLE_MS = 5 * 60_000L

    // --- Dínófutás ---
    /** A pálya sebessége: LED-enként ennyi ms, pontonként gyorsul, de legfeljebb eddig. */
    const val DINO_START_STEP_MS = 170L
    const val DINO_FASTER_PER_POINT_MS = 2L
    const val DINO_MIN_STEP_MS = 70L
    /** Az ugrás hossza pályalépésben (ennyi LED-nyi akadály fér el alatta). */
    const val DINO_JUMP_STEPS = 5L
    /** Ha a földet érés előtt ennyi ms-mal jön az ugrás, „megjegyzi”, és leérkezéskor rögtön ugrik. */
    const val DINO_JUMP_BUFFER_MS = 200L
    /** Két akadály között legalább ennyi LED. */
    const val DINO_MIN_GAP = 7

    // --- Rázás-töltés (indító mozdulat) ---
    /** Alapból ennyi rázás kell, hogy mind a 33 LED égjen. */
    const val SHAKEFILL_DEFAULT = 10
    /** Ha ennyi ideig nem rázod, a töltés félbemarad (a LED-ek elalszanak, nem indul semmi). */
    const val SHAKEFILL_GAP_MS = 4_000L

    // --- Előadás-időzítő ---
    /** Egy előadás-rész és a szünet hossza percben. */
    const val LECTURE_BLOCK_MIN = 45
    const val LECTURE_BREAK_MIN = 15
    /** Ha töltés közben ennyi ideig nem rázzák meg, leáll. */
    const val LECTURE_FILL_TIMEOUT_MS = 10 * 60_000L
    /** Szünet indítása: két rázás ennyi időn belül. */
    const val LECTURE_SHAKE_WINDOW_MS = 3_000L
    /** Az előadás indulása után ennyi ideig nem indít szünetet (a töltés utórezgése miatt). */
    const val LECTURE_ARM_MS = 5_000L

    // --- Widgetek ---
    /** A gyorsindító sáv ekkora magasságtól (dp) mutat 4 helyett 8 funkciót, két sorban. */
    const val BAR_8_MIN_HEIGHT_DP = 200

    // --- Hangerő-gombos indítás ---
    /** A két gombnyomás legfeljebb ennyi időn belül legyen. */
    const val VOL_WINDOW_MS = 1_000L

    // --- Fújásfigyelés (háttérben) ---
    /** Ekkora fújás-erő (0–1) kell… */
    const val BLOW_LISTEN_LEVEL = 0.35f
    /** …legalább ennyi ideig, hogy a háttérben elinduljon a játék (egy köhintés vagy egy szó ne indítsa). */
    const val BLOW_LISTEN_MS = 400L
    /** A háttérből indult (és fújásfigyelés közben az oldalról indult) játék ennyi csend után leáll. */
    const val BLOW_BG_IDLE_MS = 8_000L
    /** A folyamatos mikrofonfigyelés becsült áramfelvétele (mikrofon + ébren tartott processzor), mA. */
    const val BLOW_LISTEN_MA = 15.0

    // --- Előadás-órarend ---
    /** Ha egy óra kezdete után ennyin belül kapcsol be a telefon / jön az ébresztés, még elindítja. */
    const val SCHEDULE_LATE_MS = 10 * 60_000L

    // --- Fújós játék ---
    /** A fújás küszöbe (dBFS) érzékenység szerint: alacsony, közepes, magas, nagyon magas. */
    val BLOW_THRESHOLD_DB = floatArrayOf(-20f, -26f, -32f, -38f, -44f)
    /** Ennyi dB a küszöb fölött = teljes erő. */
    const val BLOW_RANGE_DB = 16f
    /** A fújás „szeles” zúgás: a mély (≈250 Hz alatti) rész aránya legalább ennyi legyen (a beszéd kiszűrésére). */
    const val BLOW_LOW_RATIO = 0.35f
    /** Ha ennyi ideig nem érkezik mikrofonjel (az oldal bezárult), a játék leáll. */
    const val BLOW_IDLE_MS = 3_000L

    // --- Leállítási parancsok ---
    /** Indulás után ennyi ideig nem figyeli a leállítást (hogy az indítás ne állítsa le rögtön). */
    const val STOP_START_GRACE_MS = 1_500L
    /** Felemelés: ennyi ideig kell a kezedben tartani. */
    const val STOP_LIFT_MS = 2_000L
    /** Megfordítás: ennyi ideig kell kijelzővel felfelé feküdnie. */
    const val STOP_FLIP_MS = 1_000L
    /** Erős rázás: két rázás-esemény ennyi időn belül. */
    const val STOP_SHAKE_WINDOW_MS = 3_000L

    // --- Fogyasztásbecslés (Akku fül) ---
    /** Egy nagy Glyph-zóna (A1, A2, B1, C2–C6) áramfelvétele teljes fényerőn, mA. */
    const val LED_BIG_MA = 12.0
    /** Egy kis LED (C1_x, D1_x, E1) áramfelvétele, mA. */
    const val LED_SMALL_MA = 3.0
    /** Szenzorok + ébren tartott processzor, mA – az érzékelési módok szerint. */
    const val SENSOR_GAME_MA = 14.0      // 100 Hz gyorsulásmérő, ébren tartott CPU (fut egy funkció)
    const val SENSOR_KNOCK_MA = 3.0      // kopogásfigyelés fekve (100 Hz, kötegelve)
    const val SENSOR_MEDIUM_MA = 2.0     // rázás / lefordítás / hengerítés figyelése (50 Hz, kötegelve)
    const val SENSOR_LOW_MA = 0.6        // alap készenlét (~5 Hz, kötegelve)
    const val SENSOR_GYRO_MA = 7.0       // giroszkóp + ébren tartott CPU (forgatós mozdulatok)
    /** Ha a telefon nem adja meg, ennyi mAh-s akkuval számol (Nothing Phone (2): 4700 mAh). */
    const val BATTERY_MAH_DEFAULT = 4700.0
    /** Futás közben ennyi mp-enként méri a telefon teljes áramfelvételét. */
    const val MEASURE_EVERY_MS = 5_000L
    /** Ennyi napig őrzi a statisztikát. */
    const val ENERGY_KEEP_DAYS = 31

    // --- Glyph Beacon (fütty) ---
    /** Tonalitás-küszöb (a csúcs energiája / a sáv teljes energiája) érzékenységenként: óvatos, normál, érzékeny. */
    val WHISTLE_TONAL = floatArrayOf(0.55f, 0.42f, 0.32f)
    /** Minimális hangerő (dBFS) érzékenységenként. */
    val WHISTLE_MIN_DB = floatArrayOf(-42f, -50f, -58f)
    /** Betanítás nélkül elfogadott füttytartomány (Hz) és szükséges hossz (ms). */
    const val WHISTLE_DEFAULT_MIN_HZ = 700f
    const val WHISTLE_DEFAULT_MAX_HZ = 4200f
    const val WHISTLE_DEFAULT_MS = 450
    /** Betanítva: ennyiszer tágabb a tartomány, és a betanított hossz ekkora része elég. */
    const val WHISTLE_BAND_MARGIN = 1.22f
    const val WHISTLE_DUR_FACTOR = 0.6f
    const val WHISTLE_MIN_MS = 300
    const val WHISTLE_MAX_MS = 900
    /** Elektronikus sípolás kiszűrése: ennyi hangmagasság-ingadozás alatt nem fütty (pl. mikró, ébresztő). */
    const val WHISTLE_MIN_WOBBLE = 1.004f
    /** Riasztás után ennyi ideig nem figyel (ne a saját hangjára induljon újra). */
    const val BEACON_COOLDOWN_MS = 6_000L
    /** A fütty-figyelés becsült többletfogyasztása (mA): mikrofon + FFT. */
    const val BEACON_LISTEN_MA = 18.0

    /** Claude app mód: ennyi csend után magától leáll (ms). */
    const val CLAUDE_IDLE_MS = 5 * 60_000L
    /** Hangerő-kombináció: ekkora szünet két nyomás között már új sorozatot kezd (ms). */
    const val VOL_COMBO_GAP_MS = 1_200L
    /** A sorozat vége: ennyi csend után értékeli ki (ms). */
    const val VOL_COMBO_END_MS = 700L

    /** Morze: az első lefutás után ennyi ideig vár a megfejtésre, utána folyamatosan ismétel. */
    const val MORSE_WAIT_MS = 8_000L

    /** Előadás „csak érintésre” módban: ennyi ideig világít egy érintés / koppintás után. */
    const val LECTURE_PEEK_MS = 6_000L

    /** Fütty: a felhangok (2f + 3f) legfeljebb ekkora része lehet az alaphangnak (óvatos, normál, érzékeny). */
    val WHISTLE_HARM = floatArrayOf(0.15f, 0.25f, 0.38f)
    /** Betanítva: ennyivel térhet el a hangmagasság a füttyödétől (óvatos, normál, érzékeny). */
    val WHISTLE_TOL = floatArrayOf(0.06f, 0.10f, 0.16f)

    /** Hangparancs: a küszöb a saját szórásod ennyiszerese (óvatos, normál, érzékeny) – szintetikus teszten hangolva. */
    val KEYWORD_FACTOR = floatArrayOf(0.78f, 0.86f, 0.95f)
}
