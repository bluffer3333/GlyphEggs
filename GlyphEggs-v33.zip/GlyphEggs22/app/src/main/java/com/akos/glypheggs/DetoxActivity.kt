package com.akos.glypheggs

import android.app.Activity
import android.content.Intent
import android.os.Bundle
import kotlinx.coroutines.cancel
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch
import android.view.Gravity
import android.view.ViewGroup.LayoutParams.MATCH_PARENT
import android.view.ViewGroup.LayoutParams.WRAP_CONTENT
import android.widget.FrameLayout
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.ScrollView

/** A Glyph Focus beállítása: cél, a haladás mutatása, indítás, rekordok. */
class DetoxActivity : Activity() {
    private lateinit var root: LinearLayout

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        darkWindow()
        root = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(dp(15), 0, dp(15), dp(30)) }
        setContentView(ScrollView(this).apply {
            background = Ui.pageBg()
            isVerticalScrollBarEnabled = false
            addView(root, FrameLayout.LayoutParams(MATCH_PARENT, WRAP_CONTENT))
            padForSystemBars()
        })
        build()
    }

    private fun build() {
        root.removeAllViews()
        val h = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL; setPadding(dp(7), dp(28), 0, dp(6)) }
        h.addView(ImageView(this).apply { setImageResource(R.drawable.ic_back); setColorFilter(Ui.TEXT); setOnClickListener { finish() } }, LinearLayout.LayoutParams(dp(24), dp(24)))
        h.addView(text("Glyph Focus", 26f).apply { setPadding(dp(30), 0, 0, 0) })
        root.addView(h)
        root.addView(text("GLYPH FOCUS", 34f, Ui.TEXT).apply { typeface = Widgets.dotoFace(this@DetoxActivity); setPadding(dp(7), dp(18), 0, 0) })
        root.addView(text("Tedd le kijelzővel lefelé, és ne nyúlj hozzá. Amíg pihen, a fény alulról felfelé nő – a cél idejére mind a 33 LED ég. " +
            "Ha felveszed vagy megfordítod, a fény összeomlik, és a sorozat véget ér.", 13.5f, Ui.SUB).apply { setPadding(dp(8), dp(8), dp(8), 0); setLineSpacing(0f, 1.2f) })

        // Rekordok
        val best = GameStats.bestOf(this, "detox_min")
        val goals = GameStats.cnt(this, "detox_goal")
        val rec = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
        for ((i, pair) in listOf("$best p" to "LEGHOSSZABB", "$goals×" to "CÉL TELJESÍTVE", shortDuration(GameStats.ms(this, Feature.DETOX)) to "ÖSSZESEN").withIndex()) {
            val c = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; background = rounded(Ui.CARD, dp(20).toFloat()); setPadding(dp(14), dp(12), dp(10), dp(12)) }
            c.addView(text(pair.first, 20f).apply { typeface = Widgets.dotoFace(this@DetoxActivity) })
            c.addView(text(pair.second, 9.5f, Ui.SUB, Ui.medium))
            rec.addView(c, LinearLayout.LayoutParams(0, WRAP_CONTENT, 1f).apply { if (i < 2) marginEnd = dp(5) })
        }
        root.addView(rec, LinearLayout.LayoutParams(MATCH_PARENT, WRAP_CONTENT).apply { topMargin = dp(16) })

        root.addView(sectionTitle("Cél"))
        val opts = listOf(15, 30, 60, 90, 120, 180)
        for (chunk in opts.chunked(3)) {
            val r = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
            chunk.forEachIndexed { i, m ->
                val sel = Settings.detoxGoal(this) == m
                r.addView(text(if (m < 60) "$m perc" else "${m / 60}${if (m % 60 == 30) ",5" else ""} óra", 14f, if (sel) Ui.DARK_TEXT else Ui.TEXT).apply {
                    gravity = Gravity.CENTER
                    background = rounded(if (sel) Ui.LIGHT else Ui.CARD, dp(22).toFloat())
                    setOnClickListener { Settings.setDetoxGoal(this@DetoxActivity, m); build() }
                }, LinearLayout.LayoutParams(0, dp(48), 1f).apply { if (i < 2) marginEnd = dp(5) })
            }
            root.addView(r, LinearLayout.LayoutParams(MATCH_PARENT, WRAP_CONTENT).apply { bottomMargin = dp(5) })
        }

        root.addView(sectionTitle("A haladás mutatása"))
        val cur = Settings.detoxShow(this)
        for (d in DetoxShow.entries) {
            val r = LinearLayout(this).apply {
                orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL
                background = rounded(Ui.CARD, dp(20).toFloat()); setPadding(dp(18), dp(14), dp(16), dp(14))
                setOnClickListener { Settings.setDetoxShow(this@DetoxActivity, d); build() }
            }
            val t = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
            t.addView(text(d.title, 16f))
            t.addView(text(d.desc, 12.5f, Ui.SUB).apply { setPadding(0, dp(2), 0, 0) })
            r.addView(t, LinearLayout.LayoutParams(0, WRAP_CONTENT, 1f))
            r.addView(RadioMark(this, d == cur), LinearLayout.LayoutParams(dp(24), dp(24)).apply { marginStart = dp(12) })
            root.addView(r, LinearLayout.LayoutParams(MATCH_PARENT, WRAP_CONTENT).apply { bottomMargin = dp(5) })
        }

        root.addView(text("●  Indítás", 17f, Ui.DARK_TEXT, Ui.medium).apply {
            gravity = Gravity.CENTER
            background = rounded(Ui.LIGHT, dp(30).toFloat())
            setOnClickListener { startForegroundService(Intent(this@DetoxActivity, SimonService::class.java).setAction(SimonService.ACTION_DETOX)) }
        }, LinearLayout.LayoutParams(MATCH_PARENT, dp(60)).apply { topMargin = dp(18) })
        root.addView(text("Indítás után 20 mp-ed van letenni. A bekapcsoló gomb is leállítja (a megszerzett perc megmarad).", 12.5f, Ui.SUB)
            .apply { setPadding(dp(8), dp(8), dp(8), 0) })

        // Focus-kitűzők és a Zen téma
        val have = DETOX_BADGES.count { Achievements.isUnlocked(this, it) }
        root.addView(sectionTitle("Focus-kitűzők · $have / ${DETOX_BADGES.size}"))
        val row = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            background = rounded(Ui.CARD, dp(22).toFloat())
            setPadding(dp(6), dp(14), dp(6), dp(10))
        }
        badgeViews.clear()
        for (b in DETOX_BADGES) {
            val cell = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; gravity = Gravity.CENTER_HORIZONTAL }
            val v = BadgeView(this, b).apply {
                unlocked = Achievements.isUnlocked(this@DetoxActivity, b)
                progress = b.progress(this@DetoxActivity).toFloat() / b.goal()
            }
            badgeViews += v
            cell.addView(v, LinearLayout.LayoutParams(dp(56), dp(56)))
            cell.addView(text(b.title, 10.5f, if (v.unlocked) Ui.TEXT else Ui.SUB).apply { gravity = Gravity.CENTER; maxLines = 2; setPadding(0, dp(4), 0, 0) },
                LinearLayout.LayoutParams(MATCH_PARENT, WRAP_CONTENT))
            cell.addView(text("${b.progress(this@DetoxActivity)}/${b.goal()}", 10f, Ui.SUB).apply { gravity = Gravity.CENTER },
                LinearLayout.LayoutParams(MATCH_PARENT, WRAP_CONTENT))
            row.addView(cell, LinearLayout.LayoutParams(0, WRAP_CONTENT, 1f))
        }
        root.addView(row, LinearLayout.LayoutParams(MATCH_PARENT, WRAP_CONTENT))
        root.addView(text(
            if (have >= DETOX_BADGES.size) "🍃 A Zen téma feloldva – a titkos menüben választhatod."
            else "🍃 Mind az 5 Focus-kitűzővel egy minimalista Zen téma nyílik a titkos menüben. Még ${DETOX_BADGES.size - have}.",
            13f, Ui.SUB).apply { setPadding(dp(8), dp(10), dp(8), 0); setLineSpacing(0f, 1.2f) })
    }

    private val badgeViews = mutableListOf<BadgeView>()
    private val animScope = kotlinx.coroutines.MainScope()
    private var animJob: kotlinx.coroutines.Job? = null

    override fun onResume() {
        super.onResume(); GlyphMirror.appVisible = true; build()
        animJob?.cancel()
        animJob = animScope.launch {
            var ph = 0f
            while (true) {
                ph = (ph + 0.006f) % 1f
                badgeViews.forEachIndexed { i, v -> v.phase = (ph + i * 0.2f) % 1f; v.invalidate() }
                delay(33)
            }
        }
    }
    override fun onPause() { super.onPause(); GlyphMirror.appVisible = false; animJob?.cancel() }
    override fun onDestroy() { animScope.cancel(); super.onDestroy() }
}
