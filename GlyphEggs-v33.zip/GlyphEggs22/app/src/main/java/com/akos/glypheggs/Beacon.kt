package com.akos.glypheggs

import android.content.Context
import android.media.AudioAttributes
import android.media.AudioManager
import android.media.MediaPlayer
import android.os.SystemClock
import android.os.VibrationEffect
import android.os.VibratorManager
import com.nothing.ketchum.Glyph
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.MutableStateFlow
import java.util.concurrent.CopyOnWriteArrayList
import kotlin.math.PI
import kotlin.math.abs
import kotlin.math.cos
import kotlin.math.ln
import kotlin.math.log10
import kotlin.math.sin
import kotlin.math.sqrt

/*
 * GLYPH BEACON – fütyülj, és a telefon felel.
 * A mikrofon hangjából (semmit nem rögzít, nem ment, nem küld el) gyors Fourier-transzformációval keresi
 * a füttyre jellemző, szinte tiszta, egyetlen hangmagasságú hangot. Ha elég hosszú, és a betanított
 * tartományba esik, a telefon riaszt: villog (SOS / radar), teljes erővel rezeg, és robotos hangot ad.
 */

/** A riasztás hangja – mind az app saját, szintetizált hangja. */
enum class BeaconSound(val title: String, val desc: String, val raw: Int) {
    ROBOT("Robot", "Bitcrush csipogás, ugráló hangok, felfutó szirénaív", R.raw.beacon_robot),
    SONAR("Szonár", "Mély pingelés visszhanggal, mint egy tengeralattjáró", R.raw.beacon_sonar),
    GLYPH("Glyph", "Kristálytiszta, gyors csengő-hármasok", R.raw.beacon_glyph)
}

/** A mikrofon nyers hangkereteinek elosztója: a [BlowRecorder] ide is küldi a mintákat. */
object MicTap {
    val listeners = CopyOnWriteArrayList<(ShortArray, Int) -> Unit>()
    fun dispatch(buf: ShortArray, n: Int) {
        for (l in listeners) try { l(buf, n) } catch (t: Throwable) { }
    }
}

/**
 * Füttyfelismerő. 16 kHz, 1024 mintás ablak (64 ms), 512 mintás lépés (32 ms).
 * Egy keret „füttyös”, ha elég hangos, és az energia nagy része egyetlen csúcsban van (400–4500 Hz).
 * Az egymást követő füttyös keretekből „hangot” rak össze; ha elég hosszú → [onDetect].
 */
object Whistle {
    private const val N = 1024
    private const val SR = 16_000f
    private const val BIN = SR / N // 15,6 Hz
    private const val FRAME_MS = 32

    /** Élő adatok a Beacon oldalnak: az épp hallott füttyhang (Hz, 0 = nincs) és a hangerő (0..1). */
    val pitch = MutableStateFlow(0f)
    val level = MutableStateFlow(0f)

    /** A szolgáltatás figyel: ilyenkor hívódik, ha füttyöt hall. */
    @Volatile var onDetect: ((Float) -> Unit)? = null
    /** Betanítás: minden befejezett hang (közép-frekvencia, min, max, hossz ms). */
    @Volatile var onTone: ((Float, Float, Float, Int) -> Unit)? = null
    /** Riasztás közben ne figyeljen (a saját hangjára ne induljon). */
    @Volatile var paused = false
    /** Betanítás közben se riasszon. */
    @Volatile var training = false

    @Volatile private var sens = 1
    @Volatile private var minHz = Config.WHISTLE_DEFAULT_MIN_HZ
    @Volatile private var maxHz = Config.WHISTLE_DEFAULT_MAX_HZ
    @Volatile private var needMs = Config.WHISTLE_DEFAULT_MS
    /** Ennél hosszabb egyenletes hang nem fütty (pl. sípoló vízforraló, csengő). */
    @Volatile private var maxMs = 2_500
    /** Betanított profil: a füttyöd középhangja és dallamíve (vége / eleje). 0 = nincs. */
    @Volatile private var profMed = 0f
    @Volatile private var profSlope = 1f
    @Volatile private var tol = 0.10f
    /** Két fütty kell-e (egymás után 2,5 mp-en belül). */
    @Volatile private var double = false
    private var lastMatchAt = 0L

    /** Az utolsó befejezett hang dallamíve (betanításhoz). */
    @Volatile var lastSlope = 1f
    /** Élő teszt: mit „gondolt” az utolsó hangról (felismerve / miért nem). */
    val verdict = MutableStateFlow("")

    private val ring = FloatArray(N)
    private var filled = 0
    private val re = FloatArray(N)
    private val im = FloatArray(N)
    private val win = FloatArray(N) { (0.5 - 0.5 * cos(2 * PI * it / (N - 1))).toFloat() }
    private val bitrev = IntArray(N).also { br ->
        var j = 0
        for (i in 0 until N) {
            br[i] = j
            var bit = N shr 1
            while (j and bit != 0) { j = j xor bit; bit = bit shr 1 }
            j = j or bit
        }
    }
    private val cosT = FloatArray(N / 2) { cos(2 * PI * it / N).toFloat() }
    private val sinT = FloatArray(N / 2) { sin(2 * PI * it / N).toFloat() }
    private val pow = FloatArray(N / 2 + 1)

    // A futó hang
    private val runFreqs = ArrayList<Float>()
    private var gap = 0
    private var fired = false

    private val tap: (ShortArray, Int) -> Unit = { buf, n -> feed(buf, n) }

    /** Beállítások betöltése (érzékenység, betanított tartomány). */
    fun configure(c: Context) {
        sens = Settings.beaconSens(c)
        tol = Config.WHISTLE_TOL[sens]
        double = Settings.beaconPattern(c) == 1
        profMed = Settings.beaconMedHz(c)
        profSlope = Settings.beaconSlope(c)
        if (Settings.beaconTrained(c)) {
            minHz = Settings.beaconMinHz(c) / Config.WHISTLE_BAND_MARGIN
            maxHz = Settings.beaconMaxHz(c) * Config.WHISTLE_BAND_MARGIN
            needMs = (Settings.beaconDurMs(c) * Config.WHISTLE_DUR_FACTOR).toInt()
                .coerceIn(Config.WHISTLE_MIN_MS, Config.WHISTLE_MAX_MS)
            maxMs = (Settings.beaconDurMs(c) * 2.2f).toInt().coerceIn(900, 3_000)
        } else {
            minHz = Config.WHISTLE_DEFAULT_MIN_HZ
            maxHz = Config.WHISTLE_DEFAULT_MAX_HZ
            needMs = Config.WHISTLE_DEFAULT_MS
            maxMs = 2_500
            profMed = 0f
        }
        // Az érzékeny fokozat rövidebb füttyöt is elfogad
        if (sens == 2) needMs = (needMs * 0.8f).toInt().coerceAtLeast(Config.WHISTLE_MIN_MS - 60)
    }

    /** Rákapcsolódik a mikrofonra (többszöri hívás nem baj). */
    fun attach() { if (tap !in MicTap.listeners) MicTap.listeners.add(tap) }
    fun detach() { MicTap.listeners.remove(tap); pitch.value = 0f; level.value = 0f }

    /** Legyen-e rákapcsolva: ha a szolgáltatás figyel, vagy a betanítás/élő kijelzés megy. */
    fun refreshAttach() { if (onDetect != null || onTone != null) attach() else detach() }

    @Synchronized
    private fun feed(buf: ShortArray, n: Int) {
        // Csúszó ablak: a régi minták balra, az újak a végére
        val k = minOf(n, N)
        System.arraycopy(ring, k, ring, 0, N - k)
        for (i in 0 until k) ring[N - k + i] = buf[n - k + i] / 32768f
        filled = minOf(N, filled + k)
        if (filled < N) return
        analyze()
    }

    private fun analyze() {
        var sum = 0.0
        for (i in 0 until N) {
            val x = ring[i]
            sum += x * x
            val j = bitrev[i]
            re[j] = x * win[i]
            im[j] = 0f
        }
        val rms = sqrt(sum / N).toFloat()
        val db = if (rms > 1e-7f) 20f * log10(rms) else -140f
        level.value = ((db + 70f) / 60f).coerceIn(0f, 1f)
        fft()
        for (b in 0..N / 2) pow[b] = re[b] * re[b] + im[b] * im[b]

        val lo = (300f / BIN).toInt()
        val hi = (6500f / BIN).toInt()
        val pLo = (400f / BIN).toInt()
        val pHi = (4500f / BIN).toInt()
        var total = 0f
        for (b in lo..hi) total += pow[b]
        var best = pLo
        for (b in pLo..pHi) if (pow[b] > pow[best]) best = b
        val peak = pow[best - 1] + pow[best] + pow[best + 1] + 0.5f * (pow[best - 2] + pow[best + 2])
        val tonal = if (total > 0f) peak / total else 0f

        // Parabolás finomítás (log-amplitúdón) a pontos hangmagassághoz
        val a = ln(pow[best - 1] + 1e-12f)
        val b0 = ln(pow[best] + 1e-12f)
        val cc = ln(pow[best + 1] + 1e-12f)
        val den = a - 2 * b0 + cc
        val delta = if (abs(den) > 1e-9f) (0.5f * (a - cc) / den).coerceIn(-0.5f, 0.5f) else 0f
        val freq = (best + delta) * BIN

        // Felhang-szűrő: a fütty szinte tiszta szinusz, a beszéd, az ének, a csipogó és a madárhang
        // második-harmadik felhangja erős – ezeket kiszűri
        fun around(bin: Int): Float = if (bin + 1 >= pow.size) 0f else pow[bin - 1] + pow[bin] + pow[bin + 1]
        val h2 = around(best * 2)
        val h3 = around(best * 3)
        val harm = if (peak > 0f) (h2 + h3) / peak else 1f
        val isWhistle = db >= Config.WHISTLE_MIN_DB[sens] && tonal >= Config.WHISTLE_TONAL[sens] && harm < Config.WHISTLE_HARM[sens]
        pitch.value = if (isWhistle) freq else 0f
        step(isWhistle, freq)
    }

    private fun step(isWhistle: Boolean, freq: Float) {
        if (isWhistle) {
            val prev = runFreqs.lastOrNull()
            if (prev != null && abs(freq / prev - 1f) > 0.09f) endRun()
            runFreqs.add(freq)
            gap = 0
            // Túl hosszú egyenletes hang: nem fütty – eldobja
            if (runFreqs.size * FRAME_MS > maxMs + 600) { verdict.value = "✗ túl hosszú hang (nem fütty)"; runFreqs.clear(); fired = true }
        } else if (runFreqs.isNotEmpty()) {
            // Egy-két kimaradó keret belefér (levegővétel, recsegés)
            if (++gap > 2) endRun()
        }
    }

    private fun endRun() {
        val dur = runFreqs.size * FRAME_MS
        if (dur >= 200 && !fired) {
            val mn = runFreqs.minOrNull() ?: 0f
            val mx = runFreqs.maxOrNull() ?: 0f
            val med = median()
            lastSlope = slope()
            onTone?.invoke(med, mn, mx, dur)
            judge(med, mn, mx, dur, lastSlope)
        }
        runFreqs.clear()
        gap = 0
        fired = false
    }

    /** Egy befejezett hang: a füttyöd-e? (hossz, hangmagasság, dallamív, ingadozás, minta) */
    private fun judge(med: Float, mn: Float, mx: Float, dur: Int, sl: Float) {
        val why = when {
            dur < needMs -> "✗ túl rövid (${dur} ms)"
            dur > maxMs -> "✗ túl hosszú (${dur} ms)"
            mx / mn.coerceAtLeast(1f) < Config.WHISTLE_MIN_WOBBLE -> "✗ gépi sípolás (túl egyenletes)"
            profMed > 0f && kotlin.math.abs(med / profMed - 1f) > tol -> "✗ más hangmagasság (%.0f Hz, a tiéd ~%.0f)".format(med, profMed)
            profMed == 0f && med !in minHz..maxHz -> "✗ a tartományon kívül (%.0f Hz)".format(med)
            profMed > 0f && kotlin.math.abs(ln(sl / profSlope)) > 0.15f ->
                "✗ más a dallama (" + (if (sl > 1.03f) "emelkedő" else if (sl < 0.97f) "ereszkedő" else "egyenes") + ")"
            else -> null
        }
        if (why != null) { verdict.value = why; return }
        if (paused || training) { verdict.value = "✓ a te füttyöd (%.0f Hz)".format(med); return }
        val now = android.os.SystemClock.elapsedRealtime()
        if (double && now - lastMatchAt !in 250L..2_500L) {
            lastMatchAt = now
            verdict.value = "✓ első fütty – jöhet a második"
            return
        }
        lastMatchAt = 0L
        verdict.value = "✓ FELISMERVE (%.0f Hz)".format(med)
        onDetect?.invoke(med)
    }

    /** Dallamív: az utolsó harmad mediánja / az első harmad mediánja (>1 emelkedő, <1 ereszkedő). */
    private fun slope(): Float {
        val n = runFreqs.size
        if (n < 6) return 1f
        val a = runFreqs.subList(0, n / 3).sorted()
        val b = runFreqs.subList(n - n / 3, n).sorted()
        return b[b.size / 2] / a[a.size / 2].coerceAtLeast(1f)
    }

    private fun median(): Float {
        val s = runFreqs.sorted()
        return if (s.isEmpty()) 0f else s[s.size / 2]
    }

    /** Helyben, radix-2 FFT (a bemenet már bitfordított sorrendben van). */
    private fun fft() {
        var size = 2
        while (size <= N) {
            val half = size / 2
            val step = N / size
            var i = 0
            while (i < N) {
                for (j in 0 until half) {
                    val wr = cosT[j * step]
                    val wi = -sinT[j * step]
                    val k = i + j
                    val l = k + half
                    val tr = wr * re[l] - wi * im[l]
                    val ti = wr * im[l] + wi * re[l]
                    re[l] = re[k] - tr; im[l] = im[k] - ti
                    re[k] += tr; im[k] += ti
                }
                i += size
            }
            size *= 2
        }
    }
}

/**
 * A riasztás: villogás a LED-eken (radar-söprés → SOS → stroboszkóp, körbe), teljes erejű rezgés és
 * a választott hang ismétlődve, ébresztő-hangerőn (ha kéri, maximumra húzva, utána visszaállítva).
 */
class BeaconAlarm(private val context: Context, private val glyph: GlyphController) {

    private var player: MediaPlayer? = null
    private var savedVol = -1

    suspend fun run(seconds: Int) {
        val end = SystemClock.elapsedRealtime() + seconds * 1000L
        startSound()
        startVibration()
        try {
            var round = 0
            while (SystemClock.elapsedRealtime() < end) {
                when (round % 3) {
                    0 -> radar()
                    1 -> sos()
                    else -> strobe()
                }
                round++
            }
        } finally {
            stopAll()
        }
    }

    /** Radar: egy fénycsík fut végig a hátlapon (töltőporttól a kameráig), csóvával, kétszer. */
    private suspend fun radar() {
        val order = LectureTimer.FILL_ORDER
        repeat(2) {
            for (i in order.indices) {
                val lit = (maxOf(0, i - 4)..i).map { order[it] }
                glyph.show(lit.toIntArray())
                delay(28)
            }
        }
        glyph.show(Zones.ALL); delay(160)
        glyph.off(); delay(120)
    }

    /** SOS morzejel az összes LED-del: · · · — — — · · · */
    private suspend fun sos() {
        val dot = 130L
        for ((i, sym) in "...---...".withIndex()) {
            glyph.show(Zones.ALL)
            delay(if (sym == '.') dot else dot * 3)
            glyph.off()
            delay(if (i == 2 || i == 5) dot * 3 else dot)
        }
        delay(dot * 4)
    }

    /** Stroboszkóp: a felső és az alsó fél felváltva, gyorsulva. */
    private suspend fun strobe() {
        val all = Zones.ALL
        val camera = intArrayOf(Glyph.Code_22111.A1, Glyph.Code_22111.A2, Glyph.Code_22111.B1)
        val bottom = intArrayOf(Glyph.Code_22111.E1) + Zones.LEVEL
        val ring = all.filter { it !in camera && it !in bottom }.toIntArray()
        val frames = listOf(camera, ring, bottom, ring)
        var d = 140L
        repeat(14) { k ->
            glyph.show(frames[k % frames.size])
            delay(d)
            d = maxOf(50L, d - 8)
        }
        repeat(4) { glyph.show(all); delay(60); glyph.off(); delay(60) }
    }

    private fun startSound() {
        try {
            val am = context.getSystemService(AudioManager::class.java)
            if (Settings.beaconMaxVolume(context)) {
                savedVol = am.getStreamVolume(AudioManager.STREAM_ALARM)
                am.setStreamVolume(AudioManager.STREAM_ALARM, am.getStreamMaxVolume(AudioManager.STREAM_ALARM), 0)
            }
            val attrs = AudioAttributes.Builder()
                .setUsage(AudioAttributes.USAGE_ALARM)
                .setContentType(AudioAttributes.CONTENT_TYPE_SONIFICATION)
                .build()
            val afd = context.resources.openRawResourceFd(Settings.beaconSound(context).raw)
            val mp = MediaPlayer()
            mp.setAudioAttributes(attrs)
            mp.setDataSource(afd.fileDescriptor, afd.startOffset, afd.length)
            afd.close()
            mp.isLooping = true
            mp.prepare()
            mp.start()
            player = mp
        } catch (t: Throwable) {
            DebugState.log("Beacon: a hang nem indult (${t.javaClass.simpleName})")
        }
    }

    private fun startVibration() {
        if (!Settings.beaconVibrate(context)) return
        try {
            val v = context.getSystemService(VibratorManager::class.java).defaultVibrator
            // Teljes erő: hosszú-rövid-rövid lüktetés, ismételve
            val timings = longArrayOf(0, 700, 120, 180, 100, 180, 300)
            val amps = intArrayOf(0, 255, 0, 255, 0, 255, 0)
            v.vibrate(VibrationEffect.createWaveform(timings, amps, 1))
        } catch (t: Throwable) {
            DebugState.log("Beacon: rezgés hiba")
        }
    }

    private fun stopAll() {
        try { player?.stop() } catch (t: Throwable) { }
        try { player?.release() } catch (t: Throwable) { }
        player = null
        try { context.getSystemService(VibratorManager::class.java).defaultVibrator.cancel() } catch (t: Throwable) { }
        if (savedVol >= 0) {
            try {
                context.getSystemService(AudioManager::class.java).setStreamVolume(AudioManager.STREAM_ALARM, savedVol, 0)
            } catch (t: Throwable) { }
            savedVol = -1
        }
        glyph.off()
    }

    companion object {
        /** Rövid megerősítő hang az appban (pl. sikeres betanítás). */
        fun blip(context: Context) {
            try {
                val mp = MediaPlayer.create(context, R.raw.beacon_ok) ?: return
                mp.setOnCompletionListener { it.release() }
                mp.start()
            } catch (t: Throwable) { }
        }
    }
}
