package com.akos.glypheggs

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.Service
import android.content.BroadcastReceiver
import android.content.ComponentName
import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.content.pm.ServiceInfo
import android.graphics.drawable.Icon
import android.media.AudioManager
import android.os.IBinder
import android.os.SystemClock
import android.service.quicksettings.TileService
import kotlinx.coroutines.CompletableDeferred
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.NonCancellable
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.cancel
import kotlinx.coroutines.channels.Channel
import kotlinx.coroutines.coroutineScope
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.MutableSharedFlow
import kotlinx.coroutines.flow.first
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.filter
import kotlinx.coroutines.flow.map
import kotlinx.coroutines.flow.merge
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import kotlinx.coroutines.withTimeoutOrNull

/**
 * Előtérszolgáltatás (állandó értesítéssel): ez vezérli a LED-eket és a szenzorokat.
 *
 *  - Mozdulatfigyelés: ha be van kapcsolva, a beállított indító mozdulatokra
 *    ([Trigger]) elindítja a hozzájuk rendelt funkciót ([Feature]).
 *  - Simon, Pörgetés, Iránytű: csempéről, az appból vagy mozdulattal indulnak.
 *  - Ha nincs Glyph (más telefon), a funkciók akkor is futnak: a képernyőn,
 *    a szimulációs módban látszanak.
 *
 * Ha a figyelés ki van kapcsolva, a szolgáltatás csak egy feladat idejére fut.
 */
class SimonService : Service() {

    companion object {
        const val ACTION_WATCH_ON = "com.akos.glypheggs.WATCH_ON"
        const val ACTION_WATCH_OFF = "com.akos.glypheggs.WATCH_OFF"
        const val ACTION_WATCH_TOGGLE = "com.akos.glypheggs.WATCH_TOGGLE"
        const val ACTION_REFRESH = "com.akos.glypheggs.REFRESH"
        const val ACTION_START_GAME = "com.akos.glypheggs.START_GAME"
        const val ACTION_SPIN = "com.akos.glypheggs.SPIN"
        const val ACTION_COMPASS = "com.akos.glypheggs.COMPASS"
        const val ACTION_LOCKPICK = "com.akos.glypheggs.LOCKPICK"
        const val ACTION_SAFE = "com.akos.glypheggs.SAFE"
        const val ACTION_PET = "com.akos.glypheggs.PET"
        const val ACTION_LEVEL = "com.akos.glypheggs.LEVEL"
        const val ACTION_TIMER = "com.akos.glypheggs.TIMER"
        const val ACTION_BREATH = "com.akos.glypheggs.BREATH"
        const val ACTION_DETOX = "com.akos.glypheggs.DETOX"
        const val ACTION_MORSE = "com.akos.glypheggs.MORSE"
        /** Glyph Stúdió: lejátszás a hátlapon; EXTRA_ANIM = az animáció (nélküle a kedvenc). */
        const val ACTION_STUDIO = "com.akos.glypheggs.STUDIO"
        const val EXTRA_ANIM = "anim"
        const val ACTION_DINO = "com.akos.glypheggs.DINO"
        const val ACTION_LECTURE = "com.akos.glypheggs.LECTURE"
        const val ACTION_BLOW = "com.akos.glypheggs.BLOW"
        /** A Fújós oldalról jött: a mikrofon már fut, indulhat a játék. */
        const val SOURCE_BLOW_PAGE = "blow_page"

        fun actionFor(f: Feature): String = when (f) {
            Feature.SIMON -> ACTION_START_GAME
            Feature.SPIN -> ACTION_SPIN
            Feature.COMPASS -> ACTION_COMPASS
            Feature.LOCKPICK -> ACTION_LOCKPICK
            Feature.SAFE -> ACTION_SAFE
            Feature.PET -> ACTION_PET
            Feature.LEVEL -> ACTION_LEVEL
            Feature.TIMER -> ACTION_TIMER
            Feature.BREATH -> ACTION_BREATH
            Feature.DINO -> ACTION_DINO
            Feature.LECTURE -> ACTION_LECTURE
            Feature.BLOW -> ACTION_BLOW
            Feature.DETOX -> ACTION_DETOX
            Feature.MORSE -> ACTION_MORSE
            Feature.STUDIO -> ACTION_STUDIO
        }
        const val ACTION_STOP = "com.akos.glypheggs.STOP"
        /** Honnan jött az indítás (pl. widget) – az Előadás widgetről azonnal, rázás nélkül indulhat. */
        const val EXTRA_SOURCE = "source"
        const val SOURCE_WIDGET = "widget"
        /** Az Előadás widget START gombja: mindig azonnal indul (rázás és lerakás nélkül). */
        const val SOURCE_INSTANT = "instant"
        /** Egy funkció indító mozdulatának figyelése be/ki (widgetről); EXTRA_FEATURE a funkció neve. */
        const val ACTION_ARM_TOGGLE = "com.akos.glypheggs.ARM_TOGGLE"
        const val EXTRA_FEATURE = "feature"
        private const val CHANNEL_ID = "glyph_eggs"
        private const val CHANNEL_HIDDEN = "glyph_eggs_hidden"
        /** Az értesítés-beállítás változott: az állandó értesítés újrarajzolása. */
        const val ACTION_NOTIF_REFRESH = "com.akos.glypheggs.NOTIF_REFRESH"
        private const val NOTIF_ID = 1

        /** Be van-e kapcsolva a mozdulatfigyelés (a csempe ebből mutatja az állapotot). */
        @Volatile
        var watching = false
            private set

        /** Be van-e kapcsolva a háttérbeli fújásfigyelés (a mikrofon fut). */
        @Volatile
        var blowListening = false
            private set

        /** Glyph Beacon: fütty-figyelés be/ki, próba-riasztás, riasztás leállítása. */
        /** Hangasszisztens: a LED-ek beszéd-animációja (a [TalkBus] állapotáig fut). */
        const val ACTION_TALK = "com.akos.glypheggs.TALK"
        /** Claude app mód: a LED-ek a hivatalos Claude app hangját követik (nem kell API-kulcs). */
        const val ACTION_CLAUDE_VOICE = "com.akos.glypheggs.CLAUDE_VOICE"
        const val ACTION_CLAUDE_VOICE_STOP = "com.akos.glypheggs.CLAUDE_VOICE_STOP"

        /** Fut-e a Claude app mód. */
        val claudeVoiceOn = kotlinx.coroutines.flow.MutableStateFlow(false)
        /** A közös mikrofon elengedése / visszavétele (a beszédfelismerés idejére); extra: EXTRA_HOLD. */
        const val ACTION_MIC_HOLD = "com.akos.glypheggs.MIC_HOLD"
        const val EXTRA_HOLD = "hold"
        const val ACTION_BEACON_ON = "com.akos.glypheggs.BEACON_ON"
        const val ACTION_BEACON_OFF = "com.akos.glypheggs.BEACON_OFF"
        const val ACTION_BEACON_TEST = "com.akos.glypheggs.BEACON_TEST"
        const val ACTION_BEACON_STOP = "com.akos.glypheggs.BEACON_STOP"

        /** Figyel-e a Beacon (fut a mikrofon a fütty miatt). */
        @Volatile
        var beaconListening = false
            private set

        /** Épp szól-e a Beacon riasztás. */
        val beaconAlarming = kotlinx.coroutines.flow.MutableStateFlow(false)

        /** Fut-e a szolgáltatás mikrofonja (fújás- vagy fütty-figyelés). */
        @Volatile
        var micOn = false
            private set

        const val ACTION_BLOW_LISTEN_ON = "com.akos.glypheggs.BLOW_LISTEN_ON"
        const val ACTION_BLOW_LISTEN_OFF = "com.akos.glypheggs.BLOW_LISTEN_OFF"
        /** A fújásfigyelés indította a játékot. */
        const val SOURCE_BLOW_LISTEN = "blow_listen"
        /** Az órarend indította az előadást (azonnal, a bejegyzés hosszával); extra: EXTRA_SCHEDULE_ID. */
        const val SOURCE_SCHEDULE = "schedule"
        const val EXTRA_SCHEDULE_ID = "schedule_id"

        /** Fut-e most az iránytű. */
        @Volatile
        var compassOn = false
            private set

        private const val IDLE_TEXT = "Készenlét"
    }

    private val scope = CoroutineScope(SupervisorJob() + Dispatchers.Default)
    private lateinit var glyph: GlyphController
    private lateinit var motion: MotionDetector
    private lateinit var haptics: Haptics
    private var job: Job? = null

    /** Rázás-töltéssel indult: az első rázás után a LED-eket fel kell tölteni, és csak utána indul a funkció. */
    private var pendingFill = false
    private var fillEvents: Channel<Long>? = null
    private var fillCollector: Job? = null
    /** A funkció már a rázás-töltés után indult (az Előadás így kihagyja a saját töltését). */
    private var filledByTrigger = false
    /** Widgetről kért pörgetés: nem vár a lerakásra. */
    private var spinInstant = false

    /** Widgetről, azonnali indításra (rázás és lerakás nélkül) kért Előadás. */
    private var lectureInstant = false

    /** A képernyő bekapcsolása (= a bekapcsoló gomb megnyomása kikapcsolt képernyőnél). */
    private val screenOn = MutableSharedFlow<Long>(extraBufferCapacity = 4)
    /** Minden bekapcsoló-gombnyomás (a képernyő be- vagy kikapcsolása) – a Dínó ugráshoz. */
    private val powerPresses = MutableSharedFlow<Long>(extraBufferCapacity = 8)
    /** Hangerő-gombok játék közben: +1 fel, −1 le. */
    private val volumeKeys = MutableSharedFlow<Int>(extraBufferCapacity = 8)
    // Hangerő-gombos indítás: a hangerő változásából ismeri fel a gombnyomást, utána visszaállítja
    private var volCount = 0
    private var volDir = 0
    private var volStream = -1
    private var volStart = 0
    private var volFirstMs = 0L
    private var volLastMs = 0L
    @Volatile private var volRestoring = false

    private val volumeReceiver = object : BroadcastReceiver() {
        override fun onReceive(context: Context, intent: Intent) {
            if (!watching || volRestoring) return
            val active = Settings.activeTriggers(this@SimonService)
            if (Trigger.VOL_COMBO in active) comboPress(intent)
            if (Trigger.VOL_UP_2 !in active && Trigger.VOL_DOWN_2 !in active) return
            val type = intent.getIntExtra("android.media.EXTRA_VOLUME_STREAM_TYPE", -1)
            val v = intent.getIntExtra("android.media.EXTRA_VOLUME_STREAM_VALUE", -1)
            val prev = intent.getIntExtra("android.media.EXTRA_PREV_VOLUME_STREAM_VALUE", -1)
            if (v < 0 || prev < 0 || v == prev) return
            val now = SystemClock.elapsedRealtime()
            val dir = if (v > prev) 1 else -1
            // Egy gombnyomásra több hangfolyam is jelezhet (csengő, értesítés): csak az elsőt számolja
            if (volCount > 0 && type != volStream) return
            if (now - volLastMs < 120) return
            if (volCount > 0 && (dir != volDir || now - volFirstMs > Config.VOL_WINDOW_MS)) volCount = 0
            if (volCount == 0) {
                volFirstMs = now
                volDir = dir
                volStream = type
                volStart = prev
            }
            volLastMs = now
            volCount++
            if (volCount >= 2) {
                volCount = 0
                val t = if (dir > 0) Trigger.VOL_UP_2 else Trigger.VOL_DOWN_2
                if (t !in active) return
                // A hangerő vissza oda, ahol a két nyomás előtt volt
                volRestoring = true
                try {
                    getSystemService(AudioManager::class.java).setStreamVolume(volStream, volStart, 0)
                } catch (e: Throwable) {
                    DebugState.log("Hangerő visszaállítása nem sikerült")
                }
                scope.launch { delay(400); volRestoring = false }
                DebugState.log("Mozdulat felismerve: ${t.title}")
                onTrigger(t)
            }
        }
    }

    // Hangerő-kombináció: a nyomások sorozata (U/D); a sorozat után rövid szünetnél kiértékel
    private val comboBuf = StringBuilder()
    private var comboStream = -1
    private var comboStartVol = 0
    private var comboLast = 0L
    private var comboJob: Job? = null

    private fun comboPress(intent: Intent) {
        val type = intent.getIntExtra("android.media.EXTRA_VOLUME_STREAM_TYPE", -1)
        val v = intent.getIntExtra("android.media.EXTRA_VOLUME_STREAM_VALUE", -1)
        val prev = intent.getIntExtra("android.media.EXTRA_PREV_VOLUME_STREAM_VALUE", -1)
        if (v < 0 || prev < 0 || v == prev) return
        val now = SystemClock.elapsedRealtime()
        if (comboBuf.isNotEmpty() && type != comboStream) return // ugyanarra a nyomásra jelző másik hangfolyam
        if (now - comboLast < 120) return
        if (comboBuf.isNotEmpty() && now - comboLast > Config.VOL_COMBO_GAP_MS) comboBuf.setLength(0)
        if (comboBuf.isEmpty()) { comboStream = type; comboStartVol = prev }
        comboLast = now
        comboBuf.append(if (v > prev) 'U' else 'D')
        if (comboBuf.length > 8) comboBuf.deleteCharAt(0)
        comboJob?.cancel()
        comboJob = scope.launch {
            delay(Config.VOL_COMBO_END_MS)
            withContext(Dispatchers.Main) {
                val seq = comboBuf.toString()
                comboBuf.setLength(0)
                val f = Settings.volCombos(this@SimonService)[seq] ?: return@withContext
                volRestoring = true
                try {
                    getSystemService(AudioManager::class.java).setStreamVolume(comboStream, comboStartVol, 0)
                } catch (e: Throwable) { }
                scope.launch { delay(400); volRestoring = false }
                DebugState.log("Hangerő-kombináció felismerve: ${comboText(seq)} → ${f.title}")
                haptics.tick()
                toggle(f)
            }
        }
    }

    private val screenReceiver = object : BroadcastReceiver() {
        override fun onReceive(context: Context, intent: Intent) {
            val t = SystemClock.elapsedRealtime()
            if (intent.action == Intent.ACTION_SCREEN_ON) screenOn.tryEmit(t)
            powerPresses.tryEmit(t)
        }
    }

    override fun onCreate() {
        super.onCreate()
        createChannel()
        startForeground(NOTIF_ID, buildNotification(IDLE_TEXT), ServiceInfo.FOREGROUND_SERVICE_TYPE_SPECIAL_USE)
        EnergyMeter.attach(this)
        registerReceiver(screenReceiver, IntentFilter(Intent.ACTION_SCREEN_ON).apply { addAction(Intent.ACTION_SCREEN_OFF) })
        // A hangerő-változás nem védett rendszerüzenet, ezért „exportált” fogadó kell
        registerReceiver(volumeReceiver, IntentFilter("android.media.VOLUME_CHANGED_ACTION"), Context.RECEIVER_EXPORTED)

        haptics = Haptics(this)
        glyph = GlyphController(this).also { it.init() }
        motion = MotionDetector(this) { t -> onTrigger(t) }.also { it.start() }
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        when (intent?.action) {
            // Rendszer általi újraindításnál (null) a mentett beállítás dönt
            null -> {
                setWatching(Settings.watching(this))
                if (Settings.beaconOn(this)) setBeaconListen(true)
            }
            ACTION_WATCH_ON -> setWatching(true)
            ACTION_WATCH_OFF -> setWatching(false)
            ACTION_WATCH_TOGGLE -> {
                val on = !Settings.watching(this)
                Settings.setWatching(this, on)
                setWatching(on)
            }
            ACTION_REFRESH -> {
                motion.setWatching(watching, Settings.activeTriggers(this))
                if (job?.isActive != true) showIdle()
                stopIfIdle()
            }
            ACTION_START_GAME -> toggle(Feature.SIMON)
            ACTION_SPIN -> {
                // Widgetről: azonnal pörög (nem vár a lerakásra)
                spinInstant = intent?.getStringExtra(EXTRA_SOURCE) == SOURCE_WIDGET
                toggle(Feature.SPIN)
                spinInstant = false
            }
            ACTION_COMPASS -> toggle(Feature.COMPASS)
            ACTION_LOCKPICK -> toggle(Feature.LOCKPICK)
            ACTION_SAFE -> toggle(Feature.SAFE)
            ACTION_PET -> toggle(Feature.PET)
            ACTION_LEVEL -> toggle(Feature.LEVEL)
            ACTION_TIMER -> toggle(Feature.TIMER)
            ACTION_BREATH -> toggle(Feature.BREATH)
            ACTION_DETOX -> toggle(Feature.DETOX)
            ACTION_MORSE -> toggle(Feature.MORSE)
            ACTION_STUDIO -> {
                studioAnimId = intent?.getStringExtra(EXTRA_ANIM)
                // Az épp futó lejátszás helyett az újat (a Stúdióból indítva ne állítsa le, hanem cserélje)
                if (studioAnimId != null && GlyphMirror.mode.value == Feature.STUDIO) {
                    val id = studioAnimId
                    val running = job
                    scope.launch {
                        running?.cancel(); running?.join()
                        withContext(Dispatchers.Main) { studioAnimId = id; toggle(Feature.STUDIO) }
                    }
                } else toggle(Feature.STUDIO)
            }
            ACTION_DINO -> toggle(Feature.DINO)
            ACTION_LECTURE -> {
                val src = intent?.getStringExtra(EXTRA_SOURCE)
                if (src == SOURCE_SCHEDULE) {
                    startScheduledLecture(intent?.getStringExtra(EXTRA_SCHEDULE_ID))
                } else {
                    lectureInstant = src == SOURCE_INSTANT || (src == SOURCE_WIDGET && Settings.lectureWidgetInstant(this))
                    toggle(Feature.LECTURE)
                    lectureInstant = false
                }
            }
            ACTION_BLOW -> toggle(Feature.BLOW)
            ACTION_NOTIF_REFRESH -> {
                updateNotification(DebugState.status.value)
                stopIfIdle()
            }
            ACTION_BLOW_LISTEN_ON -> {
                Settings.setBlowAlways(this, true)
                // Csak a Mozdulatfigyeléssel együtt figyel
                if (watching) setBlowListen(true) else {
                    DebugState.log("Fújásfigyelés: bekapcsolva – a Mozdulatfigyeléssel együtt indul")
                    stopIfIdle()
                }
            }
            ACTION_BLOW_LISTEN_OFF -> {
                Settings.setBlowAlways(this, false)
                setBlowListen(false)
            }
            ACTION_BEACON_ON -> {
                Settings.setBeaconOn(this, true)
                setBeaconListen(true)
            }
            ACTION_BEACON_OFF -> {
                Settings.setBeaconOn(this, false)
                setBeaconListen(false)
            }
            ACTION_BEACON_TEST -> startBeaconAlarm("próba")
            ACTION_TALK -> startTalk()
            ACTION_CLAUDE_VOICE -> startClaudeVoice()
            ACTION_CLAUDE_VOICE_STOP -> {
                claudeJob?.cancel()
                stopIfIdle()
            }
            ACTION_MIC_HOLD -> micHold(intent?.getBooleanExtra(EXTRA_HOLD, false) == true)
            ACTION_BEACON_STOP -> {
                beaconJob?.cancel()
                stopIfIdle()
            }
            ACTION_ARM_TOGGLE -> {
                val f = Feature.entries.firstOrNull { it.name == intent?.getStringExtra(EXTRA_FEATURE) }
                if (f != null) toggleArmed(f)
            }
            ACTION_STOP -> {
                Settings.setWatching(this, false)
                setWatching(false)
                job?.cancel()
                stopSelf()
                return START_NOT_STICKY
            }
        }
        return START_STICKY
    }

    private fun setWatching(on: Boolean) {
        watching = on
        EnergyMeter.setWatching(on)
        // A fújásfigyelés (ha be van kapcsolva) a Mozdulatfigyeléssel együtt indul és áll le
        if (on && Settings.blowAlways(this)) setBlowListen(true)
        if (!on && blowListening) setBlowListen(false)
        val active = Settings.activeTriggers(this)
        motion.setWatching(on, active)
        refreshTiles()
        Widgets.updateBar(this)
        Widgets.updateLecture(this)
        Widgets.updateCompass(this)
        DebugState.log(
            if (on) "Mozdulatfigyelés be: " + active.joinToString { it.title }.ifEmpty { "nincs kiosztott mozdulat" }
            else "Mozdulatfigyelés kikapcsolva"
        )
        if (job?.isActive != true) {
            showIdle()
            if (!on) stopIfIdle()
        }
    }

    /** Leáll, ha nincs mozdulatfigyelés, fújásfigyelés és futó funkció. */
    private fun stopIfIdle() {
        if (!watching && !blowListening && !beaconListening && job?.isActive != true && beaconJob?.isActive != true && talkJob?.isActive != true && claudeJob?.isActive != true) stopSelf()
    }

    // ------------------------------------------------------------------ fújásfigyelés

    private var blowRecorder: BlowRecorder? = null

    /**
     * A szolgáltatás közös mikrofonja (fújás- és fütty-figyelés). „Mikrofon” típusú előtér-szolgáltatásként
     * csak akkor indítható, amikor az app látható – ezért az app megnyitásakor kapcsol vissza.
     */
    private fun micStart(what: String): Boolean {
        if (blowRecorder != null) return true
        if (checkSelfPermission(android.Manifest.permission.RECORD_AUDIO) != android.content.pm.PackageManager.PERMISSION_GRANTED) {
            DebugState.log("$what: nincs mikrofon-engedély")
            return false
        }
        try {
            startForeground(NOTIF_ID, buildNotification("$what be"),
                ServiceInfo.FOREGROUND_SERVICE_TYPE_SPECIAL_USE or ServiceInfo.FOREGROUND_SERVICE_TYPE_MICROPHONE)
        } catch (t: Throwable) {
            DebugState.log("$what: a mikrofon most nem indítható a háttérben – nyisd meg az appot")
            return false
        }
        val r = BlowRecorder(this)
        if (!r.start()) {
            DebugState.log("$what: a mikrofon nem indult el")
            return false
        }
        blowRecorder = r
        micOn = true
        return true
    }

    /** A beszédfelismerés idejére elengedi a mikrofont (a figyelések szünetelnek), utána visszaveszi. */
    private fun micHold(hold: Boolean) {
        if (hold) {
            if (blowRecorder != null) {
                blowRecorder?.stop()
                blowRecorder = null
                micHeld = true
            }
        } else if (micHeld) {
            micHeld = false
            if (blowRecorder == null && (blowListening || beaconListening)) {
                val r = BlowRecorder(this)
                if (r.start()) blowRecorder = r else micOn = false
            }
        }
    }

    private var micHeld = false

    // ------------------------------------------------------------------ hangasszisztens LED-ek

    private var talkJob: Job? = null

    private fun startTalk() {
        if (talkJob?.isActive == true) return
        if (job?.isActive == true || beaconJob?.isActive == true || claudeJob?.isActive == true) return // a LED-ek foglaltak
        if (!Settings.assistantLeds(this)) return
        talkJob = scope.launch {
            try {
                withTimeoutOrNull(2_000) { while (!glyph.connected) delay(100) }
                glyph.openSession()
                TalkGlyph(this@SimonService, glyph).run()
            } finally {
                glyph.off()
                glyph.closeSession()
                withContext(NonCancellable + Dispatchers.Main) { stopIfIdle() }
            }
        }
    }

    // ------------------------------------------------------------------ Claude app mód

    private var claudeJob: Job? = null
    @Volatile private var claudeLastSound = 0L

    /**
     * A LED-ek a telefonon szóló hangot követik (a Claude app hangmódja), amíg 5 percig csend nincs,
     * vagy le nem állítják. Ha más funkció fut, azt leállítja.
     */
    private fun startClaudeVoice() {
        if (claudeJob?.isActive == true) return
        if (beaconJob?.isActive == true) return
        talkJob?.cancel()
        val running = job
        try {
            // A hang követéséhez a hangrögzítési jogosultság kell a háttérben is
            startForeground(NOTIF_ID, buildNotification("AI mód – a LED-ek a(z) ${Settings.aiName(this)} hangját követik"),
                ServiceInfo.FOREGROUND_SERVICE_TYPE_SPECIAL_USE or ServiceInfo.FOREGROUND_SERVICE_TYPE_MICROPHONE)
        } catch (t: Throwable) {
            DebugState.log("AI mód: mikrofon-típusú háttérfutás most nem kapcsolható")
        }
        claudeJob = scope.launch {
            claudeVoiceOn.value = true
            GameStats.count(this@SimonService, "ai_talk")
            val follower = SoundFollower(this@SimonService)
            withContext(Dispatchers.Main) { follower.start() }
            claudeLastSound = SystemClock.elapsedRealtime()
            try {
                if (running?.isActive == true) {
                    running.cancel()
                    running.join()
                }
                withTimeoutOrNull(2_000) { while (!glyph.connected) delay(100) }
                glyph.openSession()
                setStatus("AI mód · beszélj a(z) ${Settings.aiName(this@SimonService)} appban, a LED-ek a válaszát mutatják")
                DebugState.log("AI mód be (${Settings.aiName(this@SimonService)})" + if (follower.visualOk) " (hanghullám)" else " (ütem)")
                TalkBus.state.value = TalkState.LISTENING
                Widgets.updateAssistant(this@SimonService)
                val driver = launch {
                    var prev = 0f
                    var lastState = TalkState.LISTENING
                    var nextSyl = 0L
                    while (true) {
                        val now = SystemClock.elapsedRealtime()
                        val real = follower.realLevel()
                        val speaking = if (real) now - follower.lastLoud < 350 else follower.playing
                        if (speaking) {
                            claudeLastSound = now
                            if (real) {
                                val lv = follower.level
                                if (lv > 0.08f) TalkBus.syllable(lv)
                                if (prev < 0.06f && lv > 0.12f) TalkBus.word()
                                prev = lv
                            } else if (now >= nextSyl) {
                                TalkBus.syllable(0.5f + (Math.random() * 0.5).toFloat())
                                if (Math.random() < 0.35) TalkBus.word()
                                nextSyl = now + 150 + (Math.random() * 90).toLong()
                            }
                        } else prev = 0f
                        val st = if (speaking) TalkState.SPEAKING else TalkState.LISTENING
                        TalkBus.micLevel = 0f
                        if (st != lastState) {
                            lastState = st
                            TalkBus.state.value = st
                            Widgets.updateAssistant(this@SimonService)
                        }
                        delay(40)
                    }
                }
                TalkGlyph(this@SimonService, glyph).run {
                    SystemClock.elapsedRealtime() - claudeLastSound < Config.CLAUDE_IDLE_MS
                }
                driver.cancel()
                DebugState.log("AI mód: 5 perc csend – leállt")
            } finally {
                withContext(NonCancellable + Dispatchers.Main) { follower.stop() }
                TalkBus.state.value = TalkState.IDLE
                glyph.off()
                glyph.closeSession()
                claudeVoiceOn.value = false
                Achievements.check(this@SimonService)
                withContext(NonCancellable + Dispatchers.Main) {
                    if (!micOn) {
                        try {
                            startForeground(NOTIF_ID, buildNotification(IDLE_TEXT), ServiceInfo.FOREGROUND_SERVICE_TYPE_SPECIAL_USE)
                        } catch (t: Throwable) { }
                    }
                    Widgets.updateAssistant(this@SimonService)
                    showIdle()
                    stopIfIdle()
                }
            }
        }
    }

    private fun micStopIfUnused() {
        if (blowListening || beaconListening) return
        micHeld = false
        blowRecorder?.stop()
        blowRecorder = null
        micOn = false
        try {
            startForeground(NOTIF_ID, buildNotification(IDLE_TEXT), ServiceInfo.FOREGROUND_SERVICE_TYPE_SPECIAL_USE)
        } catch (t: Throwable) {
            // nincs teendő
        }
    }

    // ------------------------------------------------------------------ Glyph Beacon

    private var beaconListenJob: Job? = null
    private var beaconJob: Job? = null
    private var beaconCooldownUntil = 0L

    /** Fütty-figyelés be/ki: a közös mikrofonra kapcsolja a füttyfelismerőt. */
    private fun setBeaconListen(on: Boolean) {
        if (on == beaconListening) {
            if (on) wireBeaconDetectors()
            return
        }
        if (on) {
            if (!micStart("Glyph Beacon")) {
                stopIfIdle()
                return
            }
            beaconListening = true
            wireBeaconDetectors()
            DebugState.log("Glyph Beacon be – " + listOfNotNull(
                if (Settings.beaconWhistleOn(this)) "fütty" else null,
                if (Settings.beaconVoiceOn(this) && Keyword.trained(this)) "„Beacon” hangparancs" else null
            ).joinToString(" + ").ifEmpty { "nincs bekapcsolt jel!" })
            beaconListenJob = scope.launch {
                var last = SystemClock.elapsedRealtime()
                while (true) {
                    delay(60_000L)
                    val now = SystemClock.elapsedRealtime()
                    EnergyMeter.addExtra(EnergyMeter.BEACON, Config.BEACON_LISTEN_MA, now - last)
                    last = now
                }
            }
        } else {
            beaconListenJob?.cancel()
            beaconListenJob = null
            Whistle.onDetect = null
            Whistle.refreshAttach()
            Keyword.onDetect = null
            Keyword.refreshAttach()
            beaconListening = false
            DebugState.log("Glyph Beacon kikapcsolva")
            micStopIfUnused()
        }
        Widgets.updateBeaconMini(this)
        if (job?.isActive != true) showIdle()
        stopIfIdle()
    }

    /** A fütty- és a hangparancs-felismerő bekötése a beállítások szerint (beállítás-változáskor is). */
    private fun wireBeaconDetectors() {
        Whistle.configure(this)
        Keyword.configure(this)
        Whistle.onDetect = if (Settings.beaconWhistleOn(this)) { hz -> scope.launch(Dispatchers.Main) { onWhistle(hz) } } else null
        Keyword.onDetect = if (Settings.beaconVoiceOn(this) && Keyword.trained(this)) {
            { scope.launch(Dispatchers.Main) { onVoice() } }
        } else null
        Whistle.refreshAttach()
        Keyword.refreshAttach()
    }

    private fun onVoice() {
        val now = SystemClock.elapsedRealtime()
        if (beaconJob?.isActive == true || now < beaconCooldownUntil) return
        DebugState.log("Glyph Beacon: „Beacon” hangparancs – itt vagyok!")
        GameStats.count(this, "beacon_found")
        Achievements.check(this)
        startBeaconAlarm("hangparancs")
    }

    private fun onWhistle(hz: Float) {
        val now = SystemClock.elapsedRealtime()
        if (beaconJob?.isActive == true || now < beaconCooldownUntil) return
        DebugState.log("Glyph Beacon: fütty %.0f Hz – itt vagyok!".format(hz))
        GameStats.count(this, "beacon_found")
        Achievements.check(this)
        startBeaconAlarm("fütty")
    }

    /**
     * A riasztás: ha más funkció fut, leállítja; aztán villog, rezeg és szól, amíg fel nem veszik
     * (bekapcsoló gomb / a képernyő bekapcsolása, az app megnyitása, az értesítés) vagy le nem telik az idő.
     */
    private fun startBeaconAlarm(reason: String) {
        if (beaconJob?.isActive == true) return
        val running = job
        talkJob?.cancel()
        val claude = claudeJob
        claude?.cancel()
        beaconJob = scope.launch {
            claude?.join()
            beaconAlarming.value = true
            Whistle.paused = true
            Keyword.paused = true
            try {
                if (running?.isActive == true) {
                    running.cancel()
                    running.join()
                }
                withTimeoutOrNull(2_000) { while (!glyph.connected) delay(100) }
                glyph.openSession()
                setStatus("GLYPH BEACON · itt vagyok! Nyomd meg a bekapcsoló gombot")
                coroutineScope {
                    val alarm = launch { BeaconAlarm(this@SimonService, glyph).run(Settings.beaconSeconds(this@SimonService)) }
                    val stopper = launch {
                        screenOn.first()
                        DebugState.log("Glyph Beacon: megtaláltad (képernyő be)")
                        alarm.cancel()
                    }
                    alarm.join()
                    stopper.cancel()
                }
            } finally {
                glyph.off()
                glyph.closeSession()
                Whistle.paused = false
                Keyword.paused = false
                beaconCooldownUntil = SystemClock.elapsedRealtime() + Config.BEACON_COOLDOWN_MS
                beaconAlarming.value = false
                DebugState.log("Glyph Beacon riasztás vége ($reason)")
                withContext(NonCancellable + Dispatchers.Main) {
                    showIdle()
                    stopIfIdle()
                }
            }
        }
    }
    private var blowListenJob: Job? = null
    /** A következő Fújós-indítás a háttérfigyelésből jön (csend esetén magától leáll). */
    private var blowBackground = false

    /**
     * Fújásfigyelés be/ki. A mikrofont az Android csak akkor engedi a háttérben, ha a szolgáltatás
     * „mikrofon” típusú előtér-szolgáltatásként fut, és ezt akkor kapcsolja be, amikor az app látható
     * (a kapcsoló megnyomásakor). Újraindítás után az app első megnyitásakor kapcsol vissza.
     */
    private fun setBlowListen(on: Boolean) {
        if (on == blowListening) return
        if (on) {
            if (checkSelfPermission(android.Manifest.permission.RECORD_AUDIO) != android.content.pm.PackageManager.PERMISSION_GRANTED) {
                DebugState.log("Fújásfigyelés: nincs mikrofon-engedély")
                return
            }
            if (!micStart("Fújásfigyelés")) return
            blowListening = true
            DebugState.log("Fújásfigyelés be – fújj a telefonba, és indul a Fújós")
            blowListenJob = scope.launch {
                var loudMs = 0L
                var cooldownUntil = 0L
                var lastEnergy = SystemClock.elapsedRealtime()
                while (true) {
                    delay(50)
                    val now = SystemClock.elapsedRealtime()
                    if (now - lastEnergy >= 60_000L) {
                        EnergyMeter.addExtra(EnergyMeter.BLOW_LISTEN, Config.BLOW_LISTEN_MA, now - lastEnergy)
                        lastEnergy = now
                    }
                    if (BlowInput.level.value >= Config.BLOW_LISTEN_LEVEL) loudMs += 50 else loudMs = 0
                    if (loudMs >= Config.BLOW_LISTEN_MS && now >= cooldownUntil && GlyphMirror.mode.value == null) {
                        loudMs = 0
                        cooldownUntil = now + 3_000
                        withContext(Dispatchers.Main) {
                            blowBackground = true
                            toggle(Feature.BLOW)
                            blowBackground = false
                        }
                    }
                }
            }
        } else {
            blowListenJob?.cancel()
            blowListenJob = null
            blowListening = false
            DebugState.log("Fújásfigyelés kikapcsolva")
            micStopIfUnused()
        }
        if (job?.isActive != true) showIdle()
        stopIfIdle()
    }

    /**
     * Widget: a funkció indító mozdulatának figyelése be/ki. Bekapcsoláskor, ha a mozdulatfigyelés
     * ki volt kapcsolva, azt is bekapcsolja; kikapcsoláskor, ha a figyelést a widget kapcsolta be és
     * már semmi más nem figyel, leállítja (akkukímélés).
     */
    private fun toggleArmed(f: Feature) {
        val on = !Settings.listening(this, f)
        Settings.setArmed(this, f, on)
        if (on) {
            if (!Settings.watching(this)) {
                Settings.setWatching(this, true)
                Settings.setWatchByWidget(this, true)
            }
            setWatching(true)
        } else if (Settings.watchByWidget(this) && Settings.activeTriggers(this).isEmpty()) {
            Settings.setWatching(this, false)
            Settings.setWatchByWidget(this, false)
            setWatching(false)
        } else {
            setWatching(Settings.watching(this))
        }
        DebugState.log("${f.title}: indító mozdulat figyelése ${if (on) "be" else "ki"} (widget)")
    }

    /** Egy felismert mozdulat: a hozzá rendelt funkció indul. */
    private fun onTrigger(t: Trigger) {
        val f = Settings.featureFor(this, t) ?: return
        if (t == Trigger.SHAKE_FILL) {
            // Futó funkció közben a rázás a funkcióé (pl. az Előadás szünete), nem indít újat
            if (job?.isActive == true) return
            startWithFill(f)
            return
        }
        haptics.tick()
        toggle(f)
    }

    /** Rázás-töltés: az első rázás után a további rázásokat gyűjti, a funkció a töltés végén indul. */
    private fun startWithFill(f: Feature) {
        val ch = Channel<Long>(64)
        fillEvents = ch
        fillCollector?.cancel()
        motion.setGameMode(true) // gyors gyorsulásmérő: ettől jönnek a rázás-események
        fillCollector = scope.launch { merge(motion.shakeEvents, GlyphMirror.taps).collect { ch.trySend(it) } }
        pendingFill = true
        DebugState.log("Rázás-töltés indul: ${f.title}")
        toggle(f)
        if (job?.isActive != true) endFill()
    }

    private fun endFill() {
        pendingFill = false
        fillCollector?.cancel()
        fillCollector = null
        fillEvents = null
    }

    /** Ha ez a funkció fut, leállítja; ha nem, elindítja. */
    private fun toggle(f: Feature) {
        // Szól a Beacon: bármilyen indítás csak elhallgattatja
        if (beaconJob?.isActive == true) {
            beaconJob?.cancel()
            return
        }
        // Claude mód közben indított funkció: előbb a Claude mód áll le (a LED-ek felszabadulnak)
        val claude = claudeJob
        if (claude?.isActive == true) {
            scope.launch {
                claude.cancel()
                claude.join()
                withContext(Dispatchers.Main) { toggle(f) }
            }
            return
        }
        if (job?.isActive == true && GlyphMirror.mode.value == f) {
            DebugState.log("${f.title} leállítva")
            job?.cancel()
            return
        }
        when (f) {
            Feature.SIMON -> startGame()
            Feature.SPIN -> startSpin()
            Feature.COMPASS -> startCompass()
            Feature.LOCKPICK -> startLockPick()
            Feature.SAFE -> startSafe()
            Feature.PET -> startPet()
            Feature.LEVEL -> startLevel()
            Feature.TIMER -> startTimer()
            Feature.BREATH -> startBreath()
            Feature.DETOX -> startDetox()
            Feature.MORSE -> startMorse()
            Feature.STUDIO -> startStudio()
            Feature.DINO -> startDino()
            Feature.LECTURE -> startLecture()
            Feature.BLOW -> startBlow()
        }
    }

    /** Megvárja, hogy kijelzővel lefelé (szimulációban felfelé is) letedd. */
    private suspend fun waitPlaced(what: String, timeoutMs: Long): Boolean {
        if (motion.faceDown.value) return true
        setStatus("Tedd le kijelzővel lefelé – $what")
        val placed = withTimeoutOrNull(timeoutMs) { motion.faceDown.first { it } } != null
        if (placed) delay(Config.SPIN_SETTLE_MS)
        return placed
    }

    private fun showIdle() {
        val text = if (watching) {
            val parts = Feature.entries.mapNotNull { f ->
                val t = Settings.trigger(this, f)
                if (t == Trigger.NONE) null else "${f.title}: ${t.title}"
            }
            if (parts.isEmpty()) "Figyel – nincs kiosztott mozdulat" else "Figyel · " + parts.joinToString(" · ")
        } else {
            IDLE_TEXT
        } + (if (blowListening) " · fújásfigyelés be" else "") + (if (beaconListening) " · Beacon figyel" else "")
        DebugState.status.value = text
        updateNotification(text)
    }

    private fun setStatus(text: String) {
        DebugState.status.value = text
        updateNotification(text)
    }

    /** Közös keret: Glyph session megnyitása (ha lehet), a feladat futtatása, utána takarítás. */
    private fun launchWithGlyph(feature: Feature, status: String, block: suspend () -> Unit) {
        if (job?.isActive == true) {
            DebugState.log("Már fut egy funkció, előbb az fejeződjön be")
            return
        }
        job = scope.launch {
            val outer = this
            EnergyMeter.begin(feature)
            val startedAt = SystemClock.elapsedRealtime()
            // Leállítási parancsok figyelése (bekapcsoló gomb, felemelés, …)
            val stopper = launch {
                val how = awaitStop(feature)
                DebugState.log("${feature.title} leállítva: ${how.title}")
                haptics.tick()
                outer.cancel()
            }
            // A telefon teljes áramfelvételének mérése futás közben (tájékoztató)
            val meter = launch {
                while (true) {
                    delay(Config.MEASURE_EVERY_MS)
                    EnergyMeter.measureNow(this@SimonService)?.let { EnergyMeter.addMeasured(feature, it, Config.MEASURE_EVERY_MS) }
                }
            }
            try {
                GlyphMirror.mode.value = feature
                Settings.setLastFeature(this@SimonService, feature)
                refreshTiles()
                Widgets.updateAll(this@SimonService)
                // Közvetlenül indulás után a Glyph szolgáltatásnak kell egy kis idő
                withTimeoutOrNull(2_000) { while (!glyph.connected) delay(100) }
                if (!glyph.openSession()) {
                    DebugState.log("Nincs Glyph-kapcsolat – csak a képernyőn látszik (szimuláció)")
                }
                if (pendingFill) {
                    val ch = fillEvents
                    val needed = Settings.shakeFillCount(this@SimonService)
                    setStatus("Rázd, amíg minden LED ég (0/$needed)")
                    val ok = ch != null && ShakeFill(glyph, haptics, needed).run(ch, 1) { setStatus(it) }
                    endFill()
                    if (!ok) return@launch
                    filledByTrigger = true
                }
                setStatus(status)
                block()
            } finally {
                endFill()
                stopper.cancel()
                meter.cancel()
                glyph.closeSession()
                EnergyMeter.end(feature)
                GameStats.session(this@SimonService, feature, SystemClock.elapsedRealtime() - startedAt)
                Achievements.check(this@SimonService)
                motion.setGameMode(false)
                GlyphMirror.mode.value = null
                refreshTiles()
                Widgets.updateAll(this@SimonService)
                showIdle()
                stopIfIdle()
            }
        }
    }

    /** Megvárja, hogy a beállított leállítási parancsok egyike megtörténjen, és visszaadja, melyik. */
    private suspend fun awaitStop(f: Feature): StopMethod = coroutineScope {
        var methods = Settings.stopMethods(this@SimonService, f)
        // Ha a Dínó a bekapcsoló gombbal ugrik, az nem állíthatja le egyben a játékot
        if (f == Feature.DINO && DinoJump.POWER in Settings.dinoJump(this@SimonService)) methods = methods - StopMethod.POWER
        val result = CompletableDeferred<StopMethod>()
        delay(Config.STOP_START_GRACE_MS)
        val watchers = methods.map { m ->
            launch {
                watchStop(m)
                result.complete(m)
            }
        }
        try {
            result.await()
        } finally {
            watchers.forEach { it.cancel() }
        }
    }

    private suspend fun watchStop(m: StopMethod) {
        when (m) {
            StopMethod.POWER -> screenOn.first()

            StopMethod.LIFT -> {
                // Előbb le kell tenni; utána ha 2 mp-ig nincs letéve, leáll
                motion.faceDown.first { it }
                while (true) {
                    motion.faceDown.first { !it }
                    val back = withTimeoutOrNull(Config.STOP_LIFT_MS) { motion.faceDown.first { it } }
                    if (back == null) return
                }
            }

            StopMethod.FLIP_UP -> {
                // Előbb valóban kijelzővel lefelé kell feküdnie; utána 1 mp kijelzővel felfelé
                motion.reallyDown.first { it }
                while (true) {
                    motion.faceUp.first { it }
                    if (GlyphMirror.simulatorOpen) {
                        motion.faceUp.first { !it }
                        continue
                    }
                    val turnedBack = withTimeoutOrNull(Config.STOP_FLIP_MS) { motion.faceUp.first { !it } }
                    if (turnedBack == null) return
                }
            }

            StopMethod.SHAKE -> {
                var last = 0L
                motion.shakeEvents.first { t ->
                    val hit = last != 0L && t - last <= Config.STOP_SHAKE_WINDOW_MS
                    last = t
                    hit
                }
            }

            StopMethod.KNOCK_3 -> coroutineScope {
                val ch = Channel<Long>(16)
                val c = launch { motion.knockEvents.collect { ch.trySend(it) } }
                try {
                    var n = 0
                    while (true) {
                        val t = if (n == 0) ch.receive() else withTimeoutOrNull(Config.KNOCK_MAX_GAP_MS) { ch.receive() }
                        if (t == null) {
                            if (n == 3) break
                            n = 0
                        } else {
                            n++
                        }
                    }
                } finally {
                    c.cancel()
                }
            }
        }
    }

    private fun startGame() = launchWithGlyph(Feature.SIMON, "Simon játék folyamatban") {
        motion.setGameMode(true)
        val level = SimonGame(glyph, motion, haptics).run()
        Settings.setLastLevel(this, level)
        GameStats.best(this, "simon", level)
        DebugState.log("Játék vége – elért szint: $level/${Config.MAX_ROUNDS}")
    }

    private fun startSpin() {
        val instant = spinInstant
        launchWithGlyph(Feature.SPIN, "Pörgetés") {
            if (!instant && !motion.faceDown.value) {
                setStatus("Tedd le kijelzővel lefelé a pörgetéshez")
                val placed = withTimeoutOrNull(Config.SPIN_PLACE_TIMEOUT_MS) { motion.faceDown.first { it } }
                if (placed == null) DebugState.log("Nem tetted le – pörgetés így is indul")
                delay(Config.SPIN_SETTLE_MS)
            }
            setStatus("Pörgetés")
            motion.setGameMode(true) // ébren tartja a telefont, és szünetelteti a mozdulatfigyelést
            try {
                SpinWheel(glyph, haptics) { angle, done -> SpinState.update(this@SimonService, angle, done) }.run()
            } finally {
                SpinState.finish(this@SimonService)
            }
        }
    }

    private fun startCompass() {
        launchWithGlyph(Feature.COMPASS, "Iránytű") {
            compassOn = true
            refreshTiles()
            try {
                motion.setGameMode(true) // ébren tartja a telefont, gyorsan figyeli a felemelést
                Compass(this, glyph, motion, haptics) { text -> setStatus(text) }.run()
            } finally {
                compassOn = false
                CompassState.clear(this@SimonService)
                refreshTiles()
            }
        }
    }

    private fun startLockPick() = launchWithGlyph(Feature.LOCKPICK, "Zárfeltörő") {
        if (!waitPlaced("a zárfeltöréshez", Config.SPIN_PLACE_TIMEOUT_MS)) DebugState.log("Nem tetted le – a kopogás csak fekve működik, de a képernyős érintés igen")
        setStatus("Zárfeltörő – kopogj, amikor a fény az édes ponton jár")
        motion.setGameMode(true)
        val pins = LockPick(glyph, motion, haptics).run()
        if (pins > Settings.lockBest(this)) Settings.setLockBest(this, pins)
        GameStats.best(this, "lock", pins)
        if (pins >= Config.LOCK_PINS) GameStats.count(this, "lock_open")
        DebugState.log("Zárfeltörő vége: $pins/${Config.LOCK_PINS} tüske")
    }

    private fun startSafe() = launchWithGlyph(Feature.SAFE, "Széf") {
        motion.setGameMode(true)
        val pre = filledByTrigger
        filledByTrigger = false
        val open = SafeLock(this, glyph, motion, haptics, pre) { text -> setStatus(text) }.run()
        GameStats.count(this@SimonService, if (open) "safe_open" else "safe_denied")
        if (open) {
            withContext(Dispatchers.Main) { SafeOpener.open(this@SimonService) }
        }
    }

    private fun startPet() = launchWithGlyph(Feature.PET, "Glyph Tojás") {
        PetAlarmReceiver.schedule(this)
        if (!waitPlaced("a Tojás gondozásához", 20_000L)) {
            DebugState.log("Nem tetted le – a Tojás alszik tovább")
            return@launchWithGlyph
        }
        motion.setGameMode(true)
        PetSession(this, glyph, motion, haptics) { text -> setStatus(text) }.run()
    }

    private fun startLevel() = launchWithGlyph(Feature.LEVEL, "Vízmérték") {
        // Bármilyen helyzetben működik: fekve, élére állítva vagy töltőporton állva
        motion.setGameMode(true)
        LevelTool(this, glyph, motion, haptics) { text -> setStatus(text) }.run()
    }

    private fun startTimer() = launchWithGlyph(Feature.TIMER, "Időzítő") {
        waitPlaced("az időzítőhöz", 10_000L)
        motion.setGameMode(true)
        val timer = FocusTimer(this, glyph, motion, haptics) { text -> setStatus(text) }
        // Hosszú lehet: a teljes időre (+10 perc) ébren tartja a telefont
        motion.holdAwake(timer.totalMs() + 10 * 60_000L)
        timer.run()
    }

    /**
     * Fújós: a fújást a Fújós oldal mikrofonja érzékeli (háttérből a mikrofon nem használható),
     * ezért ha az oldal nincs nyitva, előbb azt nyitja meg; az oldal indítja el a játékot.
     */
    private fun startBlow() {
        if (!BlowInput.active) {
            BlowLauncher.open(this)
            return
        }
        val idle = if (blowBackground || blowListening) Config.BLOW_BG_IDLE_MS else null
        launchWithGlyph(Feature.BLOW, "Fújós") {
            BlowGame(this, glyph, haptics, idle) { text -> setStatus(text) }.run()
        }
    }

    /** Az órarend szerinti, felülírt hossz és név az épp induló előadáshoz. */
    private var scheduled: LectureSchedule.Entry? = null

    /**
     * Órarendből indított előadás: azonnal (rázás és lerakás nélkül), a bejegyzés hosszával és nevével.
     * Ha már fut egy előadás, nem csinál semmit; ha más funkció fut, leállítja, és utána indul.
     */
    private fun startScheduledLecture(id: String?) {
        val e = LectureSchedule.find(this, id)
        LectureSchedule.scheduleNext(this)
        if (e == null || !Settings.lectureScheduleOn(this)) return
        if (GlyphMirror.mode.value == Feature.LECTURE) {
            DebugState.log("Órarend: már fut egy előadás – ${e.title()}")
            return
        }
        DebugState.log("Órarend: indul – ${e.title()}")
        val running = job
        scope.launch {
            if (running?.isActive == true) {
                running.cancel()
                running.join()
            }
            withContext(Dispatchers.Main) {
                scheduled = e
                lectureInstant = true
                toggle(Feature.LECTURE)
                lectureInstant = false
                scheduled = null
            }
        }
    }

    private fun startLecture() {
        // Az indítás módját most kell kiolvasni: a feladat később, a háttérben fut
        val instant = lectureInstant
        val sched = scheduled
        startLectureJob(instant, sched)
    }

    private fun startLectureJob(instant: Boolean, sched: LectureSchedule.Entry? = null) =
        launchWithGlyph(Feature.LECTURE, if (sched != null) "Előadás · ${sched.title()}" else "Előadás") {
        // Widgetről azonnal: nem vár a lerakásra, és nincs rázós töltés
        if (!instant) waitPlaced("az előadás-időzítőhöz", 15_000L)
        motion.setGameMode(true)
        val prefilled = filledByTrigger || instant
        filledByTrigger = false
        if (instant && sched == null) DebugState.log("Előadás: azonnal indul (rázás nélkül)")
        val lecture = LectureTimer(
            this, glyph, motion, haptics, prefilled,
            blocksOverride = sched?.blocks?.takeIf { it > 0 },
            blockMinOverride = sched?.blockMin?.takeIf { it > 0 },
            name = sched?.name?.takeIf { it.isNotBlank() }
        ) { text -> setStatus(text) }
        // Közel két óra: a teljes időre (+15 perc) ébren tartja a processzort
        motion.holdAwake(lecture.totalMs() + 15 * 60_000L)
        lecture.run()
    }

    /** Glyph Focus: lerakás után nő a fény, amíg nem nyúlnak hozzá. */
    /** Morze-gyakorló: kézben is megy; az első lefutás után megnyitja a megfejtő oldalt (ha nincs nyitva). */
    private fun startMorse() = launchWithGlyph(Feature.MORSE, "Morze-gyakorló") {
        motion.setGameMode(true) // ébren tartja a processzort a pontos ütemhez
        MorseTrainer(this, glyph, haptics,
            onFirstDone = { scope.launch(Dispatchers.Main) { MorseLauncher.open(this@SimonService) } }
        ) { text -> setStatus(text) }.run()
    }

    private fun startDetox() = launchWithGlyph(Feature.DETOX, "Glyph Focus") {
        if (!waitPlaced("a Glyph Focushoz", 20_000L)) {
            DebugState.log("Glyph Focus: nem tetted le – nem indult")
            return@launchWithGlyph
        }
        val goal = Settings.detoxGoal(this)
        motion.holdAwake((goal + 240) * 60_000L)
        val s = DetoxSession(this, glyph, motion, haptics) { text -> setStatus(text) }
        try {
            s.run()
        } finally {
            GameStats.best(this, "detox_min", s.minutes)
            if (s.reachedGoal) GameStats.count(this, "detox_goal")
            DebugState.log("Glyph Focus vége: ${s.minutes} perc" + if (s.reachedGoal) " – cél teljesítve" else "")
        }
    }

    /** Melyik Stúdió-animáció induljon (null = a kedvenc). */
    private var studioAnimId: String? = null

    private fun startStudio() {
        val a = StudioStore.find(this, studioAnimId) ?: StudioStore.favorite(this)
        studioAnimId = null
        if (a == null) { DebugState.log("Glyph Stúdió: nincs animáció"); return }
        launchWithGlyph(Feature.STUDIO, "Glyph Stúdió · ${a.name}") { StudioPlayer(glyph).play(a) }
    }

    private fun startBreath() = launchWithGlyph(Feature.BREATH, "Légzés") {
        // Nem kell letenni: fekve, kézben, párnán is követhető
        motion.setGameMode(true) // ébren tartja a processzort a pontos ritmushoz
        val guide = BreathGuide(this, glyph, haptics) { text -> setStatus(text) }
        motion.holdAwake(guide.totalMs() + 2 * 60_000L)
        guide.run()
    }

    private fun startDino() = launchWithGlyph(Feature.DINO, "Dínófutás") {
        val jumpSet = Settings.dinoJump(this)
        // Kopogással fekve kell játszani; rázással és gombokkal kézben is jó
        if (DinoJump.KNOCK in jumpSet) waitPlaced("a Dínófutáshoz", Config.SPIN_PLACE_TIMEOUT_MS)
        val keys = if (DinoJump.VOL_UP in jumpSet || DinoJump.VOL_DOWN in jumpSet) {
            VolumeKeys(this) { dir -> volumeKeys.tryEmit(dir) }.also { it.start() }
        } else null
        try {
            val inputs = mutableListOf<Flow<Long>>()
            if (DinoJump.KNOCK in jumpSet) inputs += motion.knockEvents
            if (DinoJump.SHAKE in jumpSet) inputs += motion.shakeHits
            if (DinoJump.VOL_UP in jumpSet) inputs += volumeKeys.filter { it > 0 }.map { SystemClock.elapsedRealtime() }
            if (DinoJump.VOL_DOWN in jumpSet) inputs += volumeKeys.filter { it < 0 }.map { SystemClock.elapsedRealtime() }
            if (DinoJump.POWER in jumpSet) inputs += powerPresses
            setStatus("Dínófutás – ugrás: " + jumpSet.joinToString(", ") { it.title } + "; villogó madár fölött ne ugorj!")
            motion.setGameMode(true)
            val score = DinoGame(glyph, motion, haptics, inputs.merge()).run()
            if (score > Settings.dinoBest(this)) Settings.setDinoBest(this, score)
            GameStats.best(this, "dino", score)
            DebugState.log("Dínófutás vége: $score pont")
        } finally {
            keys?.stop()
        }
    }

    override fun onDestroy() {
        blowListenJob?.cancel()
        beaconListenJob?.cancel()
        beaconJob?.cancel()
        claudeJob?.cancel()
        claudeVoiceOn.value = false
        Whistle.onDetect = null
        Whistle.refreshAttach()
        Keyword.onDetect = null
        Keyword.refreshAttach()
        blowRecorder?.stop()
        blowListening = false
        beaconListening = false
        Widgets.updateBeaconMini(this)
        micOn = false
        beaconAlarming.value = false
        try {
            unregisterReceiver(screenReceiver)
            unregisterReceiver(volumeReceiver)
        } catch (t: Throwable) {
            // nem volt regisztrálva
        }
        EnergyMeter.setWatching(false)
        EnergyMeter.flush()
        scope.cancel()
        motion.stop()
        glyph.release()
        watching = false
        compassOn = false
        GlyphMirror.mode.value = null
        refreshTiles()
        Widgets.updateAll(this)
        DebugState.status.value = "Leállítva"
        DebugState.log("Szolgáltatás leállt")
        super.onDestroy()
    }

    override fun onBind(intent: Intent?): IBinder? = null

    private fun refreshTiles() {
        for (cls in listOf(
            SimonTileService::class.java, SpinTileService::class.java, CompassTileService::class.java,
            LockTileService::class.java, SafeTileService::class.java, PetTileService::class.java,
            LevelTileService::class.java, TimerTileService::class.java, BreathTileService::class.java, DetoxTileService::class.java, StudioTileService::class.java, MorseTileService::class.java,
            DinoTileService::class.java, LectureTileService::class.java, BlowTileService::class.java
        )) {
            TileService.requestListeningState(this, ComponentName(this, cls))
        }
    }

    private fun createChannel() {
        val nm = getSystemService(NotificationManager::class.java)
        nm.createNotificationChannel(NotificationChannel(CHANNEL_ID, "Glyph Eggs", NotificationManager.IMPORTANCE_LOW))
        // Rejtett mód: nincs ikon az állapotsoron, összecsukva a lehúzott menü alján
        nm.createNotificationChannel(NotificationChannel(CHANNEL_HIDDEN, "Glyph Eggs (rejtett)", NotificationManager.IMPORTANCE_MIN))
    }

    private fun buildNotification(text: String): Notification {
        val open = PendingIntent.getActivity(
            this, 0, Intent(this, MainActivity::class.java),
            PendingIntent.FLAG_IMMUTABLE
        )
        val stop = PendingIntent.getService(
            this, 1, Intent(this, SimonService::class.java).setAction(ACTION_STOP),
            PendingIntent.FLAG_IMMUTABLE
        )
        val hidden = Settings.notifPersistentHidden(this)
        return Notification.Builder(this, if (hidden) CHANNEL_HIDDEN else CHANNEL_ID)
            .setSmallIcon(R.drawable.ic_tile)
            .setContentTitle("Glyph Eggs")
            .setContentText(text)
            .setOngoing(true)
            .setShowWhen(false)
            .setVisibility(if (hidden) Notification.VISIBILITY_SECRET else Notification.VISIBILITY_PUBLIC)
            .setContentIntent(open)
            .addAction(Notification.Action.Builder(null as Icon?, "Leállítás", stop).build())
            .build()
    }

    private fun updateNotification(text: String) {
        getSystemService(NotificationManager::class.java).notify(NOTIF_ID, buildNotification(text))
    }
}
