package com.akos.glypheggs

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.content.Context
import android.content.Intent
import android.os.SystemClock
import com.nothing.ketchum.Glyph
import kotlinx.coroutines.coroutineScope
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.first
import kotlinx.coroutines.launch
import kotlinx.coroutines.withTimeoutOrNull

/*
 * MORZE-GYAKORLÓ. A hátlap felső sávján (C1, 16 LED) balra fut a szó morzekódja: pont = 1 LED,
 * vonás = 3 LED. Az első lefutás után megjelenik a billentyűzet; ha 8 mp-en belül nincs meg a megfejtés,
 * a kód folyamatosan ismétlődik a helyes válaszig (vagy leállításig). A függőleges vonal a betűk számát mutatja.
 */

object MorseCode {
    val TABLE: Map<Char, String> = mapOf(
        'A' to ".-", 'B' to "-...", 'C' to "-.-.", 'D' to "-..", 'E' to ".", 'F' to "..-.", 'G' to "--.",
        'H' to "....", 'I' to "..", 'J' to ".---", 'K' to "-.-", 'L' to ".-..", 'M' to "--", 'N' to "-.",
        'O' to "---", 'P' to ".--.", 'Q' to "--.-", 'R' to ".-.", 'S' to "...", 'T' to "-", 'U' to "..-",
        'V' to "...-", 'W' to ".--", 'X' to "-..-", 'Y' to "-.--", 'Z' to "--..",
        '0' to "-----", '1' to ".----", '2' to "..---", '3' to "...--", '4' to "....-",
        '5' to ".....", '6' to "-....", '7' to "--...", '8' to "---..", '9' to "----."
    )

    fun of(word: String): List<String> = word.uppercase().mapNotNull { TABLE[it] }

    /** „... --- ...” – betűnként szóközzel. */
    fun text(word: String): String = of(word).joinToString("  ") { it.replace('.', '·').replace('-', '—') }

    /**
     * A futó szalag pixelei: pont = 1 égő, vonás = 3 égő, jelek között 1 sötét, betűk között 3 sötét.
     */
    fun strip(word: String): BooleanArray {
        val px = ArrayList<Boolean>()
        of(word).forEachIndexed { li, code ->
            if (li > 0) repeat(3) { px += false }
            code.forEachIndexed { si, ch ->
                if (si > 0) px += false
                repeat(if (ch == '-') 3 else 1) { px += true }
            }
        }
        return px.toBooleanArray()
    }
}

/** Nehézség: milyen hosszú szavak jönnek. */
enum class MorseLevel(val title: String, val words: List<String>) {
    EASY("Könnyű", listOf("SOS", "OK", "NEM", "TE", "MA", "IS", "EZ", "AZ", "HA", "NE", "EN", "OTT", "IDE", "MI", "TV")),
    MEDIUM("Közepes", listOf("IGEN", "SZIA", "HAZA", "MOST", "HELP", "NAP", "ESTE", "KOSZ", "VIZ", "TEA", "AUTO", "BUSZ", "HIDEG", "MENJ", "GYERE")),
    HARD("Nehéz", listOf("RADIO", "ALPHA", "BRAVO", "DELTA", "HOTEL", "SIGNAL", "TELEFON", "ZSEBLAMPA", "MAYDAY", "KAPITANY", "VASUTAS", "GLYPH")),
    MIXED("Vegyes", emptyList());

    fun pool(): List<String> = if (this == MIXED) EASY.words + MEDIUM.words + HARD.words else words
}

/** Morze-tempó: ennyi ms egy szalag-lépés. */
enum class MorseSpeed(val title: String, val stepMs: Long) {
    SLOW("Lassú", 230L), NORMAL("Közepes", 160L), FAST("Gyors", 105L)
}

enum class MorsePhase { IDLE, FIRST, WAITING, LOOPING, SOLVED, REVEAL }

/** A futó gyakorlás állapota az oldal, a widget és a szolgáltatás között. */
object MorseBus {
    val phase = MutableStateFlow(MorsePhase.IDLE)
    val word = MutableStateFlow("")
    /** Megfejtve (a szolgáltatás erre vár). */
    val solved = MutableStateFlow(false)
    val skipped = MutableStateFlow(false)
    @Volatile var streak = 0
    @Volatile var roundStart = 0L
    @Volatile var wrongThisRound = 0

    fun newRound(w: String) {
        word.value = w
        solved.value = false
        skipped.value = false
        wrongThisRound = 0
        roundStart = SystemClock.elapsedRealtime()
        phase.value = MorsePhase.FIRST
    }

    /** A beírt megfejtés. true = helyes. Itt számol statisztikát is. */
    fun submit(c: Context, text: String): Boolean {
        val w = word.value
        if (w.isEmpty() || solved.value) return false
        val guess = text.trim().uppercase().filter { it.isLetterOrDigit() }
        if (guess == w) {
            val fast = phase.value == MorsePhase.FIRST || phase.value == MorsePhase.WAITING
            GameStats.count(c, "morse_solved")
            GameStats.count(c, "morse_letters", w.length)
            if (fast) GameStats.count(c, "morse_fast")
            if (wrongThisRound == 0) streak++ else streak = 1
            GameStats.best(c, "morse_streak", streak)
            val ms = SystemClock.elapsedRealtime() - roundStart
            GameStats.count(c, "morse_ms", (ms / 100).toInt()) // tizedmásodpercben, az átlaghoz
            solved.value = true
            Achievements.check(c)
            return true
        }
        wrongThisRound++
        streak = 0
        GameStats.count(c, "morse_wrong")
        return false
    }

    fun skip(c: Context) {
        if (word.value.isEmpty() || solved.value) return
        streak = 0
        GameStats.count(c, "morse_skip")
        skipped.value = true
    }
}

/** A gyakorlás a LED-eken (a szolgáltatás futtatja). */
class MorseTrainer(
    private val context: Context,
    private val glyph: GlyphController,
    private val haptics: Haptics,
    private val onFirstDone: () -> Unit,
    private val onStatus: (String) -> Unit
) {
    private val bar = IntArray(16) { Zones.LEVEL[15 - it] } // 0 = bal (C1_16) … 15 = jobb (C1_1)
    private val line = intArrayOf(
        Glyph.Code_22111.D1_1, Glyph.Code_22111.D1_2, Glyph.Code_22111.D1_3, Glyph.Code_22111.D1_4,
        Glyph.Code_22111.D1_5, Glyph.Code_22111.D1_6, Glyph.Code_22111.D1_7, Glyph.Code_22111.D1_8
    )
    private var last = ""

    suspend fun run() {
        try {
            while (true) {
                val pool = Settings.morseLevel(context).pool()
                var w = pool.random()
                if (pool.size > 1) while (w == last) w = pool.random()
                last = w
                round(w)
            }
        } finally {
            MorseBus.phase.value = MorsePhase.IDLE
            MorseBus.word.value = ""
            Widgets.updateMorse(context)
        }
    }

    private suspend fun round(w: String) = coroutineScope {
        MorseBus.newRound(w)
        Widgets.updateMorse(context)
        onStatus("Morze · figyeld a felső sávot (${w.length} betű)")
        // Jelzés: új szó jön
        glyph.show(intArrayOf(Glyph.Code_22111.E1)); delay(300); glyph.off(); delay(400)
        val done = launch { MorseBus.solved.first { it }; }
        val skip = launch { MorseBus.skipped.first { it } }
        playOnce(w)
        if (!MorseBus.solved.value && !MorseBus.skipped.value) {
            MorseBus.phase.value = MorsePhase.WAITING
            Widgets.updateMorse(context)
            onFirstDone()
            onStatus("Morze · írd be a megfejtést (8 mp)")
            withTimeoutOrNull(Config.MORSE_WAIT_MS) {
                while (!MorseBus.solved.value && !MorseBus.skipped.value) delay(100)
            }
        }
        if (!MorseBus.solved.value && !MorseBus.skipped.value) {
            MorseBus.phase.value = MorsePhase.LOOPING
            Widgets.updateMorse(context)
            onStatus("Morze · ismétlés a megfejtésig")
            while (!MorseBus.solved.value && !MorseBus.skipped.value) {
                playOnce(w)
                pause(1_200)
            }
        }
        done.cancel(); skip.cancel()
        if (MorseBus.solved.value) {
            MorseBus.phase.value = MorsePhase.SOLVED
            Widgets.updateMorse(context)
            onStatus("Morze · ✓ $w")
            haptics.result()
            celebrate()
        } else {
            MorseBus.phase.value = MorsePhase.REVEAL
            Widgets.updateMorse(context)
            onStatus("Morze · a megoldás: $w")
            haptics.denied()
            glyph.off(); delay(2_500)
        }
    }

    /** A szalag egyszer végigfut a sávon (jobbról be, balra ki); a függőleges vonal a betűk száma. */
    private suspend fun playOnce(w: String) {
        val strip = MorseCode.strip(w)
        val step = Settings.morseSpeed(context).stepMs
        val letters = line.take(w.length.coerceAtMost(8))
        val total = strip.size + 16
        for (o in 0..total) {
            if (MorseBus.solved.value || MorseBus.skipped.value) return
            val lit = ArrayList<Int>(24)
            for (i in 0 until 16) {
                val idx = o + i - 16
                if (idx in strip.indices && strip[idx]) lit += bar[i]
            }
            lit += letters
            glyph.show(lit.toIntArray())
            delay(step)
        }
        glyph.show(letters.toIntArray())
    }

    private suspend fun pause(ms: Long) {
        val end = SystemClock.elapsedRealtime() + ms
        while (SystemClock.elapsedRealtime() < end && !MorseBus.solved.value && !MorseBus.skipped.value) delay(50)
    }

    private suspend fun celebrate() {
        repeat(3) { glyph.show(Zones.ALL); delay(140); glyph.off(); delay(110) }
        val o = LectureTimer.FILL_ORDER
        for (i in o.indices) { glyph.show(o.take(i + 1).toIntArray()); delay(18) }
        delay(500)
        glyph.off()
        delay(900)
    }
}

/** A Morze oldal megnyitása a szolgáltatásból: ha lehet, közvetlenül, különben értesítésből. */
object MorseLauncher {
    private const val CHANNEL = "glyph_eggs_morse"

    fun open(context: Context) {
        if (MorseActivity.visible) return
        val intent = Intent(context, MorseActivity::class.java).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_SINGLE_TOP)
        if (GlyphMirror.appVisible || android.provider.Settings.canDrawOverlays(context)) {
            try { context.startActivity(intent); return } catch (t: Throwable) { }
        }
        if (!Settings.notifAssist(context)) return
        val nm = context.getSystemService(NotificationManager::class.java)
        nm.createNotificationChannel(NotificationChannel(CHANNEL, "Morze-gyakorló", NotificationManager.IMPORTANCE_HIGH))
        val pi = PendingIntent.getActivity(context, 78, intent, PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT)
        nm.notify(78, Notification.Builder(context, CHANNEL)
            .setSmallIcon(R.drawable.ic_morse)
            .setContentTitle("Morze: mi volt a szó?")
            .setContentText("Koppints, és írd be a megfejtést")
            .setContentIntent(pi)
            .setAutoCancel(true)
            .build())
    }
}

/** A Morze-statisztika összesítve (az oldalnak és a Stat fülnek). */
object MorseStats {
    fun solved(c: Context) = GameStats.cnt(c, "morse_solved")
    fun fast(c: Context) = GameStats.cnt(c, "morse_fast")
    fun wrong(c: Context) = GameStats.cnt(c, "morse_wrong")
    fun skipped(c: Context) = GameStats.cnt(c, "morse_skip")
    fun letters(c: Context) = GameStats.cnt(c, "morse_letters")
    fun bestStreak(c: Context) = GameStats.bestOf(c, "morse_streak")
    fun avgSec(c: Context): Float = if (solved(c) == 0) 0f else GameStats.cnt(c, "morse_ms") / 10f / solved(c)
    fun accuracy(c: Context): Int {
        val all = solved(c) + wrong(c) + skipped(c)
        return if (all == 0) 0 else solved(c) * 100 / all
    }
}
