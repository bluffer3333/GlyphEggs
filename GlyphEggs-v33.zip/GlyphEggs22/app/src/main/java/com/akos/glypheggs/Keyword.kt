package com.akos.glypheggs

import android.content.Context
import kotlinx.coroutines.flow.MutableStateFlow
import kotlin.math.PI
import kotlin.math.cos
import kotlin.math.ln
import kotlin.math.log10
import kotlin.math.sin
import kotlin.math.sqrt

/*
 * HANGPARANCS a Glyph Beaconhöz: „Beacon!” – a SAJÁT hangodra betanítva.
 * Teljesen a telefonon fut, internet és Google nélkül: a közös mikrofon hangjából (MicTap)
 * beszédszakaszokat vág ki (hangerő-alapú VAD), mindegyikből MFCC hangképet számol
 * (25 ms ablak, 10 ms lépés, 26 mel-szűrő, 12 együttható), és dinamikus időillesztéssel (DTW)
 * összeveti a 3 betanított kimondással. Ha elég közel van → riasztás.
 * Semmit nem rögzít és nem ment el hangként: csak a számokból álló hangképet tárolja.
 */
object Keyword {
    private const val SR = 16_000
    private const val WIN = 400          // 25 ms
    private const val HOP = 160          // 10 ms
    private const val NFFT = 512
    private const val NMEL = 26
    private const val NCEP = 12
    private const val MIN_FRAMES = 22    // 0,22 s
    private const val MAX_FRAMES = 160   // 1,6 s
    private const val PRE_ROLL = 8
    private const val HANG = 22          // ennyi csendes keret zárja a szakaszt (220 ms)

    /** Riasztás: a szolgáltatás állítja be, ha a hangparancs be van kapcsolva. */
    @Volatile var onDetect: (() -> Unit)? = null
    /** Betanítás / élő teszt: minden kivágott szakasz hangképe és (ha van betanítva) a távolsága. */
    @Volatile var onSegment: ((Array<FloatArray>, Float) -> Unit)? = null
    @Volatile var paused = false
    @Volatile var training = false
    /** Élő kijelzés: beszél-e most valaki (0..1 hangerő, ha igen). */
    val voice = MutableStateFlow(0f)

    @Volatile private var templates: List<Array<FloatArray>> = emptyList()
    @Volatile private var threshold = 0f
    @Volatile private var meanLen = 0f

    // --- jelfeldolgozás ---
    private val buf = FloatArray(WIN + HOP * 4)
    private var bufLen = 0
    private val window = FloatArray(WIN) { (0.54 - 0.46 * cos(2 * PI * it / (WIN - 1))).toFloat() }
    private val re = FloatArray(NFFT)
    private val im = FloatArray(NFFT)
    private val melFilters: Array<FloatArray> = buildMel()
    private val dct = Array(NCEP) { k -> FloatArray(NMEL) { m -> cos(PI * (k + 1) * (m + 0.5) / NMEL).toFloat() } }

    // --- VAD ---
    private var noiseDb = -60f
    private var voicedRun = 0
    private var silentRun = 0
    private var inSpeech = false
    private val pre = ArrayDeque<FloatArray>()
    private val seg = ArrayList<FloatArray>()
    private val segE = ArrayList<Float>()

    private val tap: (ShortArray, Int) -> Unit = { b, n -> feed(b, n) }

    fun trained(c: Context) = Settings.beaconVoiceTemplates(c).isNotEmpty()

    /** A betanított hangképek és a küszöb betöltése (érzékenység szerint). */
    fun configure(c: Context) {
        val t = decode(Settings.beaconVoiceTemplates(c))
        templates = t
        meanLen = if (t.isEmpty()) 0f else t.map { it.size }.average().toFloat()
        // „Hagyj ki egyet”: mindegyik betanított minta legközelebbi társa; ezek közül a legnagyobb
        // a saját szórásod. A küszöb ennek a része – így a hasonló, de más szavakat (bacon, igen…) kiszűri.
        var spread = 0f
        for (i in t.indices) spread = maxOf(spread, t.indices.filter { it != i }.minOfOrNull { dtw(t[i], t[it]) } ?: 0f)
        if (spread <= 0f) spread = 6f
        threshold = spread * Config.KEYWORD_FACTOR[Settings.beaconSens(c)]
    }

    fun attach() { if (tap !in MicTap.listeners) MicTap.listeners.add(tap) }
    fun detach() { MicTap.listeners.remove(tap); voice.value = 0f }
    fun refreshAttach() { if (onDetect != null || onSegment != null) attach() else detach() }

    @Synchronized
    private fun feed(b: ShortArray, n: Int) {
        var i = 0
        while (i < n) {
            val take = minOf(n - i, buf.size - bufLen)
            for (k in 0 until take) buf[bufLen + k] = b[i + k] / 32768f
            bufLen += take
            i += take
            while (bufLen >= WIN) {
                frame()
                System.arraycopy(buf, HOP, buf, 0, bufLen - HOP)
                bufLen -= HOP
            }
        }
    }

    /** Egy 25 ms-os keret: energia, MFCC, VAD-állapotgép. */
    private fun frame() {
        var e = 0.0
        for (k in 0 until WIN) e += buf[k] * buf[k]
        val db = 10f * log10((e / WIN).toFloat() + 1e-12f)
        // Zajszint: csendben lassan követi (lefelé gyorsan, felfelé lassan)
        noiseDb = if (db < noiseDb) noiseDb + (db - noiseDb) * 0.2f else noiseDb + (db - noiseDb) * 0.004f
        val voiced = db > noiseDb + 10f && db > -52f
        val mf = mfcc()
        voice.value = if (voiced) ((db + 60f) / 50f).coerceIn(0f, 1f) else 0f

        if (!inSpeech) {
            pre.addLast(mf); if (pre.size > PRE_ROLL) pre.removeFirst()
            voicedRun = if (voiced) voicedRun + 1 else 0
            if (voicedRun >= 3) {
                inSpeech = true
                seg.clear(); segE.clear()
                seg.addAll(pre); repeat(pre.size) { segE.add(db) }
                silentRun = 0
            }
        } else {
            seg.add(mf); segE.add(db)
            silentRun = if (voiced) 0 else silentRun + 1
            if (silentRun >= HANG || seg.size > MAX_FRAMES + HANG) {
                // A záró csendet levágjuk
                val keep = (seg.size - silentRun + 3).coerceIn(0, seg.size)
                val s = seg.subList(0, keep).toTypedArray()
                inSpeech = false; voicedRun = 0; pre.clear()
                if (s.size in MIN_FRAMES..MAX_FRAMES) evaluate(normalize(s))
            }
        }
    }

    /** Elég közel van-e egy szakasz a betanított szóhoz (a teszthez is). */
    fun matches(s: Array<FloatArray>, d: Float): Boolean {
        if (templates.isEmpty() || d < 0f) return false
        val lenOk = s.size in (meanLen * 0.6f).toInt()..(meanLen * 1.7f).toInt()
        return lenOk && d <= threshold
    }

    private fun evaluate(s: Array<FloatArray>) {
        val t = templates
        val d = if (t.isEmpty()) -1f else t.minOf { dtw(s, it) }
        onSegment?.invoke(s, d)
        if (t.isEmpty() || paused || training) return
        if (matches(s, d)) onDetect?.invoke()
    }

    /** Cepstrális átlag-normalizálás (a mikrofon / terem színezetét kiveszi). */
    private fun normalize(s: Array<FloatArray>): Array<FloatArray> {
        val mean = FloatArray(NCEP)
        for (f in s) for (k in 0 until NCEP) mean[k] += f[k]
        for (k in 0 until NCEP) mean[k] /= s.size
        return Array(s.size) { i -> FloatArray(NCEP) { k -> s[i][k] - mean[k] } }
    }

    private fun mfcc(): FloatArray {
        for (k in 0 until NFFT) { re[k] = if (k < WIN) buf[k] * window[k] else 0f; im[k] = 0f }
        fft(re, im)
        val pw = FloatArray(NFFT / 2 + 1) { re[it] * re[it] + im[it] * im[it] }
        val mel = FloatArray(NMEL) { m ->
            var s = 0f
            val f = melFilters[m]
            for (k in f.indices) s += f[k] * pw[k]
            ln(s + 1e-10f)
        }
        return FloatArray(NCEP) { k -> var s = 0f; for (m in 0 until NMEL) s += dct[k][m] * mel[m]; s }
    }

    private fun buildMel(): Array<FloatArray> {
        fun hz2mel(h: Double) = 2595.0 * log10(1 + h / 700.0)
        fun mel2hz(m: Double) = 700.0 * (Math.pow(10.0, m / 2595.0) - 1)
        val lo = hz2mel(80.0); val hi = hz2mel(7600.0)
        val pts = DoubleArray(NMEL + 2) { mel2hz(lo + (hi - lo) * it / (NMEL + 1)) }
        val bins = IntArray(NMEL + 2) { Math.floor((NFFT + 1) * pts[it] / SR).toInt() }
        return Array(NMEL) { m ->
            FloatArray(NFFT / 2 + 1) { k ->
                when {
                    k < bins[m] || k > bins[m + 2] -> 0f
                    k <= bins[m + 1] -> if (bins[m + 1] == bins[m]) 1f else (k - bins[m]).toFloat() / (bins[m + 1] - bins[m])
                    else -> if (bins[m + 2] == bins[m + 1]) 1f else (bins[m + 2] - k).toFloat() / (bins[m + 2] - bins[m + 1])
                }
            }
        }
    }

    /** DTW-távolság (euklideszi keret-távolság, az úthosszal normálva, sávkorláttal). */
    fun dtw(a: Array<FloatArray>, b: Array<FloatArray>): Float {
        val n = a.size; val m = b.size
        if (n == 0 || m == 0) return Float.MAX_VALUE
        val band = (maxOf(n, m) * 0.4f).toInt() + 2
        val inf = Float.MAX_VALUE / 4
        var prev = FloatArray(m + 1) { inf }
        var cur = FloatArray(m + 1) { inf }
        prev[0] = 0f
        for (i in 1..n) {
            cur.fill(inf)
            val center = i * m / n
            val j0 = maxOf(1, center - band); val j1 = minOf(m, center + band)
            for (j in j0..j1) {
                var d = 0f
                val x = a[i - 1]; val y = b[j - 1]
                for (k in x.indices) { val q = x[k] - y[k]; d += q * q }
                d = sqrt(d)
                cur[j] = d + minOf(prev[j], minOf(cur[j - 1], prev[j - 1]))
            }
            val t = prev; prev = cur; cur = t
        }
        return prev[m] / (n + m)
    }

    // --- tárolás: sablonok szövegként ---
    fun encode(list: List<Array<FloatArray>>): String =
        list.joinToString("|") { t -> t.joinToString(";") { f -> f.joinToString(",") { "%.3f".format(java.util.Locale.US, it) } } }

    fun decode(s: String): List<Array<FloatArray>> = try {
        if (s.isBlank()) emptyList() else s.split("|").map { t ->
            t.split(";").map { f -> f.split(",").map { it.toFloat() }.toFloatArray() }.toTypedArray()
        }
    } catch (e: Throwable) { emptyList() }

    private fun fft(re: FloatArray, im: FloatArray) {
        val n = re.size
        var j = 0
        for (i in 1 until n) {
            var bit = n shr 1
            while (j and bit != 0) { j = j xor bit; bit = bit shr 1 }
            j = j or bit
            if (i < j) { val tr = re[i]; re[i] = re[j]; re[j] = tr; val ti = im[i]; im[i] = im[j]; im[j] = ti }
        }
        var len = 2
        while (len <= n) {
            val ang = -2 * PI / len
            val wr0 = cos(ang).toFloat(); val wi0 = sin(ang).toFloat()
            var i = 0
            while (i < n) {
                var wr = 1f; var wi = 0f
                for (k in 0 until len / 2) {
                    val a = i + k; val b = a + len / 2
                    val tr = wr * re[b] - wi * im[b]; val ti = wr * im[b] + wi * re[b]
                    re[b] = re[a] - tr; im[b] = im[a] - ti
                    re[a] += tr; im[a] += ti
                    val nwr = wr * wr0 - wi * wi0; wi = wr * wi0 + wi * wr0; wr = nwr
                }
                i += len
            }
            len *= 2
        }
    }
}
