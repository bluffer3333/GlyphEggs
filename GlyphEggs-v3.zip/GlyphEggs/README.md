<div align="center">

<img src="glyph-eggs-logo.png" alt="Glyph Eggs logó" width="140" />

# Glyph Eggs

**Játékok és eszközök a Nothing Phone (2) hátoldali Glyph LED-jeire**

Simon Says dőléssel · Üvegpörgetés · Iránytű — csempéről vagy saját indító mozdulattal, LED-szimulációval

![Platform](https://img.shields.io/badge/platform-Android%2014%2B-3DDC84?logo=android&logoColor=white)
![Kotlin](https://img.shields.io/badge/Kotlin-2.0-7F52FF?logo=kotlin&logoColor=white)
![Device](https://img.shields.io/badge/eszköz-Nothing%20Phone%20(2)-000000)
![Glyph SDK](https://img.shields.io/badge/Glyph%20Developer%20Kit-hivatalos-D71921)
![Build](https://img.shields.io/badge/build-GitHub%20Actions-2088FF?logo=githubactions&logoColor=white)

</div>

---

## Tartalom

- [Funkciók](#funkciók)
- [Gyorsbeállítás-csempék](#gyorsbeállítás-csempék)
- [Indító mozdulatok](#indító-mozdulatok)
- [LED-szimuláció](#led-szimuláció)
- [LED-térkép](#led-térkép)
- [Telepítés](#telepítés)
- [Használat](#használat)
- [Hogyan működik](#hogyan-működik)
- [A kód felépítése](#a-kód-felépítése)
- [Algoritmusok részletesen](#algoritmusok-részletesen)
- [Beállítások (`Config.kt`)](#beállítások-configkt)
- [Engedélyek](#engedélyek)
- [Hibaelhárítás](#hibaelhárítás)
- [Ismert korlátok](#ismert-korlátok)
- [Források](#források)

---

## Funkciók

| | Funkció | Röviden |
|---|---|---|
| 🎮 | **Glyph Simon** | Klasszikus Simon Says: a LED-ek mutatnak egy sort, te a telefon döntésével ismétled. 8 szint, a haladást a C1 sáv mutatja. |
| 🍾 | **Üvegpörgetés** | A fény körbefut a nagy gyűrűn, lassul, kattog, és megáll valakinél. Társasjátékhoz, döntéshez. |
| 🧭 | **Iránytű** | Fekve mutatja az északot: durván a nagy íveken, pontosan egyetlen kis LED-del a C1 sávon. |
| ✋ | **Indító mozdulatok** | Forgatás, megpörgetés, kopogás, rázás, lefordítás – bármelyik funkcióhoz bármelyik mozdulat. |
| 👁️ | **LED-szimuláció** | A képernyőn is látszik, mit csinálnak a LED-ek – akár Glyph nélküli telefonon is. |

**Közös tulajdonságok**

- Mindhárom indítható a **lehúzható gyorsbeállítás-menüből** csempével, és **saját indító mozdulattal** is.
- **Nothing-stílusú felület**: ugyanaz a sötét, kártyás megjelenés, mint a telefon Glyph Interface beállításaiban, élő Glyph-előnézettel.
- A telefon **kijelzővel lefelé** fekszik az asztalon, így a LED-ek felfelé néznek.
- **Rezgéses visszajelzés**: indító jelzés, kattogó pörgetés, győzelmi rezgés.
- **Akkubarát háttérfigyelés**: készenlétben lassú, kötegelt gyorsulásmérő; a giroszkóp csak akkor fut, ha a telefon le van fektetve.
- A hivatalos **Nothing Glyph Developer Kit**-re épül. Nincs root, nincs trükközés.

---

## Gyorsbeállítás-csempék

Húzd le kétszer a felső menüt, koppints a ✏️ (szerkesztés) ikonra, és húzd be a csempéket. Vagy az appban a *„… csempe hozzáadása”* gombokkal egy koppintással felkerülnek.

| Csempe | Típus | Mit csinál |
|---|---|---|
| **Glyph figyelés** | Kapcsoló | Be: a háttérben figyeli a beállított indító mozdulatokat, és elindítja a hozzájuk rendelt funkciót. Ki: leállítja a figyelést. A csempe világít, amíg figyel. |
| **Pörgetés** | Gomb | Elindít egy pörgetést. Megvárja, hogy kijelzővel lefelé letedd (max. 15 mp). |
| **Iránytű** | Gomb / kapcsoló | Elindítja az iránytűt; ha fut, egy újabb koppintás leállítja. A csempe világít, amíg fut. |

> A csempe a rendszer menüjében él, ezért akkor is működik, ha az app nincs megnyitva. Ha egy Android-verzió nem engedi a csempéről közvetlenül indítani a szolgáltatást, az app magától megnyílik, és onnan indul.

---

## Indító mozdulatok

A főképernyő **Mozdulatfigyelés** kapcsolójával (vagy a *Glyph figyelés* csempével) bekapcsolva a telefon a háttérben figyeli a mozdulatokat. Az **Indító mozdulatok** kártyára koppintva funkciónként választhatsz:

| Mozdulat | Hogyan | Alapból |
|---|---|---|
| Jobbra forgatás 2× | Fekve kétszer kb. negyed fordulat jobbra | **Glyph Simon** |
| Balra forgatás 2× | Fekve kétszer kb. negyed fordulat balra | – |
| Jobbra, majd balra | Negyed fordulat jobbra, aztán vissza | – |
| Balra, majd jobbra | Negyed fordulat balra, aztán vissza | – |
| Megpörgetés | Egy lendülettel legalább egy teljes kör az asztalon | **Pörgetés** |
| Kopogás 2× | Fekve kétszer gyorsan kopogtass a telefonon | **Iránytű** |
| Kopogás 3× | Fekve háromszor gyorsan | – |
| Rázás, majd lerakás | Rázd meg, és 6 mp-en belül tedd le kijelzővel lefelé | – |
| Lefordítás 2× | Kijelzővel felfelé → lefelé, kétszer egymás után | – |
| Nincs | Csak csempével vagy az appból indul | – |

- **Bármelyik mozdulat bármelyik funkcióhoz** rendelhető. Egy mozdulat egyszerre csak egy funkcióhoz tartozhat: ha máshol már használtad, ott „Nincs” lesz.
- A **kopogás érzékenysége** (alacsony / közepes / magas) ugyanitt állítható.
- Felismeréskor rövid rezgés jelez. Egy mozdulat után 4 mp-ig nem figyel újat, hogy ne induljon kétszer.

## LED-szimuláció

**Koppints kétszer a „Glyph Eggs” címre** (vagy a Glyph-előnézetre): teljes képernyőn megjelenik a hátlap Glyph-rajza, és élőben mutatja, melyik LED ég.

- Bármelyik telefonon működik. Glyph nélkül a funkciók „csak a képernyőn” futnak, így megmutathatod másnak is, hogyan működik.
- Amíg a szimuláció nyitva van, a funkciók **kijelzővel felfelé** fekvő telefonnal is indulnak. Ilyenkor a rajz tükrözve jelenik meg, hogy minden LED a valódi helyén látsszon (a kamera felőli oldal ott, ahol a kamera van).
- Alul gombokkal is indíthatod a Simont, a pörgetést és az iránytűt. Kilépés: dupla koppintás a rajzra.

---

## LED-térkép

A Nothing Phone (2) hátlapján **33 külön vezérelhető zóna** van. Hátulról nézve, kamera bal felül:

```
        ┌───────────────────────────┐
        │  (A1)       B1 ╲          │   A1 / A2 – kamera körüli gyűrű (felső / alsó fél)
        │  (A2)           ╲         │   B1      – ferde csík
        │                           │
        │       C2  ╭─────╮ C1_16   │   C1_1…C1_16 – jobb felső ív, 16 kis LED
        │         ╱         ╲ …     │                (C1_16 felül, C1_1 a jobb szélen)
        │   C3   │           │ C1_1 │   C2 – bal felső ív     C3 – bal oldal
        │        │           │ C6   │   C4 – bal alsó ív      C5 – jobb alsó ív
        │       C4 ╲       ╱ C5     │   C6 – jobb oldal
        │            ╰─────╯        │
        │               │ D1_8      │   D1_1…D1_8 – függőleges vonal (D1_1 alul)
        │               │ D1_1      │
        │               •  E1       │   E1 – pont a töltőport felé
        └──────────── USB-C ────────┘
```

### Ki mit használ

| Zóna | Glyph Simon | Üvegpörgetés | Iránytű |
|---|---|---|---|
| A1, A2, B1 | **Fel** (B1 felé dönteni) | – | – |
| D1_1–D1_8, E1 | **Le** (töltőport felé) | – | – |
| C2, C3 | **Balra** (kamera felőli oldal) | mutató | durva irány |
| C5, C6 | **Jobbra** | mutató | durva irány |
| C4 | – (csak villogásban) | mutató | durva irány |
| C1_1–C1_16 | **Szintjelző** (körönként 2 LED) | mutató (2–3 kis LED) | **pontos irány, 1 LED** |

---

## Telepítés

### 1. APK építése GitHub Actions-szel (számítógép nélkül)

1. Hozz létre egy **privát** repót, és töltsd fel bele a projekt zipjét (*Add file → Upload files*). Egyszerre csak egy zip legyen a repóban.
2. Hozd létre a `.github/workflows/build.yml` fájlt az alábbi tartalommal. Ez bármilyen nevű zipet kicsomagol, megkeresi benne a projektet, és megépíti:

<details>
<summary><b>build.yml megnyitása</b></summary>

```yaml
name: APK építése
on:
  push:
  workflow_dispatch:
jobs:
  build:
    runs-on: ubuntu-latest
    steps:
      - uses: actions/checkout@v4
      - name: Kicsomagolás
        run: |
          unzip -q -o "$(ls *.zip | head -1)"
          ls -la
      - uses: actions/setup-java@v5
        with:
          distribution: temurin
          java-version: "17"
      - name: APK építése
        run: |
          cd "$(dirname "$(find . -maxdepth 2 -name gradlew | head -1)")"
          chmod +x gradlew
          ./gradlew assembleDebug --no-daemon
      - uses: actions/upload-artifact@v4
        with:
          name: glyph-eggs-apk
          path: "**/app/build/outputs/apk/debug/*.apk"
```

</details>

3. Az **Actions** fülön várd meg a zöld pipát (3–5 perc), majd a futás alján, az **Artifacts** résznél töltsd le a `glyph-eggs-apk` fájlt.

> Ha a projekt mappáját közvetlenül töltöd fel (nem zipben), a projektben lévő `.github/workflows/build-apk.yml` magától működik.

### 2. Android Studióval

`File → Open` → a `GlyphEggs` mappa → `Build → Build APK(s)`. Az APK itt lesz: `app/build/outputs/apk/debug/app-debug.apk`.

### 3. Telepítés a telefonra

1. Nyisd meg az APK-t, és engedélyezd a telepítést ismeretlen forrásból.
2. Ha a Play Protect figyelmeztet, válaszd a **Telepítés mindenképp** lehetőséget. Nem a Play Áruházból jön, ezért szól.
3. Ha fent van a régi **Glyph Simon** app, töröld, mert a Glyph Eggs tartalmazza, és a kettő zavarná egymást.

### 4. A Glyph vezérlés engedélyezése

| Rendszer | Teendő |
|---|---|
| Android 16 / Nothing OS 4 vagy újabb | Nincs, működik. |
| Régebbi | USB-n egyszer: `adb shell settings put global nt_glyph_interface_debug_enable 1` (48 óránként lejár). |

### 5. Első indítás

1. Nyisd meg az appot, és engedélyezd az **értesítéseket**.
2. **Akkumulátor-optimalizálás kikapcsolása** gomb. Enélkül a rendszer leállíthatja a háttérben.
3. Add hozzá a csempéket.
4. Kapcsold be a **Mozdulatfigyelés**t, és az **Indító mozdulatok** kártyákon állítsd be, mi indítsa a funkciókat.
5. Próbáld ki az **Indítás most** kártyával, és figyeld a *Diagnosztika* részt.

---

## Használat

### 🎮 Glyph Simon

1. Kapcsold be a **Mozdulatfigyelés**t (vagy a *Glyph figyelés* csempét).
2. Tedd le a telefont kijelzővel lefelé, töltőport feléd, és végezd el a Simonhoz beállított mozdulatot (alapból: **forgasd jobbra kétszer** kb. negyed fordulatot). Rövid rezgés jelzi, hogy felismerte. Vagy koppints az **Indítás most** kártyára.
3. A LED-ek háromszor körbefutnak, majd elindul a játék.
4. A telefon lejátssza a sort. Döntsd arra, amerre a LED villant, majd engedd vissza középre.
5. Minden körben **az egész sort** végig kell dönteni, a végén egy új iránnyal.
6. Teljesített körönként **2 új LED** gyullad ki a C1 szintjelzőn. 8 kör után a sáv betelik: kb. **8 mp-ig** minden összevissza villog, és a telefon rezeg. 🎉
7. Rossz iránynál vagy 7 mp tétlenség után vége; az elért szint még 3 mp-ig látszik.

### 🍾 Üvegpörgetés

1. Koppints a **Pörgetés** csempére vagy kártyára – vagy, ha a figyelés be van kapcsolva, egyszerűen **pörgesd meg a telefont** az asztalon (alapbeállítás).
2. Tedd le a telefont kijelzővel lefelé az asztal közepére.
3. A fénypont 4–6 kört fut a gyűrűn, 5–7 mp alatt lelassul, a végén kattogó rezgéssel kúszik.
4. Megáll: a kiválasztott hely 5-ször villog, a telefon rezeg, és 4 mp-ig égve marad. **Akire mutat, az a kiválasztott.**

### 🧭 Iránytű

1. Koppints az **Iránytű** csempére vagy kártyára (vagy fekve **kopogj kétszer**, ha a figyelés be van kapcsolva), és tedd le a telefont kijelzővel lefelé egy sík felületre. A gyűrű egyszer felvillan.
2. **Durva irány:** ha az észak a C2–C6 nagy ívek felé esik, az az ív ég.
3. **Pontos irány:** forgasd a telefont, amíg az észak a C1 sávra kerül. Kis kattanás jelzi, és onnantól **egyetlen kis LED** mutatja pontosan az északot.
4. Addig fut, amíg fekszik. Ha felemeled, még **5 mp-ig** vár: ha visszateszed, folytatja, különben kikapcsol.

---

## Hogyan működik

```mermaid
flowchart LR
    subgraph Indítás
        T1[Glyph figyelés csempe]
        T2[Pörgetés csempe]
        T3[Iránytű csempe]
        APP[MainActivity]
        BOOT[BootReceiver]
    end

    T1 --> TS[TileStarter]
    T2 --> TS
    T3 --> TS
    TS --> SVC
    APP --> SVC
    BOOT --> SVC

    SVC[SimonService<br/>előtérszolgáltatás]

    SVC --> MD[MotionDetector<br/>gyorsulásmérő + giroszkóp]
    SVC --> G[SimonGame]
    SVC --> S[SpinWheel]
    SVC --> C[Compass<br/>forgásvektor-szenzor]

    MD -- "indító mozdulat" --> SVC
    MD -- "dőlés, fekvés" --> G
    MD --> S
    MD --> C

    G --> GC[GlyphController]
    S --> GC
    C --> GC
    G --> H[Haptics]
    S --> H
    C --> H
    GC --> SDK[(Nothing<br/>Glyph SDK)]
```

**A lényeg:**

- **Egyetlen előtérszolgáltatás** (`SimonService`) birtokolja a LED-eket és a szenzorokat. Állandó értesítést mutat, így az Android nem állítja le.
- Egyszerre **egy feladat** fut (Simon, pörgetés vagy iránytű). Minden feladat ugyanabban a keretben (`launchWithGlyph`) fut: Glyph-kapcsolat nyitása → feladat → takarítás.
- A Glyph sessiont **csak a feladat idejére** nyitja meg, így máskor a rendszer saját Glyph-értesítései zavartalanul működnek.
- Ha a Simon-figyelés ki van kapcsolva, a szolgáltatás egy pörgetés vagy iránytű után **magától leáll**.

```mermaid
stateDiagram-v2
    state "Készenlét" as Idle
    state "Figyel" as Watch
    state "Simon játék" as Game
    state "Pörgetés" as Spin
    state "Iránytű" as Compass
    [*] --> Idle
    Idle --> Watch: figyelés BE
    Watch --> Idle: figyelés KI
    Watch --> Game: Simon mozdulata
    Watch --> Spin: Pörgetés mozdulata
    Watch --> Compass: Iránytű mozdulata
    Game --> Watch: vége
    Idle --> Spin: Pörgetés csempe
    Watch --> Spin: Pörgetés csempe
    Idle --> Compass: Iránytű csempe
    Watch --> Compass: Iránytű csempe
    Spin --> Watch: vége, ha figyel
    Compass --> Watch: felemelve 5 mp, ha figyel
    Spin --> [*]: vége, ha nem figyel
    Compass --> [*]: felemelve 5 mp, ha nem figyel
```

---

## A kód felépítése

```
GlyphEggs/
├── app/
│   ├── libs/glyph-matrix-sdk-2.0.aar        ← Nothing hivatalos Glyph SDK
│   └── src/main/
│       ├── AndroidManifest.xml
│       ├── java/com/akos/glypheggs/
│       │   ├── SimonService.kt               ← a központi szolgáltatás
│       │   ├── MotionDetector.kt             ← szenzorok + mozdulat-felismerés
│       │   ├── GlyphController.kt            ← vékony réteg a GlyphManager körül
│       │   ├── SimonGame.kt                  ← Simon Says játékmenet
│       │   ├── SpinWheel.kt                  ← üvegpörgetés
│       │   ├── Compass.kt                    ← iránytű
│       │   ├── Direction.kt                  ← irányok és LED-zónák
│       │   ├── Haptics.kt                    ← rezgésminták
│       │   ├── Config.kt                     ← minden hangolható érték
│       │   ├── SimonTileService.kt           ← „Glyph Simon” csempe
│       │   ├── SpinTileService.kt            ← „Pörgetés” csempe
│       │   ├── CompassTileService.kt         ← „Iránytű” csempe
│       │   ├── TileStarter.kt                ← csempe → szolgáltatás indítás
│       │   ├── MainActivity.kt               ← főképernyő (Nothing-stílus)
│       │   ├── GesturesActivity.kt           ← indító mozdulatok beállítása
│       │   ├── SimulatorActivity.kt          ← LED-szimuláció a képernyőn
│       │   ├── GlyphMapView.kt               ← a 33 zóna rajza (előnézet, szimuláció)
│       │   ├── GlyphMirror.kt                ← mi ég éppen (a rajzok ebből dolgoznak)
│       │   ├── Trigger.kt                    ← mozdulatok, funkciók, mentett beállítások
│       │   ├── Ui.kt                         ← színek, kártyák, kapcsoló
│       │   ├── BootReceiver.kt               ← újraindítás után visszakapcsol
│       │   └── DebugState.kt                 ← állapot és napló a képernyőre
│       └── res/
│           ├── drawable/ic_tile.xml, ic_spin.xml, ic_compass.xml   ← csempe-ikonok
│           ├── drawable/ic_launcher_*.xml                          ← tojásos logó
│           └── mipmap-anydpi-v26/ic_launcher.xml                   ← adaptív ikon
├── build.gradle.kts, settings.gradle.kts, gradle.properties
├── gradlew, gradle/wrapper/
└── .github/workflows/build-apk.yml
```

### Fájlonként

| Fájl | Feladat |
|---|---|
| **`SimonService`** | Előtérszolgáltatás (`foregroundServiceType="specialUse"`). Fogadja az `ACTION_WATCH_ON/OFF`, `ACTION_START_GAME`, `ACTION_SPIN`, `ACTION_COMPASS`, `ACTION_STOP` parancsokat. A `launchWithGlyph()` keret megnyitja a Glyph sessiont, lefuttatja a feladatot, majd mindig takarít. Frissíti az értesítést és a csempék állapotát (`watching`, `compassOn`). |
| **`MotionDetector`** | Saját szálon (`HandlerThread`) olvassa a szenzorokat. Kiszűri a gravitációt, ebből adja a `tilt` (dőlés) és a `faceDown` (fekszik-e) `StateFlow`-t. Készenlétben felismeri az indító mozdulatokat: forgatások, megpörgetés, kopogás, rázás, lefordítás. Csak a kiosztott mozdulatokhoz szükséges szenzorokat és mintavételt járatja. |
| **`Trigger` / `Feature` / `Settings`** | A mozdulatok és funkciók listája, és a mentett beállítások (melyik mozdulat melyik funkcióé, rezgés, kopogás-érzékenység, figyelés, utolsó szint). |
| **`GlyphMirror`** | Mindig tudja, melyik zóna ég és melyik funkció fut. A `GlyphController` minden kigyújtást ide is beír. |
| **`GlyphMapView`** | A hátlap rajza mind a 33 zónával, világító / halvány állapottal, tükrözési lehetőséggel. |
| **`GesturesActivity`** | Funkcióválasztó fülek, a mozdulatok listája kiválasztó jelölővel, kopogás-érzékenység, tippek. |
| **`SimulatorActivity`** | Teljes képernyős LED-szimuláció; a gyorsulásmérő szerint tükröz, amíg nyitva van, a funkciók kijelzővel felfelé is indulnak. |
| **`Ui`** | A Nothing-stílus elemei: színek, `FeatureCard`, `ToggleView`, kártyasorok, rendszersávok kezelése. |
| **`GlyphController`** | A `GlyphManager` csatlakoztatása, regisztráció (`DEVICE_22111`), session nyitás/zárás, `show(zónák)`, `off()`. Minden kigyújtást a `GlyphMirror`-ba is beír; Glyph nélkül csak a tükörkép frissül, így a funkciók más telefonon is futnak. |
| **`SimonGame`** | A játékmenet coroutine-ként: bevezető animáció → sor bővítése → lejátszás → válaszok várása `tilt.first { … }`-val, időkorláttal → szintlépés → győzelem/vereség animáció. |
| **`SpinWheel`** | Szög alapú pörgetés lassuló (ease-out) mozgással, egyenletes eséllyel sorsolt célponttal. |
| **`Compass`** | A forgásvektor-szenzorból kiszámolja, merre van az észak a hátlaphoz képest, és kigyújtja a megfelelő zónát. Felemelésnél türelmi idő. |
| **`Direction` / `Zones`** | A négy dőlési irány és a hozzájuk tartozó LED-ek; `Zones.LEVEL` (C1, 16 LED) és `Zones.ALL` (mind a 33). |
| **`Haptics`** | `tick()` indító jelzés, `click()` pörgetés-kattanás, `result()` megállás, `win()` ~8 mp-es győzelmi minta. |
| **`*TileService`** | A három csempe. A Glyph figyelés csempe kapcsoló (`TOGGLEABLE_TILE`), a másik kettő gomb. |
| **`TileStarter`** | Csempéről indítja a szolgáltatást; ha a rendszer ezt tiltja, `startActivityAndCollapse`-szel megnyitja az appot. |
| **`MainActivity`** | A Nothing Glyph Interface beállításait idéző főképernyő: élő Glyph-előnézet, gyors kártyák, Mozdulatfigyelés sáv, mozdulat-kártyák, rezgés, csempék, háttérfutás, diagnosztika. A címre dupla koppintás → szimuláció. |
| **`BootReceiver`** | Újraindítás után visszakapcsolja a Simon-figyelést, ha előtte be volt kapcsolva. |
| **`DebugState`** | `StateFlow`-k az állapotnak, a szenzoradatoknak és az utolsó 15 naplósornak; a főképernyő ezeket mutatja élőben. |

---

## Algoritmusok részletesen

<details>
<summary><b>Dőlésérzékelés (Simon)</b></summary>

A gyorsulásmérő jelét aluláteresztő szűrővel simítja (`g = α·g + (1−α)·mért`), így marad a gravitáció iránya. Kijelzővel lefelé fekve a gravitáció x és y összetevője mutatja a dőlést:

- ha `max(|x|, |y|) ≥ TILT_ON` (≈ 21°) → az erősebb tengely és az előjel adja az irányt;
- ha `< TILT_OFF` → „középen”;
- a kettő között marad az előző állapot (**hiszterézis**, nem villog a határon).

A játék minden válasz előtt megvárja a „középen” állapotot, így egy döntés pontosan egy válasz.
</details>

<details>
<summary><b>Indító mozdulatok felismerése</b></summary>

**Forgatások és megpörgetés (giroszkóp, csak fekve).** A z-tengely szögsebességét „mozdulatokra” bontja: egy mozdulat akkor kezdődik, ha a szögsebesség meghaladja a `MOVE_START_RAD_S` értéket, és akkor zárul, ha `MOVE_END_MS` ideig a `MOVE_STOP_RAD_S` alatt marad. A mozdulat alatt összegzett szög alapján:

- ≥ `SPIN_GESTURE_DEG` (300°) → **megpörgetés**;
- `TURN_MIN_DEG`–`TURN_MAX_DEG` (55–200°) → egy **jobbra** vagy **balra** forgatás (előjel szerint);
- két egymást követő forgatás (max. `TURN_GAP_MS` szünettel) adja a párt: JJ, BB, JB, BJ.

A forgásirány előjelét a gravitáció szerint fordítja, így felülről nézve az óramutató iránya mindig „jobbra”, akár lefelé, akár felfelé néz a kijelző.

**Kopogás (gyorsulásmérő, 100 Hz, csak fekve).** A gravitációt kivonva a függőleges gyorsulás rövid csúcsait számolja (küszöb az érzékenység szerint, min. `KNOCK_MIN_GAP_MS` köztük). Ha `KNOCK_MAX_GAP_MS` ideig nincs újabb, a sorozat lezárul: 2 → *Kopogás 2×*, 3 → *Kopogás 3×*. Lerakás után `KNOCK_SETTLE_MS` ideig nem figyel, mert a lerakás is koppan.

**Rázás.** Kézben `SHAKE_WINDOW_MS` időn belül legalább `SHAKE_PEAKS` erős csúcs → „megrázva”; ha utána `SHAKE_PLACE_MS` időn belül kijelzővel lefelé leteszed, indul.

**Lefordítás 2×.** A stabil „kijelző felfelé” → „kijelző lefelé” átmeneteket számolja; kettő `FLIP_WINDOW_MS` időn belül.

**Energiatakarékosság.** Csak azt méri, amire a kiosztott mozdulatokhoz szükség van: alapból ~5 Hz, 1 mp-es kötegekben; kopogáshoz fekve 100 Hz; rázáshoz/lefordításhoz kézben 50 Hz; a giroszkóp csak fekve és csak forgatós mozdulatnál fut. Az időzítés a szenzoresemények időbélyegéből számol, így a kötegelt adatküldésnél is pontos.
</details>

<details>
<summary><b>Indító mozdulatok</b></summary>

| Név | Alap | Jelentés |
|---|---|---|
| `TURN_MIN_DEG` / `TURN_MAX_DEG` | `55°` / `200°` | Ekkora forgatás számít „negyed fordulatnak” |
| `SPIN_GESTURE_DEG` | `300°` | Ennyi egy lendületből = megpörgetés |
| `TURN_GAP_MS` | `4000` | Max. szünet két forgatás között |
| `INVERT_TURN` | `false` | Ha a jobbra és balra forgatás fordítva jön ki |
| `KNOCK_THRESHOLDS` | `3.2 / 2.0 / 1.2` | Kopogás küszöbe (m/s²) alacsony / közepes / magas érzékenységnél |
| `KNOCK_MAX_GAP_MS` | `600` | Ennyi szünet zárja le a kopogássorozatot |
| `SHAKE_THRESHOLD` / `SHAKE_PEAKS` | `11` / `4` | Rázás erőssége és a csúcsok száma |
| `SHAKE_PLACE_MS` | `6000` | Rázás után ennyi időd van letenni |
| `FLIP_WINDOW_MS` | `5000` | A két lefordítás időablaka |
| `GESTURE_COOLDOWN_MS` | `4000` | Egy mozdulat után ennyi ideig nem figyel újat |
| `KEEP_AWAKE_MS` | `10 perc` | Lerakás/mozdítás után ennyi ideig ébren a forgatásfigyeléshez |
</details>

<details>
<summary><b>Üvegpörgetés</b></summary>

A gyűrű minden zónájához szögtartomány tartozik (0° = felül, óramutató irányában). A célszöget **egyenletesen sorsolja 0–360° között**, így minden irány azonos eséllyel jön ki, akkor is, ha a C1 16 kis LED-je sűrűbb.

A teljes elfordulás `fordulatok × 360° + (cél − kezdet)`, a mozgás pedig ease-out görbét követ:

```
szög(t) = kezdet + teljes · (1 − (1 − t)^SPIN_EASE_POWER)
```

Az elején gyors, a végén kúszik. A „mutató” a szög körüli ±`SPIN_POINTER_HALF_WIDTH` fokos sáv, így a C1-en 2–3 kis LED ég egyszerre. A lassuló szakaszban minden zónaváltás egy kis kattanó rezgés.
</details>

<details>
<summary><b>Iránytű</b></summary>

A `TYPE_ROTATION_VECTOR` szenzor (gyorsulásmérő + magnetométer + giroszkóp összefésülve) adja a telefon helyzetét. A forgatási mátrixból a telefon tetejének (+Y tengely) iránya:

```
irány = atan2(kelet, észak) = atan2(R[1], R[4])
```

Ez kijelzővel lefelé is helyes, mert csak az Y tengely vízszintes vetületét használja. Az észak a hátlapon ennek az ellentettje: `észak_szög = −irány` (+ mágneses elhajlás, ha be van állítva).

- **Simítás:** szinusz/koszinusz átlag, így a 359° → 0° átmenet nem ugrik.
- **Hiszterézis:** csak akkor vált zónát, ha már `COMPASS_HYSTERESIS` fokkal benne van, ezért nem villódzik a határon.
- **Durva / pontos:** C2–C6 nagy ívek → durva irány; C1 (16 × 5,6°) → egyetlen LED, belépéskor kattanás.
- **Leállás:** ha `faceDown` hamis lesz, indul egy `COMPASS_LIFT_GRACE_MS` időzítő; ha közben visszateszed, folytatja.
</details>

---

## Beállítások (`Config.kt`)

Minden hangolható érték egy helyen: `app/src/main/java/com/akos/glypheggs/Config.kt`. Módosítás után újra kell építeni az APK-t.

<details open>
<summary><b>Glyph Simon</b></summary>

| Név | Alap | Jelentés |
|---|---|---|
| `FULL_SEQUENCE` | `true` | `true`: az egész sort kell végigdönteni · `false`: csak az újat |
| `LEDS_PER_LEVEL` | `2` | Ennyi LED gyullad körönként a C1 szintjelzőn |
| `MAX_ROUNDS` | `8` | 16 / `LEDS_PER_LEVEL` – ennyi kör a győzelemhez |
| `TILT_ON` / `TILT_OFF` | `3.5` / `1.5` | Dőlés küszöbe és a „középen” határa (m/s²) |
| `INVERT_X` / `INVERT_Y` | `false` | Ha a bal/jobb vagy fel/le fordítva jön ki |
| `SHOW_MS` / `GAP_MS` | `300` / `150` | Lejátszás tempója |
| `ANSWER_TIMEOUT_MS` | `7000` | Ennyi idő van egy válaszra |
| `WIN_FLASH_MS` | `8000` | Győzelmi villogás hossza |
</details>

<details>
<summary><b>Indító mozdulatok</b></summary>

| Név | Alap | Jelentés |
|---|---|---|
| `TURN_MIN_DEG` / `TURN_MAX_DEG` | `55°` / `200°` | Ekkora forgatás számít „negyed fordulatnak” |
| `SPIN_GESTURE_DEG` | `300°` | Ennyi egy lendületből = megpörgetés |
| `TURN_GAP_MS` | `4000` | Max. szünet két forgatás között |
| `INVERT_TURN` | `false` | Ha a jobbra és balra forgatás fordítva jön ki |
| `KNOCK_THRESHOLDS` | `3.2 / 2.0 / 1.2` | Kopogás küszöbe (m/s²) alacsony / közepes / magas érzékenységnél |
| `KNOCK_MAX_GAP_MS` | `600` | Ennyi szünet zárja le a kopogássorozatot |
| `SHAKE_THRESHOLD` / `SHAKE_PEAKS` | `11` / `4` | Rázás erőssége és a csúcsok száma |
| `SHAKE_PLACE_MS` | `6000` | Rázás után ennyi időd van letenni |
| `FLIP_WINDOW_MS` | `5000` | A két lefordítás időablaka |
| `GESTURE_COOLDOWN_MS` | `4000` | Egy mozdulat után ennyi ideig nem figyel újat |
| `KEEP_AWAKE_MS` | `10 perc` | Lerakás/mozdítás után ennyi ideig ébren a forgatásfigyeléshez |
</details>

<details>
<summary><b>Üvegpörgetés</b></summary>

| Név | Alap | Jelentés |
|---|---|---|
| `SPIN_MIN_TURNS` / `SPIN_MAX_TURNS` | `4` / `6` | Ennyi teljes kört fut |
| `SPIN_MIN_MS` / `SPIN_MAX_MS` | `5000` / `7000` | A pörgetés hossza |
| `SPIN_EASE_POWER` | `3` | Lassulás erőssége (nagyobb = hosszabb kúszás) |
| `SPIN_POINTER_HALF_WIDTH` | `6°` | A fénypont szélessége |
| `SPIN_HOLD_MS` | `4000` | Ennyi ideig ég az eredmény |
| `SPIN_PLACE_TIMEOUT_MS` | `15000` | Ennyit vár a lerakásra |
</details>

<details>
<summary><b>Iránytű</b></summary>

| Név | Alap | Jelentés |
|---|---|---|
| `COMPASS_DECLINATION` | `0` | Mágneses elhajlás fokban. Földrajzi északhoz Magyarországon ≈ `5.5` |
| `COMPASS_INVERT` | `false` | Ha tükrözve mutat (keletet nyugat helyett) |
| `COMPASS_LIFT_GRACE_MS` | `5000` | Felemelés után ennyit vár a leállással |
| `COMPASS_SMOOTHING` | `0.85` | Simítás (nagyobb = nyugodtabb, lassabb) |
| `COMPASS_HYSTERESIS` | `1.2°` | Villódzás elleni küszöb |
| `COMPASS_PLACE_TIMEOUT_MS` | `20000` | Ennyit vár a lerakásra |
</details>

---

## Engedélyek

| Engedély | Miért kell |
|---|---|
| `com.nothing.ketchum.permission.ENABLE` | A Glyph LED-ek vezérlése |
| `FOREGROUND_SERVICE`, `FOREGROUND_SERVICE_SPECIAL_USE` | Háttérben futó figyelés állandó értesítéssel |
| `POST_NOTIFICATIONS` | Az állandó értesítés megjelenítése |
| `WAKE_LOCK` | Kikapcsolt képernyőnél is fut a szenzorfigyelés és az animáció |
| `VIBRATE` | Rezgéses visszajelzés |
| `RECEIVE_BOOT_COMPLETED` | Újraindítás után visszakapcsolja a figyelést |
| `REQUEST_IGNORE_BATTERY_OPTIMIZATIONS` | Az akkuoptimalizálás kikapcsolásának kérése |

Az app **nem kér** internet-, hely-, kamera- vagy mikrofon-hozzáférést.

---

## Hibaelhárítás

| Tünet | Megoldás |
|---|---|
| Nem gyulladnak ki a LED-ek | Régebbi rendszeren add ki az `adb` parancsot (48 óránként lejár). A naplóban `openSession hiba` jelenik meg. |
| Nem indul a mozdulatra | Ellenőrizd, hogy be van-e kapcsolva a **Mozdulatfigyelés**, és melyik mozdulat tartozik a funkcióhoz. A Diagnosztikában a „forgatás” sor mutatja a felismert forgatásokat (R = jobbra, L = balra). Ha fordítva jön ki, `INVERT_TURN = true`. |
| Nem érzékeli a kopogást / magától indul | Indító mozdulatok → Kopogás érzékenysége: magasabb / alacsonyabb. Kopogtass a telefonon, ne az asztalon. |
| Tesztelnéd más telefonon | Koppints kétszer a címre: a szimuláció Glyph nélkül is mutatja a LED-eket. |
| Fordítva érzékeli a dőlést | `INVERT_X` / `INVERT_Y` |
| Az iránytű tükrözve mutat | `COMPASS_INVERT = true` |
| Az iránytű téved | Fém, laptop, hangszóró van a közelben. Emeld fel, és mozgasd párszor 8-as alakban. |
| A háttérben leáll | Kapcsold ki az akkuoptimalizálást az appban. |
| Furcsán viselkedik lefelé fordításkor | A Nothing **Flip to Glyph** funkciója ütközhet. Kapcsold ki a Glyph beállításokban. |
| A csempe nem indít semmit | Az app ilyenkor magától megnyílik. Ha mégsem, indítsd az app kártyájával. |

---

## Ismert korlátok

- Csak **Nothing Phone (2)**-re készült (`DEVICE_22111`). Más Nothing telefonokon más a zónakiosztás.
- Amíg egy feladat fut, a rendszer saját Glyph-értesítései szünetelnek.
- A kopogás figyelése sűrűbb mérést igényel, ezért valamivel több akkut fogyaszt, mint a forgatás.
- Hosszú tétlenség után (`KEEP_AWAKE_MS`) a giroszkóp alvó processzornál nem kap adatot; ilyenkor egy kis mozdítás „felébreszti”.
- A C2–C6 ívek pontos szöghatárait a Nothing nem dokumentálja, ezért becsültek. A sorrendjük biztos.
- Az iránytű alapból a mágneses északot mutatja.

---

## Források

- [Nothing Glyph Developer Kit](https://github.com/Nothing-Developer-Programme/Glyph-Developer-Kit): hivatalos SDK és zóna-indexelés
- [SebiAi / custom-nothing-glyph-tools](https://github.com/SebiAi/custom-nothing-glyph-tools): a Phone (2) Glyph-zónák részletes leírása

<div align="center">

---

Készült egy Nothing Phone (2)-höz, sok dőlögetéssel és pörgetéssel. 🥚✨

</div>
