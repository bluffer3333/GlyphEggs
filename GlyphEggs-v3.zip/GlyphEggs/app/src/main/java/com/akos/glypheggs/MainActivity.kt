package com.akos.glypheggs

import android.Manifest
import android.app.Activity
import android.app.StatusBarManager
import android.content.ComponentName
import android.content.Intent
import android.content.pm.PackageManager
import android.graphics.Typeface
import android.graphics.drawable.Icon
import android.net.Uri
import android.os.Bundle
import android.os.PowerManager
import android.os.SystemClock
import android.provider.Settings as AndroidSettings
import android.view.Gravity
import android.view.ViewGroup.LayoutParams.MATCH_PARENT
import android.view.ViewGroup.LayoutParams.WRAP_CONTENT
import android.widget.FrameLayout
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView
import kotlinx.coroutines.MainScope
import kotlinx.coroutines.cancel
import kotlinx.coroutines.launch

/**
 * Főképernyő a Nothing Glyph Interface beállításainak stílusában.
 * Tipp: a "Glyph Eggs" címre kétszer koppintva megnyílik a LED-szimuláció.
 */
class MainActivity : Activity() {

    private val scope = MainScope()

    private lateinit var preview: GlyphMapView
    private val modeLabels = mutableMapOf<Feature, TextView>()
    private lateinit var statusText: TextView
    private lateinit var spinCard: FeatureCard
    private lateinit var compassCard: FeatureCard
    private lateinit var watchToggle: ToggleView
    private lateinit var watchSub: TextView
    private lateinit var levelCard: FeatureCard
    private val triggerCards = mutableMapOf<Feature, FeatureCard>()
    private lateinit var vibrateCard: FeatureCard
    private lateinit var batteryCard: FeatureCard
    private lateinit var sensorText: TextView
    private lateinit var logText: TextView
    private var lastTitleTap = 0L

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        darkWindow()

        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(15), 0, dp(15), dp(24))
        }
        val scroll = ScrollView(this).apply {
            setBackgroundColor(Ui.BG)
            isVerticalScrollBarEnabled = false
            addView(root, FrameLayout.LayoutParams(MATCH_PARENT, WRAP_CONTENT))
            padForSystemBars()
        }
        setContentView(scroll)

        // --- Cím (dupla koppintás → szimuláció) ---
        val title = text("Glyph Eggs", 35f, Ui.TEXT, Ui.light).apply {
            setPadding(dp(7), dp(64), 0, 0)
            setOnClickListener {
                val now = SystemClock.uptimeMillis()
                if (now - lastTitleTap < 400) {
                    lastTitleTap = 0L
                    startActivity(Intent(this@MainActivity, SimulatorActivity::class.java))
                } else {
                    lastTitleTap = now
                }
            }
        }
        root.addView(title)
        statusText = text("", 13f, Ui.SUB).apply { setPadding(dp(8), dp(4), dp(8), dp(22)) }
        root.addView(statusText)

        // --- Felső rész: Glyph-előnézet + két gyors kártya ---
        root.addView(buildTop(), LinearLayout.LayoutParams(MATCH_PARENT, dp(332)))

        // --- Világos sáv: mozdulatfigyelés ---
        root.addView(buildWatchBar(), LinearLayout.LayoutParams(MATCH_PARENT, dp(78)).apply { topMargin = dp(18) })

        // --- Glyph Simon ---
        root.addView(sectionTitle("Glyph Simon"))
        val startCard = FeatureCard(this, R.drawable.ic_play, "Indítás most", "Teszt játék, mozdulat nélkül", false)
        startCard.setOnClickListener { send(SimonService.ACTION_START_GAME) }
        levelCard = FeatureCard(this, R.drawable.ic_bars, "Szintjelző", "8 szint · 2 LED körönként", false)
        root.addView(row(startCard, levelCard, 160))

        // --- Indító mozdulatok ---
        root.addView(sectionTitle("Indító mozdulatok"))
        val icons = mapOf(Feature.SIMON to R.drawable.ic_tile, Feature.SPIN to R.drawable.ic_spin, Feature.COMPASS to R.drawable.ic_compass)
        for (f in Feature.entries) {
            triggerCards[f] = FeatureCard(this, icons.getValue(f), f.title, "", false).apply {
                setOnClickListener { openGestures(f) }
            }
        }
        vibrateCard = FeatureCard(this, R.drawable.ic_vibrate, "Rezgés", "Visszajelzés és győzelem", true)
        vibrateCard.toggle?.onChange = { on -> Settings.setVibrate(this, on) }
        root.addView(row(triggerCards.getValue(Feature.SIMON), triggerCards.getValue(Feature.SPIN), 160))
        root.addView(row(triggerCards.getValue(Feature.COMPASS), vibrateCard, 160))

        // --- Gyorsbeállítások ---
        root.addView(sectionTitle("Gyorsbeállítások"))
        val tilesCard = FeatureCard(this, R.drawable.ic_tiles, "Csempék", "3 csempe a lehúzható menübe", false)
        tilesCard.setOnClickListener { addTiles(tileList()) }
        batteryCard = FeatureCard(this, R.drawable.ic_battery, "Háttérfutás", "", true)
        batteryCard.setOnClickListener { askBatteryExemption() }
        batteryCard.toggle?.onChange = { askBatteryExemption() }
        root.addView(row(tilesCard, batteryCard, 160))

        // --- Diagnosztika ---
        root.addView(sectionTitle("Diagnosztika"))
        root.addView(buildDiagnostics(), LinearLayout.LayoutParams(MATCH_PARENT, WRAP_CONTENT))

        // --- Lábjegyzet ---
        root.addView(buildNote())

        // --- Élő adatok ---
        scope.launch { GlyphMirror.lit.collect { preview.lit = it } }
        scope.launch { GlyphMirror.mode.collect { updateMode(it) } }
        scope.launch { DebugState.status.collect { statusText.text = it } }
        scope.launch { DebugState.sensor.collect { sensorText.text = it } }
        scope.launch { DebugState.log.collect { lines -> logText.text = lines.takeLast(8).reversed().joinToString("\n") } }

        if (checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED) {
            requestPermissions(arrayOf(Manifest.permission.POST_NOTIFICATIONS), 1)
        }
    }

    override fun onResume() {
        super.onResume()
        // Ha be volt kapcsolva a figyelés, de a rendszer leállította, újraindítjuk
        if (Settings.watching(this) && !SimonService.watching) send(SimonService.ACTION_WATCH_ON)
        refreshStates()
    }

    private fun buildTop(): LinearLayout {
        val top = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }

        // Bal: Glyph-rajz a Nothing beállításaihoz hasonló keretben
        val previewBox = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            background = rounded(Ui.BG, dp(22).toFloat(), Ui.LINE, dp(1.5f))
            setPadding(dp(10), dp(14), dp(10), dp(10))
        }
        preview = GlyphMapView(this).apply { idleAllOn = true }
        previewBox.addView(preview, LinearLayout.LayoutParams(MATCH_PARENT, 0, 1f))
        previewBox.addView(buildModePill(), LinearLayout.LayoutParams(MATCH_PARENT, dp(36)).apply { topMargin = dp(8) })
        previewBox.setOnClickListener { startActivity(Intent(this, SimulatorActivity::class.java)) }

        // Jobb: Pörgetés és Iránytű
        val right = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        spinCard = FeatureCard(this, R.drawable.ic_spin, "Pörgetés", "Koppints, tedd le", false)
        spinCard.setOnClickListener { send(SimonService.ACTION_SPIN) }
        compassCard = FeatureCard(this, R.drawable.ic_compass, "Iránytű", "Északkeresés fekve", false)
        compassCard.setOnClickListener { send(SimonService.ACTION_COMPASS) }
        right.addView(spinCard, LinearLayout.LayoutParams(MATCH_PARENT, 0, 1f).apply { bottomMargin = dp(2.5f) })
        right.addView(compassCard, LinearLayout.LayoutParams(MATCH_PARENT, 0, 1f).apply { topMargin = dp(2.5f) })

        top.addView(previewBox, LinearLayout.LayoutParams(0, MATCH_PARENT, 1f).apply { marginEnd = dp(2.5f) })
        top.addView(right, LinearLayout.LayoutParams(0, MATCH_PARENT, 1f).apply { marginStart = dp(2.5f) })
        return top
    }

    /** A rajz alatti "pirula": melyik funkció fut éppen. */
    private fun buildModePill(): LinearLayout {
        val pill = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
            background = rounded(Ui.CARD, dp(18).toFloat())
            setPadding(dp(4), 0, dp(8), 0)
        }
        val dot = FrameLayout(this).apply { background = rounded(0xFFE8E8E8.toInt(), dp(14).toFloat()) }
        dot.addView(ImageView(this).apply { setImageResource(R.drawable.ic_glyph_small) },
            FrameLayout.LayoutParams(dp(16), dp(16), Gravity.CENTER))
        pill.addView(dot, LinearLayout.LayoutParams(dp(28), dp(28)))
        for (f in Feature.entries) {
            val label = if (f == Feature.SIMON) "Simon" else f.title
            val t = text(label, 11.5f, Ui.SUB).apply { setPadding(dp(8), 0, 0, 0) }
            modeLabels[f] = t
            pill.addView(t)
        }
        return pill
    }

    private fun buildWatchBar(): LinearLayout {
        val bar = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
            background = rounded(Ui.LIGHT, dp(22).toFloat())
            setPadding(dp(20), 0, dp(16), 0)
        }
        val texts = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        texts.addView(text("Mozdulatfigyelés", 17.5f, Ui.DARK_TEXT))
        watchSub = text("", 12f, 0xFF555555.toInt())
        texts.addView(watchSub)
        bar.addView(texts, LinearLayout.LayoutParams(0, WRAP_CONTENT, 1f))
        watchToggle = ToggleView(this).apply {
            onColor = 0xFFFFFFFF.toInt()
            onChange = { on -> setWatching(on) }
        }
        bar.addView(watchToggle)
        bar.setOnClickListener { watchToggle.performClick() }
        return bar
    }

    private fun buildDiagnostics(): LinearLayout {
        val card = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            background = rounded(Ui.CARD, dp(22).toFloat())
            setPadding(dp(16), dp(18), dp(16), dp(16))
        }
        card.addView(icon(R.drawable.ic_pulse))
        card.addView(text("Élő szenzoradatok", 19f).apply { setPadding(0, dp(18), 0, dp(10)) })
        sensorText = monoBox()
        card.addView(sensorText)
        card.addView(text("Napló", 15f).apply { setPadding(0, dp(16), 0, dp(8)) })
        logText = monoBox()
        card.addView(logText)
        return card
    }

    private fun monoBox(): TextView = text("–", 11f, 0xFFCFCFCF.toInt(), Typeface.MONOSPACE).apply {
        background = rounded(0xFF242424.toInt(), dp(12).toFloat())
        setPadding(dp(12), dp(10), dp(12), dp(10))
        setLineSpacing(0f, 1.25f)
    }

    private fun buildNote(): LinearLayout {
        val note = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            setPadding(dp(9), dp(24), dp(9), dp(12))
        }
        note.addView(icon(R.drawable.ic_info, 22))
        note.addView(text(
            "A villogó Glyph-animációk nem biztonságosak epilepsziások és más fényérzékeny állapotban lévők számára.\n\n" +
                "Tipp: koppints kétszer a „Glyph Eggs” címre, és a képernyőn is látod, mit csinálnak a LED-ek.",
            12.5f, Ui.SUB
        ).apply { setPadding(dp(12), 0, 0, 0); setLineSpacing(0f, 1.2f) })
        return note
    }

    // ------------------------------------------------------------------ állapot

    private fun refreshStates() {
        val on = Settings.watching(this)
        watchToggle.checked = on
        watchSub.text = if (on) "Bekapcsolva · a mozdulatok indítják a funkciókat" else "Kikapcsolva · csak csempével és gombbal"
        for ((f, card) in triggerCards) {
            card.subtitleView.text = Settings.trigger(this, f).title
        }
        vibrateCard.toggle?.checked = Settings.vibrate(this)
        val pm = getSystemService(PowerManager::class.java)
        val exempt = pm.isIgnoringBatteryOptimizations(packageName)
        batteryCard.toggle?.checked = exempt
        batteryCard.subtitleView.text = if (exempt) "Akkuoptimalizálás kikapcsolva" else "Koppints: ne állítsa le a rendszer"
        val lvl = Settings.lastLevel(this)
        levelCard.subtitleView.text = if (lvl < 0) "8 szint · 2 LED körönként" else "Legutóbb: $lvl/${Config.MAX_ROUNDS} szint"
        updateMode(GlyphMirror.mode.value)
    }

    private fun updateMode(mode: Feature?) {
        preview.active = mode != null
        for ((f, t) in modeLabels) {
            val active = f == mode
            t.setTextColor(if (active) Ui.TEXT else Ui.SUB)
            t.typeface = if (active) Ui.medium else Ui.regular
        }
        compassCard.subtitleView.text = if (mode == Feature.COMPASS) "Fut · koppints a leállításhoz" else "Északkeresés fekve"
        spinCard.subtitleView.text = if (mode == Feature.SPIN) "Pörög…" else "Koppints, tedd le"
    }

    private fun setWatching(on: Boolean) {
        Settings.setWatching(this, on)
        if (on) {
            send(SimonService.ACTION_WATCH_ON)
        } else if (SimonService.watching) {
            startService(Intent(this, SimonService::class.java).setAction(SimonService.ACTION_WATCH_OFF))
        }
        watchSub.text = if (on) "Bekapcsolva · a mozdulatok indítják a funkciókat" else "Kikapcsolva · csak csempével és gombbal"
    }

    private fun send(action: String) {
        startForegroundService(Intent(this, SimonService::class.java).setAction(action))
    }

    private fun openGestures(f: Feature) {
        startActivity(Intent(this, GesturesActivity::class.java).putExtra(GesturesActivity.EXTRA_FEATURE, f.name))
    }

    private fun askBatteryExemption() {
        val pm = getSystemService(PowerManager::class.java)
        if (pm.isIgnoringBatteryOptimizations(packageName)) {
            DebugState.log("Az akkumulátor-optimalizálás már ki van kapcsolva")
            batteryCard.toggle?.checked = true
            return
        }
        startActivity(
            Intent(AndroidSettings.ACTION_REQUEST_IGNORE_BATTERY_OPTIMIZATIONS, Uri.parse("package:$packageName"))
        )
    }

    private data class TileInfo(val cls: Class<*>, val label: String, val icon: Int)

    private fun tileList() = listOf(
        TileInfo(SimonTileService::class.java, "Glyph figyelés", R.drawable.ic_tile),
        TileInfo(SpinTileService::class.java, "Pörgetés", R.drawable.ic_spin),
        TileInfo(CompassTileService::class.java, "Iránytű", R.drawable.ic_compass)
    )

    /** A csempéket egymás után kéri fel a lehúzható menübe. */
    private fun addTiles(list: List<TileInfo>) {
        if (list.isEmpty()) return
        val t = list.first()
        getSystemService(StatusBarManager::class.java).requestAddTileService(
            ComponentName(this, t.cls),
            t.label,
            Icon.createWithResource(this, t.icon),
            mainExecutor
        ) { result ->
            DebugState.log("${t.label} csempe: $result")
            addTiles(list.drop(1))
        }
    }

    override fun onDestroy() {
        scope.cancel()
        super.onDestroy()
    }
}
