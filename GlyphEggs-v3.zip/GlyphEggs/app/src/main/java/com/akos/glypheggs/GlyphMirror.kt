package com.akos.glypheggs

import kotlinx.coroutines.flow.MutableStateFlow

/**
 * A LED-ek "tükörképe": mindig tudja, melyik zóna ég éppen.
 * A főképernyő előnézete és a szimulációs mód ebből rajzol, így Glyph nélküli
 * telefonon is látszik, mit csinálna a hátlap.
 */
object GlyphMirror {
    /** Az éppen világító zónák (Glyph.Code_22111 indexek). */
    val lit = MutableStateFlow<Set<Int>>(emptySet())

    /** Melyik funkció fut most (null = egyik sem). */
    val mode = MutableStateFlow<Feature?>(null)

    /** Igaz, ha a valódi Glyph LED-ek is működnek (nem csak szimuláció). */
    val hardware = MutableStateFlow(false)

    /**
     * Nyitva van-e a szimulációs képernyő. Ilyenkor a funkciók kijelzővel FELFELÉ fekvő
     * telefonnal is indulnak, hogy a képernyőn lásd az animációt.
     */
    @Volatile
    var simulatorOpen = false
}
