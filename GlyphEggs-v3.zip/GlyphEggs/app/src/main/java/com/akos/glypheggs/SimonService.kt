package com.akos.glypheggs

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.Service
import android.content.ComponentName
import android.content.Intent
import android.content.pm.ServiceInfo
import android.graphics.drawable.Icon
import android.os.IBinder
import android.service.quicksettings.TileService
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.cancel
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.first
import kotlinx.coroutines.launch
import kotlinx.coroutines.withTimeoutOrNull

/**
 * Előtérszolgáltatás (állandó értesítéssel): ez vezérli a LED-eket és a szenzorokat.
 *
 *  - Mozdulatfigyelés: ha be van kapcsolva, a beállított indító mozdulatokra
 *    ([Trigger]) elindítja a hozzájuk rendelt funkciót ([Feature]).
 *  - Simon, Pörgetés, Iránytű: csempéről, az appból vagy mozdulattal indulnak.
 *  - Ha nincs Glyph (más telefon), a funkciók akkor is futnak: a képernyőn,
 *    a szimulációs módban látszanak.
 *
 * Ha a figyelés ki van kapcsolva, a szolgáltatás csak egy feladat idejére fut.
 */
class SimonService : Service() {

    companion object {
        const val ACTION_WATCH_ON = "com.akos.glypheggs.WATCH_ON"
        const val ACTION_WATCH_OFF = "com.akos.glypheggs.WATCH_OFF"
        const val ACTION_REFRESH = "com.akos.glypheggs.REFRESH"
        const val ACTION_START_GAME = "com.akos.glypheggs.START_GAME"
        const val ACTION_SPIN = "com.akos.glypheggs.SPIN"
        const val ACTION_COMPASS = "com.akos.glypheggs.COMPASS"
        const val ACTION_STOP = "com.akos.glypheggs.STOP"
        private const val CHANNEL_ID = "glyph_eggs"
        private const val NOTIF_ID = 1

        /** Be van-e kapcsolva a mozdulatfigyelés (a csempe ebből mutatja az állapotot). */
        @Volatile
        var watching = false
            private set

        /** Fut-e most az iránytű. */
        @Volatile
        var compassOn = false
            private set

        private const val IDLE_TEXT = "Készenlét"
    }

    private val scope = CoroutineScope(SupervisorJob() + Dispatchers.Default)
    private lateinit var glyph: GlyphController
    private lateinit var motion: MotionDetector
    private lateinit var haptics: Haptics
    private var job: Job? = null

    override fun onCreate() {
        super.onCreate()
        createChannel()
        startForeground(NOTIF_ID, buildNotification(IDLE_TEXT), ServiceInfo.FOREGROUND_SERVICE_TYPE_SPECIAL_USE)

        haptics = Haptics(this)
        glyph = GlyphController(this).also { it.init() }
        motion = MotionDetector(this) { t -> onTrigger(t) }.also { it.start() }
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        when (intent?.action) {
            // Rendszer általi újraindításnál (null) a mentett beállítás dönt
            null -> setWatching(Settings.watching(this))
            ACTION_WATCH_ON -> setWatching(true)
            ACTION_WATCH_OFF -> setWatching(false)
            ACTION_REFRESH -> {
                motion.setWatching(watching, Settings.activeTriggers(this))
                if (job?.isActive != true) showIdle()
                if (!watching && job?.isActive != true) stopSelf()
            }
            ACTION_START_GAME -> startGame()
            ACTION_SPIN -> startSpin()
            ACTION_COMPASS -> toggleCompass()
            ACTION_STOP -> {
                Settings.setWatching(this, false)
                setWatching(false)
                job?.cancel()
                stopSelf()
                return START_NOT_STICKY
            }
        }
        return START_STICKY
    }

    private fun setWatching(on: Boolean) {
        watching = on
        val active = Settings.activeTriggers(this)
        motion.setWatching(on, active)
        refreshTiles()
        DebugState.log(
            if (on) "Mozdulatfigyelés be: " + active.joinToString { it.title }.ifEmpty { "nincs kiosztott mozdulat" }
            else "Mozdulatfigyelés kikapcsolva"
        )
        if (job?.isActive != true) {
            showIdle()
            if (!on) stopSelf()
        }
    }

    /** Egy felismert mozdulat: a hozzá rendelt funkció indul. */
    private fun onTrigger(t: Trigger) {
        val f = Settings.featureFor(this, t) ?: return
        haptics.tick()
        when (f) {
            Feature.SIMON -> startGame()
            Feature.SPIN -> startSpin()
            Feature.COMPASS -> toggleCompass()
        }
    }

    private fun showIdle() {
        val text = if (watching) {
            val parts = Feature.entries.mapNotNull { f ->
                val t = Settings.trigger(this, f)
                if (t == Trigger.NONE) null else "${f.title}: ${t.title}"
            }
            if (parts.isEmpty()) "Figyel – nincs kiosztott mozdulat" else "Figyel · " + parts.joinToString(" · ")
        } else {
            IDLE_TEXT
        }
        DebugState.status.value = text
        updateNotification(text)
    }

    private fun setStatus(text: String) {
        DebugState.status.value = text
        updateNotification(text)
    }

    /** Közös keret: Glyph session megnyitása (ha lehet), a feladat futtatása, utána takarítás. */
    private fun launchWithGlyph(feature: Feature, status: String, block: suspend () -> Unit) {
        if (job?.isActive == true) {
            DebugState.log("Már fut egy funkció, előbb az fejeződjön be")
            return
        }
        job = scope.launch {
            try {
                GlyphMirror.mode.value = feature
                // Közvetlenül indulás után a Glyph szolgáltatásnak kell egy kis idő
                withTimeoutOrNull(2_000) { while (!glyph.connected) delay(100) }
                if (!glyph.openSession()) {
                    DebugState.log("Nincs Glyph-kapcsolat – csak a képernyőn látszik (szimuláció)")
                }
                setStatus(status)
                block()
            } finally {
                glyph.closeSession()
                motion.setGameMode(false)
                GlyphMirror.mode.value = null
                showIdle()
                if (!watching) stopSelf()
            }
        }
    }

    private fun startGame() = launchWithGlyph(Feature.SIMON, "Simon játék folyamatban") {
        motion.setGameMode(true)
        val level = SimonGame(glyph, motion, haptics).run()
        Settings.setLastLevel(this, level)
        DebugState.log("Játék vége – elért szint: $level/${Config.MAX_ROUNDS}")
    }

    private fun startSpin() = launchWithGlyph(Feature.SPIN, "Pörgetés") {
        if (!motion.faceDown.value) {
            setStatus("Tedd le kijelzővel lefelé a pörgetéshez")
            val placed = withTimeoutOrNull(Config.SPIN_PLACE_TIMEOUT_MS) { motion.faceDown.first { it } }
            if (placed == null) DebugState.log("Nem tetted le – pörgetés így is indul")
            delay(Config.SPIN_SETTLE_MS)
        }
        setStatus("Pörgetés")
        motion.setGameMode(true) // ébren tartja a telefont, és szünetelteti a mozdulatfigyelést
        SpinWheel(glyph, haptics).run()
    }

    /** Ha az iránytű fut, kikapcsolja; ha nem, elindítja. */
    private fun toggleCompass() {
        if (compassOn) {
            DebugState.log("Iránytű kikapcsolva")
            job?.cancel()
            return
        }
        launchWithGlyph(Feature.COMPASS, "Iránytű") {
            compassOn = true
            refreshTiles()
            try {
                motion.setGameMode(true) // ébren tartja a telefont, gyorsan figyeli a felemelést
                Compass(this, glyph, motion, haptics) { text -> setStatus(text) }.run()
            } finally {
                compassOn = false
                refreshTiles()
            }
        }
    }

    override fun onDestroy() {
        scope.cancel()
        motion.stop()
        glyph.release()
        watching = false
        compassOn = false
        GlyphMirror.mode.value = null
        refreshTiles()
        DebugState.status.value = "Leállítva"
        DebugState.log("Szolgáltatás leállt")
        super.onDestroy()
    }

    override fun onBind(intent: Intent?): IBinder? = null

    private fun refreshTiles() {
        for (cls in listOf(SimonTileService::class.java, SpinTileService::class.java, CompassTileService::class.java)) {
            TileService.requestListeningState(this, ComponentName(this, cls))
        }
    }

    private fun createChannel() {
        val channel = NotificationChannel(CHANNEL_ID, "Glyph Eggs", NotificationManager.IMPORTANCE_LOW)
        getSystemService(NotificationManager::class.java).createNotificationChannel(channel)
    }

    private fun buildNotification(text: String): Notification {
        val open = PendingIntent.getActivity(
            this, 0, Intent(this, MainActivity::class.java),
            PendingIntent.FLAG_IMMUTABLE
        )
        val stop = PendingIntent.getService(
            this, 1, Intent(this, SimonService::class.java).setAction(ACTION_STOP),
            PendingIntent.FLAG_IMMUTABLE
        )
        return Notification.Builder(this, CHANNEL_ID)
            .setSmallIcon(R.drawable.ic_tile)
            .setContentTitle("Glyph Eggs")
            .setContentText(text)
            .setOngoing(true)
            .setContentIntent(open)
            .addAction(Notification.Action.Builder(null as Icon?, "Leállítás", stop).build())
            .build()
    }

    private fun updateNotification(text: String) {
        getSystemService(NotificationManager::class.java).notify(NOTIF_ID, buildNotification(text))
    }
}
