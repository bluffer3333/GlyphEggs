package com.akos.glypheggs

/**
 * Minden hangolható érték egy helyen.
 * Ha valami nem úgy működik a telefonon, ahogy szeretnéd, általában itt kell állítani.
 */
object Config {
    // --- Játékszabály ---
    /** true = klasszikus Simon Says: minden körben a teljes sort végig kell dönteni.
     *  false = csak a legújabb LED irányát kell eltalálni. */
    const val FULL_SEQUENCE = true
    /** Ennyi LED gyullad ki a C1 szintjelzőn körönként. */
    const val LEDS_PER_LEVEL = 2
    /** 16 LED / 2 = 8 kör, ekkor betelik a szintjelző és nyersz. */
    const val MAX_ROUNDS = 16 / LEDS_PER_LEVEL

    // --- Indító mozdulatok (bármelyik funkcióhoz, az appban állítható) ---
    /** |gravitáció z| ennél nagyobb → vízszintesen fekszik (m/s², max 9.81). */
    const val FLAT_Z = 8.0f
    /** Lerakás/mozdítás után ennyi ideig marad ébren a processzor a forgatások figyeléséhez. */
    const val KEEP_AWAKE_MS = 10 * 60 * 1000L
    /** Ha a jobbra forgatást balra forgatásnak érzékeli, állítsd true-ra. */
    const val INVERT_TURN = false
    /** Forgatás kezdete / vége (rad/s szögsebesség). */
    const val MOVE_START_RAD_S = 0.6f
    const val MOVE_STOP_RAD_S = 0.3f
    /** Ennyi nyugalom után zárul le egy forgatás. */
    const val MOVE_END_MS = 250L
    /** Egy "negyed fordulat" ennyi fok között számít (pontatlanul is jó). */
    const val TURN_MIN_DEG = 55f
    const val TURN_MAX_DEG = 200f
    /** Megpörgetés: legalább ennyi fok egy lendületből. */
    const val SPIN_GESTURE_DEG = 300f
    /** Két forgatás között legfeljebb ennyi idő telhet el. */
    const val TURN_GAP_MS = 4_000L
    /** Egy felismert mozdulat után ennyi ideig nem figyel újat. */
    const val GESTURE_COOLDOWN_MS = 4_000L

    /** Kopogás küszöbe (m/s²) érzékenység szerint: alacsony, közepes, magas. */
    val KNOCK_THRESHOLDS = floatArrayOf(3.2f, 2.0f, 1.2f)
    /** Két kopogás között legalább / legfeljebb ennyi idő. */
    const val KNOCK_MIN_GAP_MS = 90L
    const val KNOCK_MAX_GAP_MS = 600L
    /** Lerakás után ennyi ideig nem figyel kopogást (a lerakás is "koppan"). */
    const val KNOCK_SETTLE_MS = 1_000L

    /** Rázás: ekkora gyorsulás-csúcsokból ennyi kell, ennyi időn belül. */
    const val SHAKE_THRESHOLD = 11f
    const val SHAKE_PEAKS = 4
    const val SHAKE_WINDOW_MS = 1_200L
    /** Rázás után ennyi időd van lerakni kijelzővel lefelé. */
    const val SHAKE_PLACE_MS = 6_000L

    /** Lefordítás 2×: a két lefordításnak ennyi időn belül kell meglennie. */
    const val FLIP_WINDOW_MS = 5_000L

    // --- Döntés felismerése ---
    /** Ekkora oldalirányú gravitációs komponens felett számít döntésnek (~21°). */
    const val TILT_ON = 3.5f
    /** Ez alá kell visszaengedni, hogy "középen" legyen. */
    const val TILT_OFF = 1.5f
    /** Ha a bal/jobb vagy előre/hátra fordítva jön ki, ezeket állítsd true-ra. */
    const val INVERT_X = false
    const val INVERT_Y = false

    // --- Időzítés ---
    /** Mennyi ideig ég egy irány a sor lejátszásakor. */
    const val SHOW_MS = 300L
    /** Szünet két irány között a lejátszásnál. */
    const val GAP_MS = 150L
    const val ANSWER_TIMEOUT_MS = 7_000L
    /** Győzelmi villogás hossza (a rezgés is kb. ennyi). */
    const val WIN_FLASH_MS = 8_000L

    // --- Pörgetés (üvegpörgető) ---
    /** Ennyi teljes kört fut legalább / legfeljebb, mielőtt megáll. */
    const val SPIN_MIN_TURNS = 4
    const val SPIN_MAX_TURNS = 6
    /** A pörgetés hossza (véletlenszerűen e kettő között). */
    const val SPIN_MIN_MS = 5_000L
    const val SPIN_MAX_MS = 7_000L
    /** Mennyire lassul a végén: nagyobb szám = hirtelenebb lassulás, hosszabb "kúszás". */
    const val SPIN_EASE_POWER = 3f
    /** A fénypont szélessége (fokban, mindkét irányba). */
    const val SPIN_POINTER_HALF_WIDTH = 6f
    /** Megállás után ennyi ideig marad égve a kiválasztott hely. */
    const val SPIN_HOLD_MS = 4_000L
    /** Csempe után ennyi ideig vár, hogy letedd kijelzővel lefelé. */
    const val SPIN_PLACE_TIMEOUT_MS = 15_000L
    /** Lerakás után ennyit vár, hogy megnyugodjon a telefon. */
    const val SPIN_SETTLE_MS = 700L

    // --- Iránytű ---
    /** Csempe után ennyi ideig vár, hogy letedd kijelzővel lefelé. */
    const val COMPASS_PLACE_TIMEOUT_MS = 20_000L
    /** Lerakás után ennyit vár, mielőtt mutatni kezd. */
    const val COMPASS_SETTLE_MS = 500L
    /** Felemelés után ennyi ideig vár; ha addig visszateszed, folytatja. */
    const val COMPASS_LIFT_GRACE_MS = 5_000L
    /** Simítás 0–1 között: nagyobb = nyugodtabb, de lassabban követ. */
    const val COMPASS_SMOOTHING = 0.85f
    /** Ennyi fokkal kell átérni a szomszéd részbe, hogy váltson (villódzás ellen). */
    const val COMPASS_HYSTERESIS = 1.2f
    /** Mágneses elhajlás fokban. 0 = mágneses észak; Magyarországon a földrajzi északhoz kb. 5.5. */
    const val COMPASS_DECLINATION = 0f
    /** Ha az észak tükrözve jön ki (pl. keletet mutat nyugat helyett), állítsd true-ra. */
    const val COMPASS_INVERT = false
}
