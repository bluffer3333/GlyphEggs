package com.akos.glypheggs

import android.content.Context
import android.os.VibrationEffect
import android.os.VibratorManager

/** Rezgések: indító jelzés, pörgetés kattogása és eredménye, győzelem. Az appban kikapcsolható. */
class Haptics(context: Context) {
    private val appContext = context.applicationContext
    private val vibrator = context.getSystemService(VibratorManager::class.java).defaultVibrator

    private fun play(effect: VibrationEffect) {
        if (!Settings.vibrate(appContext)) return
        vibrator.vibrate(effect)
    }

    /** Rövid jelzés: a mozdulatot felismerte. */
    fun tick() = play(VibrationEffect.createOneShot(80, VibrationEffect.DEFAULT_AMPLITUDE))

    /** Nagyon rövid kattanás a pörgetés lassuló szakaszában és az iránytűnél. */
    fun click() = play(VibrationEffect.createPredefined(VibrationEffect.EFFECT_TICK))

    /** A pörgetés megállt. */
    fun result() = play(VibrationEffect.createWaveform(longArrayOf(0, 120, 80, 120, 80, 400), -1))

    /** Kb. 8 másodperces győzelmi rezgés: lüktető ütemek, a végén egy hosszú. */
    fun win() {
        val pattern = mutableListOf(0L)
        repeat(13) { pattern += listOf(400L, 150L) }
        pattern += 900L
        play(VibrationEffect.createWaveform(pattern.toLongArray(), -1))
    }
}
