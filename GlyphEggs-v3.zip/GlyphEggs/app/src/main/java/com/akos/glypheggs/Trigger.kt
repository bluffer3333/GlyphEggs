package com.akos.glypheggs

import android.content.Context

/** A három indítható funkció. */
enum class Feature(val title: String) {
    SIMON("Glyph Simon"),
    SPIN("Pörgetés"),
    COMPASS("Iránytű")
}

/**
 * Indító mozdulatok. Bármelyik bármelyik funkcióhoz rendelhető,
 * de egy mozdulat egyszerre csak egy funkcióhoz tartozhat.
 */
enum class Trigger(val title: String, val hint: String) {
    NONE("Nincs", "Csak csempével vagy az appból indul"),
    RIGHT_2("Jobbra forgatás 2×", "Fekve kétszer kb. negyed fordulat jobbra"),
    LEFT_2("Balra forgatás 2×", "Fekve kétszer kb. negyed fordulat balra"),
    RIGHT_LEFT("Jobbra, majd balra", "Fekve negyed fordulat jobbra, aztán vissza balra"),
    LEFT_RIGHT("Balra, majd jobbra", "Fekve negyed fordulat balra, aztán vissza jobbra"),
    SPIN("Megpörgetés", "Pörgesd meg az asztalon legalább egy teljes körre"),
    KNOCK_2("Kopogás 2×", "Fekve kopogtass kétszer gyorsan a telefonon"),
    KNOCK_3("Kopogás 3×", "Fekve kopogtass háromszor gyorsan a telefonon"),
    SHAKE("Rázás, majd lerakás", "Rázd meg, és 6 mp-en belül tedd le kijelzővel lefelé"),
    FLIP_2("Lefordítás 2×", "Kijelzővel felfelé → lefelé, kétszer egymás után");

    /** Forgatással (giroszkóppal) felismert mozdulat-e. */
    val usesGyro: Boolean
        get() = this == RIGHT_2 || this == LEFT_2 || this == RIGHT_LEFT || this == LEFT_RIGHT || this == SPIN

    val isKnock: Boolean
        get() = this == KNOCK_2 || this == KNOCK_3
}

/** Mentett beállítások egy helyen. */
object Settings {
    private const val PREFS = "glyph_eggs"
    private const val KEY_WATCHING = "enabled"
    private const val KEY_VIBRATE = "vibrate"
    private const val KEY_KNOCK_SENS = "knock_sensitivity"
    private const val KEY_LAST_LEVEL = "last_level"

    private fun p(c: Context) = c.getSharedPreferences(PREFS, Context.MODE_PRIVATE)

    private fun key(f: Feature) = "trigger_${f.name}"

    fun defaultTrigger(f: Feature): Trigger = when (f) {
        Feature.SIMON -> Trigger.RIGHT_2
        Feature.SPIN -> Trigger.SPIN
        Feature.COMPASS -> Trigger.KNOCK_2
    }

    fun trigger(c: Context, f: Feature): Trigger {
        val name = p(c).getString(key(f), null) ?: return defaultTrigger(f)
        return Trigger.entries.firstOrNull { it.name == name } ?: defaultTrigger(f)
    }

    /** Beállítja a mozdulatot; ha másik funkció használta, ott "Nincs" lesz. */
    fun setTrigger(c: Context, f: Feature, t: Trigger) {
        val e = p(c).edit()
        if (t != Trigger.NONE) {
            for (other in Feature.entries) {
                if (other != f && trigger(c, other) == t) e.putString(key(other), Trigger.NONE.name)
            }
        }
        e.putString(key(f), t.name)
        e.apply()
    }

    /** Melyik funkció indul erre a mozdulatra (ha van). */
    fun featureFor(c: Context, t: Trigger): Feature? =
        if (t == Trigger.NONE) null else Feature.entries.firstOrNull { trigger(c, it) == t }

    fun activeTriggers(c: Context): Set<Trigger> =
        Feature.entries.map { trigger(c, it) }.filter { it != Trigger.NONE }.toSet()

    fun watching(c: Context): Boolean = p(c).getBoolean(KEY_WATCHING, false)
    fun setWatching(c: Context, on: Boolean) = p(c).edit().putBoolean(KEY_WATCHING, on).apply()

    fun vibrate(c: Context): Boolean = p(c).getBoolean(KEY_VIBRATE, true)
    fun setVibrate(c: Context, on: Boolean) = p(c).edit().putBoolean(KEY_VIBRATE, on).apply()

    /** 0 = alacsony, 1 = közepes, 2 = magas. */
    fun knockSensitivity(c: Context): Int = p(c).getInt(KEY_KNOCK_SENS, 1).coerceIn(0, 2)
    fun setKnockSensitivity(c: Context, v: Int) = p(c).edit().putInt(KEY_KNOCK_SENS, v.coerceIn(0, 2)).apply()

    fun lastLevel(c: Context): Int = p(c).getInt(KEY_LAST_LEVEL, -1)
    fun setLastLevel(c: Context, v: Int) = p(c).edit().putInt(KEY_LAST_LEVEL, v).apply()
}
