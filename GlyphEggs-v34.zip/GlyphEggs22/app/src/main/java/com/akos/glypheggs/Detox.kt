package com.akos.glypheggs

import android.content.Context
import android.os.SystemClock
import com.nothing.ketchum.Glyph
import kotlinx.coroutines.delay

/*
 * GLYPH FOCUS – telefon-böjt a Glyph LED-ekkel. Tedd le kijelzővel lefelé, és amíg hozzá sem érsz,
 * a fény alulról felfelé nő: a cél idejére (alapból 60 perc) mind a 33 LED ég. Ha felveszed vagy
 * megfordítod, a sorozat megszakad – az eredmény a statisztikába kerül.
 */

/** Hogyan mutassa a haladást. */
enum class DetoxShow(val title: String, val desc: String) {
    PULSE("Percenként felvillan", "Sötét marad, és csak percenként egy pillanatra mutatja a haladást – akkubarát"),
    ALWAYS("Mindig látszik", "A megszerzett LED-ek folyamatosan égnek – látványos, de többet fogyaszt"),
    HIDDEN("Teljes sötét", "Semmi nem világít, csak a végén derül ki, meddig bírtad")
}

/** Milyen animáció mutassa a haladást. */
enum class DetoxAnim(val title: String, val desc: String) {
    FILL("Növekvő kert", "Alulról, a töltőport felől nő felfelé a fény"),
    RING("Gyűrű", "A nagy gyűrű telik körbe, mint egy óralap"),
    BAR("Felső sáv", "Csak a 16 pontos felső sáv telik – visszafogott"),
    RISE("Felszálló fény", "Egy fénypont felszáll a mostani szintig, ott megáll"),
    STUDIO("Saját animáció", "Egy Glyph Stúdió-animációd, utána egy pillanatra a haladás")
}

class DetoxSession(
    private val context: Context,
    private val glyph: GlyphController,
    private val motion: MotionDetector,
    private val haptics: Haptics,
    private val onStatus: (String) -> Unit
) {
    private val order = LectureTimer.FILL_ORDER
    private val ring = Zones.LEVEL.reversedArray() + intArrayOf(
        Glyph.Code_22111.C6, Glyph.Code_22111.C5, Glyph.Code_22111.C4, Glyph.Code_22111.C3, Glyph.Code_22111.C2)
    private val bar = IntArray(16) { Zones.LEVEL[15 - it] }
    private val anim = Settings.detoxAnim(context)
    private val studio: StudioAnim? = if (anim == DetoxAnim.STUDIO)
        (StudioStore.find(context, Settings.detoxStudioId(context)) ?: StudioStore.favorite(context)) else null
    private var studioFrame = 0

    /** A haladás képe a választott stílusban (p = 0..1). */
    private fun progressFrame(p: Float): IntArray {
        val q = p.coerceIn(0f, 1f)
        return when (anim) {
            DetoxAnim.RING -> ring.take(Math.round(q * ring.size).coerceAtLeast(1)).toIntArray()
            DetoxAnim.BAR -> bar.take(Math.round(q * 16).coerceAtLeast(1)).toIntArray()
            else -> order.take(Math.round(q * order.size).coerceAtLeast(1)).toIntArray()
        }
    }

    /** Egy „megmutatás” (percenként felvillanó módban): a stílus szerinti rövid animáció. */
    private suspend fun showOnce(p: Float) {
        when (anim) {
            DetoxAnim.RISE -> {
                val top = Math.round(p.coerceIn(0f, 1f) * order.size).coerceIn(1, order.size)
                for (i in 0 until top) { glyph.show(intArrayOf(order[i])); delay(30) }
                glyph.show(order.take(top).toIntArray()); delay(900)
            }
            DetoxAnim.STUDIO -> {
                val a = studio
                if (a != null) {
                    val end = SystemClock.elapsedRealtime() + 4_000L
                    for (fr in a.frames) {
                        if (SystemClock.elapsedRealtime() > end) break
                        if (fr.zones.isEmpty()) glyph.off() else glyph.show(fr.zones.toIntArray())
                        delay(fr.ms.toLong())
                    }
                }
                glyph.show(progressFrame(p)); delay(1_000)
            }
            else -> { glyph.show(progressFrame(p)); delay(1_200) }
        }
        glyph.off()
    }

    /** A végén: hány percig bírta (a hívó menti a statisztikába). */
    var minutes = 0
        private set
    var reachedGoal = false
        private set

    suspend fun run() {
        val goalMin = Settings.detoxGoal(context)
        val show = Settings.detoxShow(context)
        val goalMs = goalMin * 60_000L
        // Indító animáció: a fény lefut a vonalon, majd kialszik („lekapcsolódás”)
        for (i in order.indices.reversed()) {
            glyph.show(order.take(i + 1).toIntArray())
            delay(18)
        }
        glyph.off()
        haptics.tick()

        val start = SystemClock.elapsedRealtime()
        var awaySince = 0L
        var lastLit = -1
        var lastPulse = 0L
        while (true) {
            val now = SystemClock.elapsedRealtime()
            val elapsed = now - start
            minutes = (elapsed / 60_000L).toInt()
            val lit = (elapsed * order.size / goalMs).toInt().coerceIn(0, order.size)

            // Megszakad, ha 4 mp-nél tovább nincs kijelzővel lefelé (felvették / megfordították)
            if (!motion.faceDown.value) {
                if (awaySince == 0L) awaySince = now
                if (now - awaySince > 4_000) break
            } else awaySince = 0L

            if (!reachedGoal && elapsed >= goalMs) {
                reachedGoal = true
                celebrate()
                lastPulse = now
            }

            val status = if (reachedGoal) "Glyph Focus · cél teljesítve! $minutes perc – túlórában"
            else "Glyph Focus · $minutes / $goalMin perc · ne nyúlj hozzá"
            onStatus(status)

            val p = if (reachedGoal) 1f else elapsed.toFloat() / goalMs
            var step = 1_000L
            when (show) {
                DetoxShow.ALWAYS -> when {
                    // Saját animáció folyamatosan; percenként 2 mp-re a haladás
                    anim == DetoxAnim.STUDIO && studio != null && studio.frames.isNotEmpty() -> {
                        if ((now - start) % 60_000L < 2_000L) { glyph.show(progressFrame(p)); step = 500L }
                        else {
                            val fr = studio.frames[studioFrame % studio.frames.size]
                            studioFrame++
                            if (fr.zones.isEmpty()) glyph.off() else glyph.show(fr.zones.toIntArray())
                            step = fr.ms.toLong().coerceIn(30L, 2_000L)
                        }
                        lastLit = -1
                    }
                    lit != lastLit -> {
                        glyph.show(if (reachedGoal) order else progressFrame(p))
                        lastLit = lit
                    }
                }
                DetoxShow.PULSE -> if (now - lastPulse >= 60_000L) {
                    lastPulse = now
                    showOnce(p)
                }
                DetoxShow.HIDDEN -> {}
            }
            // Ha a túlórában van: percenként egy szikra a kamerán
            if (reachedGoal && show != DetoxShow.ALWAYS && (now - start) % 60_000L < 1_000L) {
                glyph.show(intArrayOf(Glyph.Code_22111.A1, Glyph.Code_22111.A2))
                delay(300)
                glyph.off()
            }
            delay(step)
        }
        finish()
    }

    private suspend fun celebrate() {
        haptics.win()
        repeat(3) {
            for (i in order.indices) { glyph.show(order.take(i + 1).toIntArray()); delay(12) }
            delay(250)
            glyph.off(); delay(150)
        }
        glyph.show(Zones.ALL); delay(900); glyph.off()
    }

    /** Vége: siker esetén a fény felfelé repül, megszakadáskor összeomlik. */
    private suspend fun finish() {
        val goalMin = Settings.detoxGoal(context)
        val lit = (minutes * order.size / goalMin.coerceAtLeast(1)).coerceIn(1, order.size)
        if (reachedGoal) {
            onStatus("Glyph Focus vége · $minutes perc, a cél megvolt! 🌙")
            haptics.result()
            for (i in order.indices) { glyph.show(intArrayOf(order[i])); delay(25) }
        } else {
            onStatus("Glyph Focus megszakadt · $minutes / $goalMin perc")
            haptics.denied()
            // Összeomlás: a megszerzett fény lehull
            for (k in lit downTo 0) { glyph.show(order.take(k).toIntArray()); delay(35) }
        }
        glyph.off()
        delay(500)
    }
}
