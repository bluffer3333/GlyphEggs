package com.akos.glypheggs

import android.app.Activity
import android.content.Context
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.graphics.Path
import android.graphics.RectF
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.view.Gravity
import android.view.View
import android.view.ViewGroup
import android.view.WindowInsets
import android.widget.FrameLayout
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.TextView

/** A Nothing Glyph Interface beállításainak színvilága. */
object Ui {
    // A színek a téma szerint változnak (alap: Nothing; titkos neon témák: Theme.kt)
    var BG = 0xFF1B1B1B.toInt()
    var CARD = 0xFF2C2C2C.toInt()
    var LINE = 0xFF3A3A3A.toInt()
    var TEXT = 0xFFF1F1F1.toInt()
    var SUB = 0xFFA8A8A8.toInt()
    var LIGHT = 0xFFD9D9D9.toInt()
    var DARK_TEXT = 0xFF111111.toInt()
    var RED = 0xFFD71921.toInt()

    /** Az aktív neon téma (null = alap Nothing-téma). */
    var neon: NeonTheme? = null
        private set
    private var density = 3f
    private var strokeFlip = 0

    /** A mentett téma betöltése (minden oldal elején). */
    fun load(c: Context) {
        density = c.resources.displayMetrics.density
        val t = NeonThemes.current(c)
        neon = t
        if (t == null) {
            BG = 0xFF1B1B1B.toInt(); CARD = 0xFF2C2C2C.toInt(); LINE = 0xFF3A3A3A.toInt()
            TEXT = 0xFFF1F1F1.toInt(); SUB = 0xFFA8A8A8.toInt(); LIGHT = 0xFFD9D9D9.toInt()
            DARK_TEXT = 0xFF111111.toInt(); RED = 0xFFD71921.toInt()
        } else {
            BG = t.bottom; CARD = t.card; LINE = t.line; TEXT = t.text; SUB = t.sub
            LIGHT = t.a; DARK_TEXT = 0xFF0A0A0A.toInt(); RED = t.a
        }
    }

    /** Az oldal háttere: alapból egyszínű, neon témában színátmenet + díszítés. */
    fun pageBg(): android.graphics.drawable.Drawable =
        neon?.let { NeonBackground(it) } ?: GradientDrawable().apply { setColor(BG) }

    /** Neon témában a kártyák szegélye felváltva a két fő szín (szivárványban körbe). */
    internal fun neonStroke(): Int? {
        val t = neon ?: return null
        strokeFlip++
        if (t.zen) return t.line // Zen: halk, egyszínű szegély
        if (t.hypno) return HypnoFx.hsv(strokeFlip * 47f, 1f, 1f) // minden kártya más neonszínű
        val c = if (t.rainbow) RAINBOW[strokeFlip % RAINBOW.size] else if (strokeFlip % 2 == 0) t.a else t.b
        return (c and 0xFFFFFF) or 0xCC000000.toInt()
    }

    internal fun strokePx() = (1.6f * density + 0.5f).toInt()

    val light: Typeface = Typeface.create("sans-serif-light", Typeface.NORMAL)
    val regular: Typeface = Typeface.create("sans-serif", Typeface.NORMAL)
    val medium: Typeface = Typeface.create("sans-serif-medium", Typeface.NORMAL)
}

fun Context.dp(v: Float): Int = (v * resources.displayMetrics.density + 0.5f).toInt()
fun Context.dp(v: Int): Int = dp(v.toFloat())

fun rounded(color: Int, radiusPx: Float, strokeColor: Int = 0, strokePx: Int = 0): GradientDrawable =
    GradientDrawable().apply {
        setColor(color)
        cornerRadius = radiusPx
        if (strokePx > 0) setStroke(strokePx, strokeColor)
        // Neon témában a kártyák neon szegélyt kapnak
        else if (color == Ui.CARD) Ui.neonStroke()?.let { setStroke(Ui.strokePx(), it) }
    }

/** Az edge-to-edge (Android 15) miatt a rendszersávok alá ne csússzon a tartalom. */
fun View.padForSystemBars(extraTop: Int = 0, extraBottom: Int = 0) {
    val baseLeft = paddingLeft
    val baseRight = paddingRight
    val baseTop = paddingTop
    val baseBottom = paddingBottom
    setOnApplyWindowInsetsListener { v, insets ->
        val bars = insets.getInsets(WindowInsets.Type.systemBars())
        v.setPadding(baseLeft + bars.left, baseTop + bars.top + extraTop, baseRight + bars.right, baseBottom + bars.bottom + extraBottom)
        insets
    }
}

fun Activity.darkWindow() {
    Ui.load(this)
    window.decorView.background = Ui.pageBg()
    // C0RRUPTED téma: a felület „sérül” (a tartalom felépülése után kapcsolódik rá)
    if (Ui.neon?.glitch == true) window.decorView.post { GlitchFx.attach(this) }
    // HYPNO RAVE: forgó spirál és ütemre lüktető felület
    if (Ui.neon?.hypno == true) window.decorView.post { HypnoFx.attach(this) }
}

fun Context.text(value: String, sizeSp: Float, color: Int = Ui.TEXT, face: Typeface = Ui.regular): TextView =
    TextView(this).apply {
        text = value
        textSize = sizeSp
        setTextColor(color)
        typeface = face
        includeFontPadding = true
        // Neon témában a nagy címek izzanak
        Ui.neon?.let { t ->
            when {
                // Glitch: éles, eltolt piros „szellemkép” – RGB-csúszás
                t.glitch -> setShadowLayer(0.01f, sizeSp * 0.14f, 0f, 0xCCFF0040.toInt())
                t.zen -> {} // Zen: semmi izzás, csak tiszta betű
                t.hypno -> if (sizeSp >= 15f) setShadowLayer(sizeSp * 0.7f, 0f, 0f, if (sizeSp >= 19f) t.a else t.b)
                sizeSp >= 19f -> setShadowLayer(sizeSp * 0.9f, 0f, 0f, t.a)
            }
        }
    }

fun Context.sectionTitle(value: String): TextView = text(value, 14f, Ui.TEXT, Ui.medium).apply {
    setPadding(dp(7), dp(26), 0, dp(12))
}

fun Context.icon(res: Int, sizeDp: Int = 24): ImageView = ImageView(this).apply {
    setImageResource(res)
    layoutParams = LinearLayout.LayoutParams(dp(sizeDp), dp(sizeDp))
}

/**
 * Kapcsoló a Nothing stílusában: bekapcsolva világos "pirula" sötét gombbal,
 * kikapcsolva szürke körvonal szürke gombbal.
 */
class ToggleView(context: Context) : View(context) {
    var checked = false
        set(value) {
            field = value
            invalidate()
        }
    var onChange: ((Boolean) -> Unit)? = null
    var onColor = if (Ui.neon != null) Ui.LIGHT else 0xFFF4F4F4.toInt()
    var knobColor = Ui.DARK_TEXT

    private val p = Paint(Paint.ANTI_ALIAS_FLAG)
    private val box = RectF()

    init {
        isClickable = true
        setOnClickListener {
            checked = !checked
            onChange?.invoke(checked)
        }
    }

    override fun onMeasure(widthMeasureSpec: Int, heightMeasureSpec: Int) {
        setMeasuredDimension(context.dp(50), context.dp(30))
    }

    override fun onDraw(canvas: Canvas) {
        val w = width.toFloat()
        val h = height.toFloat()
        val rad = h / 2f
        if (checked) {
            p.style = Paint.Style.FILL
            p.color = onColor
            box.set(0f, 0f, w, h)
            canvas.drawRoundRect(box, rad, rad, p)
            p.color = knobColor
            canvas.drawCircle(w - rad, rad, rad - context.dp(3), p)
        } else {
            val sw = context.dp(2).toFloat()
            p.style = Paint.Style.STROKE
            p.strokeWidth = sw
            p.color = 0xFF7A7A7A.toInt()
            box.set(sw / 2, sw / 2, w - sw / 2, h - sw / 2)
            canvas.drawRoundRect(box, rad, rad, p)
            p.style = Paint.Style.FILL
            p.color = 0xFF8A8A8A.toInt()
            canvas.drawCircle(rad, rad, rad - context.dp(7), p)
        }
    }
}

/**
 * Kártya a Nothing rácsában: bal felül ikon, jobb felül opcionális kapcsoló,
 * alul nagy cím és szürke alcím.
 */
class FeatureCard(context: Context, iconRes: Int, title: String, subtitle: String, withToggle: Boolean) :
    FrameLayout(context) {

    val titleView: TextView = context.text(title, 19f, Ui.TEXT, Ui.regular)
    val subtitleView: TextView = context.text(subtitle, 13f, Ui.SUB, Ui.regular)
    val toggle: ToggleView? = if (withToggle) ToggleView(context) else null

    init {
        background = rounded(Ui.CARD, context.dp(22).toFloat())
        val pad = context.dp(16)
        setPadding(pad, context.dp(18), pad, context.dp(16))

        addView(ImageView(context).apply { setImageResource(iconRes) },
            LayoutParams(context.dp(24), context.dp(24), Gravity.TOP or Gravity.START))
        toggle?.let { addView(it, LayoutParams(ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT, Gravity.TOP or Gravity.END)) }

        val bottom = LinearLayout(context).apply {
            orientation = LinearLayout.VERTICAL
            addView(titleView)
            addView(subtitleView.apply { setPadding(0, context.dp(2), 0, 0) })
        }
        addView(bottom, LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT, Gravity.BOTTOM))
    }

    /** Kis "i" (súgó) gomb a kártya jobb felső sarkában (kapcsoló mellett balra). */
    fun addInfo(onClick: () -> Unit): FeatureCard {
        val info = ImageView(context).apply {
            setImageResource(R.drawable.ic_info)
            alpha = 0.75f
            setOnClickListener { onClick() }
        }
        val size = context.dp(22)
        addView(info, LayoutParams(size, size, Gravity.TOP or Gravity.END).apply {
            if (toggle != null) marginEnd = context.dp(62)
        })
        return this
    }
}

/** Két kártya egymás mellett, kis réssel (mint a Nothing rácsában). */
fun Context.row(left: View, right: View?, heightDp: Int): LinearLayout = LinearLayout(this).apply {
    orientation = LinearLayout.HORIZONTAL
    val gap = dp(5)
    addView(left, LinearLayout.LayoutParams(0, dp(heightDp), 1f).apply { marginEnd = gap / 2 })
    if (right != null) {
        addView(right, LinearLayout.LayoutParams(0, dp(heightDp), 1f).apply { marginStart = gap / 2 })
    } else {
        addView(View(this@row), LinearLayout.LayoutParams(0, dp(heightDp), 1f).apply { marginStart = gap / 2 })
    }
    layoutParams = LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT).apply {
        bottomMargin = gap
    }
}

/** Átlátszó, "nincs színe" háttér a kattintható elemekhez. */
fun View.transparentBg() = setBackgroundColor(Color.TRANSPARENT)

/** Kerek jelölő: kiválasztva világos kör pipával, egyébként szürke gyűrű. */
class RadioMark(context: Context, private val selected: Boolean) : View(context) {
    private val p = Paint(Paint.ANTI_ALIAS_FLAG)
    private val check = Path()

    override fun onDraw(canvas: Canvas) {
        val r = minOf(width, height) / 2f
        val cx = width / 2f
        val cy = height / 2f
        if (selected) {
            p.style = Paint.Style.FILL
            p.color = Ui.LIGHT
            canvas.drawCircle(cx, cy, r, p)
            p.style = Paint.Style.STROKE
            p.strokeWidth = r * 0.22f
            p.strokeCap = Paint.Cap.ROUND
            p.strokeJoin = Paint.Join.ROUND
            p.color = Ui.DARK_TEXT
            check.reset()
            check.moveTo(cx - r * 0.42f, cy + r * 0.02f)
            check.lineTo(cx - r * 0.1f, cy + r * 0.32f)
            check.lineTo(cx + r * 0.45f, cy - r * 0.3f)
            canvas.drawPath(check, p)
        } else {
            p.style = Paint.Style.STROKE
            p.strokeWidth = r * 0.14f
            p.color = 0xFF6E6E6E.toInt()
            canvas.drawCircle(cx, cy, r - p.strokeWidth / 2f, p)
        }
    }
}
