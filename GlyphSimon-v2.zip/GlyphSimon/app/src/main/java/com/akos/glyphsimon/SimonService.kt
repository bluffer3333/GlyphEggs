package com.akos.glyphsimon

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.Service
import android.content.Intent
import android.content.pm.ServiceInfo
import android.graphics.drawable.Icon
import android.os.IBinder
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.cancel
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch
import kotlinx.coroutines.withTimeoutOrNull

/**
 * Előtérszolgáltatás: a háttérben fut (állandó értesítéssel), figyeli a pörgetést,
 * és elindítja a játékot.
 */
class SimonService : Service() {

    companion object {
        const val ACTION_START_GAME = "com.akos.glyphsimon.START_GAME"
        const val ACTION_STOP = "com.akos.glyphsimon.STOP"
        private const val CHANNEL_ID = "glyph_simon"
        private const val NOTIF_ID = 1
        private const val IDLE_TEXT = "Kijelzővel lefelé forgasd 4x jobbra"
    }

    private val scope = CoroutineScope(SupervisorJob() + Dispatchers.Default)
    private lateinit var glyph: GlyphController
    private lateinit var motion: MotionDetector
    private lateinit var haptics: Haptics
    private var gameJob: Job? = null

    override fun onCreate() {
        super.onCreate()
        createChannel()
        startForeground(NOTIF_ID, buildNotification(IDLE_TEXT), ServiceInfo.FOREGROUND_SERVICE_TYPE_SPECIAL_USE)

        haptics = Haptics(this)
        glyph = GlyphController(this).also { it.init() }
        motion = MotionDetector(this) {
            haptics.tick()
            startGame()
        }.also { it.start() }

        DebugState.status.value = "Fut – $IDLE_TEXT"
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        when (intent?.action) {
            ACTION_START_GAME -> startGame()
            ACTION_STOP -> {
                stopSelf()
                return START_NOT_STICKY
            }
        }
        return START_STICKY
    }

    private fun startGame() {
        if (gameJob?.isActive == true) return
        gameJob = scope.launch {
            // Közvetlenül indulás után a Glyph szolgáltatásnak kell egy kis idő
            withTimeoutOrNull(3_000) { while (!glyph.connected) delay(100) }
            if (!glyph.openSession()) {
                DebugState.log("Nem sikerült megnyitni a Glyph sessiont")
                return@launch
            }
            motion.setGameMode(true)
            DebugState.status.value = "Játék folyamatban"
            updateNotification("Játék folyamatban")
            try {
                val level = SimonGame(glyph, motion, haptics).run()
                DebugState.log("Játék vége – elért szint: $level/${Config.MAX_ROUNDS}")
            } finally {
                glyph.closeSession()
                motion.setGameMode(false)
                DebugState.status.value = "Fut – $IDLE_TEXT"
                updateNotification(IDLE_TEXT)
            }
        }
    }

    override fun onDestroy() {
        scope.cancel()
        motion.stop()
        glyph.release()
        DebugState.status.value = "Leállítva"
        DebugState.log("Szolgáltatás leállt")
        super.onDestroy()
    }

    override fun onBind(intent: Intent?): IBinder? = null

    private fun createChannel() {
        val channel = NotificationChannel(CHANNEL_ID, "Glyph Simon", NotificationManager.IMPORTANCE_LOW)
        getSystemService(NotificationManager::class.java).createNotificationChannel(channel)
    }

    private fun buildNotification(text: String): Notification {
        val open = PendingIntent.getActivity(
            this, 0, Intent(this, MainActivity::class.java),
            PendingIntent.FLAG_IMMUTABLE
        )
        val stop = PendingIntent.getService(
            this, 1, Intent(this, SimonService::class.java).setAction(ACTION_STOP),
            PendingIntent.FLAG_IMMUTABLE
        )
        return Notification.Builder(this, CHANNEL_ID)
            .setSmallIcon(android.R.drawable.ic_menu_compass)
            .setContentTitle("Glyph Simon")
            .setContentText(text)
            .setOngoing(true)
            .setContentIntent(open)
            .addAction(Notification.Action.Builder(null as Icon?, "Leállítás", stop).build())
            .build()
    }

    private fun updateNotification(text: String) {
        getSystemService(NotificationManager::class.java).notify(NOTIF_ID, buildNotification(text))
    }
}
