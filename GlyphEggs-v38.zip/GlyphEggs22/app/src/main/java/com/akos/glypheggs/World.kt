package com.akos.glypheggs

import android.app.Activity
import android.content.Context
import android.content.Intent
import android.graphics.Canvas
import android.graphics.LinearGradient
import android.graphics.Paint
import android.graphics.Path
import android.graphics.RadialGradient
import android.graphics.RectF
import android.graphics.Shader
import android.os.Bundle
import android.os.SystemClock
import android.view.GestureDetector
import android.view.MotionEvent
import android.view.View
import android.widget.OverScroller
import android.widget.FrameLayout
import android.widget.LinearLayout
import android.view.ViewGroup.LayoutParams.MATCH_PARENT
import android.view.ViewGroup.LayoutParams.WRAP_CONTENT
import kotlin.math.abs
import kotlin.math.cos
import kotlin.math.hypot
import kotlin.math.sin
import kotlin.random.Random

/*
 * KIS VILÁG – egy élő, függőlegesen görgethető kis univerzum, a föld mélyétől a mennyországig.
 *  - FENT: csillagok, a menny kapuja, felhőkön ülő angyalok (hárfa, glória, csapkodó szárnyak)
 *  - ÉG: bárányfelhők (koppintásra esik belőlük az eső), madárcsapat, hőlégballon, sárkány
 *  - FELSZÍN: hegy, amire kis emberek másznak fel (a csúcson ünnepelnek), rét, fák, kunyhó füstölgő kéménnyel,
 *    tábortűz körülülő emberekkel, egy gazdi, aki eldobja a labdát, és a kutya, aki visszahozza, tó halakkal
 *  - LENT: gyökerek, giliszták, vakond, hangyák, bánya csillével és lámpás bányásszal, világító kristályok…
 *  - …és a legmélyén, egy barlangban ALSZIK VALAMI. Ne ébreszd fel. (Ha mégis: megeszi az app ikonjait.)
 * Minden koppintható: integetnek, ugatnak, szívecskék, hangjegyek, szikrák.
 */
class WorldActivity : Activity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        window.decorView.setBackgroundColor(0xFF120A1E.toInt())
        val v = WorldView(this)
        v.onBack = { finish() }
        v.onMonsterAwake = {
            MonsterRampage.arm()
            startActivity(Intent(this, MainActivity::class.java).addFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP or Intent.FLAG_ACTIVITY_SINGLE_TOP))
            finish()
        }
        setContentView(v)
    }

    override fun onResume() { super.onResume(); GlyphMirror.appVisible = true }
    override fun onPause() { super.onPause(); GlyphMirror.appVisible = false }
}

class WorldView(context: Context, private val preview: Boolean = false) : View(context) {

    var onBack: (() -> Unit)? = null
    var onMonsterAwake: (() -> Unit)? = null

    private val p = Paint(Paint.ANTI_ALIAS_FLAG)
    private val tp = Paint(Paint.ANTI_ALIAS_FLAG).apply { textAlign = Paint.Align.CENTER }
    private val path = Path()
    private val rect = RectF()
    private val rnd = Random(42)

    // méretek
    private var W = 1f
    private var H = 1f
    private var WH = 1f          // a világ teljes magassága
    private var u = 1f           // 1 egység = a szélesség 1%-a
    private var ground = 1f      // a felszín y-ja
    private var scrollY = 0f
    private var bgShader: Shader? = null

    private val scroller = OverScroller(context)
    private var t = 0f           // idő (mp)
    private var lastFrame = 0L
    private val start = SystemClock.elapsedRealtime()

    // ---- állapotok
    private class Bubble(val x: Float, val y: Float, val text: String, val t0: Float, val col: Int)
    private class Part(var x: Float, var y: Float, var vx: Float, var vy: Float, val t0: Float, val life: Float, val kind: Int, val col: Int, val g: Float)
    private val bubbles = ArrayList<Bubble>()
    private val parts = ArrayList<Part>()
    private val K_HEART = 0; private val K_NOTE = 1; private val K_SPARK = 2; private val K_DROP = 3; private val K_DOT = 4; private val K_STAR = 5

    private class Cloud(var x: Float, val y: Float, val s: Float, val speed: Float, var rainUntil: Float = 0f)
    private val clouds = ArrayList<Cloud>()
    private class Angel(val x: Float, val y: Float, val col: Int, val harp: Boolean, var loopAt: Float = -99f)
    private val angels = ArrayList<Angel>()
    private class Climber(var s: Float, val speed: Float, val col: Int, var cheerUntil: Float = 0f, var waveUntil: Float = 0f)
    private val climbers = ArrayList<Climber>()
    private val trail = ArrayList<FloatArray>()  // a hegyi ösvény pontjai
    private var trailLen = 0f
    private class Fish(val a: Float, val b: Float, var ph: Float, val speed: Float, val col: Int, var jumpAt: Float = -99f)
    private val fish = ArrayList<Fish>()
    private var pondX = 0f; private var pondY = 0f; private var pondRx = 0f; private var pondRy = 0f
    private var feedX = 0f; private var feedUntil = 0f

    // kutya + labda
    private var ownerX = 0f
    private var dogX = 0f; private var dogDir = 1f; private var dogState = 0 // 0 vár, 1 fut a labdáért, 2 hozza, 3 ugrik
    private var ballX = 0f; private var ballY = 0f; private var ballVx = 0f; private var ballVy = 0f; private var ballFlying = false
    private var ballHeld = true // a gazdinál
    private var nextThrow = 2f
    private var dogBarkUntil = 0f; private var dogJumpAt = -99f

    private var balloonX = 0f; private var balloonBoostAt = -99f
    private var birdsX = 0f; private var birdsScatterAt = -99f
    private var cabinLight = true
    private var fireBoostAt = -99f
    private var moleX = 0f; private var molePeekAt = -99f
    private var cartX = 0f; private var cartDir = 1f
    private var crystalPingAt = FloatArray(5) { -99f }
    private var planeX = -30f; private var planeLoopAt = -99f
    private var rabbitHideUntil = 0f
    private var chestOpenAt = -99f
    private var fossilAt = -99f
    private var butterflyLoveAt = FloatArray(4) { -99f }

    // a szörny
    private var anger = 0
    private var lastPoke = -99f
    private var awakeAt = -99f
    private var panic = false
    private var shake = 0f

    private val gd = GestureDetector(context, object : GestureDetector.SimpleOnGestureListener() {
        override fun onDown(e: MotionEvent): Boolean { scroller.forceFinished(true); return true }
        override fun onScroll(e1: MotionEvent?, e2: MotionEvent, dx: Float, dy: Float): Boolean {
            scrollY = (scrollY + dy).coerceIn(0f, WH - H); invalidate(); return true
        }
        override fun onFling(e1: MotionEvent?, e2: MotionEvent, vx: Float, vy: Float): Boolean {
            scroller.fling(0, scrollY.toInt(), 0, -vy.toInt(), 0, 0, 0, (WH - H).toInt()); invalidate(); return true
        }
        override fun onSingleTapUp(e: MotionEvent): Boolean { tap(e.x, e.y); return true }
    })

    override fun onTouchEvent(event: MotionEvent): Boolean = if (preview) false else gd.onTouchEvent(event)

    override fun onSizeChanged(w: Int, h: Int, ow: Int, oh: Int) {
        W = w.toFloat(); H = h.toFloat()
        u = W / 100f
        WH = if (preview) H * 4f else H * 3.4f
        ground = Y(0.62f)
        scrollY = if (preview) ground - H * 0.78f else ground - H * 0.66f
        build()
    }

    private fun build() {
        rnd.nextInt()
        bgShader = LinearGradient(0f, 0f, 0f, WH,
            intArrayOf(0xFF0B0820.toInt(), 0xFF2A1B4E.toInt(), 0xFFFFD9A0.toInt(), 0xFF8EC5F0.toInt(), 0xFFB9DDF5.toInt(),
                0xFFFFB38A.toInt(), 0xFF6B4528.toInt(), 0xFF3E2716.toInt(), 0xFF22140B.toInt(), 0xFF3A0E06.toInt()),
            floatArrayOf(0f, 0.06f, 0.14f, 0.24f, 0.4f, 0.6f, 0.62f, 0.75f, 0.92f, 1f).map { Y(it) / WH }.toFloatArray(), Shader.TileMode.CLAMP)
        clouds.clear()
        // menny-felhők (ezeken ülnek az angyalok) és ég-felhők
        val heaven = listOf(18f to 0.13f, 52f to 0.16f, 84f to 0.12f)
        for ((x, y) in heaven) clouds += Cloud(x * u, Y(y), 1.3f, 0f)
        for (i in 0 until 7) clouds += Cloud(rnd.nextFloat() * W, Y(0.22f + 0.3f * i / 7f), 0.7f + rnd.nextFloat() * 0.6f, (0.6f + rnd.nextFloat()) * u * (if (i % 2 == 0) 1f else -1f))
        angels.clear()
        angels += Angel(18f * u, Y(0.13f), 0xFFFFF4E0.toInt(), true)
        angels += Angel(52f * u, Y(0.16f), 0xFFF0F6FF.toInt(), false)
        angels += Angel(84f * u, Y(0.12f), 0xFFFFEEF4.toInt(), true)
        // hegyi ösvény (cikcakk a csúcsig)
        trail.clear()
        val peakX = 30f * u; val peakY = Y(0.4700f)
        val baseL = -6f * u; val baseR = 70f * u
        val zig = 6
        for (i in 0..zig) {
            val f = i / zig.toFloat()
            val y = ground - (ground - peakY) * f * 0.97f
            val halfW = (1f - f) * (baseR - baseL) / 2f * 0.62f
            val x = peakX + (if (i % 2 == 0) -1 else 1) * halfW * 0.8f
            trail += floatArrayOf(if (i == zig) peakX else x, y)
        }
        trailLen = 0f
        for (i in 1 until trail.size) trailLen += hypot(trail[i][0] - trail[i - 1][0], trail[i][1] - trail[i - 1][1])
        climbers.clear()
        val cols = intArrayOf(0xFFE84A5F.toInt(), 0xFF2A9D8F.toInt(), 0xFFF4A261.toInt(), 0xFF6A4C93.toInt(), 0xFF3A86FF.toInt())
        for (i in 0 until 5) climbers += Climber(i / 5f, 0.012f + rnd.nextFloat() * 0.01f, cols[i])
        // tó
        pondX = 78f * u; pondY = ground + 3.5f * u; pondRx = 17f * u; pondRy = 4.2f * u
        fish.clear()
        val fc = intArrayOf(0xFFFF7A2F.toInt(), 0xFFFFB84D.toInt(), 0xFFFF4D3A.toInt(), 0xFFFFFFFF.toInt())
        for (i in 0 until 4) fish += Fish(0.6f + 0.35f * rnd.nextFloat(), 0.4f + 0.4f * rnd.nextFloat(), rnd.nextFloat() * 6.28f, 0.5f + rnd.nextFloat() * 0.6f, fc[i])
        ownerX = 46f * u; dogX = 50f * u; ballX = ownerX; ballY = ground - 6f * u
        balloonX = 70f * u; birdsX = -20f * u; moleX = 20f * u; cartX = 20f * u; planeX = -30f * u
    }

    private fun fill(col: Int) { p.shader = null; p.style = Paint.Style.FILL; p.color = col }
    private fun stroke(col: Int, w: Float) { p.shader = null; p.style = Paint.Style.STROKE; p.color = col; p.strokeWidth = w; p.strokeCap = Paint.Cap.ROUND }

    // ------------------------------------------------------------------ rajz

    override fun onDraw(c: Canvas) {
        val now = SystemClock.elapsedRealtime()
        val dt = if (lastFrame == 0L) 0.016f else ((now - lastFrame) / 1000f).coerceIn(0f, 0.05f)
        lastFrame = now
        t = (now - start) / 1000f
        if (scroller.computeScrollOffset()) scrollY = scroller.currY.toFloat().coerceIn(0f, WH - H)
        if (preview) scrollY = ground - H * 0.78f + sin(t * 0.25f) * H * 0.05f
        update(dt)

        c.save()
        val sx = if (shake > 0f) (Random.nextFloat() - 0.5f) * shake else 0f
        val sy2 = if (shake > 0f) (Random.nextFloat() - 0.5f) * shake else 0f
        c.translate(sx, -scrollY + sy2)
        val top = scrollY - 40f * u; val bot = scrollY + H + 40f * u
        p.shader = bgShader; p.style = Paint.Style.FILL
        c.drawRect(0f, scrollY - 10f, W, scrollY + H + 10f, p)
        p.shader = null

        if (vis(0f, Y(0.22f), top, bot)) drawHeaven(c)
        if (vis(Y(0.18f), ground, top, bot)) drawSky(c)
        if (vis(Y(0.4500f), ground + 12f * u, top, bot)) drawSurface(c)
        if (vis(ground, WH, top, bot)) drawUnderground(c)
        drawParts(c, dt)
        drawBubbles(c)
        c.restore()

        if (!preview) drawHud(c)
        // az előnézet (Főoldal) kíméletesebb: ~20 kép/mp
        if (preview) postInvalidateDelayed(50) else postInvalidateOnAnimation()
    }

    private fun vis(a: Float, b: Float, top: Float, bot: Float) = b >= top && a <= bot

    /**
     * A világ magasság-térképe: a „régi” arányból (0 = a menny teteje, 0,62 = felszín, 1 = a mélység alja)
     * a tényleges y. A menny és az ég sűrítve, hogy minden képernyőn történjen valami.
     */
    private fun Y(f: Float): Float {
        val hu = WH / 3.4f
        return when {
            f <= 0.2f -> f / 0.2f * 0.85f * hu
            f <= 0.62f -> (0.85f + (f - 0.2f) / 0.42f * 1.2f) * hu
            else -> (2.05f + (f - 0.62f) / 0.38f * 1.35f) * hu
        }
    }

    // ---- FENT: csillagok, menny, angyalok
    private fun drawHeaven(c: Canvas) {
        val r = Random(7)
        for (i in 0 until 90) {
            val x = r.nextFloat() * W; val y = r.nextFloat() * Y(0.1f)
            val a = (0.4f + 0.6f * (0.5f + 0.5f * sin(t * (1f + r.nextFloat() * 2f) + i))).coerceIn(0f, 1f)
            fill(((a * 255).toInt() shl 24) or 0xFFFFFF)
            c.drawCircle(x, y, u * (0.15f + r.nextFloat() * 0.25f), p)
        }
        // hullócsillag (6 mp-enként)
        val sp = (t % 6f) / 1.1f
        if (sp < 1f) {
            val sx = W * (0.9f - sp * 0.8f); val sy = Y(0.01f) + sp * Y(0.06f)
            stroke(0xCCFFFFFF.toInt(), 0.35f * u); c.drawLine(sx, sy, sx + 9f * u, sy - 4f * u, p)
            fill(0xFFFFFFFF.toInt()); c.drawCircle(sx, sy, 0.6f * u, p)
        }
        // hold
        fill(0xFFFFF3C4.toInt()); c.drawCircle(80f * u, Y(0.035f), 5f * u, p)
        fill(0xFF0B0820.toInt()); c.drawCircle(82.5f * u, Y(0.03f), 4.6f * u, p)
        // a menny kapuja – aranyló derengés
        val gx = 50f * u; val gy = Y(0.09f)
        p.shader = RadialGradient(gx, gy, 40f * u, intArrayOf(0x90FFE7A0.toInt(), 0x00FFE7A0), null, Shader.TileMode.CLAMP)
        c.drawCircle(gx, gy, 40f * u, p); p.shader = null
        stroke(0xFFFFD36B.toInt(), 0.9f * u)
        for (k in -3..3) c.drawLine(gx + k * 3f * u, gy - 7f * u + abs(k) * 0.8f * u, gx + k * 3f * u, gy + 8f * u, p)
        rect.set(gx - 11f * u, gy - 16f * u, gx + 11f * u, gy + 2f * u)
        c.drawArc(rect, 180f, 180f, false, p)
        c.drawLine(gx - 11f * u, gy - 7f * u, gx - 11f * u, gy + 8f * u, p)
        c.drawLine(gx + 11f * u, gy - 7f * u, gx + 11f * u, gy + 8f * u, p)
        fill(0xFFFFF6D8.toInt()); c.drawCircle(gx, gy - 12f * u, 1.2f * u, p)
        // felhők + angyalok
        for (cl in clouds) if (cl.y < Y(0.2f)) drawCloud(c, cl.x, cl.y, cl.s, 0xFFFFFFFF.toInt())
        for (a in angels) drawAngel(c, a)
    }

    private fun drawAngel(c: Canvas, a: Angel) {
        val loop = t - a.loopAt
        var x = a.x; var y = a.y - 6f * u + sin(t * 1.3f + a.x) * 0.8f * u
        var rot = 0f
        if (loop in 0f..2f) {
            val f = loop / 2f
            x += sin(f * 6.283f) * 10f * u
            y -= (1f - cos(f * 6.283f)) * 9f * u
            rot = f * 360f
        }
        c.save(); c.rotate(rot, x, y); c.scale(1.5f, 1.5f, x, y)
        // szárnyak
        val flap = sin(t * 6f + a.x) * 18f
        fill(0xF0FFFFFF.toInt())
        for (side in listOf(-1f, 1f)) {
            c.save(); c.rotate(side * (25f + flap), x, y - 2f * u)
            rect.set(x + side * 0.5f * u - (if (side < 0) 5f * u else 0f), y - 4.5f * u, x + side * 0.5f * u + (if (side > 0) 5f * u else 0f), y - 0.5f * u)
            c.drawOval(rect, p); c.restore()
        }
        // ruha
        fill(a.col)
        path.reset(); path.moveTo(x - 1.2f * u, y - 3f * u); path.lineTo(x + 1.2f * u, y - 3f * u)
        path.lineTo(x + 2.6f * u, y + 2.5f * u); path.lineTo(x - 2.6f * u, y + 2.5f * u); path.close(); c.drawPath(path, p)
        fill(0xFFF5D0B0.toInt()); c.drawCircle(x, y - 4.3f * u, 1.4f * u, p)
        fill(0xFFFFE08A.toInt()); c.drawCircle(x, y - 5.2f * u, 1.3f * u, p) // haj
        fill(0xFFF5D0B0.toInt()); c.drawCircle(x, y - 4.1f * u, 1.15f * u, p)
        // glória
        stroke(0xFFFFD34D.toInt(), 0.35f * u)
        rect.set(x - 1.6f * u, y - 7.3f * u, x + 1.6f * u, y - 6.4f * u); c.drawOval(rect, p)
        // hárfa
        if (a.harp) {
            stroke(0xFFFFC23D.toInt(), 0.3f * u)
            path.reset(); path.moveTo(x + 1.4f * u, y + 1.5f * u); path.quadTo(x + 4f * u, y - 1f * u, x + 2f * u, y - 3f * u)
            path.lineTo(x + 1.4f * u, y + 1.5f * u); c.drawPath(path, p)
            if (((t * 2f + a.x).toInt() % 3) == 0 && Random.nextFloat() < 0.04f) note(x + 3f * u, y - 3f * u)
        }
        c.restore()
    }

    // ---- ÉG: felhők, madarak, ballon, sárkány
    private fun drawSky(c: Canvas) {
        // lemenő nap a hegyek mögött
        val sunY = Y(0.5600f)
        p.shader = RadialGradient(62f * u, sunY, 45f * u, intArrayOf(0xB0FFE08A.toInt(), 0x30FF9A5A, 0x00FF9A5A), floatArrayOf(0f, 0.4f, 1f), Shader.TileMode.CLAMP)
        c.drawCircle(62f * u, sunY, 45f * u, p); p.shader = null
        fill(0xFFFFE6A0.toInt()); c.drawCircle(62f * u, sunY, 9f * u, p)
        // halvány szivárvány a hegyek fölött
        for (k in 0 until 6) {
            stroke((0x38 shl 24) or (intArrayOf(0xFF4D4D, 0xFFA64D, 0xFFE24D, 0x6BE07A, 0x4DA6FF, 0xA77BFF)[k]), 1.3f * u)
            val rr = (52f - k * 1.3f) * u
            rect.set(78f * u - rr, Y(0.56f) - rr, 78f * u + rr, Y(0.56f) + rr); c.drawArc(rect, 200f, 140f, false, p)
        }
        drawPlane(c, planeX, Y(0.28f) + sin(t * 0.8f) * 2f * u)
        drawGlider(c)
        for (cl in clouds) if (cl.y >= Y(0.2f)) {
            drawCloud(c, cl.x, cl.y, cl.s, if (cl.rainUntil > t) 0xFFB8C2D6.toInt() else 0xFFFFFFFF.toInt())
        }
        // madárcsapat
        val by = Y(0.4f) + sin(t * 0.4f) * 3f * u
        val scatter = t - birdsScatterAt
        for (i in 0 until 7) {
            val row = i / 2; val side = if (i % 2 == 0) -1 else 1
            var bx = birdsX - row * 4f * u
            var byy = by + row * 2.2f * u * side + (if (i == 0) 0f else 0f)
            if (scatter in 0f..3f) { bx += side * scatter * 12f * u * (row + 1) * 0.4f; byy -= scatter * 8f * u * (1 + i % 3) * 0.4f }
            drawBird(c, bx, byy, i)
        }
        // hőlégballon
        val boost = t - balloonBoostAt
        val bly = Y(0.33f) + sin(t * 0.7f) * 2f * u - (if (boost in 0f..4f) sin(boost / 4f * 3.14f) * 14f * u else 0f)
        drawBalloon(c, balloonX, bly, boost in 0f..4f)
        // sárkány a gyereknél (a rét bal oldalán)
        val kidX = 12f * u; val kidY = ground - 0.5f * u
        val kx = 22f * u + sin(t * 0.9f) * 6f * u; val ky = Y(0.5200f) + sin(t * 1.3f) * 4f * u
        stroke(0x99FFFFFF.toInt(), 0.12f * u)
        path.reset(); path.moveTo(kidX + 1f * u, kidY - 4f * u); path.quadTo((kidX + kx) / 2, ky + 14f * u, kx, ky + 3f * u); c.drawPath(path, p)
        c.save(); c.rotate(sin(t * 1.7f) * 12f, kx, ky)
        fill(0xFFFF4D6D.toInt())
        path.reset(); path.moveTo(kx, ky - 3.5f * u); path.lineTo(kx + 2.4f * u, ky); path.lineTo(kx, ky + 3f * u); path.lineTo(kx - 2.4f * u, ky); path.close(); c.drawPath(path, p)
        fill(0xFFFFD166.toInt())
        path.reset(); path.moveTo(kx, ky - 3.5f * u); path.lineTo(kx + 2.4f * u, ky); path.lineTo(kx, ky); path.close(); c.drawPath(path, p)
        stroke(0xFFFF4D6D.toInt(), 0.2f * u)
        path.reset(); path.moveTo(kx, ky + 3f * u)
        for (k in 1..4) path.lineTo(kx + sin(t * 4f + k) * 1.2f * u, ky + 3f * u + k * 1.6f * u)
        c.drawPath(path, p)
        c.restore()
    }

    private fun drawPlane(c: Canvas, x0: Float, y0: Float) {
        var x = x0; var y = y0; var rot = 0f
        val lp = t - planeLoopAt
        if (lp in 0f..2.2f) { val f = lp / 2.2f; y -= (1f - cos(f * 6.283f)) * 10f * u; x += sin(f * 6.283f) * 8f * u; rot = -f * 360f }
        // transzparens a farok mögött
        val bx = x - 34f * u
        stroke(0x99FFFFFF.toInt(), 0.15f * u); c.drawLine(x - 7f * u, y, bx + 22f * u, y, p)
        fill(0xFFFFF3D6.toInt())
        path.reset(); path.moveTo(bx, y - 2.6f * u)
        for (k in 0..11) path.lineTo(bx + k * 2f * u, y - 2.6f * u + sin(t * 6f + k * 0.7f) * 0.6f * u)
        path.lineTo(bx + 22f * u, y + 2.6f * u)
        for (k in 11 downTo 0) path.lineTo(bx + k * 2f * u, y + 2.6f * u + sin(t * 6f + k * 0.7f) * 0.6f * u)
        path.close(); c.drawPath(path, p)
        tp.textSize = 3f * u; tp.color = 0xFFD71921.toInt(); tp.isFakeBoldText = true
        c.drawText("GLYPH EGGS ♥", bx + 11f * u, y + 1f * u + sin(t * 6f + 4f) * 0.6f * u, tp); tp.isFakeBoldText = false
        c.save(); c.rotate(rot, x, y)
        fill(0xFFF4F4F4.toInt()); rect.set(x - 7f * u, y - 1.6f * u, x + 6f * u, y + 1.6f * u); c.drawOval(rect, p)
        fill(0xFFD71921.toInt()); rect.set(x - 3f * u, y - 0.4f * u, x + 3f * u, y + 0.6f * u); c.drawRect(rect, p)
        path.reset(); path.moveTo(x - 6.5f * u, y); path.lineTo(x - 8.5f * u, y - 3.5f * u); path.lineTo(x - 5f * u, y - 0.8f * u); path.close(); c.drawPath(path, p)
        fill(0xFF8EC5F0.toInt()); c.drawCircle(x + 3.5f * u, y - 0.5f * u, 0.7f * u, p)
        stroke(0x99333333.toInt(), 0.3f * u); c.drawLine(x + 6.3f * u, y - 2f * u * abs(sin(t * 40f)), x + 6.3f * u, y + 2f * u * abs(sin(t * 40f)), p)
        c.restore()
    }

    private fun drawGlider(c: Canvas) {
        val gx = 72f * u + cos(t * 0.35f) * 18f * u
        val gy = Y(0.47f) + sin(t * 0.7f) * 4f * u
        val tilt = -sin(t * 0.35f) * 12f
        c.save(); c.rotate(tilt, gx, gy)
        fill(0xFFFF6B35.toInt()); rect.set(gx - 7f * u, gy - 10f * u, gx + 7f * u, gy - 4f * u); c.drawArc(rect, 180f, 180f, true, p)
        fill(0xFFFFD166.toInt()); rect.set(gx - 2.4f * u, gy - 10f * u, gx + 2.4f * u, gy - 4f * u); c.drawArc(rect, 180f, 180f, true, p)
        stroke(0x88FFFFFF.toInt(), 0.12f * u)
        c.drawLine(gx - 6.5f * u, gy - 7f * u, gx, gy, p); c.drawLine(gx + 6.5f * u, gy - 7f * u, gx, gy, p)
        c.restore()
        drawPerson(c, gx, gy + 3.2f * u, 3.2f * u, 0xFF06D6A0.toInt(), t * 2f, 0, false)
    }

    private fun drawCloud(c: Canvas, x: Float, y: Float, s: Float, col: Int) {
        fill((col and 0xFFFFFF) or 0x30000000)
        c.drawCircle(x + 1f * u * s, y + 1.5f * u * s, 6f * u * s, p)
        fill((col and 0xFFFFFF) or 0xF0000000.toInt())
        c.drawCircle(x - 6f * u * s, y, 4.5f * u * s, p)
        c.drawCircle(x, y - 2.5f * u * s, 6f * u * s, p)
        c.drawCircle(x + 6.5f * u * s, y - 0.5f * u * s, 4.8f * u * s, p)
        rect.set(x - 10f * u * s, y - 1f * u * s, x + 11f * u * s, y + 4f * u * s)
        c.drawRoundRect(rect, 3f * u * s, 3f * u * s, p)
    }

    private fun drawBird(c: Canvas, x: Float, y: Float, i: Int) {
        c.save(); c.scale(1.5f, 1.5f, x, y)
        val f = sin(t * 9f + i) * 1.2f * u
        stroke(0xFF2A2340.toInt(), 0.35f * u)
        path.reset(); path.moveTo(x - 2f * u, y - f); path.quadTo(x - 1f * u, y - 0.6f * u, x, y)
        path.quadTo(x + 1f * u, y - 0.6f * u, x + 2f * u, y - f); c.drawPath(path, p)
        c.restore()
    }

    private fun drawBalloon(c: Canvas, x: Float, y: Float, burner: Boolean) {
        val r = 7f * u
        val cols = intArrayOf(0xFFE63946.toInt(), 0xFFFFD166.toInt(), 0xFF06D6A0.toInt(), 0xFF118AB2.toInt())
        // ballon: csíkos (egymásra tett, egyre keskenyebb oválisok)
        for (k in 0 until 4) {
            fill(cols[k])
            val ww = r * (1f - k * 0.24f)
            rect.set(x - ww, y - r, x + ww, y + r * 0.9f); c.drawOval(rect, p)
        }
        fill(cols[0])
        path.reset(); path.moveTo(x - r * 0.75f, y + r * 0.5f); path.lineTo(x + r * 0.75f, y + r * 0.5f); path.lineTo(x + r * 0.25f, y + r * 1.3f); path.lineTo(x - r * 0.25f, y + r * 1.3f); path.close()
        c.drawPath(path, p)
        stroke(0xFF5A4030.toInt(), 0.15f * u)
        c.drawLine(x - r * 0.25f, y + r * 1.3f, x - r * 0.25f, y + r * 1.75f, p); c.drawLine(x + r * 0.25f, y + r * 1.3f, x + r * 0.25f, y + r * 1.75f, p)
        fill(0xFF8B5A2B.toInt()); rect.set(x - r * 0.3f, y + r * 1.72f, x + r * 0.3f, y + r * 2.1f); c.drawRect(rect, p)
        if (burner) { fill(0xFFFFA62B.toInt()); c.drawCircle(x, y + r * 1.4f + sin(t * 30f) * 0.3f * u, 0.9f * u, p) }
        // két kis utas
        fill(0xFFF2C9A0.toInt()); c.drawCircle(x - r * 0.12f, y + r * 1.62f, 0.6f * u, p); c.drawCircle(x + r * 0.14f, y + r * 1.62f, 0.6f * u, p)
    }

    // ---- FELSZÍN
    private fun drawSurface(c: Canvas) {
        // távoli hegyek
        fill(0xFF6C5B9B.toInt())
        path.reset(); path.moveTo(0f, ground)
        path.lineTo(-5f * u, Y(0.5400f)); path.lineTo(15f * u, Y(0.5100f)); path.lineTo(40f * u, Y(0.5500f))
        path.lineTo(62f * u, Y(0.5000f)); path.lineTo(85f * u, Y(0.5400f)); path.lineTo(105f * u, Y(0.5200f)); path.lineTo(W, ground); path.close()
        c.drawPath(path, p)
        // a nagy hegy
        val peakX = 30f * u; val peakY = Y(0.4700f)
        fill(0xFF3D5A80.toInt())
        path.reset(); path.moveTo(-6f * u, ground); path.lineTo(peakX, peakY); path.lineTo(70f * u, ground); path.close(); c.drawPath(path, p)
        fill(0xFF2B4162.toInt())
        path.reset(); path.moveTo(peakX, peakY); path.lineTo(70f * u, ground); path.lineTo(40f * u, ground); path.close(); c.drawPath(path, p)
        // hósapka
        fill(0xFFF5F7FF.toInt())
        path.reset(); path.moveTo(peakX, peakY); path.lineTo(peakX + 7.6f * u, Y(0.4950f)); path.lineTo(peakX + 4f * u, Y(0.4920f))
        path.lineTo(peakX + 1f * u, Y(0.5000f)); path.lineTo(peakX - 2.5f * u, Y(0.4920f)); path.lineTo(peakX - 7f * u, Y(0.4970f)); path.close()
        c.drawPath(path, p)
        // ösvény
        stroke(0x55FFFFFF, 0.25f * u)
        path.reset(); path.moveTo(trail[0][0], trail[0][1]); for (i in 1 until trail.size) path.lineTo(trail[i][0], trail[i][1]); c.drawPath(path, p)
        // zászló a csúcson
        stroke(0xFF3A2A1A.toInt(), 0.25f * u); c.drawLine(peakX, peakY, peakX, peakY - 5f * u, p)
        fill(0xFFE63946.toInt())
        path.reset(); path.moveTo(peakX, peakY - 5f * u); path.lineTo(peakX + 3.2f * u + sin(t * 5f) * 0.4f * u, peakY - 4.2f * u); path.lineTo(peakX, peakY - 3.4f * u); path.close(); c.drawPath(path, p)
        // hegymászók
        for (cl in climbers) {
            val (x, y) = trailPos(cl.s)
            val pose = when { panic -> 4; cl.cheerUntil > t -> 2; cl.waveUntil > t -> 1; else -> 0 }
            drawPerson(c, x, y, 4.6f * u, cl.col, t * 6f + cl.speed * 300f, pose, true)
        }
        // rét
        fill(0xFF5FAD56.toInt()); c.drawRect(0f, ground - 0.5f * u, W, ground + 12f * u, p)
        fill(0xFF4C9A45.toInt())
        path.reset(); path.moveTo(0f, ground)
        var gx = 0f
        while (gx <= W) { path.quadTo(gx + 2f * u, ground - 1.6f * u, gx + 4f * u, ground); gx += 4f * u }
        path.lineTo(W, ground + 1f * u); path.lineTo(0f, ground + 1f * u); path.close(); c.drawPath(path, p)
        // virágok, fűszálak
        val r = Random(3)
        for (i in 0 until 26) {
            val fx = r.nextFloat() * W; val fy = ground + r.nextFloat() * 9f * u
            if (abs(fx - pondX) < pondRx + 2f * u && abs(fy - pondY) < pondRy + 2f * u) continue
            val sway = sin(t * 2f + i) * 0.5f * u
            stroke(0xFF3E8A3A.toInt(), 0.18f * u); c.drawLine(fx, fy, fx + sway, fy - 1.8f * u, p)
            fill(intArrayOf(0xFFFFD166.toInt(), 0xFFFF8FAB.toInt(), 0xFFFFFFFF.toInt(), 0xFFB8A1FF.toInt())[i % 4]); c.drawCircle(fx + sway, fy - 1.9f * u, 0.55f * u, p)
        }
        // nyuszi az üregénél
        val rx = 58f * u; val ry = ground + 8f * u
        fill(0xFF3B2A1A.toInt()); rect.set(rx - 2.4f * u, ry - 0.8f * u, rx + 2.4f * u, ry + 0.8f * u); c.drawOval(rect, p)
        if (rabbitHideUntil < t) {
            val cyc = t % 7f
            val out = cyc in 1f..6f
            if (out) {
                val hop = abs(sin((cyc - 1f) * 3.14f * 1.5f))
                val hx = rx + (cyc - 1f) * 2.2f * u * (if (cyc > 3.5f) -1f else 1f) * (if (cyc > 3.5f) 1f else 1f) - (if (cyc > 3.5f) (cyc - 3.5f) * 4.4f * u else 0f)
                val hy = ry - 0.6f * u - hop * 2.2f * u
                fill(0xFFF2EDE6.toInt()); rect.set(hx - 1.6f * u, hy - 1.2f * u, hx + 1.2f * u, hy + 0.8f * u); c.drawOval(rect, p)
                c.drawCircle(hx + 1.3f * u, hy - 1.3f * u, 0.9f * u, p)
                rect.set(hx + 0.8f * u, hy - 4.2f * u, hx + 1.4f * u, hy - 1.6f * u); c.drawOval(rect, p)
                rect.set(hx + 1.4f * u, hy - 4f * u, hx + 2f * u, hy - 1.6f * u); c.drawOval(rect, p)
                fill(0xFF1E1E1E.toInt()); c.drawCircle(hx + 1.7f * u, hy - 1.4f * u, 0.15f * u, p)
            }
        }
        // lepkék
        for (i in 0 until 4) {
            val bx = (20f + i * 19f) * u + sin(t * 0.8f + i * 2f) * 7f * u
            val by = ground - 3f * u + sin(t * 1.7f + i) * 2.5f * u - (if (t - butterflyLoveAt[i] in 0f..3f) (t - butterflyLoveAt[i]) * 4f * u else 0f)
            val fl = abs(sin(t * 18f + i))
            val col = intArrayOf(0xFFFFB703.toInt(), 0xFFFF70A6.toInt(), 0xFF70D6FF.toInt(), 0xFFB388EB.toInt())[i]
            fill(col)
            rect.set(bx - 1.6f * u * fl, by - 1f * u, bx, by + 0.6f * u); c.drawOval(rect, p)
            rect.set(bx, by - 1f * u, bx + 1.6f * u * fl, by + 0.6f * u); c.drawOval(rect, p)
            fill(0xFF2B2B3A.toInt()); rect.set(bx - 0.15f * u, by - 0.9f * u, bx + 0.15f * u, by + 0.6f * u); c.drawRect(rect, p)
        }
        // fák
        drawTree(c, 6f * u, ground, 1.0f, 0f); drawTree(c, 94f * u, ground, 1.15f, 1.3f); drawTree(c, 60f * u, ground, 0.8f, 2.1f)
        // kunyhó
        drawCabin(c, 86f * u, ground)
        // tábortűz
        drawCampfire(c, 34f * u, ground + 6.5f * u)
        // tó halakkal
        drawPond(c)
        // gazdi + kutya + labda
        drawPerson(c, ownerX, ground + 2f * u, 6f * u, 0xFFFF9F1C.toInt(), t * 2f, if (panic) 4 else if (!ballHeld && ballFlying) 3 else 0, false)
        drawDog(c, dogX, ground + 2.6f * u)
        if (!ballHeld) { fill(0xFFE63946.toInt()); c.drawCircle(ballX, ballY, 0.8f * u, p) }
        // sárkányos gyerek
        drawPerson(c, 12f * u, ground + 1.5f * u, 4.8f * u, 0xFF8338EC.toInt(), t, if (panic) 4 else 1, false)
    }

    private fun trailPos(s: Float): Pair<Float, Float> {
        var d = s * trailLen
        for (i in 1 until trail.size) {
            val seg = hypot(trail[i][0] - trail[i - 1][0], trail[i][1] - trail[i - 1][1])
            if (d <= seg) {
                val f = d / seg
                return (trail[i - 1][0] + (trail[i][0] - trail[i - 1][0]) * f) to (trail[i - 1][1] + (trail[i][1] - trail[i - 1][1]) * f)
            }
            d -= seg
        }
        return trail.last()[0] to trail.last()[1]
    }

    /** Kis ember. pose: 0 sétál, 1 integet, 2 ünnepel, 3 dob, 4 pánik, 5 ül. */
    private fun drawPerson(c: Canvas, x: Float, y: Float, s: Float, col: Int, ph: Float, pose: Int, pack: Boolean) {
        val bob = if (pose == 2 || pose == 4) abs(sin(ph * 1.5f)) * 0.25f * s else 0f
        val yy = y - bob
        val sw = if (pose == 0 || pose == 4) sin(ph) * 0.22f * s else 0f
        stroke(0xFF2B2B3A.toInt(), 0.12f * s)
        if (pose == 5) {
            c.drawLine(x, yy - 0.35f * s, x + 0.35f * s, yy - 0.3f * s, p); c.drawLine(x + 0.35f * s, yy - 0.3f * s, x + 0.4f * s, yy, p)
        } else {
            c.drawLine(x, yy - 0.35f * s, x + sw, yy, p); c.drawLine(x, yy - 0.35f * s, x - sw, yy, p)
        }
        if (pack) { fill(0xFF6B4F3A.toInt()); rect.set(x - 0.32f * s, yy - 0.72f * s, x - 0.08f * s, yy - 0.42f * s); c.drawRoundRect(rect, 0.06f * s, 0.06f * s, p) }
        stroke(col, 0.2f * s); c.drawLine(x, yy - 0.68f * s, x, yy - 0.36f * s, p)
        stroke(0xFF2B2B3A.toInt(), 0.1f * s)
        val sh = yy - 0.62f * s
        when (pose) {
            1 -> { c.drawLine(x, sh, x + 0.3f * s, sh - 0.3f * s + sin(t * 10f) * 0.08f * s, p); c.drawLine(x, sh, x - 0.18f * s, sh + 0.25f * s, p) }
            2, 4 -> { val wv = sin(t * 12f) * 0.08f * s; c.drawLine(x, sh, x + 0.25f * s, sh - 0.35f * s + wv, p); c.drawLine(x, sh, x - 0.25f * s, sh - 0.35f * s - wv, p) }
            3 -> { c.drawLine(x, sh, x + 0.35f * s, sh - 0.2f * s, p); c.drawLine(x, sh, x - 0.2f * s, sh + 0.2f * s, p) }
            else -> { c.drawLine(x, sh, x + sw * 0.8f, sh + 0.28f * s, p); c.drawLine(x, sh, x - sw * 0.8f, sh + 0.28f * s, p) }
        }
        fill(0xFFF2C9A0.toInt()); c.drawCircle(x, yy - 0.82f * s, 0.15f * s, p)
        fill(col); rect.set(x - 0.16f * s, yy - 0.99f * s, x + 0.16f * s, yy - 0.84f * s); c.drawArc(rect, 180f, 180f, true, p)
    }

    private fun drawDog(c: Canvas, x: Float, y: Float) {
        val run = dogState == 1 || dogState == 2
        val jump = t - dogJumpAt
        val jy = if (jump in 0f..0.6f) sin(jump / 0.6f * 3.14f) * 3f * u else 0f
        val yy = y - jy
        c.save(); c.scale(dogDir * 1.5f, 1.5f, x, yy)
        val leg = if (run) sin(t * 18f) * 0.8f * u else 0f
        stroke(0xFF8B5A2B.toInt(), 0.5f * u)
        c.drawLine(x - 1.4f * u, yy - 1f * u, x - 1.4f * u + leg, yy, p); c.drawLine(x + 1.4f * u, yy - 1f * u, x + 1.4f * u - leg, yy, p)
        fill(0xFFC98B4E.toInt()); rect.set(x - 2.4f * u, yy - 2.6f * u, x + 2.2f * u, yy - 0.8f * u); c.drawOval(rect, p)
        c.drawCircle(x + 2.4f * u, yy - 3f * u, 1.3f * u, p)
        fill(0xFF8B5A2B.toInt()); rect.set(x + 1.6f * u, yy - 4f * u, x + 2.4f * u, yy - 2.2f * u); c.drawOval(rect, p)
        fill(0xFF1E1E1E.toInt()); c.drawCircle(x + 3.6f * u, yy - 3f * u, 0.3f * u, p); c.drawCircle(x + 2.7f * u, yy - 3.3f * u, 0.18f * u, p)
        val wag = sin(t * (if (run || dogBarkUntil > t) 25f else 8f)) * 0.8f * u
        stroke(0xFFC98B4E.toInt(), 0.4f * u); c.drawLine(x - 2.3f * u, yy - 2f * u, x - 3.4f * u, yy - 3.2f * u + wag, p)
        if (dogState == 2) { fill(0xFFE63946.toInt()); c.drawCircle(x + 3.7f * u, yy - 2.5f * u, 0.8f * u, p) }
        c.restore()
    }

    private fun drawTree(c: Canvas, x: Float, y: Float, s: Float, ph: Float) {
        fill(0xFF6B4423.toInt()); rect.set(x - 1f * u * s, y - 9f * u * s, x + 1f * u * s, y + 0.5f * u); c.drawRect(rect, p)
        val sw = sin(t * 0.9f + ph) * 0.6f * u
        fill(0xFF2D6A4F.toInt()); c.drawCircle(x + sw, y - 12f * u * s, 5.5f * u * s, p)
        fill(0xFF40916C.toInt()); c.drawCircle(x - 3f * u * s + sw, y - 10f * u * s, 4f * u * s, p); c.drawCircle(x + 3.4f * u * s + sw, y - 10.5f * u * s, 4f * u * s, p)
        fill(0xFF52B788.toInt()); c.drawCircle(x - 1f * u * s + sw, y - 14.5f * u * s, 3f * u * s, p)
    }

    private fun drawCabin(c: Canvas, x: Float, y: Float) {
        fill(0xFF8C5A3C.toInt()); rect.set(x - 7f * u, y - 8f * u, x + 7f * u, y); c.drawRect(rect, p)
        stroke(0xFF6F4529.toInt(), 0.2f * u); for (k in 1..4) c.drawLine(x - 7f * u, y - k * 1.6f * u, x + 7f * u, y - k * 1.6f * u, p)
        fill(0xFF5C2E1F.toInt())
        path.reset(); path.moveTo(x - 8.5f * u, y - 8f * u); path.lineTo(x, y - 14f * u); path.lineTo(x + 8.5f * u, y - 8f * u); path.close(); c.drawPath(path, p)
        fill(0xFF4A4A4A.toInt()); rect.set(x + 3f * u, y - 15f * u, x + 5f * u, y - 10f * u); c.drawRect(rect, p)
        // füst
        for (k in 0 until 5) {
            val ph = ((t * 0.35f + k / 5f) % 1f)
            fill(((1f - ph) * 120).toInt() shl 24 or 0xDDDDDD)
            c.drawCircle(x + 4f * u + sin(ph * 6f + k) * 2f * u, y - 16f * u - ph * 14f * u, (0.8f + ph * 2.2f) * u, p)
        }
        // ablak – meleg fény
        if (cabinLight) {
            p.shader = RadialGradient(x - 3f * u, y - 4.5f * u, 9f * u, intArrayOf(0x80FFC86B.toInt(), 0x00FFC86B), null, Shader.TileMode.CLAMP)
            c.drawCircle(x - 3f * u, y - 4.5f * u, 9f * u, p); p.shader = null
        }
        fill(if (cabinLight) 0xFFFFD27A.toInt() else 0xFF2E2A3A.toInt()); rect.set(x - 5f * u, y - 6f * u, x - 1f * u, y - 3f * u); c.drawRect(rect, p)
        stroke(0xFF5C2E1F.toInt(), 0.25f * u); c.drawLine(x - 3f * u, y - 6f * u, x - 3f * u, y - 3f * u, p)
        fill(0xFF5C2E1F.toInt()); rect.set(x + 1.5f * u, y - 5f * u, x + 4.5f * u, y); c.drawRect(rect, p)
    }

    private fun drawCampfire(c: Canvas, x: Float, y: Float) {
        val boost = if (t - fireBoostAt in 0f..2f) 1.6f else 1f
        p.shader = RadialGradient(x, y - 1f * u, 14f * u * boost, intArrayOf(0x90FF9A3C.toInt(), 0x00FF9A3C), null, Shader.TileMode.CLAMP)
        c.drawCircle(x, y - 1f * u, 14f * u * boost, p); p.shader = null
        // körbeülők
        drawPerson(c, x - 6f * u, y, 4.4f * u, 0xFF2A9D8F.toInt(), 0f, if (panic) 4 else 5, false)
        c.save(); c.scale(-1f, 1f, x + 6f * u, y); drawPerson(c, x + 6f * u, y, 4.4f * u, 0xFFE76F51.toInt(), 0f, if (panic) 4 else 5, false); c.restore()
        stroke(0xFF5C3A1E.toInt(), 0.8f * u); c.drawLine(x - 2.5f * u, y + 0.3f * u, x + 2.5f * u, y - 0.6f * u, p); c.drawLine(x - 2.5f * u, y - 0.6f * u, x + 2.5f * u, y + 0.3f * u, p)
        for (k in 0 until 3) {
            val fl = 1f + sin(t * 13f + k * 2f) * 0.18f
            val col = intArrayOf(0xFFFF5A1F.toInt(), 0xFFFF9F1C.toInt(), 0xFFFFE066.toInt())[k]
            fill(col)
            val hh = (4.2f - k * 1.2f) * u * fl * boost; val ww = (1.8f - k * 0.45f) * u
            path.reset(); path.moveTo(x - ww, y - 0.4f * u); path.quadTo(x - ww, y - hh * 0.6f, x + sin(t * 7f + k) * 0.4f * u, y - hh)
            path.quadTo(x + ww, y - hh * 0.6f, x + ww, y - 0.4f * u); path.close(); c.drawPath(path, p)
        }
        if (Random.nextFloat() < 0.15f * boost) parts += Part(x + (Random.nextFloat() - 0.5f) * 2f * u, y - 3f * u, (Random.nextFloat() - 0.5f) * 3f * u, -8f * u, t, 1.2f, K_SPARK, 0xFFFFC94D.toInt(), -2f * u)
    }

    private fun drawPond(c: Canvas) {
        fill(0xFF3E7CB1.toInt()); rect.set(pondX - pondRx, pondY - pondRy, pondX + pondRx, pondY + pondRy); c.drawOval(rect, p)
        fill(0xFF5FA8D3.toInt()); rect.set(pondX - pondRx * 0.9f, pondY - pondRy * 0.85f, pondX + pondRx * 0.9f, pondY + pondRy * 0.55f); c.drawOval(rect, p)
        for (f in fish) {
            val jump = t - f.jumpAt
            val ang = f.ph
            var fx = pondX + cos(ang) * pondRx * f.a * 0.8f
            var fy = pondY + sin(ang) * pondRy * f.b * 0.6f
            if (feedUntil > t) { fx += (feedX - fx) * 0.5f }
            var jy = 0f
            if (jump in 0f..1f) jy = sin(jump * 3.14f) * 6f * u
            val dir = if (-sin(ang) * f.speed >= 0) 1f else -1f
            c.save(); c.scale(dir, 1f, fx, fy - jy)
            fill(if (jump in 0f..1f) f.col else (f.col and 0xFFFFFF) or 0xB0000000.toInt())
            rect.set(fx - 1.5f * u, fy - jy - 0.7f * u, fx + 1.5f * u, fy - jy + 0.7f * u); c.drawOval(rect, p)
            path.reset(); path.moveTo(fx - 1.3f * u, fy - jy); path.lineTo(fx - 2.6f * u, fy - jy - 0.8f * u); path.lineTo(fx - 2.6f * u, fy - jy + 0.8f * u); path.close(); c.drawPath(path, p)
            fill(0xFF101010.toInt()); c.drawCircle(fx + 0.8f * u, fy - jy - 0.15f * u, 0.18f * u, p)
            c.restore()
        }
        // fodrok
        stroke(0x66FFFFFF, 0.15f * u)
        for (k in 0 until 3) {
            val ph = (t * 0.5f + k / 3f) % 1f
            rect.set(pondX - ph * pondRx * 0.7f, pondY - ph * pondRy * 0.5f, pondX + ph * pondRx * 0.7f, pondY + ph * pondRy * 0.5f)
            p.alpha = ((1f - ph) * 120).toInt(); c.drawOval(rect, p)
        }
        p.alpha = 255
    }

    // ---- LENT
    private fun drawUnderground(c: Canvas) {
        // kövek
        val r = Random(11)
        for (i in 0 until 60) {
            val x = r.nextFloat() * W; val y = ground + 13f * u + r.nextFloat() * (WH - ground - 20f * u)
            fill((0x40 + r.nextInt(0x30) shl 24) or 0x2A1A10)
            rect.set(x - (0.6f + r.nextFloat()) * u, y - 0.5f * u, x + (0.6f + r.nextFloat()) * u, y + 0.5f * u); c.drawOval(rect, p)
        }
        // gyökerek a fák alól
        stroke(0xFF5A3A22.toInt(), 0.6f * u)
        for ((tx, len) in listOf(6f to 18f, 94f to 22f, 60f to 14f)) {
            for (k in -1..1) {
                path.reset(); path.moveTo(tx * u, ground + 12f * u)
                path.quadTo(tx * u + k * 6f * u, ground + (12f + len * 0.5f) * u, tx * u + k * 3f * u + sin(t * 0.3f + k) * 0.5f * u, ground + (12f + len) * u)
                c.drawPath(path, p)
            }
        }
        // giliszták
        for (k in 0 until 3) {
            val wy = ground + (18f + k * 7f) * u
            val wx = ((t * 3f * u + k * 37f * u) % (W + 20f * u)) - 10f * u
            stroke(0xFFE89BA8.toInt(), 0.8f * u)
            path.reset(); path.moveTo(wx, wy)
            for (s in 1..6) path.lineTo(wx - s * 1f * u, wy + sin(t * 6f + s) * 0.6f * u)
            c.drawPath(path, p)
        }
        // vakond és alagútja
        val my = ground + 27f * u
        fill(0xFF1E120A.toInt()); rect.set(0f, my - 2.2f * u, moleX + 2f * u, my + 2.2f * u); c.drawRoundRect(rect, 2.2f * u, 2.2f * u, p)
        fill(0xFF3B3B4A.toInt()); rect.set(moleX - 3f * u, my - 1.8f * u, moleX + 2f * u, my + 1.8f * u); c.drawOval(rect, p)
        fill(0xFFFF8FAB.toInt()); c.drawCircle(moleX + 2.2f * u, my, 0.5f * u, p)
        fill(0xFFFFFFFF.toInt()); stroke(0xFFFFFFFF.toInt(), 0.2f * u); c.drawLine(moleX + 1f * u, my + 1.5f * u, moleX + 1.6f * u, my + 2.3f * u + sin(t * 10f) * 0.3f * u, p)
        if (t - molePeekAt in 0f..2f) { tp.textSize = 3f * u; tp.color = 0xFFFFFFFF.toInt(); c.drawText("?", moleX, my - 3f * u, tp) }
        // bánya: alagút, sín, csille, lámpás bányász
        val mineY = Y(0.7500f)
        fill(0xFF120A06.toInt()); rect.set(-2f * u, mineY - 7f * u, W + 2f * u, mineY + 1.5f * u); c.drawRoundRect(rect, 4f * u, 4f * u, p)
        stroke(0xFF4A4A55.toInt(), 0.3f * u); c.drawLine(0f, mineY, W, mineY, p)
        stroke(0xFF5C3A1E.toInt(), 0.3f * u); var bx = 0f; while (bx < W) { c.drawLine(bx, mineY - 0.3f * u, bx, mineY + 0.6f * u, p); bx += 3f * u }
        // gerendák
        stroke(0xFF6B4423.toInt(), 0.9f * u)
        for (k in 0..4) { val x = k * 25f * u + 5f * u; c.drawLine(x, mineY, x, mineY - 7f * u, p) }
        c.drawLine(0f, mineY - 6.6f * u, W, mineY - 6.6f * u, p)
        // csille
        fill(0xFF6E6E7A.toInt()); rect.set(cartX - 3f * u, mineY - 3.6f * u, cartX + 3f * u, mineY - 1f * u); c.drawRect(rect, p)
        fill(0xFFFFD166.toInt()); c.drawCircle(cartX - 1f * u, mineY - 3.8f * u, 1f * u, p); fill(0xFF8EECF5.toInt()); c.drawCircle(cartX + 1.2f * u, mineY - 3.9f * u, 0.9f * u, p)
        fill(0xFF2A2A2A.toInt()); c.drawCircle(cartX - 1.8f * u, mineY - 0.8f * u, 0.8f * u, p); c.drawCircle(cartX + 1.8f * u, mineY - 0.8f * u, 0.8f * u, p)
        val minerX = cartX - cartDir * 5.5f * u
        p.shader = RadialGradient(minerX, mineY - 4f * u, 12f * u, intArrayOf(0x70FFE08A, 0x00FFE08A), null, Shader.TileMode.CLAMP)
        c.drawCircle(minerX, mineY - 4f * u, 12f * u, p); p.shader = null
        c.save(); c.scale(cartDir, 1f, minerX, mineY)
        drawPerson(c, minerX, mineY, 5f * u, 0xFF3A6EA5.toInt(), t * 6f, if (panic) 4 else 0, false)
        fill(0xFFFFD34D.toInt()); c.drawCircle(minerX, mineY - 5.1f * u, 0.6f * u, p)
        c.restore()
        // kristálybarlang
        val cy = Y(0.8400f)
        fill(0xFF140C08.toInt()); rect.set(10f * u, cy - 8f * u, 90f * u, cy + 6f * u); c.drawOval(rect, p)
        val cols = intArrayOf(0xFF4CC9F0.toInt(), 0xFFF72585.toInt(), 0xFF7209B7.toInt(), 0xFF4CC9F0.toInt(), 0xFFB5E48C.toInt())
        for (k in 0 until 5) {
            val x = (20f + k * 15f) * u; val y = cy + 4f * u
            val ping = t - crystalPingAt[k]
            val glow = 0.5f + 0.5f * sin(t * 1.5f + k) + (if (ping in 0f..1f) (1f - ping) * 1.5f else 0f)
            p.shader = RadialGradient(x, y - 3f * u, 8f * u, intArrayOf(((glow * 90).toInt().coerceIn(0, 255) shl 24) or (cols[k] and 0xFFFFFF), 0), null, Shader.TileMode.CLAMP)
            c.drawCircle(x, y - 3f * u, 8f * u, p); p.shader = null
            fill(cols[k])
            for (j in -1..1) {
                val hh = (5f - abs(j) * 1.6f) * u
                path.reset(); path.moveTo(x + j * 1.6f * u - 0.8f * u, y); path.lineTo(x + j * 2.2f * u, y - hh); path.lineTo(x + j * 1.6f * u + 0.8f * u, y); path.close(); c.drawPath(path, p)
            }
        }
        // hangyák egy járatban
        val ay = Y(0.9100f)
        fill(0xFF1A100A.toInt()); rect.set(-2f * u, ay - 1.6f * u, W + 2f * u, ay + 1.6f * u); c.drawRoundRect(rect, 1.6f * u, 1.6f * u, p)
        for (k in 0 until 9) {
            val x = ((t * 6f * u + k * 11f * u) % (W + 10f * u)) - 5f * u
            fill(0xFF050505.toInt()); c.drawCircle(x, ay + 0.6f * u, 0.45f * u, p); c.drawCircle(x + 0.8f * u, ay + 0.6f * u, 0.35f * u, p)
            if (k % 2 == 0) { fill(0xFF6BBF59.toInt()); rect.set(x - 0.6f * u, ay - 1.2f * u, x + 1.2f * u, ay + 0.1f * u); c.drawOval(rect, p) }
        }
        // dínó-kövület
        val fx = 66f * u; val fy = Y(0.7f)
        val ping = t - fossilAt
        stroke(if (ping in 0f..1.5f) 0xFFFFF3C4.toInt() else 0xFFD9CBB0.toInt(), 0.7f * u)
        path.reset(); path.moveTo(fx - 16f * u, fy + 2f * u); path.quadTo(fx - 4f * u, fy - 7f * u, fx + 8f * u, fy - 3f * u); path.quadTo(fx + 13f * u, fy - 1f * u, fx + 16f * u, fy - 5f * u); c.drawPath(path, p)
        for (k in 0 until 9) { val bx = fx - 12f * u + k * 2.5f * u; val by = fy - 2.5f * u - sin(k / 8f * 3.14f) * 3.2f * u; c.drawLine(bx, by, bx + 0.6f * u, by + 4f * u, p) }
        stroke(0xFFD9CBB0.toInt(), 0.5f * u)
        c.drawLine(fx - 6f * u, fy - 1f * u, fx - 7f * u, fy + 4f * u, p); c.drawLine(fx + 4f * u, fy - 2f * u, fx + 5f * u, fy + 4f * u, p)
        fill(0xFFD9CBB0.toInt()); rect.set(fx + 14f * u, fy - 8f * u, fx + 21f * u, fy - 4f * u); c.drawOval(rect, p)
        fill(0xFF22140B.toInt()); c.drawCircle(fx + 18.5f * u, fy - 6.5f * u, 0.7f * u, p)
        // kincsesláda
        val kx = 18f * u; val ky = Y(0.8f)
        val open = t - chestOpenAt in 0f..4f
        if (open) {
            p.shader = RadialGradient(kx, ky - 3f * u, 12f * u, intArrayOf(0xA0FFD166.toInt(), 0x00FFD166), null, Shader.TileMode.CLAMP)
            c.drawCircle(kx, ky - 3f * u, 12f * u, p); p.shader = null
        }
        fill(0xFF8B5A2B.toInt()); rect.set(kx - 5f * u, ky - 4f * u, kx + 5f * u, ky); c.drawRect(rect, p)
        fill(0xFF6B4423.toInt())
        if (open) { rect.set(kx - 5f * u, ky - 9f * u, kx + 5f * u, ky - 6.5f * u); c.drawRoundRect(rect, 1f * u, 1f * u, p); fill(0xFFFFD166.toInt()); for (k in -2..2) c.drawCircle(kx + k * 1.6f * u, ky - 4.3f * u, 0.9f * u, p) }
        else { rect.set(kx - 5.3f * u, ky - 6.5f * u, kx + 5.3f * u, ky - 3.8f * u); c.drawRoundRect(rect, 2f * u, 2f * u, p) }
        fill(0xFFFFC23D.toInt()); rect.set(kx - 0.7f * u, ky - 4.6f * u, kx + 0.7f * u, ky - 3f * u); c.drawRect(rect, p)
        // láva-buborékok
        for (k in 0 until 6) {
            val ph = (t * 0.5f + k / 6f) % 1f
            fill(((1f - ph) * 200).toInt() shl 24 or 0xFF6A1A)
            c.drawCircle((8f + k * 17f) * u + sin(k.toFloat()) * 4f * u, WH - 2f * u - ph * 9f * u, (0.6f + ph) * u, p)
        }
        // a legmélyén: láva derengés + a barlang a szörnnyel
        drawMonsterCave(c)
    }

    private fun monsterPos(): Pair<Float, Float> = 52f * u to Y(0.915f)

    private fun drawMonsterCave(c: Canvas) {
        val (mx, my) = monsterPos()
        p.shader = LinearGradient(0f, Y(0.88f), 0f, WH, 0x00FF3A00, 0x90FF3A00.toInt(), Shader.TileMode.CLAMP)
        c.drawRect(0f, Y(0.88f), W, WH, p); p.shader = null
        // barlang
        fill(0xFF050304.toInt()); rect.set(mx - 34f * u, my - 16f * u, mx + 34f * u, my + 10f * u); c.drawOval(rect, p)
        // tábla
        stroke(0xFF6B4423.toInt(), 0.7f * u); c.drawLine(14f * u, my + 4f * u, 14f * u, my - 9f * u, p)
        fill(0xFF8C5A3C.toInt()); rect.set(5f * u, my - 14f * u, 23f * u, my - 8f * u); c.drawRoundRect(rect, 1f * u, 1f * u, p)
        tp.color = 0xFF2A1408.toInt(); tp.textSize = 2.1f * u; tp.isFakeBoldText = true
        c.drawText("PSSZT!", 14f * u, my - 11.6f * u, tp); c.drawText("NE ÉBRESZD FEL", 14f * u, my - 9.1f * u, tp)
        tp.isFakeBoldText = false
        val awake = t - awakeAt in 0f..10f
        val breath = sin(t * (if (awake) 8f else 1.2f))
        val grow = if (awake) 1f + ((t - awakeAt) / 1.6f).coerceAtMost(1f) * 0.35f else 1f
        val stir = anger > 0 && t - lastPoke < 1.2f
        val jit = if (stir || awake) (Random.nextFloat() - 0.5f) * u * (if (awake) 1.5f else 0.6f) else 0f
        c.save(); c.translate(jit, 0f); c.scale(grow, grow * (1f + breath * 0.04f), mx, my + 6f * u)
        // test + tüskék
        fill(0xFF2E1A3D.toInt())
        for (k in 0 until 6) {
            val sx = mx - 14f * u + k * 5.6f * u
            path.reset(); path.moveTo(sx - 2f * u, my - 8f * u + abs(k - 2.5f) * 1.2f * u); path.lineTo(sx, my - 14f * u + abs(k - 2.5f) * 1.6f * u); path.lineTo(sx + 2f * u, my - 8f * u + abs(k - 2.5f) * 1.2f * u); path.close(); c.drawPath(path, p)
        }
        fill(0xFF3F2453.toInt()); rect.set(mx - 18f * u, my - 10f * u, mx + 18f * u, my + 7f * u); c.drawOval(rect, p)
        fill(0xFF5B3A70.toInt()); rect.set(mx - 11f * u, my - 3f * u, mx + 11f * u, my + 6f * u); c.drawOval(rect, p)
        // karmok
        fill(0xFFE8E0D0.toInt())
        for (side in listOf(-1f, 1f)) for (k in 0 until 3) {
            val cx = mx + side * (14f + k * 1.4f) * u
            path.reset(); path.moveTo(cx - 0.6f * u, my + 5.5f * u); path.lineTo(cx + side * 0.6f * u, my + 7.8f * u); path.lineTo(cx + 0.6f * u, my + 5.5f * u); path.close(); c.drawPath(path, p)
        }
        // szemek
        val ey = my - 4f * u
        for (side in listOf(-1f, 1f)) {
            val ex = mx + side * 6f * u
            when {
                awake -> {
                    p.shader = RadialGradient(ex, ey, 5f * u, intArrayOf(0xC0FF1A1A.toInt(), 0x00FF1A1A), null, Shader.TileMode.CLAMP)
                    c.drawCircle(ex, ey, 5f * u, p); p.shader = null
                    fill(0xFFFFD000.toInt()); c.drawCircle(ex, ey, 2.4f * u, p)
                    fill(0xFF000000.toInt()); rect.set(ex - 0.5f * u, ey - 2f * u, ex + 0.5f * u, ey + 2f * u); c.drawOval(rect, p)
                }
                stir -> { fill(0xFFFFD000.toInt()); rect.set(ex - 2f * u, ey - 0.5f * u, ex + 2f * u, ey + 0.8f * u); c.drawOval(rect, p) }
                else -> { stroke(0xFF1A0E22.toInt(), 0.5f * u); rect.set(ex - 2f * u, ey - 1.2f * u, ex + 2f * u, ey + 1.2f * u); c.drawArc(rect, 20f, 140f, false, p) }
            }
        }
        // száj
        if (awake) {
            fill(0xFF1A0006.toInt()); rect.set(mx - 8f * u, my + 0f * u, mx + 8f * u, my + 6f * u); c.drawOval(rect, p)
            fill(0xFFFFFFFF.toInt())
            for (k in 0 until 7) {
                val tx = mx - 6f * u + k * 2f * u
                path.reset(); path.moveTo(tx - 0.8f * u, my + 0.8f * u); path.lineTo(tx, my + 2.6f * u); path.lineTo(tx + 0.8f * u, my + 0.8f * u); path.close(); c.drawPath(path, p)
            }
        } else {
            stroke(0xFF1A0E22.toInt(), 0.4f * u); c.drawLine(mx - 3f * u, my + 2f * u, mx + 3f * u, my + 2f * u, p)
        }
        c.restore()
        // Zzz
        if (!awake && !stir) {
            tp.color = 0xCCB8A6FF.toInt()
            for (k in 0 until 3) {
                val ph = (t * 0.4f + k / 3f) % 1f
                tp.textSize = (2f + ph * 3f) * u; tp.alpha = ((1f - ph) * 220).toInt()
                c.drawText("Z", mx + 12f * u + ph * 8f * u, my - 12f * u - ph * 14f * u, tp)
            }
            tp.alpha = 255
        }
    }

    // ---- részecskék és buborékok
    private fun drawParts(c: Canvas, dt: Float) {
        val it = parts.iterator()
        while (it.hasNext()) {
            val q = it.next()
            val age = t - q.t0
            if (age > q.life) { it.remove(); continue }
            q.vy += q.g * dt * 10f
            q.x += q.vx * dt; q.y += q.vy * dt
            val a = ((1f - age / q.life) * 255).toInt().coerceIn(0, 255)
            when (q.kind) {
                K_HEART -> { tp.textSize = 3.2f * u; tp.color = (a shl 24) or (q.col and 0xFFFFFF); c.drawText("♥", q.x, q.y, tp) }
                K_NOTE -> { tp.textSize = 3f * u; tp.color = (a shl 24) or (q.col and 0xFFFFFF); c.drawText("♪", q.x, q.y, tp) }
                K_STAR -> { tp.textSize = 2.6f * u; tp.color = (a shl 24) or (q.col and 0xFFFFFF); c.drawText("✦", q.x, q.y, tp) }
                K_DROP -> { stroke((a shl 24) or (q.col and 0xFFFFFF), 0.25f * u); c.drawLine(q.x, q.y, q.x, q.y + 1.4f * u, p) }
                else -> { fill((a shl 24) or (q.col and 0xFFFFFF)); c.drawCircle(q.x, q.y, (if (q.kind == K_SPARK) 0.35f else 0.6f) * u, p) }
            }
        }
    }

    private fun drawBubbles(c: Canvas) {
        val it = bubbles.iterator()
        while (it.hasNext()) {
            val b = it.next()
            val age = t - b.t0
            if (age > 2.2f) { it.remove(); continue }
            val a = if (age < 1.6f) 1f else (2.2f - age) / 0.6f
            val y = b.y - age * 2f * u
            tp.textSize = 3f * u; tp.isFakeBoldText = true
            val tw = tp.measureText(b.text)
            fill(((a * 235).toInt() shl 24) or 0xFFFFFF)
            rect.set(b.x - tw / 2 - 1.5f * u, y - 3.8f * u, b.x + tw / 2 + 1.5f * u, y + 1.2f * u); c.drawRoundRect(rect, 2f * u, 2f * u, p)
            path.reset(); path.moveTo(b.x - 1f * u, y + 1.1f * u); path.lineTo(b.x, y + 2.6f * u); path.lineTo(b.x + 1f * u, y + 1.1f * u); path.close(); c.drawPath(path, p)
            tp.color = ((a * 255).toInt() shl 24) or (b.col and 0xFFFFFF)
            c.drawText(b.text, b.x, y, tp)
            tp.isFakeBoldText = false
        }
    }

    private fun say(x: Float, y: Float, s: String, col: Int = 0xFF1E1E2A.toInt()) { bubbles += Bubble(x, y, s, t, col) }
    private fun burst(x: Float, y: Float, kind: Int, col: Int, n: Int = 6, up: Float = 10f) {
        repeat(n) { parts += Part(x, y, (Random.nextFloat() - 0.5f) * 10f * u, -(up * 0.5f + Random.nextFloat() * up) * u, t, 1.6f, kind, col, if (kind == K_DOT) 3f * u else -0.5f * u) }
    }
    private fun note(x: Float, y: Float) { parts += Part(x, y, (Random.nextFloat() - 0.5f) * 3f * u, -5f * u, t, 2f, K_NOTE, 0xFFFFE08A.toInt(), 0f) }

    // ---- HUD: magasságmérő és vissza gomb
    private fun drawHud(c: Canvas) {
        // vissza
        fill(0x99000000.toInt()); c.drawCircle(7f * u + 10f, 10f * u, 5f * u, p)
        tp.textSize = 6f * u; tp.color = 0xFFFFFFFF.toInt(); c.drawText("‹", 7f * u + 10f, 12f * u, tp)
        // magasságmérő a jobb szélen
        val x = W - 4f * u; val y0 = 14f * u; val y1 = H - 8f * u
        for (k in 0..40) { fill(0x55FFFFFF); c.drawCircle(x, y0 + (y1 - y0) * k / 40f, 0.3f * u, p) }
        val f = (scrollY + H / 2) / WH
        fill(0xFFFF4D4D.toInt()); c.drawCircle(x, y0 + (y1 - y0) * f, 1.1f * u, p)
        tp.textSize = 2f * u; tp.textAlign = Paint.Align.RIGHT; tp.color = 0x77FFFFFF
        for ((lab, at) in listOf("MENNY" to 0.08f, "ÉG" to 0.32f, "HEGY" to 0.55f, "FELSZÍN" to 0.62f, "BÁNYA" to 0.76f, "MÉLY" to 0.92f)) {
            c.drawText(lab, x - 2f * u, y0 + (y1 - y0) * (Y(at) / WH) + 0.8f * u, tp)
        }
        tp.textAlign = Paint.Align.CENTER
        // tipp az elején
        if (t < 6f) {
            val a = if (t < 5f) 1f else 6f - t
            fill(((a * 170).toInt() shl 24)); rect.set(12f * u, H - 20f * u, 88f * u, H - 11f * u); c.drawRoundRect(rect, 3f * u, 3f * u, p)
            tp.textSize = 3f * u; tp.color = ((a * 255).toInt() shl 24) or 0xFFFFFF
            c.drawText("Görgess fel az egekig, le a mélybe", 50f * u, H - 15.5f * u, tp)
            tp.textSize = 2.6f * u; c.drawText("…és koppints bármire", 50f * u, H - 12.5f * u, tp)
        }
    }

    // ------------------------------------------------------------------ mozgás

    private fun update(dt: Float) {
        shake = if (t - awakeAt in 0f..2f) 4f * u else maxOf(0f, shake - dt * 30f * u)
        if (anger > 0 && t - lastPoke > 7f && t - awakeAt > 10f) anger = 0
        // felhők
        for (cl in clouds) {
            cl.x += cl.speed * dt
            if (cl.x > W + 15f * u) cl.x = -15f * u
            if (cl.x < -15f * u) cl.x = W + 15f * u
            if (cl.rainUntil > t && Random.nextFloat() < 0.8f) parts += Part(cl.x + (Random.nextFloat() - 0.5f) * 18f * u * cl.s, cl.y + 3f * u, 0f, 30f * u, t, 1.8f, K_DROP, 0xFF9CC9F5.toInt(), 0f)
        }
        // madarak, ballon
        birdsX += dt * 7f * u * (if (t - birdsScatterAt in 0f..3f) 2f else 1f)
        if (birdsX > W + 30f * u) birdsX = -20f * u
        balloonX += dt * 1.2f * u; if (balloonX > W + 12f * u) balloonX = -12f * u
        planeX += dt * 9f * u; if (planeX > W + 60f * u) planeX = -40f * u
        // hegymászók
        for (cl in climbers) {
            if (cl.cheerUntil > t || cl.waveUntil > t) continue
            cl.s += cl.speed * dt * (if (panic) -6f else 1f)
            if (cl.s >= 1f) { cl.s = 1f; cl.cheerUntil = t + 2.5f; val (x, y) = trailPos(1f); burst(x, y - 5f * u, K_STAR, 0xFFFFD166.toInt(), 8) ; say(x, y - 6f * u, "Fent vagyok!") }
            if (cl.s < 0f) cl.s = 0f
        }
        for (cl in climbers) if (cl.s >= 1f && cl.cheerUntil <= t) cl.s = 0f
        // halak
        for (f in fish) {
            f.ph += f.speed * dt * (if (feedUntil > t) 2f else 1f)
            if (Random.nextFloat() < 0.002f && t - f.jumpAt > 4f) f.jumpAt = t
        }
        // vakond, csille
        moleX += dt * 1.6f * u; if (moleX > W + 5f * u) moleX = -5f * u
        cartX += cartDir * dt * 6f * u * (if (panic) 3f else 1f)
        if (cartX > W - 8f * u) cartDir = -1f
        if (cartX < 12f * u) cartDir = 1f
        // gazdi + kutya + labda
        if (ballHeld && t > nextThrow && dogState == 0 && !panic) throwBall(ownerX + (20f + Random.nextFloat() * 25f) * u * (if (Random.nextBoolean()) 1f else -0.8f))
        if (ballFlying) {
            ballVy += 60f * u * dt
            ballX += ballVx * dt; ballY += ballVy * dt
            if (ballY >= ground + 2f * u) { ballY = ground + 2f * u; ballVy = -ballVy * 0.35f; ballVx *= 0.6f; if (abs(ballVy) < 4f * u) { ballFlying = false; ballVy = 0f } }
            ballX = ballX.coerceIn(3f * u, W - 3f * u)
        }
        when (dogState) {
            1 -> {
                val dx = ballX - dogX
                dogDir = if (dx >= 0) 1f else -1f
                dogX += dogDir * minOf(abs(dx), 26f * u * dt)
                if (abs(dx) < 1.5f * u && !ballFlying) { dogState = 2; ballHeld = false; ballX = -999f }
            }
            2 -> {
                val dx = ownerX + 3f * u - dogX
                dogDir = if (dx >= 0) 1f else -1f
                dogX += dogDir * minOf(abs(dx), 20f * u * dt)
                if (abs(dx) < 1f * u) { dogState = 0; ballHeld = true; nextThrow = t + 2.5f + Random.nextFloat() * 2f; dogDir = -1f; dogJumpAt = t }
            }
        }
        if (panic && t - awakeAt > 1.6f) {
            panic = false
            onMonsterAwake?.invoke()
            onMonsterAwake = null
        }
    }

    private fun throwBall(targetX: Float) {
        ballHeld = false; ballFlying = true
        ballX = ownerX + 1f * u; ballY = ground - 2f * u
        val dist = targetX - ballX
        ballVx = dist / 1.1f; ballVy = -33f * u
        dogState = 1
    }

    // ------------------------------------------------------------------ koppintás

    private fun tap(sx: Float, sy: Float) {
        // vissza gomb
        if (hypot(sx - (7f * u + 10f), sy - 10f * u) < 7f * u) { onBack?.invoke(); return }
        val x = sx; val y = sy + scrollY
        fun near(ax: Float, ay: Float, r: Float) = hypot(x - ax, y - ay) < r

        // szörny
        val (mx, my) = monsterPos()
        if (near(mx, my - 2f * u, 20f * u)) { pokeMonster(); return }
        // angyalok
        for (a in angels) if (near(a.x, a.y - 6f * u, 10f * u)) { a.loopAt = t; burst(a.x, a.y - 6f * u, K_HEART, 0xFFFF6B9A.toInt(), 8); say(a.x, a.y - 10f * u, listOf("Hallelúja!", "Szia! ♥", "Áldás!").random()); return }
        // menny kapuja
        if (near(50f * u, Y(0.085f), 12f * u)) { burst(50f * u, Y(0.085f), K_STAR, 0xFFFFE08A.toInt(), 14, 14f); say(50f * u, Y(0.06f), "Még korai…"); return }
        // felhők
        for (cl in clouds) if (near(cl.x, cl.y, 10f * u * cl.s)) {
            if (cl.y < Y(0.2f)) burst(cl.x, cl.y, K_STAR, 0xFFFFFFFF.toInt(), 6) else { cl.rainUntil = t + 5f }
            return
        }
        // madarak
        if (abs(y - Y(0.4f)) < 8f * u && abs(x - birdsX) < 15f * u) { birdsScatterAt = t; repeat(4) { note(birdsX + (it - 2) * 3f * u, Y(0.4f)) }; return }
        // repülő
        if (abs(y - Y(0.28f)) < 7f * u && x in planeX - 36f * u..planeX + 8f * u) { planeLoopAt = t; say(planeX, Y(0.28f) - 7f * u, "Brrrumm!"); return }
        // siklóernyős
        run { val gx = 72f * u + cos(t * 0.35f) * 18f * u; val gy = Y(0.47f) + sin(t * 0.7f) * 4f * u
            if (near(gx, gy - 2f * u, 9f * u)) { say(gx, gy - 12f * u, "Szép innen a kilátás!"); burst(gx, gy, K_HEART, 0xFFFF6B9A.toInt(), 4); return } }
        // ballon
        if (near(balloonX, Y(0.33f), 10f * u)) { balloonBoostAt = t; say(balloonX, Y(0.33f) - 10f * u, "Juhúúú!"); return }
        // hegymászók
        for (cl in climbers) { val (cx, cy) = trailPos(cl.s); if (near(cx, cy - 2.5f * u, 5f * u)) { cl.waveUntil = t + 1.6f; say(cx, cy - 4.5f * u, listOf("Hahó!", "Szia!", "Gyere te is!").random()); return } }
        // kutya
        if (near(dogX, ground - 1f * u, 7f * u)) { dogBarkUntil = t + 1f; dogJumpAt = t; say(dogX, ground - 3f * u, "Vau! Vau!"); burst(dogX, ground - 2f * u, K_HEART, 0xFFFF6B9A.toInt(), 3); return }
        // gazdi
        if (near(ownerX, ground - 2f * u, 5f * u)) { say(ownerX, ground - 5f * u, "Hozd vissza, Bodri!"); return }
        // kunyhó
        if (near(86f * u, ground - 6f * u, 9f * u)) { cabinLight = !cabinLight; if (cabinLight) say(86f * u, ground - 16f * u, "Kész a tea ☕"); return }
        // tábortűz
        if (near(34f * u, ground + 5f * u, 8f * u)) { fireBoostAt = t; burst(34f * u, ground + 2f * u, K_SPARK, 0xFFFFC94D.toInt(), 20, 18f); say(34f * u, ground - 3f * u, "Mályvacukrot!"); return }
        // tó
        if (abs(x - pondX) < pondRx && abs(y - pondY) < pondRy * 1.5f) { feedX = x; feedUntil = t + 3f; fish.random().jumpAt = t; burst(x, pondY, K_DOT, 0xFF9CC9F5.toInt(), 8); return }
        // nyuszi
        if (near(60f * u, ground + 6f * u, 7f * u) && rabbitHideUntil < t) { rabbitHideUntil = t + 4f; say(58f * u, ground + 2f * u, "!"); return }
        // lepkék
        for (i in 0 until 4) {
            val bx = (20f + i * 19f) * u + sin(t * 0.8f + i * 2f) * 7f * u
            val by = ground - 3f * u + sin(t * 1.7f + i) * 2.5f * u
            if (near(bx, by, 4f * u)) { butterflyLoveAt[i] = t; burst(bx, by, K_HEART, 0xFFFF70A6.toInt(), 4); return }
        }
        // kincsesláda, kövület
        if (near(18f * u, Y(0.8f) - 3f * u, 8f * u)) { chestOpenAt = t; burst(18f * u, Y(0.8f) - 5f * u, K_DOT, 0xFFFFD166.toInt(), 18, 16f); say(18f * u, Y(0.8f) - 11f * u, "Kincs! ✦"); return }
        if (near(70f * u, Y(0.7f) - 2f * u, 16f * u)) { fossilAt = t; say(74f * u, Y(0.7f) - 10f * u, "Rrr… csak csont."); return }
        // kristályok
        val cyy = Y(0.8400f)
        for (k in 0 until 5) if (near((20f + k * 15f) * u, cyy + 1f * u, 5f * u)) { crystalPingAt[k] = t; note((20f + k * 15f) * u, cyy - 3f * u); return }
        // vakond
        if (near(moleX, ground + 27f * u, 4f * u)) { molePeekAt = t; return }
        // bányász / csille
        val mineY = Y(0.7500f)
        if (abs(y - mineY + 3f * u) < 5f * u && abs(x - cartX) < 10f * u) { say(cartX, mineY - 8f * u, listOf("Jó szerencsét!", "Arany!", "Hó-rukk!").random()); return }
        // a rétre koppintva: TE dobod el a labdát, a kutya hozza
        if (y in (ground - 5f * u)..(ground + 11f * u) && dogState == 0 && ballHeld) { throwBall(x); say(ownerX, ground - 5f * u, "Hozd!"); return }
        // a földbe koppintva: kis porfelhő
        if (y > ground) burst(x, y, K_DOT, 0xFF8B6B4A.toInt(), 5, 4f) else burst(x, y, K_STAR, 0xFFFFFFFF.toInt(), 3, 4f)
    }

    private fun pokeMonster() {
        if (t - awakeAt < 10f) return
        anger++
        lastPoke = t
        val (mx, my) = monsterPos()
        shake = (1f + anger) * u
        when (anger) {
            1 -> say(mx, my - 18f * u, "…hmm?", 0xFF5B3A70.toInt())
            2 -> say(mx, my - 18f * u, "GRRR… hagyj aludni!", 0xFF9B1D20.toInt())
            else -> {
                awakeAt = t
                panic = true
                say(mx, my - 22f * u, "GRRRAAAAAH!!!", 0xFFFF0000.toInt())
                burst(mx, my, K_DOT, 0xFF3F2453.toInt(), 30, 20f)
                for (cl in climbers) cl.waveUntil = 0f
                birdsScatterAt = t
                try { Haptics(context).denied() } catch (e: Throwable) { }
            }
        }
    }
}

/** A Főoldal kártyája: élő, mozgó kis ablak a világra (koppintásra megnyílik). */
fun Activity.worldHero(): FrameLayout {
    val card = FrameLayout(this).apply {
        background = rounded(0xFF120A1E.toInt(), dp(24).toFloat())
        clipToOutline = true
        setOnClickListener { startActivity(Intent(this@worldHero, WorldActivity::class.java)) }
    }
    card.addView(WorldView(this, preview = true), FrameLayout.LayoutParams(MATCH_PARENT, MATCH_PARENT))
    val shade = LinearLayout(this).apply {
        orientation = LinearLayout.VERTICAL
        background = android.graphics.drawable.GradientDrawable(android.graphics.drawable.GradientDrawable.Orientation.TOP_BOTTOM,
            intArrayOf(0xB0000000.toInt(), 0x00000000))
        setPadding(dp(18), dp(14), dp(18), dp(26))
    }
    shade.addView(text("KIS VILÁG", 22f, 0xFFFFFFFF.toInt()).apply { typeface = Widgets.dotoFace(this@worldHero) })
    shade.addView(text("Lent a barlang, fent az egek · koppints bármire", 12.5f, 0xFFE0E0E0.toInt()))
    card.addView(shade, FrameLayout.LayoutParams(MATCH_PARENT, WRAP_CONTENT))
    card.layoutParams = LinearLayout.LayoutParams(MATCH_PARENT, dp(170)).apply { topMargin = dp(6) }
    return card
}

/** Az eldugott bejárat (Beállítások fül legalja): kis, halvány pontmátrixos „ajtó”. */
fun Activity.worldDoor(): LinearLayout {
    val b = LinearLayout(this).apply {
        orientation = LinearLayout.HORIZONTAL
        gravity = android.view.Gravity.CENTER_VERTICAL
        background = rounded(0xFF101010.toInt(), dp(16).toFloat(), 0xFF262626.toInt(), dp(1))
        setPadding(dp(12), dp(6), dp(14), dp(6))
        alpha = 0.55f
        setOnClickListener { startActivity(Intent(this@worldDoor, WorldActivity::class.java)) }
    }
    b.addView(text("◉", 13f, 0xFF7FB2FF.toInt()))
    b.addView(text("kis világ", 11.5f, 0xFF8A8A8A.toInt()).apply { setPadding(dp(6), 0, 0, 0); typeface = Widgets.dotoFace(this@worldDoor) })
    return b
}
