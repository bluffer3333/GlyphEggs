package com.akos.glypheggs

import android.app.Activity
import android.graphics.Canvas
import android.graphics.Paint
import android.graphics.Path
import android.graphics.RectF
import android.os.SystemClock
import android.view.MotionEvent
import android.view.View
import android.view.ViewGroup
import android.widget.FrameLayout
import android.widget.ImageView
import kotlin.math.abs
import kotlin.math.hypot
import kotlin.math.sin
import kotlin.random.Random

/** A felébresztett barlangi szörny: a következő Főoldal-megnyitáskor elszabadul. */
object MonsterRampage {
    @Volatile var armed = false
        private set
    fun arm() { armed = true }
    fun take(): Boolean { val a = armed; armed = false; return a }
}

/**
 * A SZÖRNY TOMBOL – az app fölött mászkál, és sorban MEGESZI AZ EGÉSZ APPOT (kártyákat, gombokat, fejlécet, ikonokat) (harap, morzsa repül, az ikon eltűnik).
 * Koppints rá sokszor, hogy elkergesd! Ha jóllakott, böfög egyet, és visszamászik a barlangjába; az ikonok
 * pár másodperc múlva visszanőnek. Semmi nem vész el: csak az ikonok láthatósága változik ideiglenesen.
 */
class MonsterOverlay(private val activity: Activity) : View(activity) {

    private val p = Paint(Paint.ANTI_ALIAS_FLAG)
    private val tp = Paint(Paint.ANTI_ALIAS_FLAG).apply { textAlign = Paint.Align.CENTER; isFakeBoldText = true }
    private val path = Path()
    private val rect = RectF()
    private val d = resources.displayMetrics.density

    private var x = 0f
    private var y = 0f
    private var dir = 1f
    private val size get() = 120f * d
    private val start = SystemClock.elapsedRealtime()
    private var last = 0L
    private var t = 0f

    private enum class St { ENTER, HUNT, CHOMP, FULL, FLEE, GONE }
    private var st = St.ENTER
    private var stAt = 0f
    private var target: View? = null
    private val eaten = ArrayList<View>()
    /** Repedések a képernyőn (x0,y0,x1,y1 … törött vonalak). */
    private val cracks = ArrayList<FloatArray>()
    private var hp = 10
    private var hitAt = -99f
    private var regrowAt = -1f
    private var say = ""
    private var sayAt = -99f
    private class Crumb(var x: Float, var y: Float, var vx: Float, var vy: Float, val t0: Float, val col: Int)
    private val crumbs = ArrayList<Crumb>()

    init { isClickable = false }

    override fun onSizeChanged(w: Int, h: Int, ow: Int, oh: Int) {
        if (x == 0f) { x = w / 2f; y = h + size }
    }

    /** Csak a szörnyre koppintást fogja meg; minden más átmegy az alatta lévő appra. */
    override fun onTouchEvent(e: MotionEvent): Boolean {
        if (st == St.GONE || st == St.FLEE) return false
        if (hypot(e.x - x, e.y - y) > size * 0.8f) return false
        if (e.action == MotionEvent.ACTION_DOWN) {
            hp--
            hitAt = t
            crumbs += Crumb(x, y, (Random.nextFloat() - 0.5f) * 400f, -300f, t, 0xFFFF4D4D.toInt())
            try { Haptics(activity).tick() } catch (ex: Throwable) { }
            if (hp <= 0) { set(St.FLEE); talk("JAJ! Bocsi!!"); restore(true) } else talk(listOf("AU!", "GRR!", "Hé!", "Még egy!", "NEM!").random())
        }
        return true
    }

    private fun set(s: St) { st = s; stAt = t }
    private fun talk(s: String) { say = s; sayAt = t }

    override fun onDraw(c: Canvas) {
        val now = SystemClock.elapsedRealtime()
        val dt = if (last == 0L) 0.016f else ((now - last) / 1000f).coerceIn(0f, 0.05f)
        last = now
        t = (now - start) / 1000f
        step(dt)
        drawCracks(c)
        drawCrumbs(c, dt)
        if (st == St.GONE && regrowAt > 0f) {
            tp.textSize = 26f * d; tp.color = 0xFFD71921.toInt()
            c.drawText("A SZÖRNY MEGETTE AZ APPOT", width / 2f, height * 0.45f, tp)
            tp.textSize = 15f * d; tp.color = 0xCCFFFFFF.toInt()
            c.drawText("…de már visszanő: ${(regrowAt - t).toInt().coerceAtLeast(0) + 1}", width / 2f, height * 0.45f + 30f * d, tp)
        }
        if (st != St.GONE) drawMonster(c)
        if (t - sayAt < 1.6f && say.isNotEmpty() && st != St.GONE) {
            tp.textSize = 18f * d
            val tw = tp.measureText(say)
            p.color = 0xF0FFFFFF.toInt()
            rect.set(x - tw / 2 - 10f * d, y - size - 30f * d, x + tw / 2 + 10f * d, y - size - 2f * d)
            c.drawRoundRect(rect, 12f * d, 12f * d, p)
            tp.color = 0xFF9B1D20.toInt()
            c.drawText(say, x, y - size - 10f * d, tp)
        }
        if (st == St.GONE && crumbs.isEmpty() && regrowAt < 0f) { detach(); return }
        postInvalidateOnAnimation()
    }

    private fun step(dt: Float) {
        val w = width.toFloat(); val h = height.toFloat()
        // visszanövés
        if (regrowAt > 0f && t >= regrowAt) { restore(true); regrowAt = -1f }
        when (st) {
            St.ENTER -> {
                y -= 260f * d * dt
                if (y < h * 0.75f) { set(St.HUNT); talk("ÉHES VAGYOK!") }
            }
            St.HUNT -> {
                val tg = target?.takeIf { it.isShown && it.alpha > 0.5f } ?: nextTarget()
                target = tg
                if (tg == null || eaten.size >= 80 || t - stAt > 75f && eaten.isNotEmpty()) { set(St.FULL); talk("BÖÖÖÖFF!!"); return }
                val (tx, ty) = centerOf(tg)
                val dx = tx - x; val dy = ty - y
                val dist = hypot(dx, dy)
                dir = if (dx >= 0) 1f else -1f
                val sp = 480f * d * dt
                if (dist < 30f * d) { set(St.CHOMP); crack(tx, ty) } else { x += dx / dist * minOf(sp, dist); y += dy / dist * minOf(sp, dist) }
            }
            St.CHOMP -> {
                val tg = target
                if (tg == null) { set(St.HUNT); return }
                val (tx, ty) = centerOf(tg)
                x += (tx - x) * 0.3f; y += (ty - y) * 0.3f
                val k = t - stAt
                // nagyobbat tovább rág; közben rázza az egész appot
                val dur = (0.5f + (tg.width * tg.height) / (d * d * 60_000f)).coerceIn(0.5f, 1.6f)
                tg.alpha = (1f - k / dur).coerceIn(0f, 1f)
                tg.scaleX = (1f - k / (dur * 1.6f)).coerceIn(0.2f, 1f); tg.scaleY = tg.scaleX
                tg.rotation = sin(t * 60f) * 4f
                shakeRoot((1f - k / dur).coerceIn(0f, 1f) * 6f * d)
                if (Random.nextFloat() < 0.5f) crumbs += Crumb(tx, ty, (Random.nextFloat() - 0.5f) * 500f, -Random.nextFloat() * 400f, t,
                    listOf(0xFFF4F4F4.toInt(), 0xFFD71921.toInt(), 0xFF8A8A8A.toInt()).random())
                if (k > dur) {
                    tg.alpha = 0f; tg.rotation = 0f
                    shakeRoot(0f)
                    eaten += tg
                    target = null
                    if (Random.nextFloat() < 0.4f) talk(listOf("NYAMM!", "Finom ikon!", "MÉG!", "Hamm!").random())
                    try { Haptics(activity).tick() } catch (ex: Throwable) { }
                    set(St.HUNT)
                }
            }
            St.FULL -> {
                // böfög, aztán lemászik a képernyő aljára – az app romokban marad egy darabig
                if (t - stAt > 1.4f) y += 160f * d * dt
                if (y > h + size * 1.5f) { set(St.GONE); regrowAt = t + 6f }
            }
            St.FLEE -> {
                y += 520f * d * dt
                x += dir * 120f * d * dt
                if (y > h + size * 1.5f) set(St.GONE)
            }
            St.GONE -> {}
        }
        x = x.coerceIn(size * 0.5f, w - size * 0.5f)
    }

    /**
     * A következő falat: a legközelebbi „darab” az appból – egész kártya, gomb, fejléc, felirat vagy ikon.
     * Ami kártyaméretű, azt egyben eszi meg (nem bontja tovább); a nagy tárolókba belenyúl.
     */
    private fun nextTarget(): View? {
        val root = activity.findViewById<ViewGroup>(android.R.id.content) ?: return null
        val list = ArrayList<View>()
        val sw = width.toFloat()
        fun walk(v: View, depth: Int) {
            if (v === this || !v.isShown || v.alpha < 0.5f) return
            val wd = v.width / d; val hd = v.height / d
            val (_, cy) = centerOf(v)
            val onScreen = cy in 20f * d..(height - 20f * d)
            val bite = depth >= 2 && wd >= 24f && hd in 20f..420f && v.width < sw * 1.02f
            if (bite && onScreen) { list += v; return }
            if (v is ViewGroup) for (i in 0 until v.childCount) walk(v.getChildAt(i), depth + 1)
            else if (onScreen && depth >= 2 && wd in 10f..420f && hd in 10f..420f) list += v
        }
        walk(root, 0)
        return list.minByOrNull { val (cx, cy) = centerOf(it); hypot(cx - x, cy - y) }
    }

    /** Az egész app megremeg (a tartalom eltolásával). */
    private fun shakeRoot(amp: Float) {
        val root = activity.findViewById<ViewGroup>(android.R.id.content)?.getChildAt(0) ?: return
        root.translationX = if (amp > 0f) (Random.nextFloat() - 0.5f) * 2f * amp else 0f
        root.translationY = if (amp > 0f) (Random.nextFloat() - 0.5f) * 2f * amp else 0f
    }

    /** Repedés indul a harapás helyéről. */
    private fun crack(cx: Float, cy: Float) {
        repeat(2) {
            var px = cx; var py = cy
            var ang = Random.nextFloat() * 6.283f
            val pts = ArrayList<Float>()
            pts += px; pts += py
            repeat(6 + Random.nextInt(5)) {
                ang += (Random.nextFloat() - 0.5f) * 1.2f
                val len = (14f + Random.nextFloat() * 30f) * d
                px += kotlin.math.cos(ang) * len; py += kotlin.math.sin(ang) * len
                pts += px; pts += py
            }
            cracks += pts.toFloatArray()
        }
        if (cracks.size > 80) cracks.removeAt(0)
    }

    private val loc = IntArray(2)
    private val myLoc = IntArray(2)
    private fun centerOf(v: View): Pair<Float, Float> {
        v.getLocationInWindow(loc); getLocationInWindow(myLoc)
        return (loc[0] - myLoc[0] + v.width / 2f) to (loc[1] - myLoc[1] + v.height / 2f)
    }

    /** Minden visszanő (kis „pukkanással”), a repedések eltűnnek. */
    fun restore(pop: Boolean) {
        cracks.clear()
        shakeRoot(0f)
        for (v in eaten) {
            v.alpha = 1f; v.scaleX = 1f; v.scaleY = 1f; v.rotation = 0f
            if (pop) try { v.scaleX = 0.4f; v.scaleY = 0.4f; v.animate().scaleX(1f).scaleY(1f).setDuration(350).start() } catch (e: Throwable) { v.scaleX = 1f; v.scaleY = 1f }
        }
        eaten.clear()
        target?.let { it.alpha = 1f; it.scaleX = 1f; it.scaleY = 1f; it.rotation = 0f }
        target = null
    }

    private fun detach() {
        restore(false)
        (parent as? ViewGroup)?.removeView(this)
    }

    override fun onDetachedFromWindow() {
        restore(false)
        super.onDetachedFromWindow()
    }

    private fun drawCracks(c: Canvas) {
        p.style = Paint.Style.STROKE; p.strokeWidth = 2.2f * d; p.strokeCap = Paint.Cap.ROUND
        for (cr in cracks) {
            p.color = 0xDD000000.toInt()
            path.reset(); path.moveTo(cr[0], cr[1])
            var i = 2
            while (i + 1 < cr.size) { path.lineTo(cr[i], cr[i + 1]); i += 2 }
            c.drawPath(path, p)
            p.color = 0x55FFFFFF; p.strokeWidth = 0.8f * d
            c.save(); c.translate(1.5f * d, 1.5f * d); c.drawPath(path, p); c.restore()
            p.strokeWidth = 2.2f * d
        }
        p.style = Paint.Style.FILL
    }

    private fun drawCrumbs(c: Canvas, dt: Float) {
        val it = crumbs.iterator()
        while (it.hasNext()) {
            val q = it.next()
            val age = t - q.t0
            if (age > 1.2f) { it.remove(); continue }
            q.vy += 1400f * dt; q.x += q.vx * dt; q.y += q.vy * dt
            p.color = (((1f - age / 1.2f) * 255).toInt() shl 24) or (q.col and 0xFFFFFF)
            c.drawRect(q.x - 3f * d, q.y - 3f * d, q.x + 3f * d, q.y + 3f * d, p)
        }
    }

    private fun drawMonster(c: Canvas) {
        val s = size
        val hurt = t - hitAt < 0.25f
        val chomp = st == St.CHOMP
        val mouth = if (chomp) 0.5f + 0.5f * sin(t * 30f) else if (st == St.FULL) 0.8f else 0.2f
        val bob = sin(t * 12f) * 3f * d
        val cx = x + (if (hurt) (Random.nextFloat() - 0.5f) * 10f * d else 0f)
        val cy = y + bob
        c.save(); c.scale(dir, 1f, cx, cy)
        // tüskék
        p.color = 0xFF2E1A3D.toInt()
        for (k in 0 until 5) {
            val sx = cx - s * 0.5f + k * s * 0.22f
            path.reset(); path.moveTo(sx - s * 0.08f, cy - s * 0.35f); path.lineTo(sx, cy - s * 0.62f + abs(k - 2) * s * 0.06f); path.lineTo(sx + s * 0.08f, cy - s * 0.35f); path.close(); c.drawPath(path, p)
        }
        // test
        p.color = if (hurt) 0xFFB03050.toInt() else 0xFF3F2453.toInt()
        rect.set(cx - s * 0.62f, cy - s * 0.45f, cx + s * 0.62f, cy + s * 0.45f); c.drawOval(rect, p)
        p.color = 0xFF5B3A70.toInt()
        rect.set(cx - s * 0.38f, cy - s * 0.05f, cx + s * 0.38f, cy + s * 0.4f); c.drawOval(rect, p)
        // lábak
        p.color = 0xFF2E1A3D.toInt()
        val lg = sin(t * 18f) * s * 0.08f
        rect.set(cx - s * 0.45f, cy + s * 0.3f + lg, cx - s * 0.2f, cy + s * 0.55f + lg); c.drawOval(rect, p)
        rect.set(cx + s * 0.2f, cy + s * 0.3f - lg, cx + s * 0.45f, cy + s * 0.55f - lg); c.drawOval(rect, p)
        // száj
        p.color = 0xFF1A0006.toInt()
        rect.set(cx + s * 0.05f, cy - s * 0.12f * mouth, cx + s * 0.6f, cy + s * 0.28f * mouth + s * 0.05f); c.drawOval(rect, p)
        p.color = 0xFFFFFFFF.toInt()
        for (k in 0 until 4) {
            val tx = cx + s * 0.14f + k * s * 0.11f
            path.reset(); path.moveTo(tx - s * 0.04f, cy - s * 0.1f * mouth); path.lineTo(tx, cy + s * 0.05f); path.lineTo(tx + s * 0.04f, cy - s * 0.1f * mouth); path.close(); c.drawPath(path, p)
        }
        // szem
        p.color = 0xFFFFD000.toInt(); c.drawCircle(cx + s * 0.18f, cy - s * 0.22f, s * 0.13f, p)
        p.color = 0xFF000000.toInt()
        rect.set(cx + s * 0.18f, cy - s * 0.32f, cx + s * 0.26f, cy - s * 0.12f); c.drawOval(rect, p)
        p.color = 0xFFFFD000.toInt(); c.drawCircle(cx - s * 0.12f, cy - s * 0.24f, s * 0.1f, p)
        p.color = 0xFF000000.toInt()
        rect.set(cx - s * 0.12f, cy - s * 0.31f, cx - s * 0.06f, cy - s * 0.17f); c.drawOval(rect, p)
        c.restore()
        // életerő pöttyök
        for (k in 0 until 10) {
            p.color = if (k < hp) 0xFFFF4D4D.toInt() else 0x44FFFFFF
            c.drawCircle(cx - 4.5f * 9f * d + k * 9f * d, cy + s * 0.62f, 3f * d, p)
        }
    }

    companion object {
        /** Ha fel van ébresztve, rászabadítja az oldalra. */
        fun maybeAttach(a: Activity) {
            if (!MonsterRampage.take()) return
            val decor = a.window.decorView as? FrameLayout ?: return
            decor.post {
                decor.addView(MonsterOverlay(a), FrameLayout.LayoutParams(FrameLayout.LayoutParams.MATCH_PARENT, FrameLayout.LayoutParams.MATCH_PARENT))
            }
        }
    }
}
