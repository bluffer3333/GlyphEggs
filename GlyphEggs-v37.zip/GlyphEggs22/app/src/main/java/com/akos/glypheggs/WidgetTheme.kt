package com.akos.glypheggs

import android.content.Context
import android.content.res.ColorStateList
import android.graphics.Bitmap
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.RemoteViews
import android.widget.TextView

/**
 * A widgetek a választott app-témát követik.
 *
 * Az alap Nothing-widgetek fekete-fehér-pirosak. Neon témánál minden widget-kép „átfestődik”:
 * a fekete a téma hátterére, a fehér/szürke a téma szövegszínére (az árnyalatok megmaradnak),
 * a piros a téma kiemelő színére. A widget-lap háttere és a feliratok is a téma színeit kapják.
 * Témaváltáskor az összes widget frissül ([Widgets.updateAll]).
 */
class WidgetTheme private constructor(val t: NeonTheme?) {
    val isDefault get() = t == null

    /** A widget-lap háttere (átlátszatlan). */
    val bg: Int = if (t == null) 0xFF000000.toInt() else opaque(BeaconRadar.blend(t.card or 0xFF000000.toInt(), t.bottom, 0.25f))
    val text: Int = t?.text ?: 0xFFF4F4F4.toInt()
    val accent: Int = t?.a ?: 0xFFD71921.toInt()
    val accent2: Int = t?.b ?: 0xFFF4F4F4.toInt()

    /** A Beacon radar korongja (felül, alul) és pontszínei. */
    val beaconDisc: Pair<Int, Int> = if (t == null) Alu.TOP to Alu.BOTTOM
        else BeaconRadar.blend(bg, t.line, 0.35f) to bg
    val beaconPal: BeaconRadar.Pal = if (t == null) BeaconRadar.ALU
        else BeaconRadar.Pal(BeaconRadar.blend(bg, t.unlit, 0.9f).let { BeaconRadar.blend(it, t.sub, 0.25f) }, t.b, t.a)

    /** Egy szín átfestése: fekete → háttér, szürkék → szöveg árnyalatai, piros → kiemelés. */
    fun map(col: Int): Int {
        if (t == null) return col
        val a = col ushr 24
        val r = col shr 16 and 0xFF; val g = col shr 8 and 0xFF; val b = col and 0xFF
        val gray = ((g + b) / 2f / 244f).coerceIn(0f, 1f)
        val red = ((r - maxOf(g, b)) / 182f).coerceIn(0f, 1f)
        val amber = if (r > 200 && g in 120..200 && b < 60) 1f else 0f // a Távíró-borostyán (Morze widget)
        var out = BeaconRadar.blend(bg, text, gray)
        if (red > 0f) out = BeaconRadar.blend(out, accent, red)
        if (amber > 0f) out = BeaconRadar.blend(out, accent2, amber)
        return (a shl 24) or (out and 0xFFFFFF)
    }

    /** Egy widget-kép átfestése (az alap témánál változatlan). */
    fun recolor(src: Bitmap): Bitmap {
        if (t == null) return src
        val w = src.width; val h = src.height
        val px = IntArray(w * h)
        src.getPixels(px, 0, w, 0, 0, w, h)
        val cache = HashMap<Int, Int>()
        for (i in px.indices) {
            val c = px[i]
            if (c ushr 24 == 0) continue
            px[i] = cache.getOrPut(c) { map(c) }
        }
        val out = Bitmap.createBitmap(w, h, Bitmap.Config.ARGB_8888)
        out.setPixels(px, 0, w, 0, 0, w, h)
        return out
    }

    /** Csak a fekete hátteret cseréli a téma hátterére (a színes kitűzőképeknél). */
    fun recolorBg(src: Bitmap): Bitmap {
        if (t == null) return src
        val w = src.width; val h = src.height
        val px = IntArray(w * h)
        src.getPixels(px, 0, w, 0, 0, w, h)
        for (i in px.indices) if (px[i] == 0xFF000000.toInt()) px[i] = bg
        val out = Bitmap.createBitmap(w, h, Bitmap.Config.ARGB_8888)
        out.setPixels(px, 0, w, 0, 0, w, h)
        return out
    }

    companion object {
        fun of(c: Context) = WidgetTheme(if (Settings.widgetThemed(c)) NeonThemes.current(c) else null)

        private fun opaque(c: Int) = c or 0xFF000000.toInt()

        /** Elrendezésenként: a gyökér id-je és a feliratok (id, eredeti szín). */
        private val layoutInfo = HashMap<Int, Pair<Int, List<Pair<Int, Int>>>>()

        private fun info(c: Context, layout: Int): Pair<Int, List<Pair<Int, Int>>> = layoutInfo.getOrPut(layout) {
            try {
                val root = LayoutInflater.from(c).inflate(layout, null)
                val texts = ArrayList<Pair<Int, Int>>()
                fun walk(v: View) {
                    if (v is TextView && v.id != View.NO_ID) texts += v.id to v.currentTextColor
                    if (v is ViewGroup) for (i in 0 until v.childCount) walk(v.getChildAt(i))
                }
                walk(root)
                root.id to texts
            } catch (e: Throwable) { View.NO_ID to emptyList() }
        }

        /**
         * Az elküldés előtti utolsó lépés: a lap háttere és a feliratok színe a témából.
         * (A képeket a [themed] festi át, ahol beállítják őket.)
         */
        fun apply(c: Context, v: RemoteViews): RemoteViews {
            val wt = of(c)
            if (wt.isDefault) return v
            val (root, texts) = info(c, v.layoutId)
            try {
                if (root != View.NO_ID && v.layoutId != R.layout.widget_beacon_on && v.layoutId != R.layout.widget_beacon_off)
                    v.setColorStateList(root, "setBackgroundTintList", ColorStateList.valueOf(wt.bg))
                for ((id, col) in texts) v.setTextColor(id, wt.map(col))
            } catch (e: Throwable) { }
            return v
        }
    }
}

/** Kép beállítása a widgeten, a választott téma színeire festve. */
fun RemoteViews.themed(c: Context, id: Int, bmp: Bitmap) = setImageViewBitmap(id, WidgetTheme.of(c).recolor(bmp))
