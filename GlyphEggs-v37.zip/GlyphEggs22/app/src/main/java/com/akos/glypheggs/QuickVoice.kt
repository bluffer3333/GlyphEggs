package com.akos.glypheggs

import android.Manifest
import android.app.Activity
import android.content.ClipData
import android.content.ClipboardManager
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.graphics.Canvas
import android.graphics.Paint
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.speech.RecognitionListener
import android.speech.RecognizerIntent
import android.speech.SpeechRecognizer
import android.view.Gravity
import android.view.View
import android.view.ViewGroup.LayoutParams.MATCH_PARENT
import android.view.ViewGroup.LayoutParams.WRAP_CONTENT
import android.widget.FrameLayout
import android.widget.LinearLayout
import android.widget.TextView
import android.widget.Toast
import kotlin.math.cos
import kotlin.math.hypot
import kotlin.math.sin

/** Mit csináljon az Asszisztens widget koppintásra (AI app módban). */
enum class WidgetTap(val title: String, val desc: String) {
    VOICE("Azonnal hangüzenet", "Koppintásra rögtön veszi, amit mondasz, és szövegként átküldi az AI-appnak (a LED-ek is követik)"),
    ASSISTANT("Alap asszisztens hangmódban", "A telefon alapértelmezett asszisztensét nyitja meg rögtön hallgatva (ha a Claude / Gemini az alap asszisztensed)"),
    OPEN("Csak az AI-app megnyitása", "Megnyitja az appot, a hangmódot te indítod")
}

/**
 * GYORS HANGÜZENET – az Asszisztens widgetről. Koppintásra a kezdőképernyő fölött rögtön elindul a felvétel
 * (pontmátrixos, a hangodra lüktető kör + élő felirat). Ha befejezted, a kimondott szöveget átadja a választott
 * AI-appnak (megosztásként, új üzenetként), és bekapcsolja a LED-követést, így a válasz hangjára villog a hátlap.
 * Ha az app nem fogad megosztott szöveget, vágólapra teszi, és megnyitja az appot.
 */
class QuickVoiceActivity : Activity() {

    private lateinit var orb: VoiceOrb
    private lateinit var heard: TextView
    private lateinit var status: TextView
    private lateinit var doneBtn: TextView
    private var recognizer: SpeechRecognizer? = null
    private var lastText = ""
    private var finished = false
    private val main = Handler(Looper.getMainLooper())

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val dim = FrameLayout(this).apply {
            setBackgroundColor(0x99000000.toInt())
            setOnClickListener { cancel() }
        }
        val sheet = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            gravity = Gravity.CENTER_HORIZONTAL
            background = rounded(0xF20A0A0A.toInt(), dp(30).toFloat(), 0xFF2A2A2A.toInt(), dp(1))
            setPadding(dp(22), dp(22), dp(22), dp(18))
            setOnClickListener { }
        }
        sheet.addView(text("HANGÜZENET · ${Settings.aiName(this).uppercase()}", 11f, 0xFF8A8A8A.toInt(), Ui.medium).apply { letterSpacing = 0.14f })
        orb = VoiceOrb(this)
        sheet.addView(orb, LinearLayout.LayoutParams(dp(150), dp(150)).apply { topMargin = dp(10) })
        status = text("Mondd…", 22f, 0xFFF4F4F4.toInt()).apply { typeface = Widgets.dotoFace(this@QuickVoiceActivity); gravity = Gravity.CENTER }
        sheet.addView(status, LinearLayout.LayoutParams(MATCH_PARENT, WRAP_CONTENT).apply { topMargin = dp(8) })
        heard = text("", 15f, 0xFFCFCFCF.toInt()).apply { gravity = Gravity.CENTER; setLineSpacing(0f, 1.15f); maxLines = 5 }
        sheet.addView(heard, LinearLayout.LayoutParams(MATCH_PARENT, WRAP_CONTENT).apply { topMargin = dp(6) })
        val btns = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
        btns.addView(text("Mégse", 15f, 0xFFF4F4F4.toInt(), Ui.medium).apply {
            gravity = Gravity.CENTER
            background = rounded(0xFF1E1E1E.toInt(), dp(24).toFloat())
            setOnClickListener { cancel() }
        }, LinearLayout.LayoutParams(0, dp(50), 1f).apply { marginEnd = dp(6) })
        doneBtn = text("■  Kész, küldés", 15f, 0xFFFFFFFF.toInt(), Ui.medium).apply {
            gravity = Gravity.CENTER
            background = rounded(Ui.RED, dp(24).toFloat())
            setOnClickListener { if (lastText.isNotBlank()) send(lastText) else recognizer?.stopListening() }
        }
        btns.addView(doneBtn, LinearLayout.LayoutParams(0, dp(50), 1.4f))
        sheet.addView(btns, LinearLayout.LayoutParams(MATCH_PARENT, WRAP_CONTENT).apply { topMargin = dp(16) })
        dim.addView(sheet, FrameLayout.LayoutParams(MATCH_PARENT, WRAP_CONTENT, Gravity.BOTTOM).apply {
            leftMargin = dp(12); rightMargin = dp(12); bottomMargin = dp(28)
        })
        setContentView(dim)

        if (checkSelfPermission(Manifest.permission.RECORD_AUDIO) != PackageManager.PERMISSION_GRANTED) {
            requestPermissions(arrayOf(Manifest.permission.RECORD_AUDIO), 31)
        } else listen()
    }

    override fun onRequestPermissionsResult(requestCode: Int, permissions: Array<String>, grantResults: IntArray) {
        if (grantResults.firstOrNull() == PackageManager.PERMISSION_GRANTED) listen()
        else { status.text = "Nincs mikrofon"; heard.text = "Engedélyezd a mikrofont a hangüzenethez" }
    }

    private fun listen() {
        if (!SpeechRecognizer.isRecognitionAvailable(this)) {
            status.text = "Nem elérhető"
            heard.text = "A telefonon nincs beszédfelismerő. Az AI-appot nyitom meg."
            main.postDelayed({ ClaudeLink.start(this); finish() }, 1_500)
            return
        }
        // A szolgáltatás mikrofonja (Beacon, fújás) erre az időre elenged
        try { startService(Intent(this, SimonService::class.java).setAction(SimonService.ACTION_MIC_HOLD).putExtra(SimonService.EXTRA_HOLD, true)) } catch (t: Throwable) { }
        // A LED-ek hallgatás közben a hangerőt mutatják
        TalkBus.state.value = TalkState.LISTENING
        if (Settings.assistantLeds(this)) try {
            startForegroundService(Intent(this, SimonService::class.java).setAction(SimonService.ACTION_TALK))
        } catch (t: Throwable) { }
        Widgets.updateAssistant(this)
        val rec = recognizer ?: SpeechRecognizer.createSpeechRecognizer(this).also {
            it.setRecognitionListener(listener)
            recognizer = it
        }
        val i = Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH)
            .putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM)
            .putExtra(RecognizerIntent.EXTRA_LANGUAGE, "hu-HU")
            .putExtra(RecognizerIntent.EXTRA_PARTIAL_RESULTS, true)
            // hosszabb hangüzenet is elférjen: a rövid szünetek ne zárják le
            .putExtra(RecognizerIntent.EXTRA_SPEECH_INPUT_COMPLETE_SILENCE_LENGTH_MILLIS, 2_500L)
            .putExtra(RecognizerIntent.EXTRA_SPEECH_INPUT_POSSIBLY_COMPLETE_SILENCE_LENGTH_MILLIS, 2_000L)
        status.text = "Mondd…"
        orb.listening = true
        rec.startListening(i)
    }

    private val listener = object : RecognitionListener {
        override fun onReadyForSpeech(params: Bundle?) { status.text = "Hallgatlak…" }
        override fun onBeginningOfSpeech() {}
        override fun onRmsChanged(rmsdB: Float) {
            val lv = ((rmsdB + 2f) / 12f).coerceIn(0f, 1f)
            orb.level = lv
            TalkBus.micLevel = lv
        }
        override fun onBufferReceived(buffer: ByteArray?) {}
        override fun onEndOfSpeech() { orb.level = 0f; TalkBus.micLevel = 0f; status.text = "…" }
        override fun onError(error: Int) {
            orb.listening = false
            if (lastText.isNotBlank()) { send(lastText); return }
            status.text = "Nem hallottam"
            heard.text = when (error) {
                SpeechRecognizer.ERROR_NETWORK, SpeechRecognizer.ERROR_NETWORK_TIMEOUT -> "Nincs internet a beszédfelismeréshez"
                SpeechRecognizer.ERROR_INSUFFICIENT_PERMISSIONS -> "Nincs mikrofon-engedély"
                else -> "Koppints a gombra, és próbáld újra"
            }
            doneBtn.text = "●  Újra"
            doneBtn.setOnClickListener { doneBtn.text = "■  Kész, küldés"; doneBtn.setOnClickListener { if (lastText.isNotBlank()) send(lastText) else recognizer?.stopListening() }; listen() }
            endListening()
        }
        override fun onResults(results: Bundle?) {
            val t = results?.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION)?.firstOrNull()?.trim().orEmpty()
            if (t.isNotBlank()) lastText = t
            if (lastText.isNotBlank()) send(lastText) else onError(SpeechRecognizer.ERROR_NO_MATCH)
        }
        override fun onPartialResults(partialResults: Bundle?) {
            partialResults?.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION)?.firstOrNull()?.let {
                if (it.isNotBlank()) { lastText = it; heard.text = "„$it”" }
            }
        }
        override fun onEvent(eventType: Int, params: Bundle?) {}
    }

    private fun endListening() {
        TalkBus.micLevel = 0f
        if (TalkBus.state.value == TalkState.LISTENING) TalkBus.state.value = TalkState.IDLE
        try { startService(Intent(this, SimonService::class.java).setAction(SimonService.ACTION_MIC_HOLD).putExtra(SimonService.EXTRA_HOLD, false)) } catch (t: Throwable) { }
        Widgets.updateAssistant(this)
    }

    /** A kész szöveg: átadja az AI-appnak, és indul a LED-követés. */
    private fun send(text: String) {
        if (finished) return
        finished = true
        try { recognizer?.cancel() } catch (t: Throwable) { }
        endListening()
        orb.listening = false
        status.text = "Küldöm ✓"
        heard.text = "„$text”"
        GameStats.count(this, "voice_msg")
        main.postDelayed({
            ClaudeLink.startLeds(this)
            if (!QuickVoice.shareTo(this, text)) {
                Toast.makeText(this, "Bemásoltam – illeszd be az üzenetmezőbe", Toast.LENGTH_LONG).show()
            }
            finish()
        }, 450)
    }

    private fun cancel() {
        finished = true
        try { recognizer?.cancel() } catch (t: Throwable) { }
        endListening()
        finish()
    }

    override fun onDestroy() {
        try { recognizer?.destroy() } catch (t: Throwable) { }
        recognizer = null
        if (!finished) endListening()
        super.onDestroy()
    }
}

object QuickVoice {
    /**
     * A szöveg átadása a választott AI-appnak megosztásként (új üzenet, előre kitöltve).
     * Ha nem fogadja, vágólapra teszi, és megnyitja az appot. true = megosztással ment.
     */
    fun shareTo(c: Context, text: String): Boolean {
        val pkg = Settings.aiPackage(c)
        val send = Intent(Intent.ACTION_SEND).setType("text/plain").putExtra(Intent.EXTRA_TEXT, text).setPackage(pkg)
            .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
        // Nem kérdezzük előre (csomag-láthatóság): megpróbáljuk; ha nincs ilyen képernyője, vágólap + megnyitás
        try { c.startActivity(send); return true } catch (t: Throwable) { }
        try {
            c.getSystemService(ClipboardManager::class.java).setPrimaryClip(ClipData.newPlainText("Hangüzenet", text))
        } catch (t: Throwable) { }
        ClaudeLink.open(c)
        return false
    }

    /** A widget koppintás célja a beállítás szerint. */
    fun widgetIntent(c: Context): Intent = when {
        Settings.assistantUseApi(c) -> Intent(c, AssistantActivity::class.java).putExtra(AssistantActivity.EXTRA_LISTEN, true)
        Settings.widgetTap(c) == WidgetTap.VOICE -> Intent(c, QuickVoiceActivity::class.java)
        Settings.widgetTap(c) == WidgetTap.ASSISTANT -> Intent(c, AssistantVoiceLaunchActivity::class.java)
        else -> Intent(c, ClaudeLaunchActivity::class.java)
    }
}

/** Az alap asszisztens megnyitása rögtön hallgatva (VOICE_COMMAND), és a LED-követés. */
class AssistantVoiceLaunchActivity : Activity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        ClaudeLink.startLeds(this)
        val ok = try {
            startActivity(Intent(Intent.ACTION_VOICE_COMMAND).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)); true
        } catch (t: Throwable) { false }
        if (!ok) ClaudeLink.open(this)
        finish()
    }
}

/** Pontmátrixos kör, ami a hangodra lüktet (a hangüzenet ablakban). */
class VoiceOrb(context: Context) : View(context) {
    var level = 0f
    var listening = false
    private var smooth = 0f
    private val p = Paint(Paint.ANTI_ALIAS_FLAG)

    override fun onDraw(canvas: Canvas) {
        smooth += (level - smooth) * 0.3f
        val w = width.toFloat(); val h = height.toFloat()
        val cx = w / 2; val cy = h / 2
        val r = minOf(w, h) / 2f * 0.95f
        val step = r / 8f
        val t = System.currentTimeMillis() / 1000f
        for (iy in -8..8) for (ix in -8..8) {
            val x = ix * step; val y = iy * step
            val d = hypot(x, y) / r
            if (d > 1f) continue
            // A hang hullámként fut kifelé; csendben lassú „lélegzés”
            val wave = 0.5f + 0.5f * sin(d * 9f - t * 7f)
            val reach = if (listening) 0.25f + smooth * 0.8f else 0.12f
            val on = d < reach
            val a = when {
                d < 0.14f && listening -> 1f
                on -> 0.45f + 0.55f * wave
                else -> 0.14f
            }
            p.color = if (d < 0.14f && listening) Ui.RED
            else (((a * 255).toInt() shl 24) or 0xF4F4F4)
            canvas.drawCircle(cx + x, cy + y, step * 0.27f * (if (on) 1.15f else 1f), p)
        }
        // körbefutó piros „mutató”, amíg hallgat
        if (listening) {
            val ang = t * 2.4f
            p.color = Ui.RED
            for (k in 3..7) {
                val rr = step * k
                canvas.drawCircle(cx + rr * sin(ang), cy - rr * cos(ang), step * 0.2f, p)
            }
        }
        postInvalidateOnAnimation()
    }
}
