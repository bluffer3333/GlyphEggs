package com.akos.glypheggs

import android.app.Activity
import android.app.AlertDialog
import android.content.Intent
import android.os.Bundle
import android.view.Gravity
import android.view.MotionEvent
import android.view.View
import android.view.ViewGroup.LayoutParams.MATCH_PARENT
import android.view.ViewGroup.LayoutParams.WRAP_CONTENT
import android.widget.EditText
import android.widget.FrameLayout
import android.widget.HorizontalScrollView
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView
import kotlinx.coroutines.Job
import kotlinx.coroutines.MainScope
import kotlinx.coroutines.cancel
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch

/**
 * Glyph Stúdió: saját LED-animáció szerkesztése. A hátlap képén koppintással / húzással kapcsolod
 * a zónákat; alul a képkockák sora; képkockánként állítható idő; előnézet a képernyőn és a hátlapon.
 */
class StudioActivity : Activity() {

    private val scope = MainScope()
    private lateinit var root: LinearLayout
    private lateinit var canvasView: GlyphMapView
    private lateinit var strip: LinearLayout
    private lateinit var durText: TextView
    private lateinit var titleText: TextView
    private lateinit var infoText: TextView
    private lateinit var playBtn: TextView
    private val loopPills = mutableListOf<TextView>()

    private lateinit var anim: StudioAnim
    private var cur = 0
    private var previewJob: Job? = null
    /** Húzás közben: true = festés (bekapcsol), false = radír. */
    private var paint = true
    private var lastZone: Int? = null

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        darkWindow()
        val list = StudioStore.all(this)
        anim = StudioStore.favorite(this) ?: list.firstOrNull() ?: Templates.make("Üres")!!.also { StudioStore.upsert(this, it) }
        root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(15), 0, dp(15), dp(30))
        }
        val scroll = ScrollView(this).apply {
            background = Ui.pageBg()
            isVerticalScrollBarEnabled = false
            addView(root, FrameLayout.LayoutParams(MATCH_PARENT, WRAP_CONTENT))
            padForSystemBars()
        }
        setContentView(scroll)
        build()
    }

    private fun save() = StudioStore.upsert(this, anim)
    private fun frame() = anim.frames[cur]

    private fun pill(label: String, sel: Boolean = false, onClick: () -> Unit): TextView = text(label, 13.5f, if (sel) Ui.DARK_TEXT else Ui.TEXT).apply {
        gravity = Gravity.CENTER
        background = rounded(if (sel) Ui.LIGHT else Ui.CARD, dp(22).toFloat())
        setOnClickListener { onClick() }
    }

    private fun row(vararg views: View, height: Int = 46): LinearLayout = LinearLayout(this).apply {
        orientation = LinearLayout.HORIZONTAL
        views.forEachIndexed { i, v -> addView(v, LinearLayout.LayoutParams(0, dp(height), 1f).apply { if (i < views.size - 1) marginEnd = dp(5) }) }
    }

    private fun build() {
        root.removeAllViews()
        loopPills.clear()
        val h = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
            setPadding(dp(7), dp(28), 0, dp(6))
        }
        h.addView(ImageView(this).apply { setImageResource(R.drawable.ic_back); setColorFilter(Ui.TEXT); setOnClickListener { finish() } },
            LinearLayout.LayoutParams(dp(24), dp(24)))
        h.addView(text("Glyph Stúdió", 26f).apply { setPadding(dp(30), 0, 0, 0) })
        root.addView(h)

        // Animáció választó
        val sel = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
            background = rounded(Ui.CARD, dp(22).toFloat())
            setPadding(dp(18), dp(12), dp(14), dp(12))
            setOnClickListener { chooseAnim() }
        }
        val st = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        st.addView(text("ANIMÁCIÓ", 10.5f, Ui.SUB, Ui.medium))
        titleText = text("", 18f)
        st.addView(titleText)
        sel.addView(st, LinearLayout.LayoutParams(0, WRAP_CONTENT, 1f))
        sel.addView(text("Váltás  ›", 14f, Ui.SUB))
        root.addView(sel, LinearLayout.LayoutParams(MATCH_PARENT, WRAP_CONTENT).apply { topMargin = dp(14) })
        root.addView(row(
            pill(if (StudioStore.favoriteId(this) == anim.id) "★ Kedvenc" else "☆ Legyen kedvenc", StudioStore.favoriteId(this) == anim.id) {
                StudioStore.setFavorite(this, anim.id); build()
            },
            pill("Átnevezés") { rename() },
            pill("Törlés") { deleteAnim() }
        ), LinearLayout.LayoutParams(MATCH_PARENT, WRAP_CONTENT).apply { topMargin = dp(6) })

        // A vászon: a hátlap képe
        val box = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            gravity = Gravity.CENTER_HORIZONTAL
            background = rounded(Ui.BG, dp(24).toFloat(), Ui.LINE, dp(1.5f))
            setPadding(dp(10), dp(12), dp(10), dp(10))
        }
        canvasView = GlyphMapView(this).apply { unlitColor = 0xFF353535.toInt() }
        canvasView.setOnTouchListener { _, ev -> onCanvasTouch(ev); true }
        box.addView(canvasView, LinearLayout.LayoutParams(MATCH_PARENT, dp(380)))
        infoText = text("", 12.5f, Ui.SUB).apply { gravity = Gravity.CENTER; setPadding(0, dp(8), 0, 0) }
        box.addView(infoText, LinearLayout.LayoutParams(MATCH_PARENT, WRAP_CONTENT))
        root.addView(box, LinearLayout.LayoutParams(MATCH_PARENT, WRAP_CONTENT).apply { topMargin = dp(12) })

        // Eszközök
        root.addView(row(
            pill("Mind be") { frame().zones.clear(); frame().zones += Zones.ALL.toList(); changed() },
            pill("Mind ki") { frame().zones.clear(); changed() },
            pill("Fordít") { val inv = Zones.ALL.filter { it !in frame().zones }; frame().zones.clear(); frame().zones += inv; changed() },
            pill("Előző") {
                if (cur > 0) { frame().zones.clear(); frame().zones += anim.frames[cur - 1].zones; changed() }
            }
        ), LinearLayout.LayoutParams(MATCH_PARENT, WRAP_CONTENT).apply { topMargin = dp(8) })

        // Képkockák
        root.addView(sectionTitle("Képkockák"))
        strip = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
        val hs = HorizontalScrollView(this).apply {
            isHorizontalScrollBarEnabled = false
            addView(strip, FrameLayout.LayoutParams(WRAP_CONTENT, WRAP_CONTENT))
        }
        root.addView(hs, LinearLayout.LayoutParams(MATCH_PARENT, WRAP_CONTENT))
        root.addView(row(
            pill("+ Új") { anim.frames.add(cur + 1, StudioFrame(mutableSetOf(), frame().ms)); cur++; changed(true) },
            pill("Másolat") { anim.frames.add(cur + 1, frame().copy()); cur++; changed(true) },
            pill("◀") { if (cur > 0) { val f = anim.frames.removeAt(cur); cur--; anim.frames.add(cur, f); changed(true) } },
            pill("▶") { if (cur < anim.frames.size - 1) { val f = anim.frames.removeAt(cur); cur++; anim.frames.add(cur, f); changed(true) } },
            pill("✕") { if (anim.frames.size > 1) { anim.frames.removeAt(cur); cur = cur.coerceAtMost(anim.frames.size - 1); changed(true) } }
        ), LinearLayout.LayoutParams(MATCH_PARENT, WRAP_CONTENT).apply { topMargin = dp(8) })

        // Időtartam
        root.addView(sectionTitle("A képkocka ideje"))
        val dur = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
            background = rounded(Ui.CARD, dp(20).toFloat())
            setPadding(dp(12), dp(10), dp(12), dp(10))
        }
        val minus = pill("−") { setMs(frame().ms - step(frame().ms, false)) }
        val plus = pill("+") { setMs(frame().ms + step(frame().ms, true)) }
        durText = text("", 18f, Ui.TEXT, Ui.medium).apply { gravity = Gravity.CENTER }
        dur.addView(minus, LinearLayout.LayoutParams(dp(52), dp(44)))
        dur.addView(durText, LinearLayout.LayoutParams(0, WRAP_CONTENT, 1f))
        dur.addView(plus, LinearLayout.LayoutParams(dp(52), dp(44)))
        root.addView(dur)
        root.addView(row(
            pill("Mindre ugyanennyi") { val ms = frame().ms; anim.frames.forEach { it.ms = ms }; changed() },
            pill("Gyorsabb ×½") { anim.frames.forEach { it.ms = (it.ms / 2).coerceAtLeast(30) }; changed() },
            pill("Lassabb ×2") { anim.frames.forEach { it.ms = (it.ms * 2).coerceAtMost(5_000) }; changed() }
        ), LinearLayout.LayoutParams(MATCH_PARENT, WRAP_CONTENT).apply { topMargin = dp(6) })

        // Ismétlés
        root.addView(sectionTitle("Ismétlés a hátlapon"))
        val lr = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
        listOf(1, 3, 5, 10, 0).forEachIndexed { i, n ->
            val p = pill(if (n == 0) "∞" else "$n×", anim.loops == n) { anim.loops = n; save(); build() }
            loopPills += p
            lr.addView(p, LinearLayout.LayoutParams(0, dp(44), 1f).apply { if (i < 4) marginEnd = dp(5) })
        }
        root.addView(lr)

        // Lejátszás
        playBtn = text("", 16f, Ui.DARK_TEXT, Ui.medium).apply {
            gravity = Gravity.CENTER
            background = rounded(Ui.LIGHT, dp(28).toFloat())
            setOnClickListener { togglePreview() }
        }
        val leds = text("✦  Lejátszás a hátlapon", 16f, Ui.TEXT, Ui.medium).apply {
            gravity = Gravity.CENTER
            background = rounded(Ui.CARD, dp(28).toFloat())
            setOnClickListener {
                save()
                startForegroundService(Intent(this@StudioActivity, SimonService::class.java)
                    .setAction(SimonService.ACTION_STUDIO).putExtra(SimonService.EXTRA_ANIM, anim.id))
            }
        }
        root.addView(row(playBtn, leds, height = 56), LinearLayout.LayoutParams(MATCH_PARENT, WRAP_CONTENT).apply { topMargin = dp(18) })
        root.addView(text("Koppints egy fényre a be- vagy kikapcsoláshoz, vagy húzd végig az ujjad (festés / radír). " +
            "A ★ kedvenc animáció indul a Glyph Stúdió csempéjéről, widgetről vagy mozdulattal (Indítás és leállítás).",
            12.5f, Ui.SUB).apply { setPadding(dp(8), dp(12), dp(8), 0); setLineSpacing(0f, 1.2f) })
        refresh(true)
    }

    private fun step(ms: Int, up: Boolean) = when {
        ms < 200 || (!up && ms <= 200) -> 10
        ms < 1_000 || (!up && ms <= 1_000) -> 50
        else -> 250
    }

    private fun setMs(v: Int) { frame().ms = v.coerceIn(30, 5_000); changed() }

    private fun changed(strip: Boolean = false) {
        save()
        refresh(strip)
    }

    private fun refresh(rebuildStrip: Boolean) {
        titleText.text = anim.name
        canvasView.lit = frame().zones.toSet()
        durText.text = "${frame().ms} ms"
        infoText.text = "${cur + 1}. / ${anim.frames.size} képkocka · ${frame().zones.size} fény · egy kör: ${"%.1f".format(anim.cycleMs() / 1000.0)} mp"
        playBtn.text = if (previewJob?.isActive == true) "■  Állj" else "▶  Előnézet"
        if (rebuildStrip) buildStrip() else updateThumb(cur)
    }

    private fun buildStrip() {
        strip.removeAllViews()
        anim.frames.forEachIndexed { i, f ->
            val cell = LinearLayout(this).apply {
                orientation = LinearLayout.VERTICAL
                gravity = Gravity.CENTER_HORIZONTAL
                background = if (i == cur) rounded(Ui.CARD, dp(16).toFloat(), Ui.LIGHT, dp(2)) else rounded(Ui.CARD, dp(16).toFloat())
                setPadding(dp(4), dp(6), dp(4), dp(4))
                setOnClickListener { cur = i; stopPreview(); refresh(true) }
            }
            cell.addView(GlyphMapView(this).apply { lit = f.zones.toSet(); unlitColor = 0xFF303030.toInt() },
                LinearLayout.LayoutParams(dp(52), dp(84)))
            cell.addView(text("${i + 1}", 11f, if (i == cur) Ui.TEXT else Ui.SUB).apply { gravity = Gravity.CENTER })
            strip.addView(cell, LinearLayout.LayoutParams(WRAP_CONTENT, WRAP_CONTENT).apply { marginEnd = dp(5) })
        }
        // A végén: új képkocka
        strip.addView(text("+", 24f, Ui.SUB).apply {
            gravity = Gravity.CENTER
            background = rounded(Ui.CARD, dp(16).toFloat())
            setOnClickListener { anim.frames += StudioFrame(mutableSetOf(), frame().ms); cur = anim.frames.size - 1; changed(true) }
        }, LinearLayout.LayoutParams(dp(56), dp(108)))
    }

    private fun updateThumb(i: Int) {
        val cell = strip.getChildAt(i) as? LinearLayout ?: return
        (cell.getChildAt(0) as? GlyphMapView)?.lit = anim.frames[i].zones.toSet()
    }

    private fun onCanvasTouch(ev: MotionEvent) {
        val z = canvasView.zoneAt(ev.x, ev.y)
        when (ev.actionMasked) {
            MotionEvent.ACTION_DOWN -> {
                // A görgetés ne vegye át a húzást
                canvasView.parent?.requestDisallowInterceptTouchEvent(true)
                stopPreview()
                lastZone = z
                if (z == null) return
                paint = z !in frame().zones
                if (paint) frame().zones += z else frame().zones -= z
                changed()
            }
            MotionEvent.ACTION_MOVE -> {
                if (z == null || z == lastZone) return
                lastZone = z
                val had = z in frame().zones
                if (paint && !had) { frame().zones += z; changed() }
                if (!paint && had) { frame().zones -= z; changed() }
            }
            else -> lastZone = null
        }
    }

    private fun togglePreview() {
        if (previewJob?.isActive == true) { stopPreview(); refresh(false); return }
        previewJob = scope.launch {
            playBtn.text = "■  Állj"
            var k = 0
            while (true) {
                for (f in anim.frames) { canvasView.lit = f.zones.toSet(); delay(f.ms.toLong()) }
                k++
                if (anim.loops in 1..k) break
            }
            canvasView.lit = frame().zones.toSet()
            playBtn.text = "▶  Előnézet"
        }
    }

    private fun stopPreview() {
        previewJob?.cancel()
        previewJob = null
        canvasView.lit = frame().zones.toSet()
    }

    private fun chooseAnim() {
        val list = StudioStore.all(this)
        val items = list.map { (if (it.id == StudioStore.favoriteId(this)) "★ " else "") + it.name + "  ·  ${it.frames.size} kocka" } +
            "+ Új animáció sablonból…"
        AlertDialog.Builder(this, android.R.style.Theme_DeviceDefault_Dialog_Alert)
            .setTitle("Animációk")
            .setItems(items.toTypedArray()) { _, which ->
                if (which < list.size) { anim = list[which]; cur = 0; stopPreview(); build() } else newFromTemplate()
            }
            .show()
    }

    private fun newFromTemplate() {
        AlertDialog.Builder(this, android.R.style.Theme_DeviceDefault_Dialog_Alert)
            .setTitle("Kezdés sablonból")
            .setItems(Templates.names.toTypedArray()) { _, which ->
                val a = Templates.make(Templates.names[which]) ?: return@setItems
                a.name = if (Templates.names[which] == "Üres") "Saját animáció" else "${Templates.names[which]} (saját)"
                StudioStore.upsert(this, a)
                GameStats.count(this, "studio_made")
                Achievements.check(this)
                anim = a; cur = 0; build()
            }
            .show()
    }

    private fun rename() {
        val e = EditText(this).apply {
            setText(anim.name); setSingleLine(true); setTextColor(Ui.TEXT)
            setPadding(dp(20), dp(12), dp(20), dp(12))
        }
        AlertDialog.Builder(this, android.R.style.Theme_DeviceDefault_Dialog_Alert)
            .setTitle("Átnevezés")
            .setView(e)
            .setPositiveButton("OK") { _, _ -> anim.name = e.text.toString().ifBlank { anim.name }; save(); refresh(false) }
            .setNegativeButton("Mégse", null)
            .show()
    }

    private fun deleteAnim() {
        AlertDialog.Builder(this, android.R.style.Theme_DeviceDefault_Dialog_Alert)
            .setTitle("Törlöd: ${anim.name}?")
            .setPositiveButton("Törlés") { _, _ ->
                StudioStore.delete(this, anim.id)
                anim = StudioStore.all(this).firstOrNull() ?: Templates.make("Üres")!!.also { StudioStore.upsert(this, it) }
                cur = 0; build()
            }
            .setNegativeButton("Mégse", null)
            .show()
    }

    override fun onResume() { super.onResume(); GlyphMirror.appVisible = true }
    override fun onPause() { super.onPause(); GlyphMirror.appVisible = false; stopPreview() }
    override fun onDestroy() { scope.cancel(); super.onDestroy() }
}
