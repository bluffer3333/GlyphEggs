package com.akos.glypheggs

import android.os.SystemClock
import com.nothing.ketchum.Glyph
import kotlinx.coroutines.channels.Channel
import kotlinx.coroutines.channels.awaitClose
import kotlinx.coroutines.coroutineScope
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.merge
import kotlinx.coroutines.launch
import kotlin.math.max
import kotlin.random.Random

/**
 * Dínófutás – a böngésző internet nélküli dínós játéka a hátlapon.
 *
 *  - A felső sáv (C1, 16 LED) a pálya. A dínó a bal végén áll (2. LED), a jobb oldalról
 *    akadályok közelednek.
 *  - KAKTUSZ (folyamatosan égő LED): kopogj, hogy a dínó átugorja. Ugrás közben a dínó
 *    "fent" van: a sávból eltűnik, helyette a ferde csík (B1) és a kamera felső fele (A1) ég.
 *  - MADÁR (villogó LED): NE ugorj – ugrás közben nekirepülsz; maradj a földön, és átrepül fölötted.
 *  - Az idővel egyre gyorsabb. Minden 10. legyőzött akadálynál egy LED gyullad a D1 vonalon,
 *    100 pontonként minden felvillan (mint az eredetiben).
 *  - Ütközés: vége; a pontszám a D1 vonalon és a felső sávon látszik.
 *
 * Kopogás fekve működik; a szimulációban az Érintés gomb is ugrik.
 */
class DinoGame(
    private val glyph: GlyphController,
    private val motion: MotionDetector,
    private val haptics: Haptics,
    /** Az ugrást kiváltó jelek (kopogás, rázás, gombok – a Dínófutás beállításában választható). */
    private val jump: Flow<Long> = motion.knockEvents
) {
    private class Obstacle(var pos: Int, val bird: Boolean)

    private val bar: IntArray = IntArray(16) { Zones.LEVEL[15 - it] } // 0 = bal vége, 15 = jobb vége
    private val dLine = intArrayOf(
        Glyph.Code_22111.D1_1, Glyph.Code_22111.D1_2, Glyph.Code_22111.D1_3, Glyph.Code_22111.D1_4,
        Glyph.Code_22111.D1_5, Glyph.Code_22111.D1_6, Glyph.Code_22111.D1_7, Glyph.Code_22111.D1_8
    )
    private val dinoIdx = 1
    private val inAir = intArrayOf(Glyph.Code_22111.B1, Glyph.Code_22111.A1)

    /** Visszaadja a pontszámot (legyőzött akadályok). */
    suspend fun run(): Int = coroutineScope {
        val inputs = Channel<Long>(Channel.CONFLATED)
        val collector = launch { merge(jump, GlyphMirror.taps).collect { inputs.trySend(it) } }
        try {
            play(inputs)
        } finally {
            collector.cancel()
        }
    }

    private suspend fun play(inputs: Channel<Long>): Int {
        intro()
        while (inputs.tryReceive().isSuccess) Unit

        val obstacles = mutableListOf<Obstacle>()
        var score = 0
        var stepMs = Config.DINO_START_STEP_MS
        var nextStepAt = SystemClock.elapsedRealtime() + stepMs
        var airUntil = 0L
        var bufferedJump = false
        var gap = 6
        var frame = 0

        while (true) {
            val now = SystemClock.elapsedRealtime()

            // Ugrás – ha még a levegőben van, de mindjárt földet ér, megjegyzi, és leérkezéskor rögtön ugrik
            if (inputs.tryReceive().isSuccess) {
                if (now >= airUntil) {
                    airUntil = now + (stepMs * Config.DINO_JUMP_STEPS)
                    haptics.click()
                } else if (airUntil - now <= Config.DINO_JUMP_BUFFER_MS) {
                    bufferedJump = true
                }
            }
            if (bufferedJump && now >= airUntil) {
                bufferedJump = false
                airUntil = now + (stepMs * Config.DINO_JUMP_STEPS)
                haptics.click()
            }
            val jumping = now < airUntil

            // A pálya léptetése
            if (now >= nextStepAt) {
                nextStepAt = now + stepMs
                for (o in obstacles) o.pos--
                // Átjutott a dínón: pont
                val passed = obstacles.count { it.pos < 0 }
                if (passed > 0) {
                    obstacles.removeAll { it.pos < 0 }
                    score += passed
                    if (score % 100 == 0) milestone()
                    stepMs = max(Config.DINO_MIN_STEP_MS, Config.DINO_START_STEP_MS - score * Config.DINO_FASTER_PER_POINT_MS)
                }
                // Új akadály
                gap--
                if (gap <= 0) {
                    val birdChance = if (score >= 8) 0.3f else 0f
                    obstacles += Obstacle(15, Random.nextFloat() < birdChance)
                    gap = Random.nextInt(Config.DINO_MIN_GAP, Config.DINO_MIN_GAP + 6)
                }
            }

            // Ütközés: kaktusz a dínónál, és a földön van – vagy madár, és épp ugrik
            val hit = obstacles.firstOrNull { it.pos == dinoIdx }
            if (hit != null && ((!hit.bird && !jumping) || (hit.bird && jumping))) {
                crash(score)
                return score
            }

            // Kirajzolás
            val lit = mutableListOf<Int>()
            if (jumping) lit += inAir.toList() else lit += bar[dinoIdx]
            for (o in obstacles) {
                if (o.pos in 0..15 && (!o.bird || frame % 4 < 2)) lit += bar[o.pos]
            }
            lit += dLine.take((score / 10).coerceAtMost(8))
            // A föld "fut" a pont alatt: az E1 ritmusosan pislog, mint a dínó lába
            if (!jumping && frame % 6 < 3) lit += Glyph.Code_22111.E1
            glyph.show(lit.distinct().toIntArray())

            frame++
            delay(20)
        }
    }

    private suspend fun intro() {
        glyph.show(intArrayOf(bar[dinoIdx]))
        delay(400)
        // Két próbaugrás
        repeat(2) {
            glyph.show(inAir)
            delay(250)
            glyph.show(intArrayOf(bar[dinoIdx], Glyph.Code_22111.E1))
            delay(250)
        }
        for (i in 15 downTo 2) {
            glyph.show(intArrayOf(bar[dinoIdx], bar[i]))
            delay(25)
        }
        glyph.show(intArrayOf(bar[dinoIdx]))
        delay(500)
    }

    /** 100 pontonként: minden felvillan (mint az eredetiben). */
    private suspend fun milestone() {
        haptics.tick()
        repeat(2) {
            glyph.show(Zones.ALL)
            delay(80)
            glyph.off()
            delay(60)
        }
    }

    private suspend fun crash(score: Int) {
        DebugState.log("Dínó: ütközés – $score pont")
        haptics.denied()
        repeat(4) {
            glyph.show(Zones.ALL)
            delay(130)
            glyph.off()
            delay(110)
        }
        // Eredmény: a D1 a tízesek (max 8), a felső sáv az egyesek
        val lit = dLine.take((score / 10).coerceAtMost(8)) + bar.take(score % 10)
        glyph.show(lit.toIntArray())
        delay(3500)
        glyph.off()
    }
}

/**
 * Kiáltás-érzékelő a Dínófutáshoz: a közös mikrofonból ([MicTap]) hall.
 * Folyamatosan méri a háttérzajt; ugrás, ha a hang hirtelen jóval hangosabb (≥ 14 dB a zaj fölött,
 * és abszolút értékben is erős), utána 300 ms szünet, hogy egy kiáltás csak egy ugrás legyen.
 */
object Shout {
    fun hits(): kotlinx.coroutines.flow.Flow<Long> = kotlinx.coroutines.flow.callbackFlow {
        var floor = -55f
        var last = 0L
        var loudFrames = 0
        val l: (ShortArray, Int) -> Unit = { buf, n ->
            var sum = 0.0
            for (i in 0 until n) { val x = buf[i] / 32768.0; sum += x * x }
            val rms = kotlin.math.sqrt(sum / max(1, n))
            val db = if (rms > 1e-7) (20 * kotlin.math.log10(rms)).toFloat() else -120f
            val now = SystemClock.elapsedRealtime()
            val loud = db > floor + 14f && db > -32f
            loudFrames = if (loud) loudFrames + 1 else 0
            // A háttérzaj lassan követ (csak csendes kereteken), így a zajos szoba sem ugrál
            if (!loud) floor += (db - floor) * (if (db < floor) 0.2f else 0.03f)
            if (loudFrames >= 2 && now - last > 300) { // ≥ 64 ms hangos: nem egy koppanás
                last = now
                trySend(now)
            }
        }
        MicTap.listeners += l
        awaitClose { MicTap.listeners -= l }
    }
}
