package com.akos.glypheggs

import android.app.Activity
import android.content.Intent
import android.graphics.Canvas
import android.graphics.ColorFilter
import android.graphics.LinearGradient
import android.graphics.Paint
import android.graphics.PixelFormat
import android.graphics.RectF
import android.graphics.Shader
import android.graphics.drawable.Drawable
import android.view.Gravity
import android.view.ViewGroup.LayoutParams.MATCH_PARENT
import android.view.ViewGroup.LayoutParams.WRAP_CONTENT
import android.widget.FrameLayout
import android.widget.LinearLayout
import android.widget.TextView

/*
 * A Főoldal kiemelt Glyph Stúdió kártyája – „sötétkamra / fényfestés” stílus:
 * mélyfekete lap pixelrácsos vászonnal, fényfestés-színátmenetes szegély (magenta → borostyán → cián),
 * átlós fénycsík, színátmenetes pontmátrix-cím, és egy élő mini hátlap, amin a kedvenc animáció fut.
 */

/**
 * A kártya színei: alap Nothing-témában fekete-fehér-szürke (egy csepp pirossal), neon témában
 * a téma két fő színéből készül a fényfestés-átmenet.
 */
private fun paintColors(): IntArray? = Ui.neon?.let { t ->
    if (t.rainbow) intArrayOf(RAINBOW[0], RAINBOW[2], RAINBOW[4], RAINBOW[6]) else intArrayOf(t.a, BadgeArt.mix(t.a, t.b, 0.5f), t.b)
}

/** A kártya háttere: pixelrács + fényfestés-szegély + átlós fénycsík. */
class StudioHeroBackground(private val density: Float) : Drawable() {
    private val p = Paint(Paint.ANTI_ALIAS_FLAG)
    private val box = RectF()

    override fun draw(canvas: Canvas) {
        val b = bounds
        val w = b.width().toFloat()
        val h = b.height().toFloat()
        val r = 26 * density
        canvas.save()
        canvas.translate(b.left.toFloat(), b.top.toFloat())
        // Mélyfekete lap
        p.style = Paint.Style.FILL
        p.shader = null
        p.color = if (Ui.neon == null) 0xFF0B0B0B.toInt() else 0xFF07070A.toInt()
        box.set(0f, 0f, w, h)
        canvas.drawRoundRect(box, r, r, p)
        // Pixelrácsos vászon
        p.color = if (Ui.neon == null) 0xFF1E1E1E.toInt() else 0xFF1A1A22.toInt()
        val step = 9 * density
        var y = step
        while (y < h - step / 2) {
            var x = step
            while (x < w - step / 2) { canvas.drawCircle(x, y, 1.1f * density, p); x += step }
            y += step
        }
        val cols = paintColors()
        // Átlós fénycsík (neon témában színes fényfestés, alapban halvány fehér)
        val a0 = cols?.first() ?: 0xFFFFFFFF.toInt()
        val a1 = cols?.last() ?: 0xFFFFFFFF.toInt()
        val al = if (cols == null) 0x0C else 0x30
        p.shader = LinearGradient(w * 0.35f, 0f, w * 0.75f, h,
            intArrayOf(a0 and 0xFFFFFF, (a0 and 0xFFFFFF) or (al shl 24), (a1 and 0xFFFFFF) or (al shl 24), a1 and 0xFFFFFF), null, Shader.TileMode.CLAMP)
        canvas.drawRoundRect(box, r, r, p)
        // Szegély: neonban színátmenetes, alapban vékony szürke (mint a Nothing kártyák)
        p.style = Paint.Style.STROKE
        p.strokeWidth = (if (cols == null) 1.5f else 2.2f) * density
        p.shader = if (cols != null) LinearGradient(0f, 0f, w, h, cols, null, Shader.TileMode.CLAMP) else null
        if (cols == null) p.color = 0xFF3A3A3A.toInt()
        val inset = p.strokeWidth / 2
        box.set(inset, inset, w - inset, h - inset)
        canvas.drawRoundRect(box, r, r, p)
        p.shader = null
        p.style = Paint.Style.FILL
        // Alap témában a Nothing piros pöttye a jobb felső sarokban
        if (cols == null) {
            p.color = 0xFFD71921.toInt()
            canvas.drawCircle(w - 18 * density, 18 * density, 3.5f * density, p)
        }
        canvas.restore()
    }

    override fun setAlpha(alpha: Int) {}
    override fun setColorFilter(colorFilter: ColorFilter?) {}
    @Deprecated("Drawable API")
    override fun getOpacity(): Int = PixelFormat.TRANSLUCENT
}

fun Activity.studioHero(): LinearLayout {
    val fav = StudioStore.favorite(this)
    val count = StudioStore.all(this).size
    val card = LinearLayout(this).apply {
        orientation = LinearLayout.HORIZONTAL
        gravity = Gravity.CENTER_VERTICAL
        background = StudioHeroBackground(resources.displayMetrics.density)
        setPadding(dp(14), dp(14), dp(16), dp(14))
        setOnClickListener { startActivity(Intent(this@studioHero, StudioActivity::class.java)) }
    }
    // Élő mini hátlap: a kedvenc animáció fut rajta (csak a képernyőn)
    val plain = Ui.neon == null
    val mini = GlyphMapView(this).apply { unlitColor = if (plain) 0xFF2A2A2A.toInt() else 0xFF1E1E26.toInt() }
    val frame = FrameLayout(this).apply {
        background = rounded(if (plain) 0xFF0E0E0E.toInt() else 0xFF0C0C12.toInt(), dp(18).toFloat(), if (plain) 0xFF2E2E2E.toInt() else 0xFF24242E.toInt(), dp(1))
    }
    frame.addView(mini, FrameLayout.LayoutParams(MATCH_PARENT, MATCH_PARENT).apply { setMargins(dp(6), dp(8), dp(6), dp(8)) })
    card.addView(frame, LinearLayout.LayoutParams(dp(84), dp(126)).apply { marginEnd = dp(14) })
    val frames = fav?.frames?.takeIf { it.isNotEmpty() }
    if (frames != null) {
        var i = 0
        val tick = object : Runnable {
            override fun run() {
                if (!mini.isAttachedToWindow && i > 0) return
                val f = frames[i % frames.size]
                mini.lit = f.zones.toSet()
                mini.invalidate()
                i++
                mini.postDelayed(this, f.ms.toLong().coerceIn(40L, 2_000L))
            }
        }
        mini.post(tick)
    }

    val texts = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
    val title = text("GLYPH STÚDIÓ", 22f, 0xFFFFFFFF.toInt()).apply {
        typeface = Widgets.dotoFace(this@studioHero)
        setShadowLayer(0f, 0f, 0f, 0)
    }
    // Neon témában színátmenetes pontmátrix-cím; alapban tiszta fehér
    paintColors()?.let { cols ->
        title.post {
            title.paint.shader = LinearGradient(0f, 0f, title.width.toFloat().coerceAtLeast(1f), 0f, cols, null, Shader.TileMode.CLAMP)
            title.invalidate()
        }
    }
    texts.addView(title)
    texts.addView(text("Rajzolj fényt. Képkockánként.", 13f, if (Ui.neon == null) 0xFFA8A8A8.toInt() else 0xFFB9B9C6.toInt()).apply { setPadding(0, dp(2), 0, 0) })
    texts.addView(text(
        if (fav != null) "★ ${fav.name}  ·  $count animáció" else "Még nincs animációd – kezdd egy sablonnal",
        11.5f, Ui.neon?.a ?: 0xFFD9D9D9.toInt(), Ui.medium).apply {
            setPadding(0, dp(8), 0, dp(10)); letterSpacing = 0.04f
            if (Ui.neon == null) typeface = Widgets.dotoFace(this@studioHero)
        })
    val btns = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
    fun btn(label: String, filled: Boolean, onClick: () -> Unit): TextView = text(label, 13.5f, if (filled) 0xFF07070A.toInt() else 0xFFFFFFFF.toInt(), Ui.medium).apply {
        gravity = Gravity.CENTER
        background = if (filled) rounded(0xFFFFFFFF.toInt(), dp(20).toFloat()) else rounded(0x00000000, dp(20).toFloat(), if (Ui.neon == null) 0xFF3A3A3A.toInt() else 0xFF3A3A48.toInt(), dp(1.5f))
        setOnClickListener { onClick() }
    }
    btns.addView(btn("✎ Rajzolás", true) { startActivity(Intent(this, StudioActivity::class.java)) },
        LinearLayout.LayoutParams(0, dp(40), 1f).apply { marginEnd = dp(6) })
    btns.addView(btn("▶ Hátlapon", false) {
        if (fav == null) startActivity(Intent(this, StudioActivity::class.java))
        else startForegroundService(Intent(this, SimonService::class.java).setAction(SimonService.ACTION_STUDIO))
    }, LinearLayout.LayoutParams(0, dp(40), 1f))
    texts.addView(btns, LinearLayout.LayoutParams(MATCH_PARENT, WRAP_CONTENT))
    card.addView(texts, LinearLayout.LayoutParams(0, WRAP_CONTENT, 1f))
    return card
}
