package com.akos.glypheggs

import android.app.Activity
import android.graphics.Canvas
import android.graphics.Paint
import android.graphics.RadialGradient
import android.graphics.Shader
import android.graphics.Typeface
import android.os.Handler
import android.os.Looper
import android.view.View
import android.view.ViewGroup
import android.widget.EditText
import android.widget.TextView
import kotlin.math.abs
import kotlin.math.sin

/**
 * SUTTOGÁS – a nyugtalanító téma. Semmi nem harsány, minden csak a látótér szélén történik:
 *  - a háttérben halk szemcsézet „lélegzik”, a sarkok sötétje lassan ki-be húzódik,
 *  - a szélén néha egy pontmátrixos SZEM nyílik ki egy pillanatra, pislog, és a közepe felé néz,
 *  - halvány, suttogó szavak tűnnek fel és úsznak el a peremen,
 *  - ritkán egy sötét alak áll a képernyő szélén – mire odanézel, eltűnik,
 *  - a feliratokban néha egy betű egy pillanatra megváltozik, aztán visszaáll, mintha mi sem történt volna,
 *  - a kártyák időnként alig észrevehetően megrezzennek, a nagy feliratoknak halvány, csúszó „árnyék-mása” van.
 * Erős villogás nincs benne. Minden idő-alapú, így bármelyik oldal ugyanazt a „jelenést” látja.
 */
object WhisperFx {
    private val p = Paint(Paint.ANTI_ALIAS_FLAG)
    private val tp = Paint(Paint.ANTI_ALIAS_FLAG).apply { typeface = Typeface.create(Typeface.SERIF, Typeface.ITALIC) }
    private val rnd = java.util.Random()

    private val WORDS = listOf(
        "figyelnek", "hallod?", "ne nézz hátra", "itt vagyok", "mögötted", "tudják",
        "ki volt az?", "csitt", "láttad?", "nem vagy egyedül", "már tudja", "maradj",
        "ugye hallod", "nézd a sarkot", "ne mondd el", "közel"
    )

    /** Determinisztikus „véletlen” egy időablakhoz (minden oldalon ugyanaz). */
    private fun hash(a: Long, salt: Int): Float {
        var x = a * 6364136223846793005L + salt * 1442695040888963407L
        x = x xor (x ushr 33); x *= -0x40a7b892e31b1a47L; x = x xor (x ushr 29)
        return ((x ushr 11) and 0xFFFFFF).toFloat() / 0xFFFFFF
    }

    /** Be- és kifakulás egy ablakon belül (0..1 → 0..1..0). */
    private fun fade(u: Float, inF: Float = 0.25f, outF: Float = 0.3f): Float = when {
        u < 0f || u > 1f -> 0f
        u < inF -> u / inF
        u > 1f - outF -> (1f - u) / outF
        else -> 1f
    }

    fun paintBackground(canvas: Canvas, w: Float, h: Float) {
        val now = System.currentTimeMillis()
        val t = now / 1000f
        // Alap: majdnem fekete, alul még sötétebb
        p.shader = android.graphics.LinearGradient(0f, 0f, 0f, h, 0xFF101012.toInt(), 0xFF050506.toInt(), Shader.TileMode.CLAMP)
        canvas.drawRect(0f, 0f, w, h, p)
        p.shader = null

        // Lélegző szemcsézet
        val breath = 0.5f + 0.5f * sin(t * 2f * Math.PI.toFloat() / 6.5f)
        val grains = 260
        for (i in 0 until grains) {
            val a = (10 + rnd.nextInt(22) * (0.6f + 0.4f * breath)).toInt()
            p.color = (a shl 24) or 0xD8D2C4
            val x = rnd.nextFloat() * w; val y = rnd.nextFloat() * h
            canvas.drawRect(x, y, x + 2f, y + 2f, p)
        }

        // Suttogó szavak a peremen (5 mp-es ablakok)
        run {
            val win = now / 5_000L
            for (k in 0..1) {
                val wi = win - k
                if (hash(wi, 11) > 0.62f) continue
                val u = ((now - wi * 5_000L) / 7_000f) // 7 mp-ig él, átfedve
                val f = fade(u, 0.3f, 0.45f)
                if (f <= 0f) continue
                val word = WORDS[(hash(wi, 12) * WORDS.size).toInt().coerceIn(0, WORDS.size - 1)]
                val left = hash(wi, 13) < 0.5f
                val y = h * (0.12f + 0.76f * hash(wi, 14))
                tp.textSize = w * (0.045f + 0.03f * hash(wi, 15))
                tp.color = ((f * 46).toInt() shl 24) or 0xD8D2C4
                tp.letterSpacing = 0.25f + 0.2f * u
                canvas.save()
                val drift = u * w * 0.05f
                val x = if (left) w * 0.03f + drift else w * 0.97f - tp.measureText(word) - drift
                canvas.rotate(if (left) -90f + 6f * hash(wi, 16) else 90f - 6f * hash(wi, 16), x, y)
                canvas.drawText(word, x, y, tp)
                canvas.restore()
            }
        }

        // Szem a peremen (9 mp-es ablak, 1,8 mp-ig nyitva, közben pislog)
        run {
            val win = now / 9_000L
            if (hash(win, 21) < 0.55f) {
                val u = (now - win * 9_000L) / 1_800f
                val f = fade(u, 0.35f, 0.35f)
                if (f > 0f) {
                    val side = hash(win, 22)
                    val ex = if (side < 0.5f) w * (0.08f + 0.1f * hash(win, 23)) else w * (0.92f - 0.1f * hash(win, 23))
                    val ey = h * (0.15f + 0.7f * hash(win, 24))
                    // pislogás a közepén
                    val blink = if (u in 0.48f..0.56f) 0.1f else 1f
                    drawEye(canvas, ex, ey, w * 0.11f, f * blink, w / 2f, h / 2f)
                }
            }
        }

        // Sötét alak a szélén (23 mp-es ablak, csak egy pillanatra)
        run {
            val win = now / 23_000L
            if (hash(win, 31) < 0.5f) {
                val u = (now - win * 23_000L - 11_000L) / 900f
                val f = fade(u, 0.15f, 0.5f)
                if (f > 0f) {
                    val left = hash(win, 32) < 0.5f
                    val fx = if (left) -w * 0.04f else w * 1.04f
                    val fy = h * (0.45f + 0.3f * hash(win, 33))
                    drawFigure(canvas, fx, fy, h * 0.42f, f)
                }
            }
        }

        // Lélegző, sötét sarkok (vignetta)
        val r = Math.hypot(w.toDouble(), h.toDouble()).toFloat() * (0.55f + 0.05f * breath)
        p.shader = RadialGradient(w / 2f, h * 0.45f, r, intArrayOf(0x00000000, 0x00000000, (0xC0 + (0x30 * breath).toInt()) shl 24),
            floatArrayOf(0f, 0.55f, 1f), Shader.TileMode.CLAMP)
        canvas.drawRect(0f, 0f, w, h, p)
        p.shader = null
    }

    /** Pontmátrixos mandula-szem; a pupilla a (lx, ly) felé néz. */
    private fun drawEye(c: Canvas, cx: Float, cy: Float, size: Float, alpha: Float, lx: Float, ly: Float) {
        val dot = size * 0.06f
        val open = alpha.coerceIn(0f, 1f)
        val base = 0xD8D2C4
        // a szemhéj íve pontokból
        val n = 18
        for (i in 0..n) {
            val x = -1f + 2f * i / n
            val yy = (1f - x * x) * 0.42f * size * open
            p.color = ((open * 110).toInt() shl 24) or base
            c.drawCircle(cx + x * size, cy - yy, dot, p)
            c.drawCircle(cx + x * size, cy + yy, dot, p)
        }
        // a pupilla a közép felé néz
        val dx = (lx - cx); val dy = (ly - cy)
        val d = Math.hypot(dx.toDouble(), dy.toDouble()).toFloat().coerceAtLeast(1f)
        val px = cx + dx / d * size * 0.32f
        val py = cy + dy / d * size * 0.1f
        p.color = ((open * 150).toInt() shl 24) or 0x8A1C1C
        c.drawCircle(px, py, size * 0.2f * open, p)
        p.color = ((open * 220).toInt() shl 24)
        c.drawCircle(px, py, size * 0.09f * open, p)
    }

    /** Egy elmosódó, sötét emberalak sziluettje (fej + váll), részben a képen kívül. */
    private fun drawFigure(c: Canvas, x: Float, y: Float, h: Float, alpha: Float) {
        for (k in 0 until 5) {
            val s = 1f + k * 0.05f
            p.color = ((alpha * 60 / (k + 1)).toInt() shl 24)
            c.drawCircle(x, y - h * 0.38f, h * 0.085f * s, p)
            c.drawOval(x - h * 0.17f * s, y - h * 0.28f, x + h * 0.17f * s, y + h * 0.6f, p)
        }
    }

    /** Rákapcsolja a „jelenéseket” egy oldalra: háttér-mozgás, megváltozó betűk, megrezzenő kártyák. */
    fun attach(activity: Activity) {
        val content = activity.findViewById<ViewGroup>(android.R.id.content) ?: return
        val handler = Handler(Looper.getMainLooper())
        val tick = object : Runnable {
            var nextLetter = System.currentTimeMillis() + 4_000L + rnd.nextInt(6_000)
            var nextFlinch = System.currentTimeMillis() + 9_000L + rnd.nextInt(8_000)
            override fun run() {
                val root = content.getChildAt(0) ?: return
                if (!root.isAttachedToWindow) return
                if (root.windowVisibility != View.VISIBLE) { handler.postDelayed(this, 500); return }
                activity.window.decorView.background?.invalidateSelf()
                root.background?.invalidateSelf()
                val now = System.currentTimeMillis()
                if (now >= nextLetter) { nextLetter = now + 5_000L + rnd.nextInt(9_000); tamper(content, handler) }
                if (now >= nextFlinch) { nextFlinch = now + 10_000L + rnd.nextInt(12_000); flinch(content, handler) }
                handler.postDelayed(this, 70)
            }
        }
        handler.postDelayed(tick, 400)
    }

    private val SWAP = mapOf('a' to 'á', 'e' to 'é', 'o' to 'ö', 'u' to 'ü', 'i' to 'l', 'n' to 'm', 'm' to 'n', 's' to 'z', 't' to 'f',
        'A' to 'Á', 'E' to 'É', 'O' to 'Ö', 'S' to 'Z', 'N' to 'M', 'M' to 'N', 'T' to 'F', 'l' to 'i', 'r' to 'n')

    /** Egy látható feliratban egy betű egy pillanatra megváltozik, aztán visszaáll (ha közben nem írták át). */
    private fun tamper(content: ViewGroup, handler: Handler) {
        val list = ArrayList<TextView>()
        fun walk(v: View) {
            if (v is TextView && v !is EditText && v.isShown && (v.text?.length ?: 0) in 4..60) list += v
            if (v is ViewGroup) for (i in 0 until v.childCount) walk(v.getChildAt(i))
        }
        walk(content)
        if (list.isEmpty()) return
        val tv = list[rnd.nextInt(list.size)]
        val orig = tv.text?.toString() ?: return
        val idx = orig.indices.filter { orig[it] in SWAP }.shuffled().firstOrNull() ?: return
        val changed = orig.substring(0, idx) + SWAP[orig[idx]] + orig.substring(idx + 1)
        tv.text = changed
        handler.postDelayed({ if (tv.text?.toString() == changed) tv.text = orig }, 220L + rnd.nextInt(260))
    }

    /** Egy kártya alig észrevehetően megrezzen (oldalra csúszik és vissza). */
    private fun flinch(content: ViewGroup, handler: Handler) {
        val out = ArrayList<View>()
        fun walk(v: ViewGroup, depth: Int) {
            for (i in 0 until v.childCount) {
                val c = v.getChildAt(i)
                if (depth >= 2 && c.height in 60..1400 && c.width > 120 && c.isShown) out += c
                if (c is ViewGroup && depth < 3) walk(c, depth + 1)
            }
        }
        walk(content, 0)
        if (out.isEmpty()) return
        val v = out[rnd.nextInt(out.size)]
        val d = v.resources.displayMetrics.density * (2f + rnd.nextFloat() * 2f) * (if (rnd.nextBoolean()) 1 else -1)
        v.translationX = d
        handler.postDelayed({ v.translationX = -d * 0.4f }, 60)
        handler.postDelayed({ v.translationX = 0f }, 130)
    }

    /** A nagy feliratok halvány, kicsit elcsúszott „árnyék-mása” (kettős látás). */
    fun ghostOffset(sizeSp: Float): Float = sizeSp * 0.12f * (0.6f + 0.4f * abs(sin(System.currentTimeMillis() / 1700.0)).toFloat())
}
