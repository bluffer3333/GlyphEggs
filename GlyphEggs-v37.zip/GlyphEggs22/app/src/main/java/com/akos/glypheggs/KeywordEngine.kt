package com.akos.glypheggs

import kotlin.math.PI
import kotlin.math.abs
import kotlin.math.cos
import kotlin.math.ln
import kotlin.math.log10
import kotlin.math.sin
import kotlin.math.sqrt

/*
 * A hangparancs-felismerő motorja (Android nélkül, így asztalon is tesztelhető).
 *
 * A mikrofon hangjából hangerő alapján kivágja a kimondott szót, és keretenként (25 ms ablak, 10 ms lépés)
 * három dolgot mér:
 *  - HANGKÉP: MFCC (12 együttható), ebből derül ki, milyen hangok vannak benne,
 *  - HANGLEJTÉS: az alaphang magassága (autokorreláció, 70–500 Hz),
 *  - HANGSÚLY: a hangerő (dB).
 *
 * AZ IDŐT NEM NÉZI: mindkét kimondást ugyanakkora hosszúra nyújtja/zsugorítja, mielőtt összeveti,
 * így mindegy, gyorsan vagy lassan mondod. Az összevetés a felvett mintáiddal történik:
 *  - a hangkép rugalmas időillesztéssel (DTW),
 *  - a hanglejtés és a hangsúly íve egyszerű pontonkénti eltéréssel.
 * A küszöböt a saját mintáid egymástól való eltéréséből számolja („hagyj ki egyet”).
 */

/** Egy kimondás nyers keretei: [0..11] MFCC, [12] alaphang Hz (0 = zöngétlen), [13] hangerő dB. */
typealias KwFrames = Array<FloatArray>

/** Összevetésre kész hangkép. */
class KwFeat(val spec: Array<FloatArray>, val pros: FloatArray)

object KwMatch {
    const val NCEP = 12
    const val FRAME = 14
    private const val L = 40      // ennyi keretre normálja a hangképet
    private const val P = 20      // ennyi pontra a hanglejtést és a hangsúlyt

    /** Levágja az elejéről és a végéről a halk részeket (a csúcs alatt 18 dB-lel), hogy csak a szó maradjon. */
    fun trim(f: KwFrames): KwFrames {
        val mx = f.maxOf { it[13] }
        val a = f.indexOfFirst { it[13] > mx - 18f }
        val b = f.indexOfLast { it[13] > mx - 18f }
        return if (a < 0 || b - a < 8) f else f.copyOfRange(a, b + 1)
    }

    fun features(raw: KwFrames): KwFeat {
        val f = trim(raw)
        // Hangkép: cepstrális átlag-normalizálás (a mikrofon / terem színezetét kiveszi), majd időnormálás
        val mean = FloatArray(NCEP)
        for (x in f) for (k in 0 until NCEP) mean[k] += x[k]
        for (k in 0 until NCEP) mean[k] /= f.size
        val cmn = Array(f.size) { i -> FloatArray(NCEP) { k -> f[i][k] - mean[k] } }
        val spec = resample(cmn, L)

        // Hanglejtés: félhangokban, a saját középhangjához mérve; a zöngétlen részeket kitölti
        val hz = FloatArray(f.size) { f[it][12] }
        val voiced = hz.filter { it > 0f }.sorted()
        val st = FloatArray(f.size)
        if (voiced.size >= maxOf(4, f.size / 5)) {
            val med = voiced[voiced.size / 2]
            var last = 0f
            for (i in hz.indices) { if (hz[i] > 0f) last = (12f * ln(hz[i] / med) / ln(2f)).coerceIn(-12f, 12f); st[i] = last }
            // az elejét is kitölti az első zöngés értékkel
            val first = hz.indexOfFirst { it > 0f }
            for (i in 0 until first) st[i] = st[first]
        }
        // Hangsúly: dB a legerősebb ponthoz képest, harmadolva (3 dB ≈ 1 félhang súlya)
        val dbMax = f.maxOf { it[13] }
        val en = FloatArray(f.size) { ((f[it][13] - dbMax).coerceAtLeast(-30f)) / 3f }
        val pros = FloatArray(P * 2)
        val ps = resample1(st, P); val pe = resample1(en, P)
        for (i in 0 until P) { pros[i] = ps[i]; pros[P + i] = pe[i] }
        return KwFeat(spec, pros)
    }

    /** A hangkép távolsága (DTW az időnormált sorozatokon; a sáv csak kis helyi csúszást enged). */
    fun specDist(a: KwFeat, b: KwFeat): Float = dtw(a.spec, b.spec)

    /** A hanglejtés + hangsúly ívének átlagos eltérése (± 1 pont elcsúszást megengedve). */
    fun prosDist(a: KwFeat, b: KwFeat): Float {
        var best = Float.MAX_VALUE
        for (shift in -1..1) {
            var s = 0f; var n = 0
            for (half in 0..1) for (i in 0 until P) {
                val j = i + shift
                if (j !in 0 until P) continue
                s += abs(a.pros[half * P + i] - b.pros[half * P + j]); n++
            }
            best = minOf(best, s / n)
        }
        return best
    }

    /** A betanított minták modellje: küszöbök a saját szórásodból. */
    class Model(val t: List<KwFeat>) {
        val thrS: Float
        val thrP: Float
        init {
            var s = 0f; var p = 0f
            for (i in t.indices) {
                val others = t.indices.filter { it != i }
                if (others.isEmpty()) continue
                s = maxOf(s, others.minOf { specDist(t[i], t[it]) })
                p = maxOf(p, others.minOf { prosDist(t[i], t[it]) })
            }
            thrS = maxOf(s, 2.2f)
            thrP = maxOf(p, 0.9f)
        }

        /**
         * Pontszám: a hangkép 75%-ban, a hanglejtés + hangsúly 25%-ban számít, mindkettő a saját
         * szórásodhoz mérve. ≤ 1 körül: olyan, mint a mintáid. (A legközelebbi mintához mér.)
         */
        fun score(f: KwFeat): Float = t.minOf { 0.75f * specDist(f, it) / thrS + 0.25f * prosDist(f, it) / thrP }
    }

    private fun resample(x: Array<FloatArray>, n: Int): Array<FloatArray> = Array(n) { i ->
        val pos = if (n == 1) 0f else i * (x.size - 1f) / (n - 1f)
        val a = pos.toInt().coerceIn(0, x.size - 1); val b = minOf(a + 1, x.size - 1); val w = pos - a
        FloatArray(x[0].size) { k -> x[a][k] * (1 - w) + x[b][k] * w }
    }

    private fun resample1(x: FloatArray, n: Int): FloatArray = FloatArray(n) { i ->
        val pos = if (n == 1) 0f else i * (x.size - 1f) / (n - 1f)
        val a = pos.toInt().coerceIn(0, x.size - 1); val b = minOf(a + 1, x.size - 1); val w = pos - a
        x[a] * (1 - w) + x[b] * w
    }

    fun dtw(a: Array<FloatArray>, b: Array<FloatArray>): Float {
        val n = a.size; val m = b.size
        if (n == 0 || m == 0) return Float.MAX_VALUE
        val band = (maxOf(n, m) * 0.25f).toInt() + 2
        val inf = Float.MAX_VALUE / 4
        var prev = FloatArray(m + 1) { inf }
        var cur = FloatArray(m + 1) { inf }
        prev[0] = 0f
        for (i in 1..n) {
            cur.fill(inf)
            val center = i * m / n
            val j0 = maxOf(1, center - band); val j1 = minOf(m, center + band)
            for (j in j0..j1) {
                var d = 0f
                val x = a[i - 1]; val y = b[j - 1]
                for (k in x.indices) { val q = x[k] - y[k]; d += q * q }
                d = sqrt(d)
                cur[j] = d + minOf(prev[j], minOf(cur[j - 1], prev[j - 1]))
            }
            val tmp = prev; prev = cur; cur = tmp
        }
        return prev[m] / (n + m)
    }

    // --- tárolás szövegként ---
    fun encode(list: List<KwFrames>): String =
        list.joinToString("|") { t -> t.joinToString(";") { f -> f.joinToString(",") { "%.2f".format(java.util.Locale.US, it) } } }

    /** Csak az új (14 értékes) formátumot fogadja el; a régit üresnek veszi (újra kell tanítani). */
    fun decode(s: String): List<KwFrames> = try {
        if (s.isBlank()) emptyList() else s.split("|").map { t ->
            t.split(";").map { f -> f.split(",").map { it.toFloat() }.toFloatArray() }.toTypedArray()
        }.filter { it.isNotEmpty() && it[0].size == FRAME }
    } catch (e: Throwable) { emptyList() }
}

/** Beszédszakasz-kivágó és keret-elemző (VAD + MFCC + alaphang + hangerő). */
class KwSegmenter(private val onSegment: (KwFrames) -> Unit) {
    private val SR = 16_000
    private val WIN = 400
    private val HOP = 160
    private val NFFT = 512
    private val NMEL = 26
    private val MIN_FRAMES = 20   // 0,2 s
    private val MAX_FRAMES = 200  // 2 s
    private val PRE_ROLL = 8
    private val HANG = 22         // 220 ms csend zárja a szakaszt

    /** Élő kijelzés: 0..1, ha épp beszéd van. */
    @Volatile var voice = 0f

    private val buf = FloatArray(WIN + HOP * 4)
    private var bufLen = 0
    private val window = FloatArray(WIN) { (0.54 - 0.46 * cos(2 * PI * it / (WIN - 1))).toFloat() }
    private val re = FloatArray(NFFT)
    private val im = FloatArray(NFFT)
    private val melFilters = buildMel()
    private val dct = Array(KwMatch.NCEP) { k -> FloatArray(NMEL) { m -> cos(PI * (k + 1) * (m + 0.5) / NMEL).toFloat() } }

    private var noiseDb = -60f
    private var frames = 0
    private var voicedRun = 0
    private var silentRun = 0
    private var inSpeech = false
    private val pre = ArrayDeque<FloatArray>()
    private val seg = ArrayList<FloatArray>()

    @Synchronized
    fun feed(b: ShortArray, n: Int) {
        var i = 0
        while (i < n) {
            val take = minOf(n - i, buf.size - bufLen)
            for (k in 0 until take) buf[bufLen + k] = b[i + k] / 32768f
            bufLen += take
            i += take
            while (bufLen >= WIN) {
                frame()
                System.arraycopy(buf, HOP, buf, 0, bufLen - HOP)
                bufLen -= HOP
            }
        }
    }

    private fun frame() {
        var e = 0.0
        for (k in 0 until WIN) e += buf[k] * buf[k]
        val db = 10f * log10((e / WIN).toFloat() + 1e-12f)
        // Zajszint: az első fél másodpercben gyorsan beáll, utána csendben lassan követ
        val up = if (frames < 50) 0.15f else 0.004f
        if (frames < 50) frames++
        noiseDb = if (db < noiseDb) noiseDb + (db - noiseDb) * 0.2f else noiseDb + (db - noiseDb) * up
        val voiced = db > noiseDb + 10f && db > -52f
        voice = if (voiced) ((db + 60f) / 50f).coerceIn(0f, 1f) else 0f
        val fr = FloatArray(KwMatch.FRAME)
        mfcc(fr)
        fr[12] = if (db > noiseDb + 6f) pitch() else 0f
        fr[13] = db

        if (!inSpeech) {
            pre.addLast(fr); if (pre.size > PRE_ROLL) pre.removeFirst()
            voicedRun = if (voiced) voicedRun + 1 else 0
            if (voicedRun >= 3) {
                inSpeech = true
                seg.clear(); seg.addAll(pre)
                silentRun = 0
            }
        } else {
            seg.add(fr)
            silentRun = if (voiced) 0 else silentRun + 1
            if (silentRun >= HANG || seg.size > MAX_FRAMES + HANG) {
                val keep = (seg.size - silentRun + 3).coerceIn(0, seg.size)
                val s = seg.subList(0, keep).toTypedArray()
                inSpeech = false; voicedRun = 0; pre.clear()
                if (s.size in MIN_FRAMES..MAX_FRAMES) onSegment(s)
            }
        }
    }

    /** Alaphang normált autokorrelációval (70–500 Hz); 0, ha nem zöngés. */
    private fun pitch(): Float {
        val minLag = SR / 500; val maxLag = SR / 70
        var best = 0f; var bestLag = 0
        for (lag in minLag..maxLag) {
            var s = 0f; var e1 = 0f; var e2 = 0f
            val n = WIN - lag
            for (i in 0 until n) { val a = buf[i]; val b = buf[i + lag]; s += a * b; e1 += a * a; e2 += b * b }
            val r = if (e1 > 0f && e2 > 0f) s / sqrt(e1 * e2) else 0f
            if (r > best) { best = r; bestLag = lag }
        }
        return if (best > 0.5f && bestLag > 0) SR.toFloat() / bestLag else 0f
    }

    private fun mfcc(out: FloatArray) {
        for (k in 0 until NFFT) { re[k] = if (k < WIN) buf[k] * window[k] else 0f; im[k] = 0f }
        fft(re, im)
        val pw = FloatArray(NFFT / 2 + 1) { re[it] * re[it] + im[it] * im[it] }
        val mel = FloatArray(NMEL) { m ->
            var s = 0f
            val f = melFilters[m]
            for (k in f.indices) s += f[k] * pw[k]
            ln(s + 1e-10f)
        }
        for (k in 0 until KwMatch.NCEP) { var s = 0f; for (m in 0 until NMEL) s += dct[k][m] * mel[m]; out[k] = s }
    }

    private fun buildMel(): Array<FloatArray> {
        fun hz2mel(h: Double) = 2595.0 * log10(1 + h / 700.0)
        fun mel2hz(m: Double) = 700.0 * (Math.pow(10.0, m / 2595.0) - 1)
        val lo = hz2mel(80.0); val hi = hz2mel(7600.0)
        val pts = DoubleArray(NMEL + 2) { mel2hz(lo + (hi - lo) * it / (NMEL + 1)) }
        val bins = IntArray(NMEL + 2) { Math.floor((NFFT + 1) * pts[it] / SR).toInt() }
        return Array(NMEL) { m ->
            FloatArray(NFFT / 2 + 1) { k ->
                when {
                    k < bins[m] || k > bins[m + 2] -> 0f
                    k <= bins[m + 1] -> if (bins[m + 1] == bins[m]) 1f else (k - bins[m]).toFloat() / (bins[m + 1] - bins[m])
                    else -> if (bins[m + 2] == bins[m + 1]) 1f else (bins[m + 2] - k).toFloat() / (bins[m + 2] - bins[m + 1])
                }
            }
        }
    }

    private fun fft(re: FloatArray, im: FloatArray) {
        val n = re.size
        var j = 0
        for (i in 1 until n) {
            var bit = n shr 1
            while (j and bit != 0) { j = j xor bit; bit = bit shr 1 }
            j = j or bit
            if (i < j) { val tr = re[i]; re[i] = re[j]; re[j] = tr; val ti = im[i]; im[i] = im[j]; im[j] = ti }
        }
        var len = 2
        while (len <= n) {
            val ang = -2 * PI / len
            val wr0 = cos(ang).toFloat(); val wi0 = sin(ang).toFloat()
            var i = 0
            while (i < n) {
                var wr = 1f; var wi = 0f
                for (k in 0 until len / 2) {
                    val a = i + k; val b = a + len / 2
                    val tr = wr * re[b] - wi * im[b]; val ti = wr * im[b] + wi * re[b]
                    re[b] = re[a] - tr; im[b] = im[a] - ti
                    re[a] += tr; im[a] += ti
                    val nwr = wr * wr0 - wi * wi0; wi = wr * wi0 + wi * wr0; wr = nwr
                }
                i += len
            }
            len *= 2
        }
    }
}
