package com.akos.glypheggs

import android.content.Context
import com.nothing.ketchum.Glyph
import kotlinx.coroutines.delay

/*
 * GLYPH STÚDIÓ – saját LED-animációk. Egy animáció képkockák sora; minden képkocka a világító zónák
 * halmaza és egy időtartam. A kedvenc animáció a „Glyph Stúdió” funkcióval (csempe, mozdulat, widget)
 * a hátlapon lejátszható.
 */

class StudioFrame(val zones: MutableSet<Int>, var ms: Int) {
    fun copy() = StudioFrame(zones.toMutableSet(), ms)
}

class StudioAnim(val id: String, var name: String, var loops: Int, val frames: MutableList<StudioFrame>) {
    /** Egy kör hossza (ms). */
    fun cycleMs(): Long = frames.sumOf { it.ms.toLong() }

    fun encode(): String = listOf(id, name.replace("|", "/").replace("\n", " "), loops.toString(),
        frames.joinToString(";") { f -> "${f.ms}:" + f.zones.joinToString(",") }).joinToString("|")

    companion object {
        fun decode(s: String): StudioAnim? = try {
            val p = s.split("|")
            val frames = p[3].split(";").filter { it.isNotBlank() }.map { fs ->
                val ms = fs.substringBefore(":").toInt()
                val z = fs.substringAfter(":", "").split(",").filter { it.isNotBlank() }.map { it.toInt() }.toMutableSet()
                StudioFrame(z, ms.coerceIn(30, 5_000))
            }.toMutableList()
            if (frames.isEmpty()) null else StudioAnim(p[0], p[1], p[2].toInt().coerceIn(0, 99), frames)
        } catch (t: Throwable) { null }
    }
}

object StudioStore {
    private const val PREFS = "glyph_eggs_studio"
    private fun p(c: Context) = c.getSharedPreferences(PREFS, Context.MODE_PRIVATE)

    fun all(c: Context): MutableList<StudioAnim> {
        val list = (p(c).getString("anims", null) ?: "").split("\n").mapNotNull { if (it.isBlank()) null else StudioAnim.decode(it) }.toMutableList()
        if (list.isEmpty() && !p(c).getBoolean("seeded", false)) {
            // Első megnyitás: két mintaanimáció, hogy legyen mivel kezdeni
            list += Templates.make("Körbefutó")!!
            list += Templates.make("Szívverés")!!
            save(c, list)
            p(c).edit().putBoolean("seeded", true).apply()
        }
        return list
    }

    fun save(c: Context, list: List<StudioAnim>) {
        p(c).edit().putString("anims", list.joinToString("\n") { it.encode() }).apply()
    }

    fun upsert(c: Context, a: StudioAnim) {
        val list = all(c)
        val i = list.indexOfFirst { it.id == a.id }
        if (i >= 0) list[i] = a else list += a
        save(c, list)
    }

    fun delete(c: Context, id: String) = save(c, all(c).filter { it.id != id })
    fun find(c: Context, id: String?): StudioAnim? = all(c).firstOrNull { it.id == id }

    fun favorite(c: Context): StudioAnim? = find(c, p(c).getString("fav", null)) ?: all(c).firstOrNull()
    fun favoriteId(c: Context): String? = p(c).getString("fav", null)
    fun setFavorite(c: Context, id: String) = p(c).edit().putString("fav", id).apply()

    fun newId(): String = "a" + System.currentTimeMillis().toString(36)
}

/** Kész sablonok kiindulásnak. */
object Templates {
    val names = listOf("Üres", "Körbefutó", "Szívverés", "Töltés", "Villogó", "Pislogó szem", "Eső", "Ping-pong")

    private val ring: IntArray get() = Zones.LEVEL.reversedArray() + intArrayOf(
        Glyph.Code_22111.C6, Glyph.Code_22111.C5, Glyph.Code_22111.C4, Glyph.Code_22111.C3, Glyph.Code_22111.C2)

    fun make(name: String): StudioAnim? {
        val f = mutableListOf<StudioFrame>()
        when (name) {
            "Üres" -> f += StudioFrame(mutableSetOf(), 300)
            "Körbefutó" -> { val r = ring; for (i in r.indices) f += StudioFrame(mutableSetOf(r[i], r[(i + r.size - 1) % r.size]), 50) }
            "Szívverés" -> {
                val heart = (ring.toList() + Glyph.Code_22111.E1).toMutableSet()
                f += StudioFrame(heart.toMutableSet(), 120); f += StudioFrame(mutableSetOf(), 120)
                f += StudioFrame(heart.toMutableSet(), 160); f += StudioFrame(mutableSetOf(), 600)
            }
            "Töltés" -> { val o = LectureTimer.FILL_ORDER; for (i in 1..o.size) f += StudioFrame(o.take(i).toMutableSet(), 45); f += StudioFrame(mutableSetOf(), 400) }
            "Villogó" -> { f += StudioFrame(Zones.ALL.toMutableSet(), 150); f += StudioFrame(mutableSetOf(), 150) }
            "Pislogó szem" -> {
                f += StudioFrame(mutableSetOf(Glyph.Code_22111.A1, Glyph.Code_22111.A2), 1_400)
                f += StudioFrame(mutableSetOf(Glyph.Code_22111.A1), 90)
                f += StudioFrame(mutableSetOf(), 90)
                f += StudioFrame(mutableSetOf(Glyph.Code_22111.A1), 90)
            }
            "Eső" -> {
                val rnd = java.util.Random(7)
                repeat(14) { f += StudioFrame(mutableSetOf(Zones.ALL[rnd.nextInt(Zones.ALL.size)], Zones.ALL[rnd.nextInt(Zones.ALL.size)]), 110) }
            }
            "Ping-pong" -> { val b = Zones.LEVEL; for (i in b.indices) f += StudioFrame(mutableSetOf(b[i]), 40); for (i in b.indices.reversed()) f += StudioFrame(mutableSetOf(b[i]), 40) }
            else -> return null
        }
        return StudioAnim(StudioStore.newId() + name.hashCode().toString(36), name, 3, f)
    }
}

/** Lejátszás a hátlapon. [loops] 0 = amíg le nem állítják (legfeljebb 10 percig). */
class StudioPlayer(private val glyph: GlyphController) {
    suspend fun play(a: StudioAnim) {
        val loops = if (a.loops == 0) Int.MAX_VALUE else a.loops
        val until = System.currentTimeMillis() + 10 * 60_000L
        var k = 0
        while (k < loops && System.currentTimeMillis() < until) {
            for (fr in a.frames) {
                if (fr.zones.isEmpty()) glyph.off() else glyph.show(fr.zones.toIntArray())
                delay(fr.ms.toLong())
            }
            k++
        }
        glyph.off()
    }
}
