package com.akos.glypheggs

import android.content.Context

/** Az indítható funkciók. [game] = a Játékok fülön van, különben az Eszközök fülön. */
enum class Feature(val title: String, val short: String, val icon: Int, val game: Boolean) {
    SIMON("Glyph Simon", "Simon", R.drawable.ic_play, true),
    SPIN("Pörgetés", "Pörgetés", R.drawable.ic_spin, false),
    COMPASS("Iránytű", "Iránytű", R.drawable.ic_compass, false),
    LOCKPICK("Zárfeltörő", "Zár", R.drawable.ic_lock, true),
    SAFE("Széf", "Széf", R.drawable.ic_safe, false),
    PET("Glyph Tojás", "Tojás", R.drawable.ic_pet, true),
    LEVEL("Vízmérték", "Vízmérték", R.drawable.ic_level, false),
    TIMER("Időzítő", "Időzítő", R.drawable.ic_timer, false),
    BREATH("Légzés", "Légzés", R.drawable.ic_breath, false),
    DINO("Dínófutás", "Dínó", R.drawable.ic_dino, true),
    LECTURE("Előadás", "Előadás", R.drawable.ic_lecture, false),
    BLOW("Fújós", "Fújós", R.drawable.ic_wind, true),
    DETOX("Glyph Focus", "Focus", R.drawable.ic_focus, false),
    STUDIO("Glyph Stúdió", "Stúdió", R.drawable.ic_studio, false),
    MORSE("Morze-gyakorló", "Morze", R.drawable.ic_morse, false)
}

/**
 * Indító mozdulatok. Bármelyik bármelyik funkcióhoz rendelhető,
 * de egy mozdulat egyszerre csak egy funkcióhoz tartozhat.
 */
enum class Trigger(val title: String, val hint: String) {
    NONE("Nincs", "Csak csempével vagy az appból indul"),
    RIGHT_2("Jobbra forgatás 2×", "Fekve kétszer kb. negyed fordulat jobbra"),
    LEFT_2("Balra forgatás 2×", "Fekve kétszer kb. negyed fordulat balra"),
    RIGHT_LEFT("Jobbra, majd balra", "Fekve negyed fordulat jobbra, aztán vissza balra"),
    LEFT_RIGHT("Balra, majd jobbra", "Fekve negyed fordulat balra, aztán vissza jobbra"),
    SPIN("Megpörgetés", "Pörgesd meg az asztalon legalább egy teljes körre"),
    KNOCK_2("Kopogás 2×", "Fekve kopogtass kétszer a telefonon (nem kell sietni)"),
    KNOCK_3("Kopogás 3×", "Fekve kopogtass háromszor a telefonon (nem kell sietni)"),
    SHAKE("Rázás, majd lerakás", "Rázd meg, és 6 mp-en belül tedd le kijelzővel lefelé"),
    FLIP_2("Lefordítás 2×", "Kijelzővel felfelé → lefelé, kétszer egymás után"),
    SHAKE_FILL("Rázás-töltés", "Rázd a telefont: a LED-ek alulról (töltőport) felfelé gyulladnak, és ha mind ég, elindul a funkció. A rázások száma állítható. Ne használd együtt a „Rázás, majd lerakás” mozdulattal."),
    VOL_UP_2("Hangerő fel 2×", "Nyomd meg kétszer gyorsan a hangerő-növelő gombot. Bekapcsolt (akár zárolt) képernyőnél megy; kikapcsolt képernyőnél csak, ha épp szól valami. A hangerő utána visszaáll. Max. hangerőnél nem érzékelhető"),
    VOL_DOWN_2("Hangerő le 2×", "Nyomd meg kétszer gyorsan a hangerő-csökkentő gombot. Bekapcsolt (akár zárolt) képernyőnél megy; kikapcsolt képernyőnél csak, ha épp szól valami. A hangerő utána visszaáll. Némításnál nem érzékelhető"),
    VOL_COMBO("Hangerő-kombináció", "Saját sorrend a hangerő-gombokkal (pl. ▲▲▼) – funkciónként más-más. A sorozat után kb. 0,7 mp szünet, és indul; a hangerő visszaáll"),
    ROLL_3("Hengerítés 3×", "Két kézben, fekvő helyzetben magad előtt (töltőport a jobb kezed felé): forgasd 3-szor körbe a hosszanti tengelye körül, mint egy sodrófát");

    /** Forgatással (giroszkóppal) felismert mozdulat-e. */
    val usesGyro: Boolean
        get() = this == RIGHT_2 || this == LEFT_2 || this == RIGHT_LEFT || this == LEFT_RIGHT || this == SPIN

    val isKnock: Boolean
        get() = this == KNOCK_2 || this == KNOCK_3
}

/**
 * Leállítási parancsok: futás közben mivel lehessen leállítani egy funkciót.
 * Funkciónként több is bekapcsolható. A csempe, a widget, az értesítés „Leállítás” gombja
 * és az app „Most fut” kártyája ezen felül mindig működik.
 */
enum class StopMethod(val title: String, val hint: String) {
    POWER("Bekapcsoló gomb", "Nyomd meg egyszer, amikor a képernyő ki van kapcsolva (lefelé fekvő telefonnál ez a megszokott). Ha épp be van kapcsolva, nyomd meg kétszer."),
    LIFT("Felemelés", "Vedd fel az asztalról, és tartsd a kezedben 2 mp-ig"),
    FLIP_UP("Megfordítás", "Fordítsd kijelzővel felfelé, és hagyd így 1 mp-ig"),
    SHAKE("Erős rázás", "Rázd meg erősen kétszer, kb. 3 mp-en belül"),
    KNOCK_3("Kopogás 3×", "Fekve kopogtass háromszor a telefonon (nem kell sietni)");

    /** Miért nem választható ennél a funkciónál (null = választható). */
    fun blockedFor(f: Feature): String? = when (this) {
        POWER -> null
        LIFT -> when (f) {
            Feature.SIMON -> "A Simonban kézben is döntheted a telefont"
            Feature.SAFE -> "A kódot döntéssel adod meg – kézben is"
            Feature.LEVEL -> "A vízmérték élére és portra állítva is mér"
            Feature.LECTURE -> "Az előadás alatt időnként kézbe veszed a telefont – az nem állíthatja le"
            Feature.BLOW -> "A Fújósnál a kezedben tartod a telefont"
            Feature.BREATH -> "A légzést kézben vagy párnán fekve is követheted"
            Feature.DETOX -> "A Glyph Focus magától figyeli a felemelést – az a vége"
            Feature.MORSE -> "A megfejtéshez kézbe veszed a telefont"
            else -> null
        }
        FLIP_UP -> if (f == Feature.LEVEL) "A vízmérték fekve bármelyik oldalán mér"
            else if (f == Feature.DETOX) "A Glyph Focus magától figyeli a megfordítást"
            else if (f == Feature.MORSE) "A megfejtéshez megfordítod a telefont" else null
        SHAKE -> when (f) {
            Feature.PET -> "A rázás a Tojás egyik játéka"
            Feature.LECTURE -> "A rázás tölti fel az előadást, és indíthatja a szünetet"
            else -> null
        }
        KNOCK_3 -> when (f) {
            Feature.LOCKPICK, Feature.DINO -> "Ebben a játékban kopogással irányítasz"
            Feature.PET -> "A Tojást kopogással gondozod"
            Feature.LEVEL -> "A vízmérték kopogással kalibrál"
            Feature.TIMER -> "Az időzítőt kopogással vezérled"
            Feature.LECTURE -> "A kopogás az indításra és a szünetre van fenntartva"
            else -> null
        }
    }

    /** Ezt a funkció magától is tudja (mindig be van kapcsolva). */
    fun builtInFor(f: Feature): Boolean =
        this == LIFT && (f == Feature.COMPASS || f == Feature.PET)
}

/** Az előadás-időzítő indítása (töltése): mivel kell „feltölteni”, hogy elinduljon. */
enum class LectureStart(val title: String, val hint: String) {
    SHAKE("Rázás", "Rázd a telefont: a LED-ek alulról (töltőport) felfelé gyulladnak, és ha mind ég, indul"),
    KNOCK("Kopogás", "Kopogtass az asztalon fekvő telefonon: minden kopogásra feljebb mennek a LED-ek, és ha mind ég, indul"),
    INSTANT("Azonnal", "Nincs töltés: az indítás után rögtön indul az előadás")
}

/** Az előadás közbeni szünet indítása (és, ha engedélyezett, korai befejezése). */
enum class BreakCommand(val title: String, val hint: String) {
    SHAKE("Rázás kétszer", "Rázd meg kétszer, kb. 3 mp-en belül"),
    KNOCK_3("Kopogás 3×", "Fekve kopogtass háromszor a telefonon (nem kell sietni)"),
    NONE("Nincs", "Nem indul szünet; az előadás megszakítás nélkül megy")
}

/** Mivel lehet ugrani a Dínófutásban (több is bekapcsolható). */
enum class DinoJump(val title: String, val hint: String) {
    KNOCK("Kopogás", "Kopogtass a fekvő telefonon (a kopogás érzékenysége az Indítás és leállítás oldalon állítható)"),
    SHAKE("Rázás", "Egy erős rázás / rántás – kézben is játszható"),
    VOL_UP("Hangerő fel gomb", "Nyomd meg a hangerő-növelő gombot. Kísérleti: a játék alatt a hangerő-gombok nem a hangerőt állítják"),
    VOL_DOWN("Hangerő le gomb", "Nyomd meg a hangerő-csökkentő gombot. Kísérleti: a játék alatt a hangerő-gombok nem a hangerőt állítják"),
    POWER("Bekapcsoló gomb", "Minden gombnyomás ugrás (a képernyő közben ki-be kapcsolhat). Ilyenkor a bekapcsoló gombos leállítás nem működik"),
    SHOUT("Kiáltás", "Kiálts rá (HOPP! / HÉ!) – minden hangos, rövid kiáltás ugrás. Mikrofon kell; az appból vagy widgetről indítsd, mert háttérből az Android nem engedi a mikrofont")
}

/** Mentett beállítások egy helyen. */
object Settings {
    private const val PREFS = "glyph_eggs"
    private const val KEY_WATCHING = "enabled"
    private const val KEY_VIBRATE = "vibrate"
    private const val KEY_KNOCK_SENS = "knock_sensitivity"
    private const val KEY_LAST_LEVEL = "last_level"

    private fun p(c: Context) = c.getSharedPreferences(PREFS, Context.MODE_PRIVATE)

    private fun key(f: Feature) = "trigger_${f.name}"

    fun defaultTrigger(f: Feature): Trigger = when (f) {
        Feature.SIMON -> Trigger.RIGHT_2
        Feature.SPIN -> Trigger.SPIN
        Feature.COMPASS -> Trigger.KNOCK_2
        Feature.LOCKPICK -> Trigger.NONE
        Feature.SAFE -> Trigger.NONE
        Feature.PET -> Trigger.NONE
        Feature.LEVEL -> Trigger.NONE
        Feature.TIMER -> Trigger.NONE
        Feature.BREATH -> Trigger.NONE
        Feature.DINO -> Trigger.NONE
        Feature.LECTURE -> Trigger.SHAKE_FILL
        Feature.BLOW -> Trigger.NONE
        Feature.DETOX -> Trigger.NONE
        Feature.MORSE -> Trigger.NONE
        Feature.STUDIO -> Trigger.NONE
    }

    fun trigger(c: Context, f: Feature): Trigger {
        val name = p(c).getString(key(f), null) ?: return defaultTrigger(f)
        return Trigger.entries.firstOrNull { it.name == name } ?: defaultTrigger(f)
    }

    /** Beállítja a mozdulatot; ha másik funkció használta, ott "Nincs" lesz. */
    fun setTrigger(c: Context, f: Feature, t: Trigger) {
        val e = p(c).edit()
        // A hangerő-kombináció több funkcióé is lehet (mindegyiknek saját sorrendje van)
        if (t != Trigger.NONE && t != Trigger.VOL_COMBO) {
            for (other in Feature.entries) {
                if (other != f && trigger(c, other) == t) e.putString(key(other), Trigger.NONE.name)
            }
        }
        e.putString(key(f), t.name)
        e.apply()
    }

    /** Melyik funkció indul erre a mozdulatra (ha van). */
    fun featureFor(c: Context, t: Trigger): Feature? =
        if (t == Trigger.NONE) null else Feature.entries.firstOrNull { trigger(c, it) == t }

    fun activeTriggers(c: Context): Set<Trigger> =
        Feature.entries.filter { armed(c, it) }.map { trigger(c, it) }.filter { it != Trigger.NONE }.toSet()

    /**
     * Élesítve van-e a funkció indító mozdulata (a widget „FIGYEL / RÁZÁS: BE-KI” gombja ezt kapcsolja).
     * Kikapcsolva a mozdulat megmarad, csak nem figyeli.
     */
    fun armed(c: Context, f: Feature): Boolean = p(c).getBoolean("armed_${f.name}", true)
    fun setArmed(c: Context, f: Feature, v: Boolean) = p(c).edit().putBoolean("armed_${f.name}", v).apply()
    /** A widget kapcsolta be a mozdulatfigyelést (így ha ott kikapcsolod, a figyelés is leállhat). */
    fun watchByWidget(c: Context): Boolean = p(c).getBoolean("watch_by_widget", false)
    fun setWatchByWidget(c: Context, v: Boolean) = p(c).edit().putBoolean("watch_by_widget", v).apply()
    /** Figyel-e most a funkció indító mozdulatára. */
    fun listening(c: Context, f: Feature): Boolean =
        watching(c) && armed(c, f) && trigger(c, f) != Trigger.NONE

    // --- Leállítási parancsok ---
    /** Alapból a bekapcsoló gomb mindenhol leállít, kivéve az Időzítőt és az Előadást (azokat hosszan futtatod, közben nézheted a telefont). */
    fun defaultStops(f: Feature): Set<StopMethod> =
        if (f == Feature.TIMER || f == Feature.LECTURE || f == Feature.MORSE) emptySet() else setOf(StopMethod.POWER)

    fun stopMethods(c: Context, f: Feature): Set<StopMethod> {
        val raw = p(c).getString("stop_${f.name}", null) ?: return defaultStops(f)
        return raw.split(",").mapNotNull { n -> StopMethod.entries.firstOrNull { it.name == n } }
            .filter { it.blockedFor(f) == null }.toSet()
    }

    fun setStopMethod(c: Context, f: Feature, m: StopMethod, on: Boolean) {
        val cur = stopMethods(c, f).toMutableSet()
        if (on) cur += m else cur -= m
        p(c).edit().putString("stop_${f.name}", cur.joinToString(",") { it.name }).apply()
    }

    /** Rövid felsorolás a felülethez, pl. „Bekapcsoló gomb, Felemelés”. */
    fun stopSummary(c: Context, f: Feature): String {
        val list = StopMethod.entries.filter { it in stopMethods(c, f) || it.builtInFor(f) }
        return if (list.isEmpty()) "Csak csempe / widget / app" else list.joinToString(", ") { it.title }
    }

    fun watching(c: Context): Boolean = p(c).getBoolean(KEY_WATCHING, false)
    fun setWatching(c: Context, on: Boolean) = p(c).edit().putBoolean(KEY_WATCHING, on).apply()

    fun vibrate(c: Context): Boolean = p(c).getBoolean(KEY_VIBRATE, true)
    fun setVibrate(c: Context, on: Boolean) = p(c).edit().putBoolean(KEY_VIBRATE, on).apply()

    /** Rázás érzékenysége: 0 = alacsony, 1 = közepes (alap), 2 = magas, 3 = nagyon magas. */
    fun shakeSensitivity(c: Context): Int = p(c).getInt("shake_sens", 1).coerceIn(0, 3)
    fun setShakeSensitivity(c: Context, v: Int) = p(c).edit().putInt("shake_sens", v.coerceIn(0, 3)).apply()
    /** A rázás-küszöbök szorzója az érzékenység szerint. */
    fun shakeFactor(c: Context): Float = Config.SHAKE_SENS_FACTORS[shakeSensitivity(c)]

    /** 0 = alacsony, 1 = közepes, 2 = magas. */
    fun knockSensitivity(c: Context): Int = p(c).getInt(KEY_KNOCK_SENS, 1).coerceIn(0, 3)
    fun setKnockSensitivity(c: Context, v: Int) = p(c).edit().putInt(KEY_KNOCK_SENS, v.coerceIn(0, 3)).apply()

    fun lastLevel(c: Context): Int = p(c).getInt(KEY_LAST_LEVEL, -1)
    fun setLastLevel(c: Context, v: Int) = p(c).edit().putInt(KEY_LAST_LEVEL, v).apply()

    // --- Zárfeltörő ---
    fun lockBest(c: Context): Int = p(c).getInt("lock_best", 0)
    fun setLockBest(c: Context, v: Int) = p(c).edit().putInt("lock_best", v).apply()

    // --- Széf ---
    /** Döntéses kód: irányok sorozata (3–8 lépés). Alap: előre, jobbra, hátra, balra. */
    fun safeTiltCode(c: Context): List<Direction> {
        val raw = p(c).getString("safe_tilt", null) ?: return listOf(Direction.FORWARD, Direction.RIGHT, Direction.BACK, Direction.LEFT)
        val list = raw.split(",").mapNotNull { n -> Direction.entries.firstOrNull { it.name == n } }
        return if (list.size in 3..8) list else listOf(Direction.FORWARD, Direction.RIGHT, Direction.BACK, Direction.LEFT)
    }
    fun setSafeTiltCode(c: Context, code: List<Direction>) =
        p(c).edit().putString("safe_tilt", code.take(8).joinToString(",") { it.name }).apply()

    /** (Régi, villanásos kód – már nem használt.) A kód: 4 pozíció (0–7) a [SafePositions] listából. */
    fun safeCode(c: Context): IntArray {
        val raw = p(c).getString("safe_code", null) ?: return intArrayOf(0, 3, 5, 7)
        val parts = raw.split(",").mapNotNull { it.trim().toIntOrNull() }.filter { it in 0..7 }
        return if (parts.size == SafePositions.CODE_LENGTH) parts.toIntArray() else intArrayOf(0, 3, 5, 7)
    }
    fun setSafeCode(c: Context, code: IntArray) = p(c).edit().putString("safe_code", code.joinToString(",")).apply()

    /** Mivel kell kiválasztani a villanást: true = rázás, false = kopogás. */
    fun safeUsesShake(c: Context): Boolean = p(c).getBoolean("safe_shake", true)
    fun setSafeUsesShake(c: Context, v: Boolean) = p(c).edit().putBoolean("safe_shake", v).apply()

    /** Mi nyíljon meg: NOTES (titkos jegyzetek), FOLDER, APP, URL, NONE. */
    fun safeTargetType(c: Context): String = p(c).getString("safe_target_type", null) ?: "NOTES"
    fun safeTargetValue(c: Context): String = p(c).getString("safe_target_value", null) ?: ""
    fun safeTargetLabel(c: Context): String = p(c).getString("safe_target_label", null) ?: ""
    fun setSafeTarget(c: Context, type: String, value: String, label: String) = p(c).edit()
        .putString("safe_target_type", type).putString("safe_target_value", value)
        .putString("safe_target_label", label).apply()

    fun secretNotes(c: Context): String = p(c).getString("secret_notes", null) ?: ""
    fun setSecretNotes(c: Context, v: String) = p(c).edit().putString("secret_notes", v).apply()

    // --- Értesítések (Beállítások fül → Értesítések) ---
    /**
     * Az állandó értesítés elrejtése: „csendes” csatornára kerül – nincs ikon az állapotsoron,
     * a lehúzott menü alján összecsukva látszik, a zárolt képernyőn nem. (Teljesen nem tüntethető el,
     * mert a háttérfutáshoz az Android megköveteli; a rendszerbeállításban viszont kikapcsolható.)
     */
    /** Alapból rejtett: nincs ikon az állapotsoron, összecsukva a lehúzott menü alján. */
    fun notifPersistentHidden(c: Context): Boolean = p(c).getBoolean("notif_hidden", true)
    fun setNotifPersistentHidden(c: Context, v: Boolean) = p(c).edit().putBoolean("notif_hidden", v).apply()
    /** Órarend: „Kezdődik…” értesítés, ha a rendszer nem engedte az automatikus indítást. */
    fun notifSchedule(c: Context): Boolean = p(c).getBoolean("notif_schedule", true)
    fun setNotifSchedule(c: Context, v: Boolean) = p(c).edit().putBoolean("notif_schedule", v).apply()
    /** „Koppints a megnyitáshoz” értesítések (Széf, Fújós), ha az app nem nyílhat meg magától. */
    fun notifAssist(c: Context): Boolean = p(c).getBoolean("notif_assist", true)
    fun setNotifAssist(c: Context, v: Boolean) = p(c).edit().putBoolean("notif_assist", v).apply()
    /** Minden értesítés el van-e rejtve / kikapcsolva. */
    fun notifAllOff(c: Context): Boolean =
        notifPersistentHidden(c) && !petNotifications(c) && !notifSchedule(c) && !notifAssist(c) && !notifBadges(c)
    /** Értesítés új kitűzőről. */
    fun notifBadges(c: Context): Boolean = p(c).getBoolean("notif_badges", true)
    fun setNotifBadges(c: Context, v: Boolean) = p(c).edit().putBoolean("notif_badges", v).apply()
    fun setNotifAllOff(c: Context, off: Boolean) {
        setNotifPersistentHidden(c, off)
        setPetNotifications(c, !off)
        setNotifSchedule(c, !off)
        setNotifAssist(c, !off)
        setNotifBadges(c, !off)
    }

    // --- Glyph Tojás ---
    fun petNotifications(c: Context): Boolean = p(c).getBoolean("pet_notif", true)
    fun setPetNotifications(c: Context, v: Boolean) = p(c).edit().putBoolean("pet_notif", v).apply()

    // --- Felület: kitűzött funkciók (Főoldal) és a választott fül ---
    private val DEFAULT_PINNED = listOf(Feature.COMPASS, Feature.SPIN, Feature.SIMON, Feature.SAFE)

    fun pinned(c: Context): List<Feature> {
        val raw = p(c).getString("pinned", null) ?: return DEFAULT_PINNED
        return raw.split(",").mapNotNull { n -> Feature.entries.firstOrNull { it.name == n } }
    }
    fun setPinned(c: Context, list: List<Feature>) =
        p(c).edit().putString("pinned", list.joinToString(",") { it.name }).apply()
    fun togglePinned(c: Context, f: Feature): Boolean {
        val cur = pinned(c).toMutableList()
        val nowPinned = if (f in cur) { cur.remove(f); false } else { cur.add(f); true }
        setPinned(c, cur)
        return nowPinned
    }

    fun tab(c: Context): Int = p(c).getInt("tab", 0)
    fun setTab(c: Context, v: Int) = p(c).edit().putInt("tab", v).apply()

    // --- Vízmérték kalibráció (fokban), helyzetenként: "flat_x", "flat_y", "edge", "port" ---
    fun levelOffset(c: Context, key: String): Float = p(c).getFloat("level_$key", 0f)
    fun setLevelOffset(c: Context, key: String, v: Float) = p(c).edit().putFloat("level_$key", v).apply()

    // --- Utoljára indított funkció (a Főoldal "Újra" kártyájához) ---
    fun lastFeature(c: Context): Feature? =
        Feature.entries.firstOrNull { it.name == p(c).getString("last_feature", null) }
    fun setLastFeature(c: Context, f: Feature) = p(c).edit().putString("last_feature", f.name).apply()

    // --- Dínófutás: ugrás-bemenetek ---
    fun dinoJump(c: Context): Set<DinoJump> {
        val raw = p(c).getString("dino_jump", null) ?: return setOf(DinoJump.KNOCK)
        val set = raw.split(",").mapNotNull { n -> DinoJump.entries.firstOrNull { it.name == n } }.toSet()
        return if (set.isEmpty()) setOf(DinoJump.KNOCK) else set
    }
    fun setDinoJump(c: Context, m: DinoJump, on: Boolean) {
        val cur = dinoJump(c).toMutableSet()
        if (on) cur += m else cur -= m
        if (cur.isEmpty()) cur += DinoJump.KNOCK // legalább egy bemenet kell
        p(c).edit().putString("dino_jump", cur.joinToString(",") { it.name }).apply()
    }

    // --- Dínófutás ---
    fun dinoBest(c: Context): Int = p(c).getInt("dino_best", 0)
    fun setDinoBest(c: Context, v: Int) = p(c).edit().putInt("dino_best", v).apply()

    // --- Időzítő ---
    fun timerMode(c: Context): TimerMode =
        TimerMode.entries.firstOrNull { it.name == p(c).getString("timer_mode", null) } ?: TimerMode.POMODORO
    fun setTimerMode(c: Context, m: TimerMode) = p(c).edit().putString("timer_mode", m.name).apply()
    fun timerStyle(c: Context): TimerStyle =
        TimerStyle.entries.firstOrNull { it.name == p(c).getString("timer_style", null) } ?: TimerStyle.SAND
    fun setTimerStyle(c: Context, s: TimerStyle) = p(c).edit().putString("timer_style", s.name).apply()
    /** Az egyszeri időzítő és a homokóra hossza percben. */
    fun timerMinutes(c: Context): Int = p(c).getInt("timer_minutes", 10)
    fun setTimerMinutes(c: Context, v: Int) = p(c).edit().putInt("timer_minutes", v).apply()

    // --- Előadás ---
    /** Hány részből áll az előadás (alap: 2). */
    fun lectureBlocks(c: Context): Int = p(c).getInt("lec_blocks", 2).coerceIn(1, 4)
    fun setLectureBlocks(c: Context, v: Int) = p(c).edit().putInt("lec_blocks", v.coerceIn(1, 4)).apply()
    /** Egy rész hossza percben (alap: 45). */
    fun lectureBlockMin(c: Context): Int = p(c).getInt("lec_block_min", Config.LECTURE_BLOCK_MIN).coerceIn(5, 180)
    fun setLectureBlockMin(c: Context, v: Int) = p(c).edit().putInt("lec_block_min", v.coerceIn(5, 180)).apply()
    /** A szünet hossza percben (alap: 15). */
    fun lectureBreakMin(c: Context): Int = p(c).getInt("lec_break_min", Config.LECTURE_BREAK_MIN).coerceIn(1, 60)
    fun setLectureBreakMin(c: Context, v: Int) = p(c).edit().putInt("lec_break_min", v.coerceIn(1, 60)).apply()

    fun lectureStart(c: Context): LectureStart =
        LectureStart.entries.firstOrNull { it.name == p(c).getString("lec_start", null) } ?: LectureStart.SHAKE
    fun setLectureStart(c: Context, v: LectureStart) = p(c).edit().putString("lec_start", v.name).apply()
    /** Hány rázás (vagy kopogás) kell a LED-ek feltöltéséhez – a Rázás-töltés mozdulathoz és az Előadás töltéséhez. */
    fun shakeFillCount(c: Context): Int = p(c).getInt("shake_fill", Config.SHAKEFILL_DEFAULT).coerceIn(3, 40)
    fun setShakeFillCount(c: Context, v: Int) = p(c).edit().putInt("shake_fill", v.coerceIn(3, 40)).apply()

    fun lectureBreakCmd(c: Context): BreakCommand =
        BreakCommand.entries.firstOrNull { it.name == p(c).getString("lec_break_cmd", null) } ?: BreakCommand.SHAKE
    fun setLectureBreakCmd(c: Context, v: BreakCommand) = p(c).edit().putString("lec_break_cmd", v.name).apply()
    /** Többször is lehet szünetet indítani (különben csak egyszer). */
    fun lectureMultiBreak(c: Context): Boolean = p(c).getBoolean("lec_multi", false)
    fun setLectureMultiBreak(c: Context, v: Boolean) = p(c).edit().putBoolean("lec_multi", v).apply()
    /** A részek között magától indul a szünet. */
    fun lectureAutoBreak(c: Context): Boolean = p(c).getBoolean("lec_auto", false)
    fun setLectureAutoBreak(c: Context, v: Boolean) = p(c).edit().putBoolean("lec_auto", v).apply()
    /** A szünetet ugyanazzal a paranccsal előbb is be lehet fejezni (folytatás). */
    fun lectureEarlyResume(c: Context): Boolean = p(c).getBoolean("lec_resume", true)
    fun setLectureEarlyResume(c: Context, v: Boolean) = p(c).edit().putBoolean("lec_resume", v).apply()

    /** Az előadás visszaszámlálójának animációja. */
    fun lectureStyle(c: Context): LectureStyle =
        LectureStyle.entries.firstOrNull { it.name == p(c).getString("lec_style", null) } ?: LectureStyle.BAR
    fun setLectureStyle(c: Context, v: LectureStyle) = p(c).edit().putString("lec_style", v.name).apply()
    /** Jelezzen-e a rész vége előtt (Config.LECTURE_WARN_MIN perccel). */
    fun lectureWarn(c: Context): Boolean = p(c).getBoolean("lec_warn", true)
    fun setLectureWarn(c: Context, v: Boolean) = p(c).edit().putBoolean("lec_warn", v).apply()
    /** Widgetről (gombnyomásra) rázás nélkül, azonnal induljon. */
    fun lectureWidgetInstant(c: Context): Boolean = p(c).getBoolean("lec_widget_instant", true)
    fun setLectureWidgetInstant(c: Context, v: Boolean) = p(c).edit().putBoolean("lec_widget_instant", v).apply()

    // --- Fújós ---
    /** Fújásfigyelés: a háttérben is figyeli a mikrofont, és fújásra magától indul a játék. */
    fun blowAlways(c: Context): Boolean = p(c).getBoolean("blow_always", false)
    fun setBlowAlways(c: Context, v: Boolean) = p(c).edit().putBoolean("blow_always", v).apply()

    // --- Előadás: heti órarend (a bejegyzéseket a LectureSchedule kezeli) ---
    fun lectureScheduleOn(c: Context): Boolean = p(c).getBoolean("lec_sched_on", true)
    fun setLectureScheduleOn(c: Context, v: Boolean) = p(c).edit().putBoolean("lec_sched_on", v).apply()
    /** Csak érintésre világít: a LED-ek sötétek, és csak a lefektetett telefon megérintésekor mutatják a hátralévő időt. */
    fun lecturePeek(c: Context): Boolean = p(c).getBoolean("lec_peek", false)
    fun setLecturePeek(c: Context, v: Boolean) = p(c).edit().putBoolean("lec_peek", v).apply()

    fun blowStyle(c: Context): BlowStyle =
        BlowStyle.entries.firstOrNull { it.name == p(c).getString("blow_style", null) } ?: BlowStyle.BALL
    fun setBlowStyle(c: Context, v: BlowStyle) = p(c).edit().putString("blow_style", v.name).apply()
    /** Fújás érzékenysége: 0 = alacsony … 4 = maximális (alap: 2 = magas). */
    fun blowSensitivity(c: Context): Int = p(c).getInt("blow_sens2", 2).coerceIn(0, 4)
    fun setBlowSensitivity(c: Context, v: Int) = p(c).edit().putInt("blow_sens2", v.coerceIn(0, 4)).apply()
    /** Rekord (ms) animációnként – a célba érős módoknál. 0 = még nincs. */
    fun blowBest(c: Context, s: BlowStyle): Long = p(c).getLong("blow_best_${s.name}", 0L)
    fun setBlowBest(c: Context, s: BlowStyle, ms: Long) = p(c).edit().putLong("blow_best_${s.name}", ms).apply()
    /** Hányszor durrant ki a lufi összesen. */
    fun blowPops(c: Context): Int = p(c).getInt("blow_pops", 0)
    fun addBlowPop(c: Context) = p(c).edit().putInt("blow_pops", blowPops(c) + 1).apply()

    // --- Légzés ---
    fun breathPattern(c: Context): BreathPattern =
        BreathPattern.entries.firstOrNull { it.name == p(c).getString("breath_pattern", null) } ?: BreathPattern.RELAX
    fun setBreathPattern(c: Context, v: BreathPattern) = p(c).edit().putString("breath_pattern", v.name).apply()
    /** A légzés hossza percben. */
    fun breathMinutes(c: Context): Int = p(c).getInt("breath_min", 3).coerceIn(1, 20)
    fun setBreathMinutes(c: Context, v: Int) = p(c).edit().putInt("breath_min", v.coerceIn(1, 20)).apply()

    // --- Glyph Beacon (füttyre megtalálható telefon) ---
    fun beaconOn(c: Context): Boolean = p(c).getBoolean("beacon_on", false)
    fun setBeaconOn(c: Context, v: Boolean) = p(c).edit().putBoolean("beacon_on", v).apply()
    /** 0 = óvatos, 1 = normál, 2 = érzékeny. */
    fun beaconSens(c: Context): Int = p(c).getInt("beacon_sens", 1).coerceIn(0, 2)
    fun setBeaconSens(c: Context, v: Int) = p(c).edit().putInt("beacon_sens", v.coerceIn(0, 2)).apply()
    fun beaconSound(c: Context): BeaconSound =
        BeaconSound.entries.firstOrNull { it.name == p(c).getString("beacon_sound", null) } ?: BeaconSound.ROBOT
    fun setBeaconSound(c: Context, v: BeaconSound) = p(c).edit().putString("beacon_sound", v.name).apply()
    fun beaconMaxVolume(c: Context): Boolean = p(c).getBoolean("beacon_maxvol", true)
    fun setBeaconMaxVolume(c: Context, v: Boolean) = p(c).edit().putBoolean("beacon_maxvol", v).apply()
    fun beaconVibrate(c: Context): Boolean = p(c).getBoolean("beacon_vib", true)
    fun setBeaconVibrate(c: Context, v: Boolean) = p(c).edit().putBoolean("beacon_vib", v).apply()
    /** Meddig szóljon, ha nem állítják le (mp). */
    fun beaconSeconds(c: Context): Int = p(c).getInt("beacon_sec", 60).coerceIn(15, 300)
    fun setBeaconSeconds(c: Context, v: Int) = p(c).edit().putInt("beacon_sec", v.coerceIn(15, 300)).apply()
    /** A betanított fütty: legmélyebb és legmagasabb hang (Hz) és átlagos hossz (ms); 0 = nincs betanítva. */
    fun beaconMinHz(c: Context): Float = p(c).getFloat("beacon_min_hz", 0f)
    fun beaconMaxHz(c: Context): Float = p(c).getFloat("beacon_max_hz", 0f)
    fun beaconDurMs(c: Context): Int = p(c).getInt("beacon_dur", 0)
    fun beaconTrained(c: Context): Boolean = beaconMinHz(c) > 0f && beaconMaxHz(c) > 0f
    fun setBeaconTraining(c: Context, minHz: Float, maxHz: Float, durMs: Int) =
        p(c).edit().putFloat("beacon_min_hz", minHz).putFloat("beacon_max_hz", maxHz).putInt("beacon_dur", durMs).apply()
    fun clearBeaconTraining(c: Context) { setBeaconTraining(c, 0f, 0f, 0); setBeaconProfile(c, 0f, 1f); setBeaconContours(c, "") }
    /** A betanított füttyök dallamívei (időre normálva), szövegként. */
    fun beaconContours(c: Context): String = p(c).getString("beacon_contours", null) ?: ""
    fun setBeaconContours(c: Context, v: String) = p(c).edit().putString("beacon_contours", v).apply()
    /** Figyelje-e a fütty dallamát is (nem csak a magasságát). */
    fun beaconMelody(c: Context): Boolean = p(c).getBoolean("beacon_melody", true)
    fun setBeaconMelody(c: Context, v: Boolean) = p(c).edit().putBoolean("beacon_melody", v).apply()
    /** A hangparancs szava (csak felirat: a felismerés a te hangmintáidból dolgozik). */
    /** Az Asszisztens widget koppintása (AI app módban). */
    fun widgetTap(c: Context): WidgetTap = WidgetTap.entries.firstOrNull { it.name == p(c).getString("widget_tap", null) } ?: WidgetTap.VOICE
    fun setWidgetTap(c: Context, v: WidgetTap) = p(c).edit().putString("widget_tap", v.name).apply()
    /** A widgetek kövessék-e a választott neon témát. */
    fun widgetThemed(c: Context): Boolean = p(c).getBoolean("widget_themed", true)
    fun setWidgetThemed(c: Context, v: Boolean) = p(c).edit().putBoolean("widget_themed", v).apply()
    fun beaconWord(c: Context): String = p(c).getString("beacon_word", null) ?: "Kukucs"
    fun setBeaconWord(c: Context, v: String) = p(c).edit().putString("beacon_word", v).apply()
    /** A betanított fütty profilja: középhang (Hz) és dallamív (vége / eleje). */
    fun beaconMedHz(c: Context): Float = p(c).getFloat("beacon_med_hz", 0f)
    fun beaconSlope(c: Context): Float = p(c).getFloat("beacon_slope", 1f)
    fun setBeaconProfile(c: Context, med: Float, slope: Float) = p(c).edit().putFloat("beacon_med_hz", med).putFloat("beacon_slope", slope).apply()
    /** 0 = egy fütty, 1 = két fütty egymás után. */
    fun beaconPattern(c: Context): Int = p(c).getInt("beacon_pattern", 0)
    fun setBeaconPattern(c: Context, v: Int) = p(c).edit().putInt("beacon_pattern", v).apply()
    /** Füttyre figyel-e (kikapcsolható, ha csak a hangparancs kell). */
    fun beaconWhistleOn(c: Context): Boolean = p(c).getBoolean("beacon_whistle", true)
    fun setBeaconWhistleOn(c: Context, v: Boolean) = p(c).edit().putBoolean("beacon_whistle", v).apply()
    /** Hangparancs („Beacon!”) be / ki, és a betanított hangképek. */
    fun beaconVoiceOn(c: Context): Boolean = p(c).getBoolean("beacon_voice", false)
    fun setBeaconVoiceOn(c: Context, v: Boolean) = p(c).edit().putBoolean("beacon_voice", v).apply()
    fun beaconVoiceTemplates(c: Context): String = p(c).getString("beacon_voice_t", null) ?: ""
    fun setBeaconVoiceTemplates(c: Context, v: String) = p(c).edit().putString("beacon_voice_t", v).apply()

    // --- Hangasszisztens ---
    fun assistantKey(c: Context): String = p(c).getString("asst_key", null) ?: ""
    fun setAssistantKey(c: Context, v: String) = p(c).edit().putString("asst_key", v.trim()).apply()
    fun assistantModel(c: Context): AssistantModel =
        AssistantModel.entries.firstOrNull { it.name == p(c).getString("asst_model", null) } ?: AssistantModel.HAIKU
    fun setAssistantModel(c: Context, v: AssistantModel) = p(c).edit().putString("asst_model", v.name).apply()
    fun talkAnim(c: Context): TalkAnim = TalkAnim.entries.firstOrNull { it.name == p(c).getString("talk_anim", null) } ?: TalkAnim.COMBO
    fun setTalkAnim(c: Context, v: TalkAnim) = p(c).edit().putString("talk_anim", v.name).apply()
    /** Beszédtempó: 0 = lassú … 3 = gyors. */
    fun talkRate(c: Context): Int = p(c).getInt("talk_rate", 1).coerceIn(0, 3)
    fun setTalkRate(c: Context, v: Int) = p(c).edit().putInt("talk_rate", v.coerceIn(0, 3)).apply()
    /** Emlékezzen-e az előző kérdésekre (egy beszélgetésen belül). */
    fun assistantMemory(c: Context): Boolean = p(c).getBoolean("asst_mem", true)
    fun setAssistantMemory(c: Context, v: Boolean) = p(c).edit().putBoolean("asst_mem", v).apply()
    fun assistantLeds(c: Context): Boolean = p(c).getBoolean("asst_leds", true)
    fun setAssistantLeds(c: Context, v: Boolean) = p(c).edit().putBoolean("asst_leds", v).apply()
    /** true = saját API-kulccsal az appon belül; false (alap) = a Claude app, a saját fiókoddal. */
    fun assistantUseApi(c: Context): Boolean = p(c).getBoolean("asst_use_api", false)
    fun setAssistantUseApi(c: Context, v: Boolean) = p(c).edit().putBoolean("asst_use_api", v).apply()
    /** Az AI mód appja (csomagnév és név); alapból a Claude. */
    fun aiPackage(c: Context): String = p(c).getString("ai_pkg", null) ?: KnownAi.CLAUDE.pkg
    fun aiName(c: Context): String = p(c).getString("ai_name", null) ?: KnownAi.CLAUDE.title
    fun setAiApp(c: Context, pkg: String, name: String) = p(c).edit().putString("ai_pkg", pkg).putString("ai_name", name).apply()
    // --- Titkos neon témák ---
    fun neonTheme(c: Context): String = p(c).getString("neon_theme", null) ?: ""
    fun setNeonTheme(c: Context, v: String) = p(c).edit().putString("neon_theme", v).apply()
    /** A titkos gomb (10 mp nyomva tartás) mindet feloldotta. */
    fun neonCheat(c: Context): Boolean = p(c).getBoolean("neon_cheat", false)
    fun setNeonCheat(c: Context, v: Boolean) = p(c).edit().putBoolean("neon_cheat", v).apply()
    fun themesSeen(c: Context): Int = p(c).getInt("themes_seen", 0)
    fun setThemesSeen(c: Context, v: Int) = p(c).edit().putInt("themes_seen", v).apply()
    // --- Glyph Focus ---
    fun detoxGoal(c: Context): Int = p(c).getInt("detox_goal", 60)
    fun setDetoxGoal(c: Context, v: Int) = p(c).edit().putInt("detox_goal", v).apply()
    fun detoxShow(c: Context): DetoxShow = DetoxShow.entries.firstOrNull { it.name == p(c).getString("detox_show", null) } ?: DetoxShow.PULSE
    fun setDetoxShow(c: Context, v: DetoxShow) = p(c).edit().putString("detox_show", v.name).apply()
    fun detoxAnim(c: Context): DetoxAnim = DetoxAnim.entries.firstOrNull { it.name == p(c).getString("detox_anim", null) } ?: DetoxAnim.FILL
    fun setDetoxAnim(c: Context, v: DetoxAnim) = p(c).edit().putString("detox_anim", v.name).apply()
    /** A Glyph Focushoz választott Stúdió-animáció (üres = a kedvenc). */
    fun detoxStudioId(c: Context): String? = p(c).getString("detox_studio", null)
    fun setDetoxStudioId(c: Context, v: String) = p(c).edit().putString("detox_studio", v).apply()

    // --- Hangerő-kombináció: funkciónként egy sorrend, U = fel, D = le ---
    fun volCombo(c: Context, f: Feature): String = p(c).getString("volcombo_${f.name}", null) ?: "UDU"
    fun setVolCombo(c: Context, f: Feature, v: String) = p(c).edit().putString("volcombo_${f.name}", v.filter { it == 'U' || it == 'D' }.take(8)).apply()
    /** A kombinációval induló (élesített) funkciók és a sorrendjük. */
    fun volCombos(c: Context): Map<String, Feature> =
        Feature.entries.filter { armed(c, it) && trigger(c, it) == Trigger.VOL_COMBO }.associateBy { volCombo(c, it) }

    /** Melyik témákról szólt már értesítés (hogy mindig a ténylegesen újat nevezze meg). */
    fun themesKnown(c: Context): Set<String> = p(c).getStringSet("themes_known", null) ?: emptySet()
    fun setThemesKnown(c: Context, v: Set<String>) = p(c).edit().putStringSet("themes_known", v).apply()

    // --- Morze-gyakorló ---
    fun morseLevel(c: Context): MorseLevel = MorseLevel.entries.firstOrNull { it.name == p(c).getString("morse_level", null) } ?: MorseLevel.LEARN
    fun setMorseLevel(c: Context, v: MorseLevel) = p(c).edit().putString("morse_level", v.name).apply()
    fun morseSpeed(c: Context): MorseSpeed = MorseSpeed.entries.firstOrNull { it.name == p(c).getString("morse_speed", null) } ?: MorseSpeed.NORMAL
    fun setMorseSpeed(c: Context, v: MorseSpeed) = p(c).edit().putString("morse_speed", v.name).apply()
}

/** Kombináció szövegként: „▲ ▲ ▼”. */
fun comboText(seq: String): String = seq.map { if (it == 'U') "▲" else "▼" }.joinToString(" ")
