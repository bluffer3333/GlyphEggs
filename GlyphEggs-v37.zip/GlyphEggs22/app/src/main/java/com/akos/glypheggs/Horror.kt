package com.akos.glypheggs

import android.app.Activity
import android.graphics.Canvas
import android.graphics.Paint
import android.graphics.Path
import android.graphics.RadialGradient
import android.graphics.Shader
import android.os.Handler
import android.os.Looper
import android.view.View
import android.view.ViewGroup
import kotlin.math.cos
import kotlin.math.hypot
import kotlin.math.sin

/**
 * HALLOWEEN – brutális, piros-fekete horror-téma.
 *  - A háttér vérvörösen lüktet, mint egy szívverés (dupla dobbanás, ~66 BPM),
 *  - alulról és oldalról fekete-vörös CSÁPOK tekeregnek fel, tapadókorongokkal,
 *  - a sötétben véreres SZEMGOLYÓK néznek: a pupillák követik egymást és egy vándorló pontot, néha mind
 *    egyszerre rád szegeződnek, és időnként pislognak,
 *  - a képernyő tetejéről vér csöpög le,
 *  - a kártyák a szívverésre dobbannak.
 * Minden idő-alapú; erős villogás nincs benne.
 */
object HorrorFx {
    private val p = Paint(Paint.ANTI_ALIAS_FLAG)
    private val path = Path()

    private const val BLOOD = 0xFFB0000F.toInt()
    private const val DARK = 0xFF2A0004.toInt()

    /** Szívverés: 0..1 erősség (dupla dobbanás). */
    fun heartbeat(): Float {
        val period = 900L
        val t = (System.currentTimeMillis() % period) / period.toFloat()
        fun bump(c: Float, w: Float) = maxOf(0f, 1f - kotlin.math.abs(t - c) / w)
        return maxOf(bump(0.05f, 0.08f), bump(0.27f, 0.07f) * 0.7f)
    }

    // A szemgolyók helye (arány a képernyőn), mérete és „egyénisége”
    private class Eye(val x: Float, val y: Float, val r: Float, val seed: Int)
    private val EYES = listOf(
        Eye(0.14f, 0.12f, 0.085f, 1), Eye(0.86f, 0.22f, 0.065f, 2), Eye(0.10f, 0.47f, 0.05f, 3),
        Eye(0.90f, 0.58f, 0.095f, 4), Eye(0.22f, 0.80f, 0.07f, 5), Eye(0.72f, 0.90f, 0.055f, 6),
        Eye(0.55f, 0.06f, 0.045f, 7)
    )

    private class Tentacle(val baseX: Float, val baseY: Float, val ang: Float, val len: Float, val thick: Float, val speed: Float, val phase: Float)
    private val TENTACLES = listOf(
        Tentacle(-0.05f, 1.02f, -55f, 0.62f, 0.075f, 1.0f, 0f),
        Tentacle(0.30f, 1.05f, -85f, 0.42f, 0.06f, 1.3f, 1.7f),
        Tentacle(0.70f, 1.05f, -98f, 0.48f, 0.065f, 0.9f, 3.1f),
        Tentacle(1.05f, 0.98f, -128f, 0.66f, 0.08f, 1.1f, 4.4f),
        Tentacle(-0.06f, 0.35f, 8f, 0.38f, 0.05f, 1.5f, 2.2f),
        Tentacle(1.06f, 0.42f, 175f, 0.34f, 0.045f, 1.25f, 5.3f)
    )

    fun paintBackground(canvas: Canvas, w: Float, h: Float) {
        val now = System.currentTimeMillis()
        val t = now / 1000f
        val beat = heartbeat()

        // Alap: fekete, középen lüktető vérvörös derengés
        p.shader = null
        p.color = 0xFF050000.toInt()
        canvas.drawRect(0f, 0f, w, h, p)
        val glowA = (0x55 + 0x60 * beat).toInt().coerceAtMost(0xD0)
        p.shader = RadialGradient(w / 2f, h * 0.45f, hypot(w, h) * (0.55f + 0.04f * beat),
            intArrayOf((glowA shl 24) or 0x7A0008, 0x30200000, 0x00000000), floatArrayOf(0f, 0.55f, 1f), Shader.TileMode.CLAMP)
        canvas.drawRect(0f, 0f, w, h, p)
        p.shader = null

        // Szemgolyók (a csápok mögött)
        val lookX = w * (0.5f + 0.35f * sin(t * 0.37f))
        val lookY = h * (0.45f + 0.3f * sin(t * 0.23f + 1f))
        val stare = ((now / 7_000L) % 3L == 0L) && (now % 7_000L) < 1_600L // időnként mind rád néz
        for (e in EYES) drawEyeball(canvas, e.x * w, e.y * h, e.r * w, if (stare) w / 2f else lookX, if (stare) h * 0.5f else lookY, now, e.seed, stare)

        // Csápok
        for (tc in TENTACLES) drawTentacle(canvas, tc, w, h, t)

        // Csöpögő vér a tetejéről
        drawDrips(canvas, w, h, now)

        // Sötét sarkok
        p.shader = RadialGradient(w / 2f, h / 2f, hypot(w, h) * 0.62f, intArrayOf(0x00000000, 0x00000000, 0xE0000000.toInt()),
            floatArrayOf(0f, 0.6f, 1f), Shader.TileMode.CLAMP)
        canvas.drawRect(0f, 0f, w, h, p)
        p.shader = null
    }

    private fun drawEyeball(c: Canvas, cx: Float, cy: Float, r: Float, lx: Float, ly: Float, now: Long, seed: Int, stare: Boolean) {
        // Pislogás: minden szem a saját ütemében
        val blinkPeriod = 4_000L + seed * 900L
        val bt = ((now + seed * 1_337L) % blinkPeriod).toFloat()
        val lid = if (!stare && bt < 180f) 1f - kotlin.math.abs(bt - 90f) / 90f else 0f // 0 = nyitva, 1 = csukva

        // Árnyék / üreg
        p.color = 0xCC000000.toInt()
        c.drawCircle(cx, cy + r * 0.08f, r * 1.12f, p)
        // Ínhártya: piszkosfehér → vöröses szél
        p.shader = RadialGradient(cx - r * 0.25f, cy - r * 0.3f, r * 1.25f,
            intArrayOf(0xFFF2E6DC.toInt(), 0xFFD9B8A8.toInt(), 0xFF8A1010.toInt()), floatArrayOf(0f, 0.6f, 1f), Shader.TileMode.CLAMP)
        c.drawCircle(cx, cy, r, p)
        p.shader = null
        // Erek
        p.style = Paint.Style.STROKE
        p.strokeCap = Paint.Cap.ROUND
        p.color = 0xD0B00010.toInt()
        val rnd = java.util.Random(seed * 7919L)
        repeat(9) {
            val a0 = rnd.nextFloat() * 6.283f
            var x = cx + cos(a0) * r * 0.98f
            var y = cy + sin(a0) * r * 0.98f
            var a = a0 + Math.PI.toFloat()
            path.reset(); path.moveTo(x, y)
            p.strokeWidth = r * (0.035f + rnd.nextFloat() * 0.03f)
            repeat(4) {
                a += (rnd.nextFloat() - 0.5f) * 1.1f
                x += cos(a) * r * 0.16f; y += sin(a) * r * 0.16f
                path.lineTo(x, y)
            }
            c.drawPath(path, p)
        }
        p.style = Paint.Style.FILL
        // Írisz és pupilla a nézési irányba
        val dx = lx - cx; val dy = ly - cy
        val d = hypot(dx, dy).coerceAtLeast(1f)
        val off = r * 0.38f
        val ix = cx + dx / d * off
        val iy = cy + dy / d * off * 0.85f
        p.shader = RadialGradient(ix, iy, r * 0.46f, intArrayOf(0xFFFF2A1A.toInt(), 0xFFB00008.toInt(), 0xFF3A0002.toInt()),
            floatArrayOf(0f, 0.6f, 1f), Shader.TileMode.CLAMP)
        c.drawCircle(ix, iy, r * 0.44f, p)
        p.shader = null
        val pupil = r * (if (stare) 0.13f else 0.2f + 0.04f * heartbeat())
        p.color = 0xFF000000.toInt()
        c.drawCircle(ix, iy, pupil, p)
        // Csillanás
        p.color = 0xB0FFFFFF.toInt()
        c.drawCircle(ix - r * 0.12f, iy - r * 0.14f, r * 0.07f, p)
        // Szemhéj (pislogáskor felülről és alulról záródik)
        if (lid > 0f) {
            p.color = 0xFF120002.toInt()
            c.drawRect(cx - r * 1.15f, cy - r * 1.15f, cx + r * 1.15f, cy - r * 1.15f + r * 1.15f * lid, p)
            c.drawRect(cx - r * 1.15f, cy + r * 1.15f - r * 1.15f * lid, cx + r * 1.15f, cy + r * 1.15f, p)
        }
    }

    private fun drawTentacle(c: Canvas, tc: Tentacle, w: Float, h: Float, t: Float) {
        val n = 26
        val len = tc.len * h
        val xs = FloatArray(n + 1); val ys = FloatArray(n + 1)
        var x = tc.baseX * w; var y = tc.baseY * h
        var a = Math.toRadians(tc.ang.toDouble()).toFloat()
        xs[0] = x; ys[0] = y
        val seg = len / n
        for (i in 1..n) {
            val u = i / n.toFloat()
            // Tekergés: hullám fut végig, a vége felé erősebb, a hegye feltekeredik
            a += 0.11f * sin(t * 1.6f * tc.speed - u * 5f + tc.phase) * (0.4f + u) + u * u * 0.06f * sin(t * tc.speed + tc.phase)
            x += cos(a) * seg; y += sin(a) * seg
            xs[i] = x; ys[i] = y
        }
        val base = tc.thick * w
        // Test: szegmensenként vékonyodó körök (sötét → vörös él), a végén hegyes
        for (pass in 0..1) {
            for (i in 0..n) {
                val u = i / n.toFloat()
                val r = base * (1f - u * 0.92f)
                p.color = if (pass == 0) 0xFF4A0008.toInt() else 0xFF14000A.toInt()
                c.drawCircle(xs[i], ys[i], if (pass == 0) r else r * 0.84f, p)
            }
        }
        // Fényes gerinc
        p.style = Paint.Style.STROKE
        p.strokeCap = Paint.Cap.ROUND
        p.color = 0x55FF3030
        p.strokeWidth = base * 0.12f
        path.reset(); path.moveTo(xs[0], ys[0])
        for (i in 1..n) path.lineTo(xs[i], ys[i])
        c.drawPath(path, p)
        p.style = Paint.Style.FILL
        // Tapadókorongok az egyik oldalon
        for (i in 2 until n - 3 step 2) {
            val u = i / n.toFloat()
            val r = base * (1f - u * 0.92f)
            val nx = -(ys[i + 1] - ys[i]); val ny = xs[i + 1] - xs[i]
            val nl = hypot(nx, ny).coerceAtLeast(0.01f)
            val sx = xs[i] + nx / nl * r * 0.55f; val sy = ys[i] + ny / nl * r * 0.55f
            p.color = 0xFF7A1018.toInt()
            c.drawCircle(sx, sy, r * 0.3f, p)
            p.color = 0xFF1A0004.toInt()
            c.drawCircle(sx, sy, r * 0.15f, p)
        }
    }

    private fun drawDrips(c: Canvas, w: Float, h: Float, now: Long) {
        // Felső vércsík, hullámos alsó éllel
        p.color = 0xFF5A0006.toInt()
        path.reset(); path.moveTo(0f, 0f); path.lineTo(w, 0f)
        val steps = 24
        for (i in steps downTo 0) {
            val x = w * i / steps
            path.lineTo(x, h * (0.012f + 0.01f * ((i * 7919) % 5) / 5f))
        }
        path.close(); c.drawPath(path, p)
        // Lefolyó cseppek: mindegyik saját ütemben nő, leszakad, lezuhan
        for (k in 0 until 9) {
            val x = w * ((k * 0.113f + 0.05f) % 1f)
            val period = 5_000L + k * 731L
            val u = ((now + k * 977L) % period) / period.toFloat()
            val maxLen = h * (0.05f + 0.025f * (k % 3))
            val stem = if (u < 0.75f) maxLen * (u / 0.75f) else maxLen
            val rw = w * 0.012f
            p.color = BLOOD
            c.drawRect(x - rw * 0.45f, 0f, x + rw * 0.45f, h * 0.015f + stem, p)
            c.drawCircle(x, h * 0.015f + stem, rw * (0.8f + 0.4f * (u.coerceAtMost(0.75f) / 0.75f)), p)
            if (u >= 0.75f) {
                // leszakadt csepp zuhan
                val fall = (u - 0.75f) / 0.25f
                val fy = h * 0.015f + stem + fall * fall * h * 0.9f
                p.color = 0xE0B0000F.toInt()
                c.drawOval(x - rw * 0.7f, fy - rw * 1.4f, x + rw * 0.7f, fy + rw * 0.8f, p)
            }
        }
    }

    /** Mozgás: háttér-animáció és a szívverésre dobbanó kártyák. */
    fun attach(activity: Activity) {
        val content = activity.findViewById<ViewGroup>(android.R.id.content) ?: return
        val handler = Handler(Looper.getMainLooper())
        val tick = object : Runnable {
            var pool: List<View> = emptyList()
            var poolAt = 0L
            override fun run() {
                val root = content.getChildAt(0) ?: return
                if (!root.isAttachedToWindow) return
                if (root.windowVisibility != View.VISIBLE) { handler.postDelayed(this, 500); return }
                activity.window.decorView.background?.invalidateSelf()
                root.background?.invalidateSelf()
                val now = System.currentTimeMillis()
                if (now - poolAt > 2_000) { poolAt = now; pool = cards(content) }
                val sc = 1f + 0.012f * heartbeat()
                for (v in pool) { v.scaleX = sc; v.scaleY = sc }
                handler.postDelayed(this, 40)
            }
        }
        handler.postDelayed(tick, 300)
    }

    private fun cards(g: ViewGroup): List<View> {
        val out = ArrayList<View>()
        fun walk(v: ViewGroup, depth: Int) {
            for (i in 0 until v.childCount) {
                val c = v.getChildAt(i)
                if (depth >= 2 && c.height in 60..1400 && c.width > 120) out += c
                if (c is ViewGroup && depth < 3) walk(c, depth + 1)
            }
        }
        walk(g, 0)
        return out
    }
}
