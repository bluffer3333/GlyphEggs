package com.akos.glypheggs

import android.content.Context
import kotlinx.coroutines.flow.MutableStateFlow

/*
 * HANGPARANCS a Glyph Beaconhöz – a SAJÁT hangodra betanítva, bármilyen szóra (ajánlott: „Kukucs!”).
 * Teljesen a telefonon fut, internet nélkül. A betanításkor 4-szer kimondod a szót; ezekből hangképet
 * (MFCC), hanglejtést (alaphang) és hangsúlyt (hangerő-ív) tárol – hangfelvételt nem.
 * Figyeléskor minden kimondott szót ugyanakkora hosszúra normál, és így veti össze a mintáiddal:
 * az IDŐT NEM NÉZI (gyorsan vagy lassan is mondhatod), csak a hangokat, a hanglejtést és a hangsúlyt.
 * A motor: [KwSegmenter], [KwMatch].
 */
object Keyword {
    /** Hány minta kell a betanításhoz. */
    const val SAMPLES = 4

    /** Riasztás: a szolgáltatás állítja be, ha a hangparancs be van kapcsolva. */
    @Volatile var onDetect: (() -> Unit)? = null
    /** Betanítás / élő teszt: minden kivágott szakasz és (ha van betanítva) a pontszáma (≤ küszöb = egyezik). */
    @Volatile var onSegment: ((KwFrames, Float) -> Unit)? = null
    @Volatile var paused = false
    @Volatile var training = false
    /** Élő kijelzés: beszél-e most valaki (0..1 hangerő, ha igen). */
    val voice = MutableStateFlow(0f)

    @Volatile private var model: KwMatch.Model? = null
    @Volatile private var limit = 1.45f

    private val seg = KwSegmenter { s -> evaluate(s) }
    private val tap: (ShortArray, Int) -> Unit = { b, n -> seg.feed(b, n); voice.value = seg.voice }

    fun trained(c: Context) = KwMatch.decode(Settings.beaconVoiceTemplates(c)).size >= 2

    /** Volt-e régi (időfüggő) betanítás, amit újra kell csinálni. */
    fun needsRetrain(c: Context) = Settings.beaconVoiceTemplates(c).isNotBlank() && !trained(c)

    /** A betanított minták és a küszöb betöltése (érzékenység szerint). */
    fun configure(c: Context) {
        val t = KwMatch.decode(Settings.beaconVoiceTemplates(c))
        model = if (t.size >= 2) KwMatch.Model(t.map { KwMatch.features(it) }) else null
        limit = Config.KEYWORD_LIMIT[Settings.beaconSens(c)]
    }

    fun attach() { if (tap !in MicTap.listeners) MicTap.listeners.add(tap) }
    fun detach() { MicTap.listeners.remove(tap); voice.value = 0f }
    fun refreshAttach() { if (onDetect != null || onSegment != null) attach() else detach() }

    /** Pontszám egy kimondásra (−1, ha nincs betanítva). */
    fun score(s: KwFrames): Float = model?.score(KwMatch.features(s)) ?: -1f

    /** Egyezik-e (a teszthez is). */
    fun matches(score: Float) = score in 0f..limit

    private fun evaluate(s: KwFrames) {
        val sc = score(s)
        onSegment?.invoke(s, sc)
        if (model == null || paused || training) return
        if (matches(sc)) onDetect?.invoke()
    }

    /** A betanítás mintái egymáshoz képest: túl különbözők-e (akkor újra kell). */
    fun samplesTooDifferent(list: List<KwFrames>): Boolean {
        val f = list.map { KwMatch.features(it) }
        var worst = 0f
        for (i in f.indices) worst = maxOf(worst, f.indices.filter { it != i }.minOf { KwMatch.specDist(f[i], f[it]) })
        return worst > 9f
    }

    fun encode(list: List<KwFrames>) = KwMatch.encode(list)
}
