package com.akos.glypheggs

import android.app.Activity
import android.content.Intent
import android.os.Bundle
import android.text.InputType
import android.view.Gravity
import android.view.View
import android.view.ViewGroup.LayoutParams.MATCH_PARENT
import android.view.ViewGroup.LayoutParams.WRAP_CONTENT
import android.view.inputmethod.EditorInfo
import android.view.inputmethod.InputMethodManager
import android.widget.EditText
import android.widget.FrameLayout
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView
import kotlinx.coroutines.Job
import kotlinx.coroutines.MainScope
import kotlinx.coroutines.cancel
import kotlinx.coroutines.delay
import kotlinx.coroutines.isActive
import kotlinx.coroutines.launch

/**
 * A Morze-gyakorló oldala: élő hátlap-kép, a megfejtés beírása (az első lefutás után magától megjelenik
 * a billentyűzet), beállítások, Morze-ABC, statisztika és a Morze-kitűzők.
 */
class MorseActivity : Activity() {

    companion object {
        /** Widgetről: azonnal indul. */
        const val EXTRA_START = "start"
        @Volatile var visible = false
    }

    private val scope = MainScope()
    private lateinit var root: LinearLayout
    private lateinit var preview: GlyphMapView
    private lateinit var phaseText: ImageView
    private lateinit var hintText: TextView
    private lateinit var input: EditText
    private lateinit var feedback: TextView
    private lateinit var startBtn: TextView
    private var abcOpen = false
    private var liveJob: Job? = null
    private var lastPhase: MorsePhase? = null
    private val badgeViews = mutableListOf<BadgeView>()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        darkWindow()
        root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(15), 0, dp(15), dp(30))
        }
        setContentView(ScrollView(this).apply {
            background = Ui.pageBg()
            isVerticalScrollBarEnabled = false
            addView(root, FrameLayout.LayoutParams(MATCH_PARENT, WRAP_CONTENT))
            padForSystemBars()
        })
        build()
        if (intent.getBooleanExtra(EXTRA_START, false) && GlyphMirror.mode.value != Feature.MORSE) start()
    }

    private fun running() = GlyphMirror.mode.value == Feature.MORSE

    private fun start() {
        startForegroundService(Intent(this, SimonService::class.java).setAction(SimonService.ACTION_MORSE))
    }

    private fun build() {
        root.removeAllViews()
        badgeViews.clear()
        val h = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
            setPadding(dp(7), dp(28), 0, dp(6))
        }
        h.addView(ImageView(this).apply { setImageResource(R.drawable.ic_back); setColorFilter(Ui.TEXT); setOnClickListener { finish() } },
            LinearLayout.LayoutParams(dp(24), dp(24)))
        h.addView(text("Morze-gyakorló", 26f).apply { setPadding(dp(30), 0, 0, 0) })
        root.addView(h)

        // Élő hátlap + állapot
        val box = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            gravity = Gravity.CENTER_HORIZONTAL
            background = rounded(Ui.BG, dp(22).toFloat(), Ui.LINE, dp(1.5f))
            setPadding(dp(14), dp(16), dp(14), dp(14))
        }
        preview = GlyphMapView(this).apply { unlitColor = 0xFF303030.toInt() }
        box.addView(preview, LinearLayout.LayoutParams(MATCH_PARENT, dp(220)))
        phaseText = ImageView(this)
        box.addView(phaseText, LinearLayout.LayoutParams(WRAP_CONTENT, WRAP_CONTENT).apply { topMargin = dp(12) })
        hintText = text("", 12.5f, Ui.SUB).apply { gravity = Gravity.CENTER; setPadding(dp(6), dp(4), dp(6), 0) }
        box.addView(hintText, LinearLayout.LayoutParams(MATCH_PARENT, WRAP_CONTENT))
        root.addView(box, LinearLayout.LayoutParams(MATCH_PARENT, WRAP_CONTENT).apply { topMargin = dp(14) })

        // Megfejtés
        input = EditText(this).apply {
            hint = "Megfejtés…"
            setSingleLine(true)
            inputType = InputType.TYPE_CLASS_TEXT or InputType.TYPE_TEXT_FLAG_CAP_CHARACTERS or InputType.TYPE_TEXT_FLAG_NO_SUGGESTIONS
            imeOptions = EditorInfo.IME_ACTION_DONE
            typeface = Widgets.dotoFace(this@MorseActivity)
            textSize = 30f
            gravity = Gravity.CENTER
            setTextColor(Ui.TEXT)
            setHintTextColor(0xFF5A5A5A.toInt())
            background = rounded(Ui.CARD, dp(22).toFloat())
            setPadding(dp(16), dp(14), dp(16), dp(14))
            setOnEditorActionListener { _, _, _ -> submit(); true }
        }
        root.addView(input, LinearLayout.LayoutParams(MATCH_PARENT, WRAP_CONTENT).apply { topMargin = dp(12) })
        feedback = text("", 13.5f, Ui.SUB).apply { gravity = Gravity.CENTER; setPadding(0, dp(6), 0, 0) }
        root.addView(feedback, LinearLayout.LayoutParams(MATCH_PARENT, WRAP_CONTENT))

        val btns = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
        btns.addView(pill("✓ Küldés", true) { submit() }, LinearLayout.LayoutParams(0, dp(52), 1.3f).apply { marginEnd = dp(5) })
        btns.addView(pill("Megoldás") { MorseBus.skip(this) }, LinearLayout.LayoutParams(0, dp(52), 1f))
        root.addView(btns, LinearLayout.LayoutParams(MATCH_PARENT, WRAP_CONTENT).apply { topMargin = dp(8) })
        startBtn = pill("") { if (running()) send(SimonService.ACTION_MORSE) else start() }
        root.addView(startBtn, LinearLayout.LayoutParams(MATCH_PARENT, dp(52)).apply { topMargin = dp(6) })

        // Beállítások
        root.addView(sectionTitle("Mit gyakorolj?"))
        val lv = Settings.morseLevel(this)
        val all = MorseLevel.entries
        for (row in all.chunked(4)) {
            root.addView(pills(row.map { it.title }, row.indexOf(lv)) { Settings.setMorseLevel(this, row[it]); build() },
                LinearLayout.LayoutParams(MATCH_PARENT, WRAP_CONTENT).apply { bottomMargin = dp(5) })
        }
        root.addView(text(when (lv) {
            MorseLevel.LEARN -> "Fokozatos: két jellel kezd (E, T). Ha egy jelet 3-szor elsőre eltalálsz, „megy”; ha mind megy, jön a következő – előbb a betűk, aztán a számok. Utána egyre nehezebb szavak."
            MorseLevel.LETTERS -> "Egyenként a 26 betű, véletlen sorrendben."
            MorseLevel.NUMBERS -> "Egyenként a 10 számjegy (öt jelből állnak)."
            MorseLevel.CUSTOM -> "A saját listád (lent adhatod meg szavakat vagy egyes betűket). Ha üres, a szótárad szavai jönnek."
            else -> "Véletlen szavak ebből a szintből."
        }, 12.5f, Ui.SUB).apply { setPadding(dp(8), dp(4), dp(8), 0); setLineSpacing(0f, 1.2f) })
        if (lv == MorseLevel.LEARN) {
            val card = LinearLayout(this).apply {
                orientation = LinearLayout.VERTICAL
                background = rounded(Ui.CARD, dp(22).toFloat())
                setPadding(dp(16), dp(14), dp(16), dp(14))
            }
            card.addView(text(MorseLearn.progressText(this), 15f))
            if (MorseLearn.stage(this) == 0) {
                // A már megnyílt jelek: telt = megy, félig = tanulod
                val set = MorseLearn.ORDER.take(MorseLearn.unlocked(this))
                val sb = StringBuilder()
                for (ch in MorseLearn.ORDER) {
                    sb.append(when {
                        ch !in set -> "·"
                        MorseLearn.hits(this, ch) >= MorseLearn.NEED -> ch.toString()
                        else -> ch.lowercaseChar().toString()
                    }).append(' ')
                }
                card.addView(text(sb.toString().trim(), 17f).apply { typeface = Widgets.dotoFace(this@MorseActivity); setPadding(0, dp(8), 0, 0); letterSpacing = 0.05f })
                card.addView(text("NAGYBETŰ = megy · kisbetű = most tanulod · pont = még zárva", 11.5f, Ui.SUB).apply { setPadding(0, dp(4), 0, 0) })
            }
            card.addView(text("Újrakezdés az elejéről", 12.5f, Ui.SUB, Ui.medium).apply {
                setPadding(0, dp(10), 0, 0)
                setOnClickListener { MorseLearn.reset(this@MorseActivity); build() }
            })
            root.addView(card, LinearLayout.LayoutParams(MATCH_PARENT, WRAP_CONTENT).apply { topMargin = dp(8) })
        }
        if (lv == MorseLevel.CUSTOM) root.addView(customCard(), LinearLayout.LayoutParams(MATCH_PARENT, WRAP_CONTENT).apply { topMargin = dp(8) })
        root.addView(sectionTitle("Tempó"))
        val sp = Settings.morseSpeed(this)
        root.addView(pills(MorseSpeed.entries.map { it.title }, MorseSpeed.entries.indexOf(sp)) { Settings.setMorseSpeed(this, MorseSpeed.entries[it]); build() })

        // Morze-ABC
        root.addView(pill(if (abcOpen) "Morze-ABC elrejtése" else "Morze-ABC megmutatása") { abcOpen = !abcOpen; build() },
            LinearLayout.LayoutParams(MATCH_PARENT, dp(46)).apply { topMargin = dp(18) })
        if (abcOpen) {
            val card = LinearLayout(this).apply {
                orientation = LinearLayout.VERTICAL
                background = rounded(Ui.CARD, dp(22).toFloat())
                setPadding(dp(14), dp(12), dp(14), dp(12))
            }
            for (chunk in MorseCode.TABLE.entries.chunked(3)) {
                val r = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
                for ((ch, code) in chunk) {
                    r.addView(text("$ch  ${code.replace('.', '·').replace('-', '—')}", 15f).apply {
                        typeface = Widgets.dotoFace(this@MorseActivity); setPadding(0, dp(3), 0, dp(3))
                    }, LinearLayout.LayoutParams(0, WRAP_CONTENT, 1f))
                }
                card.addView(r)
            }
            card.addView(text("A hátlapon: pont = 1 LED, vonás = 3 LED a felső sávon; a betűk között 3 sötét LED. A függőleges vonal annyi LED-del ég, ahány betűs a szó.",
                12f, Ui.SUB).apply { setPadding(0, dp(8), 0, 0); setLineSpacing(0f, 1.2f) })
            root.addView(card, LinearLayout.LayoutParams(MATCH_PARENT, WRAP_CONTENT).apply { topMargin = dp(6) })
        }

        // Statisztika
        root.addView(sectionTitle("Statisztika"))
        val c = this
        val tiles = listOf(
            "${MorseStats.solved(c)}" to "MEGFEJTVE",
            "${MorseStats.accuracy(c)}%" to "PONTOSSÁG",
            "${MorseStats.bestStreak(c)}" to "LEGJOBB SOROZAT",
            "%.1f mp".format(MorseStats.avgSec(c)) to "ÁTLAGIDŐ",
            "${MorseStats.fast(c)}" to "8 MP-EN BELÜL",
            "${MorseStats.letters(c)}" to "BETŰ ÖSSZESEN"
        )
        for (pair in tiles.chunked(2)) {
            val r = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
            pair.forEachIndexed { i, (v, l) ->
                val t = LinearLayout(this).apply {
                    orientation = LinearLayout.VERTICAL
                    background = rounded(Ui.CARD, dp(20).toFloat())
                    setPadding(dp(16), dp(12), dp(16), dp(12))
                }
                t.addView(text(v, 24f).apply { typeface = Widgets.dotoFace(this@MorseActivity) })
                t.addView(text(l, 10.5f, Ui.SUB, Ui.medium))
                r.addView(t, LinearLayout.LayoutParams(0, WRAP_CONTENT, 1f).apply { if (i == 0) marginEnd = dp(5) })
            }
            root.addView(r, LinearLayout.LayoutParams(MATCH_PARENT, WRAP_CONTENT).apply { bottomMargin = dp(5) })
        }
        root.addView(text("Rossz tipp: ${MorseStats.wrong(c)} · feladva: ${MorseStats.skipped(c)}", 12.5f, Ui.SUB).apply { setPadding(dp(8), dp(2), 0, 0) })

        // Szótár
        val dict = MorseDict.all(this)
        root.addView(sectionTitle("Szótár · ${dict.size} megfejtett"))
        val dc = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            background = rounded(Ui.CARD, dp(22).toFloat())
            setPadding(dp(14), dp(12), dp(14), dp(12))
        }
        if (dict.isEmpty()) dc.addView(text("Még üres. Minden megfejtett szó és jel ide kerül, hogy lásd, mit tudsz már.", 13f, Ui.SUB))
        else {
            dc.addView(text("Koppints egy szóra: megmutatja a kódját.", 12f, Ui.SUB).apply { setPadding(0, 0, 0, dp(6)) })
            val codeText = text("", 15f).apply { typeface = Widgets.dotoFace(this@MorseActivity) }
            val showAll = dictOpen || dict.size <= 24
            for (chunk in (if (showAll) dict else dict.take(24)).chunked(3)) {
                val r = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
                for ((w, n) in chunk) {
                    r.addView(text("$w ×$n", 14f).apply {
                        typeface = Widgets.dotoFace(this@MorseActivity); setPadding(0, dp(4), 0, dp(4))
                        setOnClickListener { codeText.text = "$w   ${MorseCode.text(w)}" }
                    }, LinearLayout.LayoutParams(0, WRAP_CONTENT, 1f))
                }
                repeat(3 - chunk.size) { r.addView(View(this), LinearLayout.LayoutParams(0, 1, 1f)) }
                dc.addView(r)
            }
            dc.addView(codeText.apply { setPadding(0, dp(8), 0, 0) })
            val links = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; setPadding(0, dp(8), 0, 0) }
            if (dict.size > 24) links.addView(text(if (dictOpen) "Kevesebb" else "Mind (${dict.size})", 12.5f, Ui.SUB, Ui.medium).apply {
                setOnClickListener { dictOpen = !dictOpen; build() }
            }, LinearLayout.LayoutParams(0, WRAP_CONTENT, 1f))
            links.addView(text("Gyakorold a szótárat →", 12.5f, Ui.TEXT, Ui.medium).apply {
                setOnClickListener { if (MorseCustom.list(this@MorseActivity).isEmpty()) { Settings.setMorseLevel(this@MorseActivity, MorseLevel.CUSTOM); build() } else feedback.text = "A „Saját” szint a saját listádat használja – töröld a listát, és a szótárad jön" }
            })
            dc.addView(links)
        }
        root.addView(dc, LinearLayout.LayoutParams(MATCH_PARENT, WRAP_CONTENT))

        // Kitűzők + téma
        val have = MORSE_BADGES.count { Achievements.isUnlocked(this, it) }
        root.addView(sectionTitle("Morze-kitűzők · $have / ${MORSE_BADGES.size}"))
        val row = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            background = rounded(Ui.CARD, dp(22).toFloat())
            setPadding(dp(6), dp(14), dp(6), dp(10))
        }
        for (b in MORSE_BADGES) {
            val cell = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; gravity = Gravity.CENTER_HORIZONTAL }
            val v = BadgeView(this, b).apply { unlocked = Achievements.isUnlocked(c, b); progress = b.progress(c).toFloat() / b.goal() }
            badgeViews += v
            cell.addView(v, LinearLayout.LayoutParams(dp(56), dp(56)))
            cell.addView(text(b.title, 10.5f, if (v.unlocked) Ui.TEXT else Ui.SUB).apply { gravity = Gravity.CENTER; maxLines = 2; setPadding(0, dp(4), 0, 0) },
                LinearLayout.LayoutParams(MATCH_PARENT, WRAP_CONTENT))
            cell.addView(text("${b.progress(c)}/${b.goal()}", 10f, Ui.SUB).apply { gravity = Gravity.CENTER }, LinearLayout.LayoutParams(MATCH_PARENT, WRAP_CONTENT))
            row.addView(cell, LinearLayout.LayoutParams(0, WRAP_CONTENT, 1f))
        }
        root.addView(row, LinearLayout.LayoutParams(MATCH_PARENT, WRAP_CONTENT))
        root.addView(text(
            if (have >= MORSE_BADGES.size) "📡 A Távíró téma feloldva – a titkos menüben választhatod."
            else "📡 Mind az 5 Morze-kitűzővel feloldódik a Távíró téma (borostyán képcső, pont-vonás minta). Még ${MORSE_BADGES.size - have}.",
            13f, Ui.SUB).apply { setPadding(dp(8), dp(10), dp(8), 0); setLineSpacing(0f, 1.2f) })
        refresh(true)
    }

    private var dictOpen = false

    /** Saját szavak és jelek: beírod, hozzáadod, ×-szel törlöd. */
    private fun customCard(): LinearLayout {
        val card = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            background = rounded(Ui.CARD, dp(22).toFloat())
            setPadding(dp(14), dp(12), dp(14), dp(12))
        }
        card.addView(text("Saját lista · szavak vagy egyes betűk, számok", 14f))
        val row = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL; setPadding(0, dp(8), 0, 0) }
        val et = EditText(this).apply {
            hint = "pl. KUTYA, K, 7, SOS"
            setSingleLine(true)
            inputType = InputType.TYPE_CLASS_TEXT or InputType.TYPE_TEXT_FLAG_CAP_CHARACTERS or InputType.TYPE_TEXT_FLAG_NO_SUGGESTIONS
            setTextColor(Ui.TEXT); setHintTextColor(0xFF5A5A5A.toInt())
            background = rounded(Ui.BG, dp(18).toFloat())
            setPadding(dp(14), dp(10), dp(14), dp(10))
        }
        row.addView(et, LinearLayout.LayoutParams(0, WRAP_CONTENT, 1f))
        row.addView(pill("Hozzáad", true) {
            val n = MorseCustom.add(this, et.text.toString())
            if (n > 0) build() else et.error = "Csak betű (ékezet nélkül is jó) és szám"
        }, LinearLayout.LayoutParams(dp(104), dp(44)).apply { marginStart = dp(6) })
        card.addView(row)
        val list = MorseCustom.list(this)
        if (list.isEmpty()) card.addView(text("Üres – a szótárad szavai jönnek.", 12.5f, Ui.SUB).apply { setPadding(0, dp(8), 0, 0) })
        for (chunk in list.chunked(3)) {
            val r = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; setPadding(0, dp(6), 0, 0) }
            for (w in chunk) r.addView(text("$w  ✕", 14f).apply {
                typeface = Widgets.dotoFace(this@MorseActivity)
                setOnClickListener { MorseCustom.remove(this@MorseActivity, w); build() }
            }, LinearLayout.LayoutParams(0, WRAP_CONTENT, 1f))
            repeat(3 - chunk.size) { r.addView(View(this), LinearLayout.LayoutParams(0, 1, 1f)) }
            card.addView(r)
        }
        return card
    }

    private fun pill(label: String, sel: Boolean = false, onClick: () -> Unit): TextView =
        text(label, 14.5f, if (sel) Ui.DARK_TEXT else Ui.TEXT, Ui.medium).apply {
            gravity = Gravity.CENTER
            background = rounded(if (sel) Ui.LIGHT else Ui.CARD, dp(24).toFloat())
            setOnClickListener { onClick() }
        }

    private fun pills(labels: List<String>, selected: Int, onPick: (Int) -> Unit): LinearLayout {
        val r = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
        labels.forEachIndexed { i, l ->
            r.addView(pill(l, i == selected) { onPick(i) }, LinearLayout.LayoutParams(0, dp(46), 1f).apply { if (i < labels.size - 1) marginEnd = dp(5) })
        }
        return r
    }

    private fun send(action: String) = startService(Intent(this, SimonService::class.java).setAction(action))

    private fun submit() {
        val t = input.text.toString()
        if (t.isBlank()) return
        if (MorseBus.word.value.isEmpty()) { feedback.text = "Előbb indítsd el a gyakorlást"; return }
        if (MorseBus.submit(this, t)) {
            feedback.setTextColor(Ui.LIGHT)
            feedback.text = "✓ Helyes: ${MorseBus.word.value}" + if (MorseBus.streak > 1) " · sorozat: ${MorseBus.streak}" else ""
            input.setText("")
            Haptics(this).result()
        } else {
            feedback.setTextColor(0xFFE0857F.toInt())
            feedback.text = "✗ Nem ez – figyeld tovább a sávot"
            Haptics(this).denied()
            input.selectAll()
        }
    }

    private fun showKeyboard() {
        input.requestFocus()
        try { getSystemService(InputMethodManager::class.java).showSoftInput(input, InputMethodManager.SHOW_IMPLICIT) } catch (t: Throwable) { }
    }

    /** Állapot frissítése; fáziváltáskor (első lefutás vége) feldobja a billentyűzetet. */
    private fun refresh(force: Boolean = false) {
        val ph = MorseBus.phase.value
        val run = running()
        if (!force && ph == lastPhase) return
        val prev = lastPhase
        lastPhase = ph
        val label = when {
            !run -> "KOPPINTS: INDÍTÁS"
            ph == MorsePhase.FIRST -> "FIGYELD A SÁVOT…"
            ph == MorsePhase.WAITING -> if (MorseBus.word.value.length == 1) "MI VOLT A JEL?" else "MI VOLT A SZÓ?"
            ph == MorsePhase.LOOPING -> "ISMÉTLÉS…"
            ph == MorsePhase.SOLVED -> "✓ MEGFEJTVE"
            ph == MorsePhase.REVEAL -> "A SZÓ: ${MorseBus.word.value}"
            else -> "INDUL…"
        }
        phaseText.setImageBitmap(Widgets.dotText(this, label, 16f, if (ph == MorsePhase.SOLVED) Ui.LIGHT else 0xFFF4F4F4.toInt()))
        val n = MorseBus.word.value.length
        val note = MorseBus.notice.value
        hintText.text = when {
            note.isNotEmpty() -> note
            run && n == 1 -> "Egy jel (betű vagy szám) · pont = 1 LED, vonás = 3 LED"
            run && n > 0 -> "$n betűs szó · pont = 1 LED, vonás = 3 LED"
            else -> "A felső sávon fut a kód – az első lefutás után írd be"
        }
        startBtn.text = if (run) "■  Gyakorlás vége" else "●  Gyakorlás indítása"
        if (prev == MorsePhase.FIRST && (ph == MorsePhase.WAITING || ph == MorsePhase.LOOPING)) showKeyboard()
        if (ph == MorsePhase.FIRST && prev != MorsePhase.FIRST) { input.setText(""); feedback.text = "" }
        // Az új jel bemutatása az első lefutás alatt látszik, utána eltűnik
        if (ph != MorsePhase.FIRST && prev == MorsePhase.FIRST) MorseBus.notice.value = ""
    }

    override fun onResume() {
        super.onResume()
        visible = true
        GlyphMirror.appVisible = true
        liveJob?.cancel()
        liveJob = scope.launch {
            var ph = 0f
            while (isActive) {
                preview.lit = GlyphMirror.lit.value
                refresh()
                ph = (ph + 0.006f) % 1f
                badgeViews.forEachIndexed { i, v -> v.phase = (ph + i * 0.2f) % 1f; v.invalidate() }
                delay(40)
            }
        }
        // Ha az első lefutás már lement, rögtön írhat
        if (running() && MorseBus.phase.value != MorsePhase.FIRST) showKeyboard()
        refresh(true)
    }

    override fun onPause() {
        super.onPause()
        visible = false
        GlyphMirror.appVisible = false
        liveJob?.cancel()
    }

    override fun onDestroy() {
        scope.cancel()
        super.onDestroy()
    }
}
