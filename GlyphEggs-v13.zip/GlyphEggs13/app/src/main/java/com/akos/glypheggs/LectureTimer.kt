package com.akos.glypheggs

import android.content.Context
import android.os.SystemClock
import com.nothing.ketchum.Glyph
import kotlinx.coroutines.channels.Channel
import kotlinx.coroutines.coroutineScope
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.merge
import kotlinx.coroutines.launch
import kotlin.math.ceil

/**
 * Egyetemi előadás-időzítő. Alapból 2 × 45 perc, köztük egy 15 perces szünet – minden beállítható
 * (Eszközök → Előadás beállítása): a részek száma és hossza, a szünet hossza, a töltés (indítás)
 * módja, a szünet parancsa, a szünet korai befejezése, az automatikus szünet. A leállítás és az
 * indító mozdulat az „Indítás és leállítás” oldalon állítható, mint minden funkciónál.
 *
 *  1. TÖLTÉS (indítás): a telefon az asztalon fekszik. Rázd meg (vagy kopogtass, ahogy beállítottad),
 *     és LED-ek gyulladnak a töltőport felől (E1 → függőleges vonal → ívek → felső sáv → kamera)
 *     egészen felfelé. Amikor mind a 33 LED ég, elindul az előadás. („Azonnal” módban nincs töltés.)
 *  2. ELŐADÁS: a felső sáv (C1, 16 LED) mutatja a hátralévő időt – a teljes előadást osztja 16 felé
 *     (2 × 45 percnél LED-enként ≈ 5,6 perc, a sáv fele pontosan az első 45 perc). A soron lévő
 *     LED pislog. Egy rész végén rezgés és villogás jelzi.
 *  3. SZÜNET: a beállított paranccsal (alapból kétszeri rázás) elindul a szünet. Ezt a függőleges
 *     vonal (D1, 8 LED, a töltőport felől) mutatja; közben az előadás ideje áll, és a felső sáv
 *     változatlanul mutatja, mennyi van még hátra. A szünet végén az előadás folytatódik ott, ahol
 *     abbamaradt. Ha engedélyezted, ugyanazzal a paranccsal a szünetet előbb is befejezheted.
 *  4. VÉGE: minden LED villog, aztán kikapcsol.
 *
 * A szimulációban az Érintés gomb számít rázásnak és kopogásnak is.
 */
/** Az előadás visszaszámlálójának animációja (Előadás beállítása → Animáció). */
enum class LectureStyle(val title: String, val desc: String) {
    BAR("Fogyó sáv", "A felső sáv a teljes előadást mutatja, LED-enként fogy; a soron lévő LED pislog"),
    STEADY("Nyugodt sáv", "Mint a fogyó sáv, de semmi nem pislog – a legkevésbé zavaró"),
    BLOCK("Részenként", "A felső sáv mindig az aktuális részt mutatja (minden rész elején újra megtelik); a kamera körüli LED-ek jelzik, hányadik résznél tartasz"),
    SAND("Homokóra", "Felül a felső sáv fogy, alul a pont és a függőleges vonal telik a töltőport felől; 2 mp-enként egy homokszem hullik le"),
    PULSE("Szívverés", "Álló sáv, és a pont a töltőportnál kétszer dobban 2 mp-enként – látod, hogy fut"),
    RUNNER("Futófény", "A hátralévő idő ég a sávon, és egy sötét rés fut végig rajta, mint egy töltésjelző"),
    RING("Óramutató", "Egy fénypont körbejár a nagy gyűrűn: egy kör = egy rész; mögötte megtelik. A felső sáv a teljes előadást mutatja"),
    MINIMAL("Takarékos", "Majdnem sötét: 30 mp-enként 1,5 mp-re felvillan a hátralévő idő, közben csak a pont pislan – a legkevesebb akku")
}

class LectureTimer(
    private val context: Context,
    private val glyph: GlyphController,
    private val motion: MotionDetector,
    private val haptics: Haptics,
    /** A rázás-töltés indító mozdulattal indult: a LED-ek már fel vannak töltve, nincs újabb töltés. */
    private val prefilled: Boolean = false,
    private val onStatus: (String) -> Unit
) {
    private val blocks = Settings.lectureBlocks(context)
    private val blockMin = Settings.lectureBlockMin(context)
    private val blockMs = blockMin * 60_000L
    private val breakMin = Settings.lectureBreakMin(context)
    private val breakMs = breakMin * 60_000L
    private val lectureMs = blocks * blockMs
    private val startMode = Settings.lectureStart(context)
    private val fillCount = Settings.shakeFillCount(context)
    private val breakCmd = Settings.lectureBreakCmd(context)
    private val multiBreak = Settings.lectureMultiBreak(context)
    private val autoBreak = Settings.lectureAutoBreak(context)
    private val earlyResume = Settings.lectureEarlyResume(context)
    private val style = Settings.lectureStyle(context)
    private val warn = Settings.lectureWarn(context)

    /** A felső sáv bal végétől a jobb végéig. */
    private val bar: IntArray = IntArray(16) { Zones.LEVEL[15 - it] }
    /** A függőleges vonal, D1_1 alul (a töltőport felől). */
    private val dLine = intArrayOf(
        Glyph.Code_22111.D1_1, Glyph.Code_22111.D1_2, Glyph.Code_22111.D1_3, Glyph.Code_22111.D1_4,
        Glyph.Code_22111.D1_5, Glyph.Code_22111.D1_6, Glyph.Code_22111.D1_7, Glyph.Code_22111.D1_8
    )

    private val fillOrder: IntArray get() = FILL_ORDER

    companion object {
        private val BAR: IntArray = IntArray(16) { Zones.LEVEL[15 - it] }
        /** Alulról felfelé: E1, majd D1_1 … D1_8. */
        private val BOTTOM: IntArray = intArrayOf(
            Glyph.Code_22111.E1,
            Glyph.Code_22111.D1_1, Glyph.Code_22111.D1_2, Glyph.Code_22111.D1_3, Glyph.Code_22111.D1_4,
            Glyph.Code_22111.D1_5, Glyph.Code_22111.D1_6, Glyph.Code_22111.D1_7, Glyph.Code_22111.D1_8
        )
        /** A nagy gyűrű körbe, felülről az óramutató irányában. */
        private val RING: IntArray = intArrayOf(
            Glyph.Code_22111.C2, Glyph.Code_22111.C6, Glyph.Code_22111.C5,
            Glyph.Code_22111.C4, Glyph.Code_22111.C3
        )
        /** Részjelzők a kamera körül (1–4. rész). */
        private val MARKERS: IntArray = intArrayOf(
            Glyph.Code_22111.A1, Glyph.Code_22111.A2, Glyph.Code_22111.B1, Glyph.Code_22111.C2
        )

        /**
         * Egy kép az előadás alatt (a szünetet nem ez rajzolja).
         * @param p a teljes előadásból hátralévő rész (1 → 0)
         * @param bp az aktuális részből hátralévő rész (1 → 0)
         * @param block az aktuális rész (0-tól), [blocks] a részek száma
         * @param now ms (az animáció ütemezéséhez)
         */
        fun frame(style: LectureStyle, p: Double, bp: Double, block: Int, blocks: Int, now: Long): IntArray {
            val n = ceil(p * 16).toInt().coerceIn(0, 16)
            val blink = (now / 500) % 2 == 0L
            val lit = mutableListOf<Int>()
            when (style) {
                LectureStyle.BAR -> {
                    lit += BAR.take((n - 1).coerceAtLeast(0))
                    if (n > 0 && blink) lit += BAR[n - 1]
                }
                LectureStyle.STEADY -> lit += BAR.take(n)
                LectureStyle.BLOCK -> {
                    val bn = ceil(bp * 16).toInt().coerceIn(0, 16)
                    lit += BAR.take((bn - 1).coerceAtLeast(0))
                    if (bn > 0 && blink) lit += BAR[bn - 1]
                    lit += MARKERS.take((block + 1).coerceIn(1, minOf(blocks, MARKERS.size)))
                }
                LectureStyle.SAND -> {
                    lit += BAR.take(n)
                    val filled = ((1.0 - p) * BOTTOM.size).toInt().coerceIn(0, BOTTOM.size)
                    lit += BOTTOM.take(filled)
                    // Homokszem: 2 mp-enként végighull a vonalon a homok tetejéig
                    val step = ((now % 2_000) / 110).toInt()
                    val pos = BOTTOM.size - 1 - step
                    if (n > 0 && pos >= filled) lit += BOTTOM[pos]
                }
                LectureStyle.PULSE -> {
                    lit += BAR.take(n)
                    val t = now % 2_000
                    if (t < 120 || t in 250..369) lit += Glyph.Code_22111.E1
                }
                LectureStyle.RUNNER -> {
                    val on = BAR.take(n).toMutableList()
                    if (n > 1) on.removeAt(((now / 140) % n).toInt())
                    lit += on
                }
                LectureStyle.RING -> {
                    lit += BAR.take(n)
                    val done = (1.0 - bp).coerceIn(0.0, 0.9999)
                    val pos = (done * RING.size).toInt()
                    lit += RING.take(pos)
                    if (blink) lit += RING[pos]
                }
                LectureStyle.MINIMAL -> {
                    if (now % 30_000 < 1_500) lit += BAR.take(n)
                    else if (now % 5_000 < 100) lit += Glyph.Code_22111.E1
                }
            }
            return lit.distinct().toIntArray()
        }

        /** A töltés sorrendje: alulról (töltőport) felfelé, mind a 33 zóna. */
        val FILL_ORDER: IntArray = (
            listOf(Glyph.Code_22111.E1) +
                listOf(
                    Glyph.Code_22111.D1_1, Glyph.Code_22111.D1_2, Glyph.Code_22111.D1_3, Glyph.Code_22111.D1_4,
                    Glyph.Code_22111.D1_5, Glyph.Code_22111.D1_6, Glyph.Code_22111.D1_7, Glyph.Code_22111.D1_8
                ) +
                listOf(Glyph.Code_22111.C4, Glyph.Code_22111.C5, Glyph.Code_22111.C3, Glyph.Code_22111.C6, Glyph.Code_22111.C2) +
                Zones.LEVEL.toList() +
                listOf(Glyph.Code_22111.A2, Glyph.Code_22111.B1, Glyph.Code_22111.A1)
            ).distinct().toIntArray()
    }

    /** Az egész előadás + a lehetséges szünetek hossza (a processzor ébren tartásához). */
    fun totalMs(): Long {
        val autoBreaks = if (autoBreak) blocks - 1 else 0
        val manual = if (breakCmd == BreakCommand.NONE) 0 else if (multiBreak) 3 else 1
        return lectureMs + breakMs * (autoBreaks + manual)
    }

    private fun fmt(ms: Long): String {
        val s = (ms / 1000).coerceAtLeast(0)
        return if (s >= 3600) "%d:%02d:%02d".format(s / 3600, (s % 3600) / 60, s % 60) else "%d:%02d".format(s / 60, s % 60)
    }

    /** Felismeri a szünet-parancsot a rázás- és kopogás-eseményekből. */
    private class CommandDetector(
        private val cmd: BreakCommand,
        private val shakes: Channel<Long>,
        private val knocks: Channel<Long>
    ) {
        private var lastShake = 0L
        private var knockCount = 0
        private var lastKnock = 0L

        fun reset() {
            while (shakes.tryReceive().isSuccess) Unit
            while (knocks.tryReceive().isSuccess) Unit
            lastShake = 0L
            knockCount = 0
        }

        /** True, ha a parancs most hangzott el. */
        fun poll(now: Long): Boolean {
            var s = 0
            while (shakes.tryReceive().isSuccess) s++
            var k = 0
            while (knocks.tryReceive().isSuccess) k++
            when (cmd) {
                BreakCommand.SHAKE -> {
                    if (s >= 2) { lastShake = 0L; return true }
                    if (s == 1) {
                        if (lastShake != 0L && now - lastShake <= Config.LECTURE_SHAKE_WINDOW_MS) {
                            lastShake = 0L
                            return true
                        }
                        lastShake = now
                    }
                    if (lastShake != 0L && now - lastShake > Config.LECTURE_SHAKE_WINDOW_MS) lastShake = 0L
                }
                BreakCommand.KNOCK_3 -> {
                    if (k > 0) { knockCount += k; lastKnock = now }
                    if (knockCount > 0 && now - lastKnock > Config.KNOCK_MAX_GAP_MS) {
                        val n = knockCount
                        knockCount = 0
                        return n == 3
                    }
                }
                BreakCommand.NONE -> Unit
            }
            return false
        }
    }

    suspend fun run() = coroutineScope {
        val shakes = Channel<Long>(16)
        val knocks = Channel<Long>(16)
        val c1 = launch { merge(motion.shakeEvents, GlyphMirror.taps).collect { shakes.trySend(it) } }
        val c2 = launch { merge(motion.knockEvents, GlyphMirror.taps).collect { knocks.trySend(it) } }
        try {
            val go = when (if (prefilled) LectureStart.INSTANT else startMode) {
                LectureStart.SHAKE -> fill(shakes, "rázd")
                LectureStart.KNOCK -> fill(knocks, "kopogj")
                LectureStart.INSTANT -> {
                    delay(600)
                    startSignal()
                    true
                }
            }
            if (go) lecture(CommandDetector(breakCmd, shakes, knocks))
        } finally {
            c1.cancel()
            c2.cancel()
            glyph.off()
        }
    }

    // ------------------------------------------------------------------ 1. töltés (indítás)

    /** @return true, ha megtelt (indulhat az előadás); false, ha túl sokáig nem érkezett esemény. */
    private suspend fun fill(events: Channel<Long>, verb: String): Boolean {
        DebugState.log("Előadás: $verb, amíg minden LED ég (${fillOrder.size} LED)")
        onStatus("Előadás – $verb, amíg minden LED ég")
        var lit = 0
        var count = 0
        var lastEvent = SystemClock.elapsedRealtime()
        while (true) {
            val now = SystemClock.elapsedRealtime()
            var got = 0
            while (events.tryReceive().isSuccess) got++
            if (got > 0) {
                lastEvent = now
                count += got
                lit = ceil(count.toDouble() * fillOrder.size / fillCount).toInt().coerceIn(0, fillOrder.size)
                haptics.tick()
                if (count >= fillCount) break
            }
            if (now - lastEvent > Config.LECTURE_FILL_TIMEOUT_MS) {
                DebugState.log("Előadás: nem érkezett jel – leáll")
                return false
            }
            // Amíg még nincs LED, az E1 pont pislog (hívó jel)
            val show = if (lit == 0) {
                if ((now / 500) % 2 == 0L) intArrayOf(Glyph.Code_22111.E1) else intArrayOf()
            } else fillOrder.copyOfRange(0, lit)
            glyph.show(show)
            delay(60)
        }
        // Megtelt: minden LED ég, majd a felső sáv "feltöltődik" – indul
        glyph.show(Zones.ALL)
        haptics.result()
        delay(1_200)
        startSignal()
        return true
    }

    private suspend fun startSignal() {
        for (n in 0..16) {
            glyph.show(bar.take(n).toIntArray())
            delay(45)
        }
        delay(400)
        DebugState.log("Előadás elindult: $blocks × $blockMin perc, szünet: $breakMin perc")
    }

    // ------------------------------------------------------------------ 2–4. előadás, szünet, vége

    private suspend fun lecture(detector: CommandDetector) {
        detector.reset() // a töltés utolsó rázásai / kopogásai ne számítsanak

        var elapsed = 0L            // az előadásból eltelt idő (a szünet alatt áll)
        var breakElapsed = 0L
        var inBreak = false
        var breaksUsed = 0
        var blocksDone = 0
        var lastStatus = 0L
        var lastShown: IntArray? = null
        var warnedBlock = -1
        var last = SystemClock.elapsedRealtime()
        var guardUntil = last + Config.LECTURE_ARM_MS

        suspend fun startBreak(auto: Boolean) {
            inBreak = true
            breakElapsed = 0L
            if (!auto) breaksUsed++
            DebugState.log("Előadás: szünet indul ($breakMin perc" + (if (auto) ", magától)" else ")"))
            haptics.tick()
            breakStartSignal()
            lastShown = null
            detector.reset()
            guardUntil = SystemClock.elapsedRealtime() + 3_000L
        }

        suspend fun endBreak(early: Boolean) {
            inBreak = false
            DebugState.log("Előadás: a szünet véget ért" + (if (early) " (előbb befejezted)" else "") + " – folytatódik")
            breakEndSignal()
            lastShown = null
            detector.reset()
            guardUntil = SystemClock.elapsedRealtime() + 3_000L
        }

        while (elapsed < lectureMs) {
            val now = SystemClock.elapsedRealtime()
            val dt = now - last
            last = now

            if (inBreak) {
                breakElapsed += dt
                if (breakElapsed >= breakMs) {
                    endBreak(false)
                    continue
                }
            } else {
                elapsed += dt
            }

            // Egy rész vége (az utolsó rész vége az előadás vége)
            if (!inBreak && blocksDone < blocks - 1 && elapsed >= (blocksDone + 1) * blockMs) {
                blocksDone++
                DebugState.log("Előadás: letelt a(z) $blocksDone. rész ($blockMin perc)")
                blockEndSignal()
                lastShown = null
                if (autoBreak) startBreak(true)
                continue
            }

            // Szünet parancs: indítás, illetve (ha engedélyezett) a szünet korai befejezése
            val cmd = detector.poll(now)
            if (cmd && now >= guardUntil) {
                if (inBreak) {
                    if (earlyResume) {
                        endBreak(true)
                        continue
                    }
                } else if (breakCmd != BreakCommand.NONE && (multiBreak || breaksUsed == 0)) {
                    startBreak(false)
                    continue
                }
            }

            // Rész vége előtti figyelmeztetés (pl. 5 perccel előtte): rezgés + egy felvillanás
            val blockEnd = (blocksDone + 1) * blockMs
            if (warn && !inBreak && warnedBlock != blocksDone && blockMs > Config.LECTURE_WARN_MIN * 60_000L * 2 &&
                blockEnd - elapsed <= Config.LECTURE_WARN_MIN * 60_000L
            ) {
                warnedBlock = blocksDone
                DebugState.log("Előadás: ${Config.LECTURE_WARN_MIN} perc van hátra a(z) ${blocksDone + 1}. részből")
                haptics.tick()
                glyph.show(Zones.LEVEL)
                delay(300)
                glyph.off()
                delay(200)
                glyph.show(Zones.LEVEL)
                delay(300)
                lastShown = null
            }

            // Kijelzés
            val blink = (now / 500) % 2 == 0L
            val remaining = lectureMs - elapsed
            val n = ceil(remaining.toDouble() / (lectureMs / 16.0)).toInt().coerceIn(0, 16)
            val lit = mutableListOf<Int>()
            if (inBreak) {
                // Felső sáv: állandó (az előadásból még hátralévő idő); D1: a szünet hátralévő ideje, a soron lévő LED pislog
                val m = ceil((breakMs - breakElapsed).toDouble() / (breakMs / 8.0)).toInt().coerceIn(1, 8)
                if (style == LectureStyle.MINIMAL) {
                    // Takarékos: 30 mp-enként felvillan a szünet hátralévő ideje
                    if (now % 30_000 < 1_500) lit += dLine.take(m)
                } else {
                    lit += bar.take(n)
                    lit += dLine.take(m - 1)
                    if (blink) lit += dLine[m - 1]
                }
            } else {
                val bp = ((blockEnd - elapsed).toDouble() / blockMs).coerceIn(0.0, 1.0)
                lit += frame(style, remaining.toDouble() / lectureMs, bp, blocksDone, blocks, now).toList()
            }
            val show = lit.toIntArray()
            val shown = lastShown
            if (shown == null || !shown.contentEquals(show)) {
                glyph.show(show)
                lastShown = show
            }

            if (lastStatus == 0L || now - lastStatus > 10_000) {
                lastStatus = now
                val part = (blocksDone + 1).coerceAtMost(blocks)
                val partLeft = (blocksDone + 1) * blockMs - elapsed
                val canBreak = !inBreak && breakCmd != BreakCommand.NONE && (multiBreak || breaksUsed == 0)
                onStatus(
                    if (inBreak) "Szünet · ${fmt(breakMs - breakElapsed)} van hátra (utána folytatódik: $part. rész)" +
                        if (earlyResume && breakCmd != BreakCommand.NONE) " · előbb: ${breakCmd.title}" else ""
                    else "Előadás · $part/$blocks. rész · ${fmt(partLeft)} van hátra · összesen ${fmt(lectureMs - elapsed)}" +
                        if (canBreak) " · szünet: ${breakCmd.title}" else ""
                )
            }
            delay(100)
        }
        finale()
    }

    // ------------------------------------------------------------------ jelzések

    private suspend fun blockEndSignal() {
        haptics.phaseEnd()
        repeat(3) {
            glyph.show(Zones.ALL)
            delay(220)
            glyph.off()
            delay(180)
        }
    }

    private suspend fun breakStartSignal() {
        // A függőleges vonal alulról felfelé megtelik: indul a szünet
        for (n in 0..8) {
            glyph.show(dLine.take(n).toIntArray())
            delay(70)
        }
        delay(250)
    }

    private suspend fun breakEndSignal() {
        haptics.phaseEnd()
        repeat(3) {
            glyph.show(dLine + Glyph.Code_22111.E1)
            delay(220)
            glyph.off()
            delay(180)
        }
    }

    private suspend fun finale() {
        DebugState.log("Előadás vége")
        haptics.win()
        repeat(12) {
            glyph.show(Zones.ALL)
            delay(220)
            glyph.off()
            delay(180)
        }
        glyph.off()
    }
}
