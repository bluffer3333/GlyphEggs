package com.akos.glypheggs

import android.app.PendingIntent
import android.appwidget.AppWidgetManager
import android.appwidget.AppWidgetProvider
import android.content.BroadcastReceiver
import android.content.ComponentName
import android.content.Context
import android.content.Intent
import android.graphics.Bitmap
import android.graphics.Canvas
import android.os.SystemClock
import android.view.View
import android.widget.RemoteViews
import com.nothing.ketchum.Glyph

/**
 * Az időzítő állapota a widgethez (mentve, hogy a widget akkor is lássa, ha az app újraindult).
 */
object TimerState {
    private const val PREFS = "glyph_eggs_timer"

    private fun p(c: Context) = c.getSharedPreferences(PREFS, Context.MODE_PRIVATE)

    fun running(c: Context, title: String, endElapsed: Long, index: Int, count: Int, isBreak: Boolean) {
        p(c).edit().putBoolean("active", true).putBoolean("paused", false).putString("title", title)
            .putLong("end", endElapsed).putInt("index", index).putInt("count", count)
            .putBoolean("break", isBreak).apply()
        Widgets.updateTimer(c)
    }

    fun pause(c: Context, remainingMs: Long) {
        p(c).edit().putBoolean("paused", true).putLong("remaining", remainingMs).apply()
        Widgets.updateTimer(c)
    }

    fun resume(c: Context, remainingMs: Long) {
        p(c).edit().putBoolean("paused", false).putLong("end", SystemClock.elapsedRealtime() + remainingMs).apply()
        Widgets.updateTimer(c)
    }

    fun clear(c: Context) {
        p(c).edit().putBoolean("active", false).apply()
        Widgets.updateTimer(c)
    }

    fun active(c: Context) = p(c).getBoolean("active", false)
    fun paused(c: Context) = p(c).getBoolean("paused", false)
    fun title(c: Context) = p(c).getString("title", null) ?: ""
    fun end(c: Context) = p(c).getLong("end", 0L)
    fun remaining(c: Context) = p(c).getLong("remaining", 0L)
    fun isBreak(c: Context) = p(c).getBoolean("break", false)
}

/** A widgetek kirajzolása és frissítése egy helyen. */
object Widgets {
    private const val PREFS = "glyph_eggs_widgets"
    private const val DARK = 0xFF111111.toInt()
    private const val LIGHT = 0xFFEEEEEE.toInt()

    private fun p(c: Context) = c.getSharedPreferences(PREFS, Context.MODE_PRIVATE)

    // --- widgetenkénti beállítás ---
    fun barFeatures(c: Context, id: Int): List<Feature> {
        val raw = p(c).getString("bar_$id", null)
        val list = raw?.split(",")?.mapNotNull { n -> Feature.entries.firstOrNull { it.name == n } }
        return (list ?: (Settings.pinned(c) + Feature.entries).distinct()).take(4)
    }
    fun setBarFeatures(c: Context, id: Int, list: List<Feature>) =
        p(c).edit().putString("bar_$id", list.joinToString(",") { it.name }).apply()

    fun singleFeature(c: Context, id: Int): Feature =
        Feature.entries.firstOrNull { it.name == p(c).getString("single_$id", null) } ?: Feature.SPIN
    fun setSingleFeature(c: Context, id: Int, f: Feature) = p(c).edit().putString("single_$id", f.name).apply()

    fun forget(c: Context, ids: IntArray) {
        val e = p(c).edit()
        for (id in ids) { e.remove("bar_$id"); e.remove("single_$id") }
        e.apply()
    }

    // --- frissítés ---
    private fun ids(c: Context, cls: Class<*>): IntArray =
        AppWidgetManager.getInstance(c).getAppWidgetIds(ComponentName(c, cls))

    fun updateAll(c: Context) {
        updateBar(c)
        updateSingle(c)
        updatePet(c)
        updateTimer(c)
    }

    fun updateBar(c: Context, ids: IntArray = ids(c, QuickBarWidget::class.java)) {
        val m = AppWidgetManager.getInstance(c)
        for (id in ids) m.updateAppWidget(id, barViews(c, id))
    }

    fun updateSingle(c: Context, ids: IntArray = ids(c, FeatureWidget::class.java)) {
        val m = AppWidgetManager.getInstance(c)
        for (id in ids) m.updateAppWidget(id, singleViews(c, id))
    }

    fun updatePet(c: Context, ids: IntArray = ids(c, PetWidget::class.java)) {
        if (ids.isEmpty()) return
        val m = AppWidgetManager.getInstance(c)
        val views = petViews(c)
        for (id in ids) m.updateAppWidget(id, views)
    }

    fun updateTimer(c: Context, ids: IntArray = ids(c, TimerWidget::class.java)) {
        if (ids.isEmpty()) return
        val m = AppWidgetManager.getInstance(c)
        val views = timerViews(c)
        for (id in ids) m.updateAppWidget(id, views)
    }

    // --- kattintások ---
    private fun serviceIntent(c: Context, action: String, req: Int, fromWidget: Boolean = false): PendingIntent =
        PendingIntent.getForegroundService(
            c, req, Intent(c, SimonService::class.java).setAction(action).apply {
                if (fromWidget) putExtra(SimonService.EXTRA_SOURCE, SimonService.SOURCE_WIDGET)
            },
            PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT
        )

    private fun activityIntent(c: Context, cls: Class<*>, req: Int): PendingIntent =
        PendingIntent.getActivity(
            c, req, Intent(c, cls).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK),
            PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT
        )

    /** A Tojás vagy a funkció indítása: a Tojás a saját oldalát nyitja, a többi a szolgáltatást. */
    private fun featureIntent(c: Context, f: Feature, req: Int): PendingIntent =
        if (f == Feature.PET) activityIntent(c, PetActivity::class.java, req)
        else serviceIntent(c, SimonService.actionFor(f), req, fromWidget = true)

    private fun petActionIntent(c: Context, a: PetAction): PendingIntent =
        PendingIntent.getBroadcast(
            c, 500 + a.ordinal,
            Intent(c, WidgetActionReceiver::class.java).setAction(WidgetActionReceiver.ACTION_PET).putExtra("act", a.name),
            PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT
        )

    // --- nézetek ---
    private val slotRoot = intArrayOf(R.id.slot0, R.id.slot1, R.id.slot2, R.id.slot3)
    private val slotBg = intArrayOf(R.id.slot0_bg, R.id.slot1_bg, R.id.slot2_bg, R.id.slot3_bg)
    private val slotIcon = intArrayOf(R.id.slot0_icon, R.id.slot1_icon, R.id.slot2_icon, R.id.slot3_icon)
    private val slotLabel = intArrayOf(R.id.slot0_label, R.id.slot1_label, R.id.slot2_label, R.id.slot3_label)

    private fun barViews(c: Context, id: Int): RemoteViews {
        val v = RemoteViews(c.packageName, R.layout.widget_bar)
        val mode = GlyphMirror.mode.value
        val watching = Settings.watching(c)
        v.setTextViewText(R.id.bar_status, if (mode != null) "${mode.title} fut · koppints a leállításhoz" else "Készenlét")
        v.setTextViewText(R.id.bar_watch, if (watching) "Figyel" else "Figyelés ki")
        v.setInt(R.id.bar_watch, "setBackgroundResource", if (watching) R.drawable.widget_pill_on else R.drawable.widget_pill)
        v.setTextColor(R.id.bar_watch, if (watching) DARK else LIGHT)
        v.setOnClickPendingIntent(R.id.bar_watch, serviceIntent(c, SimonService.ACTION_WATCH_TOGGLE, id * 10 + 9))
        v.setOnClickPendingIntent(R.id.bar_title, activityIntent(c, MainActivity::class.java, id * 10 + 8))

        val list = barFeatures(c, id)
        for (i in 0 until 4) {
            val f = list.getOrNull(i)
            if (f == null) {
                v.setViewVisibility(slotRoot[i], View.INVISIBLE)
                continue
            }
            v.setViewVisibility(slotRoot[i], View.VISIBLE)
            val on = mode == f
            v.setImageViewResource(slotIcon[i], f.icon)
            v.setInt(slotIcon[i], "setColorFilter", if (on) DARK else LIGHT)
            v.setInt(slotBg[i], "setBackgroundResource", if (on) R.drawable.widget_btn_on else R.drawable.widget_btn)
            v.setTextViewText(slotLabel[i], if (on) "Fut" else f.short)
            v.setOnClickPendingIntent(slotRoot[i], featureIntent(c, f, id * 10 + i))
        }
        return v
    }

    private fun singleViews(c: Context, id: Int): RemoteViews {
        val v = RemoteViews(c.packageName, R.layout.widget_feature)
        val f = singleFeature(c, id)
        val on = GlyphMirror.mode.value == f
        v.setImageViewResource(R.id.f_icon, f.icon)
        v.setInt(R.id.f_icon, "setColorFilter", if (on) DARK else LIGHT)
        v.setInt(R.id.f_bg, "setBackgroundResource", if (on) R.drawable.widget_btn_on else R.drawable.widget_btn)
        v.setTextViewText(R.id.f_label, if (on) "${f.short} · fut" else f.short)
        v.setOnClickPendingIntent(R.id.f_root, featureIntent(c, f, 20_000 + id))
        return v
    }

    /** A Tojás "portréja" a Glyph-rajzon: szemek, antenna, test a hangulat szerint. */
    fun petZones(s: PetState): Set<Int> {
        val c1: IntArray = IntArray(16) { Zones.LEVEL[15 - it] }
        val z = mutableSetOf<Int>()
        if (s.stage == PetStage.EGG) {
            z += c1.toList()
            z += listOf(Glyph.Code_22111.C2, Glyph.Code_22111.C3, Glyph.Code_22111.C4, Glyph.Code_22111.C5, Glyph.Code_22111.C6)
            return z
        }
        if (s.mood != PetMood.SLEEP) z += listOf(Glyph.Code_22111.A1, Glyph.Code_22111.A2)
        if (s.mood == PetMood.HAPPY || s.stage.ordinal >= PetStage.TEEN.ordinal) z += Glyph.Code_22111.B1
        val size = when (s.stage) { PetStage.BABY -> 2; PetStage.TEEN -> 3; else -> 4 }
        when (s.mood) {
            PetMood.HAPPY -> { for (k in 0 until size + 2) z += c1[7 - size / 2 + k - 1]; z += Glyph.Code_22111.C2; z += Glyph.Code_22111.C6 }
            PetMood.OK -> for (k in 0 until size) z += c1[7 - size / 2 + k]
            PetMood.SAD -> { for (k in 0 until size) z += c1[7 - size / 2 + k]; z += Glyph.Code_22111.D1_6; z += Glyph.Code_22111.D1_3 }
            PetMood.SICK -> { for (k in 0 until size) z += c1[7 - size / 2 + k]; z += Glyph.Code_22111.C4 }
            PetMood.SLEEP -> { z += Glyph.Code_22111.D1_1 }
        }
        if (s.poops > 0 || s.mood == PetMood.SLEEP) z += Glyph.Code_22111.E1
        return z
    }

    /** A Glyph-rajz képpé alakítva (a widget nem tud saját nézetet rajzolni). */
    fun glyphBitmap(c: Context, lit: Set<Int>, sizePx: Int, idleAllOn: Boolean = false): Bitmap {
        val view = GlyphMapView(c).apply {
            unlitColor = 0xFF2E2E2E.toInt()
            this.idleAllOn = idleAllOn
            this.lit = lit
        }
        val spec = View.MeasureSpec.makeMeasureSpec(sizePx, View.MeasureSpec.EXACTLY)
        view.measure(spec, spec)
        view.layout(0, 0, sizePx, sizePx)
        val bmp = Bitmap.createBitmap(sizePx, sizePx, Bitmap.Config.ARGB_8888)
        view.draw(Canvas(bmp))
        return bmp
    }

    private fun petViews(c: Context): RemoteViews {
        val v = RemoteViews(c.packageName, R.layout.widget_pet)
        val s = PetStore.load(c)
        v.setImageViewBitmap(R.id.pet_image, glyphBitmap(c, petZones(s), 260))
        v.setTextViewText(R.id.pet_title, if (s.stage == PetStage.EGG) "Tojás" else "${s.stage.title} · ${s.mood.title}")
        val need = s.need()
        v.setTextViewText(
            R.id.pet_sub,
            when {
                s.stage == PetStage.EGG -> "Melegítsd: ${s.warmth}/3 gondoskodás"
                need != null -> "Most: $need"
                else -> "Minden rendben"
            }
        )
        v.setProgressBar(R.id.pet_bar_food, 100, s.food.toInt(), false)
        v.setProgressBar(R.id.pet_bar_fun, 100, s.fun_.toInt(), false)
        v.setProgressBar(R.id.pet_bar_energy, 100, s.energy.toInt(), false)
        v.setProgressBar(R.id.pet_bar_clean, 100, s.clean.toInt(), false)
        v.setOnClickPendingIntent(R.id.pet_btn_feed, petActionIntent(c, PetAction.FEED))
        v.setOnClickPendingIntent(R.id.pet_btn_play, petActionIntent(c, PetAction.PLAY))
        v.setOnClickPendingIntent(R.id.pet_btn_pet, petActionIntent(c, PetAction.PET))
        v.setOnClickPendingIntent(R.id.pet_btn_clean, petActionIntent(c, PetAction.CLEAN))
        v.setOnClickPendingIntent(R.id.pet_image, activityIntent(c, PetActivity::class.java, 600))
        v.setOnClickPendingIntent(R.id.pet_title, activityIntent(c, PetActivity::class.java, 601))
        return v
    }

    private fun fmt(ms: Long): String {
        val sec = (ms / 1000).coerceAtLeast(0)
        return "%d:%02d".format(sec / 60, sec % 60)
    }

    private fun timerViews(c: Context): RemoteViews {
        val v = RemoteViews(c.packageName, R.layout.widget_timer)
        val mode = Settings.timerMode(c)
        val style = Settings.timerStyle(c)
        val running = TimerState.active(c) && GlyphMirror.mode.value == Feature.TIMER
        if (running) {
            val paused = TimerState.paused(c)
            v.setTextViewText(R.id.t_title, TimerState.title(c) + if (paused) " · szünetel" else "")
            v.setViewVisibility(R.id.t_chrono, View.VISIBLE)
            v.setViewVisibility(R.id.t_time, View.GONE)
            if (paused) {
                v.setChronometer(R.id.t_chrono, SystemClock.elapsedRealtime() + TimerState.remaining(c), null, false)
            } else {
                v.setChronometer(R.id.t_chrono, TimerState.end(c), null, true)
            }
            v.setChronometerCountDown(R.id.t_chrono, true)
            v.setImageViewResource(R.id.t_btn_icon, R.drawable.ic_stop)
            v.setTextViewText(R.id.t_hint, if (TimerState.isBreak(c)) "Pihenj – a gyűrű lélegzik" else "Fókusz – a LED-ek mutatják az időt")
        } else {
            val minutes = if (mode.custom) Settings.timerMinutes(c) else mode.workMin
            v.setTextViewText(R.id.t_title, "${mode.title} · ${style.title}")
            v.setViewVisibility(R.id.t_chrono, View.GONE)
            v.setViewVisibility(R.id.t_time, View.VISIBLE)
            v.setTextViewText(R.id.t_time, fmt(minutes * 60_000L))
            v.setImageViewResource(R.id.t_btn_icon, R.drawable.ic_play)
            v.setTextViewText(R.id.t_hint, "Koppints az órára a beállításhoz")
        }
        v.setOnClickPendingIntent(R.id.t_btn, serviceIntent(c, SimonService.ACTION_TIMER, 700))
        v.setOnClickPendingIntent(R.id.t_root, activityIntent(c, TimerActivity::class.java, 701))
        return v
    }
}

/** Gyorsindító sáv: 4 választható funkció + Mozdulatfigyelés kapcsoló. */
class QuickBarWidget : AppWidgetProvider() {
    override fun onUpdate(context: Context, manager: AppWidgetManager, ids: IntArray) = Widgets.updateBar(context, ids)
    override fun onDeleted(context: Context, ids: IntArray) = Widgets.forget(context, ids)
}

/** Egygombos widget egy választott funkcióhoz. */
class FeatureWidget : AppWidgetProvider() {
    override fun onUpdate(context: Context, manager: AppWidgetManager, ids: IntArray) = Widgets.updateSingle(context, ids)
    override fun onDeleted(context: Context, ids: IntArray) = Widgets.forget(context, ids)
}

/** Glyph Tojás: portré, állapotsávok, gyors gondozás. */
class PetWidget : AppWidgetProvider() {
    override fun onUpdate(context: Context, manager: AppWidgetManager, ids: IntArray) = Widgets.updatePet(context, ids)
}

/** Időzítő: visszaszámlálás, indítás / leállítás. */
class TimerWidget : AppWidgetProvider() {
    override fun onUpdate(context: Context, manager: AppWidgetManager, ids: IntArray) = Widgets.updateTimer(context, ids)
}

/** Widget-gombok, amikhez nem kell a szolgáltatás (Tojás gondozása). */
class WidgetActionReceiver : BroadcastReceiver() {
    companion object {
        const val ACTION_PET = "com.akos.glypheggs.WIDGET_PET"
    }

    override fun onReceive(context: Context, intent: Intent) {
        if (intent.action != ACTION_PET) return
        val a = PetAction.entries.firstOrNull { it.name == intent.getStringExtra("act") } ?: return
        val msg = PetStore.act(context, a)
        DebugState.log("Tojás (widget): ${a.title} – $msg")
        Widgets.updatePet(context)
    }
}
