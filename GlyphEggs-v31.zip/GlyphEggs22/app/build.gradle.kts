plugins {
    id("com.android.application")
    id("org.jetbrains.kotlin.android")
}

android {
    namespace = "com.akos.glypheggs"
    compileSdk = 35

    defaultConfig {
        applicationId = "com.akos.glypheggs"
        // A Glyph SDK csak Android 14+ Nothing telefonokon működik
        minSdk = 34
        targetSdk = 35
        versionCode = 31
        versionName = "12.8.1"
    }

    // Állandó fejlesztői aláírás: így az új APK a régi app fölé települ (nem kell törölni)
    signingConfigs {
        getByName("debug") {
            storeFile = file("debug.keystore")
            storePassword = "android"
            keyAlias = "androiddebugkey"
            keyPassword = "android"
        }
    }

    buildTypes {
        release {
            isMinifyEnabled = false
        }
    }

    compileOptions {
        sourceCompatibility = JavaVersion.VERSION_17
        targetCompatibility = JavaVersion.VERSION_17
    }
    kotlinOptions {
        jvmTarget = "17"
    }
}

dependencies {
    // Nothing hivatalos Glyph SDK (github.com/Nothing-Developer-Programme/Glyph-Developer-Kit)
    implementation(files("libs/glyph-matrix-sdk-2.0.aar"))
    implementation("org.jetbrains.kotlinx:kotlinx-coroutines-android:1.9.0")
}
