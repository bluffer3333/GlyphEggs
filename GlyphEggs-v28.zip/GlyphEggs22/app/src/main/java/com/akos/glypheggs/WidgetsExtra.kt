package com.akos.glypheggs

import android.app.PendingIntent
import android.appwidget.AppWidgetManager
import android.appwidget.AppWidgetProvider
import android.content.ComponentName
import android.content.Context
import android.content.Intent
import android.graphics.Bitmap
import android.graphics.Canvas
import android.graphics.Paint
import android.os.SystemClock
import android.widget.RemoteViews
import kotlin.math.abs
import kotlin.math.cos
import kotlin.math.sin

/*
 * Nothing-stílusú kis widgetek (2×2): Vízmérték, Pörgetés, Homokóra.
 * Fekete lap, pontmátrixos rajz és számok (az app rajzolja képpé, így minden indítón betölt).
 */

/** A vízmérték állapota a widgethez. */
object LevelState {
    private const val PREFS = "glyph_eggs_level_w"
    private fun p(c: Context) = c.getSharedPreferences(PREFS, Context.MODE_PRIVATE)

    fun update(c: Context, pose: String, poseTitle: String, a0: Float, a1: Float, level: Boolean) {
        // Statisztika: minden új „pont vízszintes” egyszer számít
        if (level && !(p(c).getBoolean("has", false) && p(c).getBoolean("level", false))) GameStats.count(c, "level_zero")
        p(c).edit().putBoolean("has", true).putString("pose", pose).putString("title", poseTitle)
            .putFloat("a0", a0).putFloat("a1", a1).putBoolean("level", level).apply()
        Widgets.updateLevel(c)
    }

    fun clear(c: Context) {
        p(c).edit().putBoolean("has", false).apply()
        Widgets.updateLevel(c)
    }

    fun has(c: Context) = p(c).getBoolean("has", false)
    fun pose(c: Context) = p(c).getString("pose", null) ?: "FLAT"
    fun title(c: Context) = p(c).getString("title", null) ?: ""
    fun a0(c: Context) = p(c).getFloat("a0", 0f)
    fun a1(c: Context) = p(c).getFloat("a1", 0f)
    fun level(c: Context) = p(c).getBoolean("level", false)
}

/** A pörgetés állapota a widgethez: a palack szöge, pörög-e még, és mikor állt meg. */
object SpinState {
    private const val PREFS = "glyph_eggs_spin_w"
    private fun p(c: Context) = c.getSharedPreferences(PREFS, Context.MODE_PRIVATE)

    fun update(c: Context, angle: Float, done: Boolean) {
        p(c).edit().putFloat("angle", angle).putBoolean("spinning", !done)
            .putLong("stoppedAt", if (done) SystemClock.elapsedRealtime() else 0L).apply()
        Widgets.updateSpin(c)
    }

    fun finish(c: Context) {
        p(c).edit().putBoolean("spinning", false).apply()
        Widgets.updateSpin(c)
    }

    fun angle(c: Context) = p(c).getFloat("angle", 0f)
    fun spinning(c: Context) = p(c).getBoolean("spinning", false)
    fun stoppedAt(c: Context) = p(c).getLong("stoppedAt", 0L)
}

private const val W_WHITE = 0xFFF4F4F4.toInt()
private const val W_GREY = 0xFF8A8A8A.toInt()
private const val W_DIM = 0xFF2E2E2E.toInt()
private const val W_MID = 0xFF5E5E5E.toInt()
private const val W_RED = 0xFFD71921.toInt()

private fun wIds(c: Context, cls: Class<*>): IntArray =
    AppWidgetManager.getInstance(c).getAppWidgetIds(ComponentName(c, cls))

private fun wService(c: Context, action: String, req: Int): PendingIntent =
    PendingIntent.getForegroundService(
        c, req, Intent(c, SimonService::class.java).setAction(action)
            .putExtra(SimonService.EXTRA_SOURCE, SimonService.SOURCE_WIDGET),
        PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT
    )

private fun degText(v: Float): String = "%.1f°".format(abs(v))

// ------------------------------------------------------------------ rajzok

/**
 * Vízmérték-rajz: pontokból álló kör (fekve) vagy pontsor (élére / portra állítva),
 * benne a „buborék”, ami a magasabb oldal felé mozdul. Vízszintesnél középen, pirosan, és a kör kivilágosodik.
 */
fun levelBitmap(pose: String?, a0: Float, a1: Float, level: Boolean, size: Int = 360): Bitmap {
    val bmp = Bitmap.createBitmap(size, size, Bitmap.Config.ARGB_8888)
    val cv = Canvas(bmp)
    val p = Paint(Paint.ANTI_ALIAS_FLAG)
    val c = size / 2f
    val dot = size * 0.018f
    val range = 10f // ennyi fok = a kör széle
    if (pose == null || pose == "FLAT") {
        val r = size * 0.44f
        for (k in 0 until 40) {
            val a = Math.toRadians(k * 9.0)
            p.color = if (pose == null) W_DIM else if (level) W_WHITE else W_MID
            cv.drawCircle(c + r * sin(a).toFloat(), c - r * cos(a).toFloat(), dot, p)
        }
        // Célkereszt
        p.color = if (pose == null) W_DIM else W_MID
        for (i in -3..3) if (i != 0) {
            cv.drawCircle(c + i * size * 0.06f, c, dot * 0.8f, p)
            cv.drawCircle(c, c + i * size * 0.06f, dot * 0.8f, p)
        }
        cv.drawCircle(c, c, size * 0.13f, p.apply { color = if (pose == null) W_DIM else 0xFF3A3A3A.toInt(); style = Paint.Style.STROKE; strokeWidth = size * 0.012f })
        p.style = Paint.Style.FILL
        if (pose != null) {
            val bx = (-a0 / range).coerceIn(-1f, 1f) * size * 0.30f
            val by = (-a1 / range).coerceIn(-1f, 1f) * size * 0.30f
            p.color = if (level) W_RED else W_WHITE
            cv.drawCircle(c + bx, c + by, size * 0.09f, p)
        }
    } else {
        // Élére / portra állítva: vízszintes pontsor, rajta a buborék
        val n = 15
        val step = size * 0.84f / (n - 1)
        val x0 = size * 0.08f
        for (i in 0 until n) {
            p.color = if (level) W_WHITE else if (i == n / 2) W_GREY else W_MID
            cv.drawCircle(x0 + i * step, c, dot * 1.2f, p)
        }
        val bx = (-a0 / range).coerceIn(-1f, 1f) * size * 0.40f
        p.color = if (level) W_RED else W_WHITE
        cv.drawCircle(c + bx, c, size * 0.08f, p)
        p.color = W_MID
        cv.drawCircle(c, c - size * 0.13f, dot, p)
        cv.drawCircle(c, c + size * 0.13f, dot, p)
    }
    return bmp
}

/**
 * Pörgetés-rajz: 36 pontos gyűrű, közepén pontokból rakott palack (vastag test, vékony nyak, piros
 * kupak), ami az [angle] felé mutat (0° = felül, óramutató irányában). A gyűrűn a célpont kivilágosodik.
 */
fun spinBitmap(angle: Float?, highlight: Boolean, size: Int = 360): Bitmap {
    val bmp = Bitmap.createBitmap(size, size, Bitmap.Config.ARGB_8888)
    val cv = Canvas(bmp)
    val p = Paint(Paint.ANTI_ALIAS_FLAG)
    val c = size / 2f
    val r = size * 0.45f
    val a = Math.toRadians((angle ?: 0f).toDouble())
    val ux = sin(a).toFloat()
    val uy = -cos(a).toFloat()
    for (k in 0 until 36) {
        val ka = Math.toRadians(k * 10.0)
        val diff = abs((((k * 10f) - (angle ?: -999f)) + 540f) % 360f - 180f)
        p.color = when {
            angle == null -> W_DIM
            diff <= 6f -> if (highlight) W_RED else W_WHITE
            diff <= 16f -> W_GREY
            else -> 0xFF333333.toInt()
        }
        cv.drawCircle(c + r * sin(ka).toFloat(), c - r * cos(ka).toFloat(), size * (if (diff <= 6f && angle != null) 0.026f else 0.019f), p)
    }
    // A palack pontjai a tengely mentén: hátul vastag test, előre keskenyedő nyak
    val body = if (angle == null) W_MID else W_WHITE
    val px = -uy
    val py = ux
    fun dotAt(t: Float, side: Float, rad: Float, col: Int) {
        p.color = col
        cv.drawCircle(c + ux * t * size + px * side * size, c + uy * t * size + py * side * size, rad * size, p)
    }
    for (t in listOf(-0.24f, -0.18f, -0.12f, -0.06f, 0.0f)) {
        dotAt(t, -0.05f, 0.024f, body); dotAt(t, 0.0f, 0.024f, body); dotAt(t, 0.05f, 0.024f, body)
    }
    dotAt(0.06f, -0.03f, 0.022f, body); dotAt(0.06f, 0.03f, 0.022f, body)
    for (t in listOf(0.12f, 0.17f, 0.22f)) dotAt(t, 0f, 0.02f, body)
    dotAt(0.28f, 0f, 0.03f, if (angle == null) W_MID else W_RED)
    return bmp
}

/**
 * Pontmátrixos homokóra: felül fogy a homok (a nyak felől ürül), alul gyűlik; futás közben egy szem a nyakban.
 * [left] = a szakaszból hátralévő rész (1 → 0).
 */
fun hourglassBitmap(left: Float, running: Boolean, isBreak: Boolean, size: Int = 360): Bitmap {
    val bmp = Bitmap.createBitmap(size, size, Bitmap.Config.ARGB_8888)
    val cv = Canvas(bmp)
    val p = Paint(Paint.ANTI_ALIAS_FLAG)
    val widths = intArrayOf(9, 7, 5, 3, 1) // felső kamra soronként, fentről a nyakig
    val step = size * 0.085f
    val dot = size * 0.03f
    val cx = size / 2f
    val top = size * 0.10f
    val total = widths.sum()
    val sandCol = if (isBreak) 0xFF9AD0FF.toInt() else W_WHITE
    // Felső kamra: a homok a nyak felől ürül → a felső sorok fogynak el először
    val topLeft = Math.round(left.coerceIn(0f, 1f) * total)
    var remaining = topLeft
    val topRowsFill = IntArray(widths.size)
    for (row in widths.indices.reversed()) { // a nyaktól felfelé töltve
        val f = minOf(widths[row], remaining); topRowsFill[row] = f; remaining -= f
    }
    for ((row, w) in widths.withIndex()) {
        val y = top + row * step
        val filled = topRowsFill[row]
        for (i in 0 until w) {
            val x = cx + (i - (w - 1) / 2f) * step
            // A sor közepén lévők tele (a homok középen marad)
            val fromCenter = abs(i - (w - 1) / 2f)
            val isSand = fromCenter * 2f < filled
            p.color = if (isSand) sandCol else W_DIM
            cv.drawCircle(x, y, dot, p)
        }
    }
    // Nyak és lehulló szem
    val neckY = top + widths.size * step
    p.color = if (running && left > 0f) W_RED else W_DIM
    cv.drawCircle(cx, neckY, dot * 0.9f, p)
    // Alsó kamra: alulról felfelé gyűlik
    val bottomFill = total - topLeft
    var acc = bottomFill
    val bw = widths.reversedArray() // 1,3,5,7,9 a nyaktól lefelé
    val bottomRowsFill = IntArray(bw.size)
    for (row in bw.indices.reversed()) { // alulról
        val f = minOf(bw[row], acc); bottomRowsFill[row] = f; acc -= f
    }
    for ((row, w) in bw.withIndex()) {
        val y = neckY + (row + 1) * step
        val filled = bottomRowsFill[row]
        for (i in 0 until w) {
            val x = cx + (i - (w - 1) / 2f) * step
            val fromCenter = abs(i - (w - 1) / 2f)
            p.color = if (fromCenter * 2f < filled) sandCol else W_DIM
            cv.drawCircle(x, y, dot, p)
        }
    }
    return bmp
}

// ------------------------------------------------------------------ frissítés és nézetek

fun Widgets.updateLevel(c: Context, ids: IntArray = wIds(c, LevelWidget::class.java)) {
    if (ids.isEmpty()) return
    val m = AppWidgetManager.getInstance(c)
    val v = levelViews(c)
    for (id in ids) m.updateAppWidget(id, v)
}

fun Widgets.updateSpin(c: Context, ids: IntArray = wIds(c, SpinWidget::class.java)) {
    if (ids.isEmpty()) return
    val m = AppWidgetManager.getInstance(c)
    val v = spinViews(c)
    for (id in ids) m.updateAppWidget(id, v)
}

fun Widgets.updateHourglass(c: Context, ids: IntArray = wIds(c, HourglassWidget::class.java)) {
    if (ids.isEmpty()) return
    val m = AppWidgetManager.getInstance(c)
    val v = hourglassViews(c)
    for (id in ids) m.updateAppWidget(id, v)
}

private fun levelViews(c: Context): RemoteViews {
    val v = RemoteViews(c.packageName, R.layout.widget_level)
    val running = GlyphMirror.mode.value == Feature.LEVEL
    if (running && LevelState.has(c)) {
        val pose = LevelState.pose(c)
        val a0 = LevelState.a0(c)
        val a1 = LevelState.a1(c)
        val level = LevelState.level(c)
        v.setImageViewBitmap(R.id.lv_img, levelBitmap(pose, a0, a1, level))
        val dev = if (pose == "FLAT") maxOf(abs(a0), abs(a1)) else abs(a0)
        v.setImageViewBitmap(R.id.lv_deg, Widgets.dotText(c, if (level) "0,0°" else degText(dev), 24f, if (level) W_RED else W_WHITE))
        v.setImageViewBitmap(R.id.lv_label, Widgets.dotText(c,
            if (level) "VÍZSZINTES" else LevelState.title(c).uppercase(), 9f, W_GREY))
    } else {
        v.setImageViewBitmap(R.id.lv_img, levelBitmap(if (running) "FLAT" else null, 0f, 0f, false))
        v.setImageViewBitmap(R.id.lv_deg, Widgets.dotText(c, if (running) "…" else "—°", 24f, if (running) W_WHITE else W_MID))
        v.setImageViewBitmap(R.id.lv_label, Widgets.dotText(c, if (running) "MÉR" else "VÍZMÉRTÉK", 9f, W_GREY))
    }
    v.setOnClickPendingIntent(R.id.lv_root, wService(c, SimonService.ACTION_LEVEL, 1001))
    return v
}

private fun spinViews(c: Context): RemoteViews {
    val v = RemoteViews(c.packageName, R.layout.widget_spin)
    val running = GlyphMirror.mode.value == Feature.SPIN
    val spinning = running && SpinState.spinning(c)
    val stopped = SpinState.stoppedAt(c)
    val recent = stopped > 0 && SystemClock.elapsedRealtime() - stopped < 60_000L
    when {
        spinning -> {
            v.setImageViewBitmap(R.id.sp_img, spinBitmap(SpinState.angle(c), false))
            v.setImageViewBitmap(R.id.sp_label, Widgets.dotText(c, "PÖRÖG…", 10f, W_GREY))
        }
        recent -> {
            v.setImageViewBitmap(R.id.sp_img, spinBitmap(SpinState.angle(c), true))
            v.setImageViewBitmap(R.id.sp_label, Widgets.dotText(c, "ITT ÁLLT MEG", 10f, W_RED))
        }
        running -> {
            v.setImageViewBitmap(R.id.sp_img, spinBitmap(0f, false))
            v.setImageViewBitmap(R.id.sp_label, Widgets.dotText(c, "INDUL", 10f, W_GREY))
        }
        else -> {
            v.setImageViewBitmap(R.id.sp_img, spinBitmap(null, false))
            v.setImageViewBitmap(R.id.sp_label, Widgets.dotText(c, "KOPPINTS · PÖRGESS", 10f, W_GREY))
        }
    }
    v.setOnClickPendingIntent(R.id.sp_root, wService(c, SimonService.ACTION_SPIN, 1002))
    return v
}

private fun hourglassViews(c: Context): RemoteViews {
    val v = RemoteViews(c.packageName, R.layout.widget_hourglass)
    val running = TimerState.active(c) && GlyphMirror.mode.value == Feature.TIMER
    if (running) {
        val phase = TimerState.phaseMs(c).coerceAtLeast(1L)
        val left = TimerState.left(c)
        val frac = left.toFloat() / phase
        val paused = TimerState.paused(c)
        v.setImageViewBitmap(R.id.hg_img, hourglassBitmap(frac, !paused, TimerState.isBreak(c)))
        val min = (left + 59_999) / 60_000
        v.setImageViewBitmap(R.id.hg_time, Widgets.dotNumber(c, if (left in 1..59_999) "<1" else "$min", "PERC", 22f, 10f))
        val label = (TimerState.title(c) + if (paused) " · SZÜNETEL" else " · ${TimerState.index(c) + 1}/${TimerState.count(c)}").uppercase()
        v.setImageViewBitmap(R.id.hg_label, Widgets.dotText(c, label, 9f, if (paused) W_RED else W_GREY))
    } else {
        val mode = Settings.timerMode(c)
        val minutes = if (mode.custom) Settings.timerMinutes(c) else mode.workMin
        v.setImageViewBitmap(R.id.hg_img, hourglassBitmap(1f, false, false))
        v.setImageViewBitmap(R.id.hg_time, Widgets.dotNumber(c, "$minutes", "PERC", 22f, 10f, W_MID))
        v.setImageViewBitmap(R.id.hg_label, Widgets.dotText(c, mode.title.uppercase(), 9f, W_GREY))
    }
    v.setOnClickPendingIntent(R.id.hg_root, wService(c, SimonService.ACTION_TIMER, 1003))
    return v
}

/** Vízmérték widget: koppintásra indul (és leáll); a fokot és a buborékot mutatja. */
class LevelWidget : AppWidgetProvider() {
    override fun onUpdate(context: Context, manager: AppWidgetManager, ids: IntArray) = Widgets.updateLevel(context, ids)
}

/** Pörgetés widget: koppintásra pörög a pontokból rakott palack, és közben a LED-ek is. */
class SpinWidget : AppWidgetProvider() {
    override fun onUpdate(context: Context, manager: AppWidgetManager, ids: IntArray) = Widgets.updateSpin(context, ids)
}

/** Homokóra widget az Időzítőhöz: koppintásra indul / leáll; a homok mutatja a szakaszból hátralévő időt. */
class HourglassWidget : AppWidgetProvider() {
    override fun onUpdate(context: Context, manager: AppWidgetManager, ids: IntArray) = Widgets.updateHourglass(context, ids)
}

// ------------------------------------------------------------------ Asszisztens

/** Mikrofon pontokból egy pontgyűrűben; hallgatás közben piros. */
fun assistantBitmap(state: TalkState, size: Int = 300): Bitmap {
    val bmp = Bitmap.createBitmap(size, size, Bitmap.Config.ARGB_8888)
    val cv = Canvas(bmp)
    val p = Paint(Paint.ANTI_ALIAS_FLAG)
    val c = size / 2f
    val r = size * 0.45f
    val active = state != TalkState.IDLE
    for (k in 0 until 28) {
        val a = Math.toRadians(k * 360.0 / 28)
        p.color = when (state) {
            TalkState.LISTENING -> if (k % 2 == 0) W_RED else W_MID
            TalkState.SPEAKING -> if (k % 3 == 0) W_WHITE else W_MID
            TalkState.THINKING -> if (k < 6) W_WHITE else W_DIM
            TalkState.IDLE -> W_MID
        }
        cv.drawCircle(c + r * sin(a).toFloat(), c - r * cos(a).toFloat(), size * 0.02f, p)
    }
    val step = size * 0.065f
    val dot = size * 0.024f
    val col = if (state == TalkState.LISTENING) W_RED else W_WHITE
    p.color = col
    // Kapszula (3 oszlop × 5 sor, a sarkok nélkül)
    for (row in 0 until 5) for (colI in -1..1) {
        if ((row == 0 || row == 4) && colI != 0) continue
        cv.drawCircle(c + colI * step, c - size * 0.20f + row * step, dot, p)
    }
    // Tartó-ív és láb
    p.color = if (active) col else W_GREY
    for (i in -2..2) cv.drawCircle(c + i * step, c + size * 0.17f - (if (abs(i) == 2) step else 0f), dot * 0.9f, p)
    cv.drawCircle(c, c + size * 0.17f + step, dot * 0.9f, p)
    cv.drawCircle(c - step, c + size * 0.17f + 2 * step, dot * 0.9f, p)
    cv.drawCircle(c, c + size * 0.17f + 2 * step, dot * 0.9f, p)
    cv.drawCircle(c + step, c + size * 0.17f + 2 * step, dot * 0.9f, p)
    return bmp
}

fun Widgets.updateAssistant(c: Context, ids: IntArray = wIds(c, AssistantWidget::class.java)) {
    if (ids.isEmpty()) return
    val m = AppWidgetManager.getInstance(c)
    val v = RemoteViews(c.packageName, R.layout.widget_assistant)
    val st = TalkBus.state.value
    v.setImageViewBitmap(R.id.as_img, assistantBitmap(st))
    val claude = SimonService.claudeVoiceOn.value
    val label = when {
        claude && st == TalkState.SPEAKING -> "BESZÉL"
        claude -> "AI MÓD"
        st == TalkState.IDLE -> "KÉRDEZZ"
        else -> st.label
    }
    v.setImageViewBitmap(R.id.as_label, Widgets.dotText(c, label, 10f,
        if (st == TalkState.LISTENING || (claude && st == TalkState.SPEAKING)) W_RED else W_GREY))
    val last = AssistantState.lastA(c)
    v.setTextViewText(R.id.as_text, when {
        claude -> "A LED-ek a(z) ${Settings.aiName(c)} hangját követik"
        Settings.assistantUseApi(c) && last.isNotEmpty() -> last
        Settings.assistantUseApi(c) -> "Koppints, és kérdezz bármit"
        else -> "Koppints: ${Settings.aiName(c)} + LED-ek"
    })
    // Alapból a Claude appot nyitja (a saját fiókoddal), API-kulcsos módban az app saját asszisztensét
    val target = if (Settings.assistantUseApi(c))
        Intent(c, AssistantActivity::class.java).putExtra(AssistantActivity.EXTRA_LISTEN, true)
    else Intent(c, ClaudeLaunchActivity::class.java)
    val pi = PendingIntent.getActivity(c, 1004,
        target.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_CLEAR_TOP),
        PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT)
    v.setOnClickPendingIntent(R.id.as_root, pi)
    for (id in ids) m.updateAppWidget(id, v)
}

/** Asszisztens widget: koppintásra hallgatni kezd; az utolsó választ mutatja. */
class AssistantWidget : AppWidgetProvider() {
    override fun onUpdate(context: Context, manager: AppWidgetManager, ids: IntArray) = Widgets.updateAssistant(context, ids)
}

/** A Főoldal asszisztens-kártyája. */
fun android.app.Activity.assistantHero(): android.widget.LinearLayout {
    val card = android.widget.LinearLayout(this).apply {
        orientation = android.widget.LinearLayout.HORIZONTAL
        gravity = android.view.Gravity.CENTER_VERTICAL
        background = rounded(Ui.CARD, dp(24).toFloat())
        setPadding(dp(16), dp(14), dp(14), dp(14))
        setOnClickListener { startActivity(Intent(this@assistantHero, AssistantActivity::class.java)) }
    }
    card.addView(android.widget.ImageView(this).apply { setImageBitmap(assistantBitmap(TalkState.IDLE, 200)) },
        android.widget.LinearLayout.LayoutParams(dp(56), dp(56)).apply { marginEnd = dp(14) })
    val t = android.widget.LinearLayout(this).apply { orientation = android.widget.LinearLayout.VERTICAL }
    t.addView(text("ASSZISZTENS", 18f).apply { typeface = Widgets.dotoFace(this@assistantHero) })
    t.addView(text(if (Settings.assistantUseApi(this)) "Kérdezz hangosan – Claude válaszol, a LED-ek beszélnek"
        else "Beszélgess a(z) ${Settings.aiName(this)} appal – a LED-ek a hangjára villognak", 12.5f, Ui.SUB).apply { setPadding(0, dp(2), 0, 0) })
    card.addView(t, android.widget.LinearLayout.LayoutParams(0, android.view.ViewGroup.LayoutParams.WRAP_CONTENT, 1f))
    card.addView(text("●", 20f, Ui.DARK_TEXT).apply {
        gravity = android.view.Gravity.CENTER
        background = rounded(Ui.LIGHT, dp(22).toFloat())
        setOnClickListener {
            if (Settings.assistantUseApi(this@assistantHero))
                startActivity(Intent(this@assistantHero, AssistantActivity::class.java).putExtra(AssistantActivity.EXTRA_LISTEN, true))
            else ClaudeLink.start(this@assistantHero)
        }
    }, android.widget.LinearLayout.LayoutParams(dp(44), dp(44)))
    return card
}

// ------------------------------------------------------------------ Kitűzők

/**
 * Kitűzők widget: balra a kiemelt kitűző MOZOG (6 képkocka egy ViewFlipperben – a kezdőképernyő
 * pörgeti, nem az app), koppintásra a következőre vált; jobbra a szint, a darabszám és a legutóbbiak.
 */
fun Widgets.updateBadges(c: Context, ids: IntArray = wIds(c, BadgeWidget::class.java)) {
    if (ids.isEmpty()) return
    val m = AppWidgetManager.getInstance(c)
    val got = Achievements.recent(c)
    val prefs = c.getSharedPreferences("glyph_eggs_widgets", Context.MODE_PRIVATE)
    val idx = prefs.getInt("badge_idx", 0)
    // Kiemelt: a kiválasztott megszerzett, vagy ha még nincs, a legközelebbi cél (szürkén, haladással)
    val featured = if (got.isNotEmpty()) got[Math.floorMod(idx, got.size)]
    else Badge.entries.maxByOrNull { it.progress(c).toFloat() / it.goal() } ?: Badge.FIRST_LIGHT
    val unlocked = Achievements.isUnlocked(c, featured)
    val prog = featured.progress(c).toFloat() / featured.goal()
    val v = RemoteViews(c.packageName, R.layout.widget_badges)
    val frames = intArrayOf(R.id.bw_f0, R.id.bw_f1, R.id.bw_f2, R.id.bw_f3, R.id.bw_f4, R.id.bw_f5)
    for ((i, id) in frames.withIndex()) {
        v.setImageViewBitmap(id, BadgeArt.bitmap(featured, i / frames.size.toFloat(), unlocked, 140, prog, opaque = true))
    }
    v.setImageViewBitmap(R.id.bw_title, Widgets.dotText(c, featured.title.uppercase(), 13f, if (unlocked) featured.tier.color else W_WHITE))
    val xp = GameStats.xp(c)
    v.setImageViewBitmap(R.id.bw_sub, Widgets.dotText(c,
        if (unlocked) "${featured.tier.title.uppercase()} · SZINT ${GameStats.level(xp)}"
        else "KÖVETKEZŐ · ${featured.progress(c)}/${featured.goal()}", 9f, W_GREY))
    v.setImageViewBitmap(R.id.bw_count, Widgets.dotNumber(c, "${got.size}", "/${Badge.entries.size} KITŰZŐ", 20f, 9f))
    val small = intArrayOf(R.id.bw_s0, R.id.bw_s1, R.id.bw_s2, R.id.bw_s3, R.id.bw_s4)
    for ((i, id) in small.withIndex()) {
        val b = got.getOrNull(i)
        if (b != null) v.setImageViewBitmap(id, BadgeArt.bitmap(b, 0.12f, true, 64))
        else v.setImageViewBitmap(id, BadgeArt.bitmap(Badge.entries[i], 0f, false, 64))
    }
    val next = PendingIntent.getBroadcast(c, 1005,
        Intent(c, BadgeWidget::class.java).setAction(BadgeWidget.ACTION_NEXT),
        PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT)
    v.setOnClickPendingIntent(R.id.bw_flip, next)
    val open = PendingIntent.getActivity(c, 1006,
        Intent(c, MainActivity::class.java).putExtra(MainActivity.EXTRA_TAB, MainActivity.TAB_STATS)
            .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_CLEAR_TOP),
        PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT)
    v.setOnClickPendingIntent(R.id.bw_info, open)
    for (id in ids) m.updateAppWidget(id, v)
}

/** Kitűzők widget: mozgó kiemelt kitűző (koppintás = következő), szint és a legutóbbiak (koppintás = Stat fül). */
class BadgeWidget : AppWidgetProvider() {
    companion object {
        const val ACTION_NEXT = "com.akos.glypheggs.BADGE_NEXT"
    }

    override fun onUpdate(context: Context, manager: AppWidgetManager, ids: IntArray) = Widgets.updateBadges(context, ids)

    override fun onReceive(context: Context, intent: Intent) {
        if (intent.action == ACTION_NEXT) {
            val p = context.getSharedPreferences("glyph_eggs_widgets", Context.MODE_PRIVATE)
            p.edit().putInt("badge_idx", p.getInt("badge_idx", 0) + 1).apply()
            Widgets.updateBadges(context)
            return
        }
        super.onReceive(context, intent)
    }
}

// ------------------------------------------------------------------ Morze

/** Morzekód-kép: pontok és vonások a téma borostyán színében; futás közben a mostani szó kódja. */
fun morseBitmap(c: Context, word: String, active: Boolean): Bitmap {
    val d = c.resources.displayMetrics.density
    val strip = MorseCode.strip(if (word.isEmpty()) "SOS" else word)
    val cell = 5.5f * d
    val w = (strip.size * cell + 4 * d).toInt().coerceAtLeast(1)
    val h = (cell * 2).toInt()
    val bmp = Bitmap.createBitmap(w, h, Bitmap.Config.ARGB_8888)
    val cv = Canvas(bmp)
    val p = Paint(Paint.ANTI_ALIAS_FLAG)
    p.color = if (active) 0xFFFFB000.toInt() else W_MID
    var i = 0
    while (i < strip.size) {
        if (!strip[i]) { i++; continue }
        var j = i
        while (j < strip.size && strip[j]) j++
        val x0 = 2 * d + i * cell
        if (j - i == 1) cv.drawCircle(x0 + cell / 2, h / 2f, cell * 0.36f, p)
        else cv.drawRoundRect(android.graphics.RectF(x0 + cell * 0.12f, h / 2f - cell * 0.34f, x0 + (j - i) * cell - cell * 0.12f, h / 2f + cell * 0.34f), cell * 0.34f, cell * 0.34f, p)
        i = j
    }
    return bmp
}

fun Widgets.updateMorse(c: Context, ids: IntArray = wIds(c, MorseWidget::class.java)) {
    if (ids.isEmpty()) return
    val m = AppWidgetManager.getInstance(c)
    val v = RemoteViews(c.packageName, R.layout.widget_morse)
    val running = GlyphMirror.mode.value == Feature.MORSE
    val ph = MorseBus.phase.value
    val word = MorseBus.word.value
    // Futás közben a mostani szó KÓDJA látszik (a szó nem) – a widgetről is megfejthető
    v.setImageViewBitmap(R.id.mw_code, morseBitmap(c, if (running) word else "", running))
    val state = when {
        !running -> "MORZE"
        ph == MorsePhase.FIRST -> "FIGYELD…"
        ph == MorsePhase.WAITING || ph == MorsePhase.LOOPING -> "MI A SZÓ? (${word.length} BETŰ)"
        ph == MorsePhase.SOLVED -> "✓ $word"
        ph == MorsePhase.REVEAL -> "A SZÓ: $word"
        else -> "MORZE"
    }
    v.setImageViewBitmap(R.id.mw_title, Widgets.dotText(c, state, 12f, if (running) 0xFFFFB000.toInt() else W_WHITE))
    v.setImageViewBitmap(R.id.mw_stats, Widgets.dotText(c,
        "${MorseStats.solved(c)} MEGFEJTVE · SOROZAT ${MorseStats.bestStreak(c)} · ${MorseStats.accuracy(c)}%", 8.5f, W_GREY))
    v.setImageViewResource(R.id.mw_btn, if (running) R.drawable.widget_btn_on else R.drawable.widget_btn)
    val pi = PendingIntent.getActivity(c, 1007,
        Intent(c, MorseActivity::class.java).putExtra(MorseActivity.EXTRA_START, true)
            .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_SINGLE_TOP),
        PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT)
    v.setOnClickPendingIntent(R.id.mw_root, pi)
    for (id in ids) m.updateAppWidget(id, v)
}

/** Morze widget: koppintásra indul a gyakorlás, és megnyílik a megfejtő oldal; futás közben a kódot mutatja. */
class MorseWidget : AppWidgetProvider() {
    override fun onUpdate(context: Context, manager: AppWidgetManager, ids: IntArray) = Widgets.updateMorse(context, ids)
}
