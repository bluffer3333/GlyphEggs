package com.akos.glypheggs

import android.content.Context
import android.os.SystemClock
import com.nothing.ketchum.Glyph
import kotlinx.coroutines.delay

/*
 * CSENDZÓNA – telefon-böjt a Glyph LED-ekkel. Tedd le kijelzővel lefelé, és amíg hozzá sem érsz,
 * a fény alulról felfelé nő: a cél idejére (alapból 60 perc) mind a 33 LED ég. Ha felveszed vagy
 * megfordítod, a sorozat megszakad – az eredmény a statisztikába kerül.
 */

/** Hogyan mutassa a haladást. */
enum class DetoxShow(val title: String, val desc: String) {
    PULSE("Percenként felvillan", "Sötét marad, és csak percenként egy pillanatra mutatja a haladást – akkubarát"),
    ALWAYS("Mindig látszik", "A megszerzett LED-ek folyamatosan égnek – látványos, de többet fogyaszt"),
    HIDDEN("Teljes sötét", "Semmi nem világít, csak a végén derül ki, meddig bírtad")
}

class DetoxSession(
    private val context: Context,
    private val glyph: GlyphController,
    private val motion: MotionDetector,
    private val haptics: Haptics,
    private val onStatus: (String) -> Unit
) {
    private val order = LectureTimer.FILL_ORDER

    /** A végén: hány percig bírta (a hívó menti a statisztikába). */
    var minutes = 0
        private set
    var reachedGoal = false
        private set

    suspend fun run() {
        val goalMin = Settings.detoxGoal(context)
        val show = Settings.detoxShow(context)
        val goalMs = goalMin * 60_000L
        // Indító animáció: a fény lefut a vonalon, majd kialszik („lekapcsolódás”)
        for (i in order.indices.reversed()) {
            glyph.show(order.take(i + 1).toIntArray())
            delay(18)
        }
        glyph.off()
        haptics.tick()

        val start = SystemClock.elapsedRealtime()
        var awaySince = 0L
        var lastLit = -1
        var lastPulse = 0L
        while (true) {
            val now = SystemClock.elapsedRealtime()
            val elapsed = now - start
            minutes = (elapsed / 60_000L).toInt()
            val lit = (elapsed * order.size / goalMs).toInt().coerceIn(0, order.size)

            // Megszakad, ha 4 mp-nél tovább nincs kijelzővel lefelé (felvették / megfordították)
            if (!motion.faceDown.value) {
                if (awaySince == 0L) awaySince = now
                if (now - awaySince > 4_000) break
            } else awaySince = 0L

            if (!reachedGoal && elapsed >= goalMs) {
                reachedGoal = true
                celebrate()
                lastPulse = now
            }

            val status = if (reachedGoal) "Csendzóna · cél teljesítve! $minutes perc – túlórában"
            else "Csendzóna · $minutes / $goalMin perc · ne nyúlj hozzá"
            onStatus(status)

            when (show) {
                DetoxShow.ALWAYS -> if (lit != lastLit) {
                    glyph.show(if (reachedGoal) order else order.take(lit).toIntArray())
                    lastLit = lit
                }
                DetoxShow.PULSE -> if (now - lastPulse >= 60_000L) {
                    lastPulse = now
                    // Egy pillanatra: a megszerzett LED-ek, a következő halványan pislan
                    glyph.show(order.take(maxOf(1, lit)).toIntArray())
                    delay(1_200)
                    glyph.off()
                }
                DetoxShow.HIDDEN -> {}
            }
            // Ha a túlórában van: percenként egy szikra a kamerán
            if (reachedGoal && show != DetoxShow.ALWAYS && (now - start) % 60_000L < 1_000L) {
                glyph.show(intArrayOf(Glyph.Code_22111.A1, Glyph.Code_22111.A2))
                delay(300)
                glyph.off()
            }
            delay(1_000)
        }
        finish()
    }

    private suspend fun celebrate() {
        haptics.win()
        repeat(3) {
            for (i in order.indices) { glyph.show(order.take(i + 1).toIntArray()); delay(12) }
            delay(250)
            glyph.off(); delay(150)
        }
        glyph.show(Zones.ALL); delay(900); glyph.off()
    }

    /** Vége: siker esetén a fény felfelé repül, megszakadáskor összeomlik. */
    private suspend fun finish() {
        val goalMin = Settings.detoxGoal(context)
        val lit = (minutes * order.size / goalMin.coerceAtLeast(1)).coerceIn(1, order.size)
        if (reachedGoal) {
            onStatus("Csendzóna vége · $minutes perc, a cél megvolt! 🌙")
            haptics.result()
            for (i in order.indices) { glyph.show(intArrayOf(order[i])); delay(25) }
        } else {
            onStatus("Csendzóna megszakadt · $minutes / $goalMin perc")
            haptics.denied()
            // Összeomlás: a megszerzett fény lehull
            for (k in lit downTo 0) { glyph.show(order.take(k).toIntArray()); delay(35) }
        }
        glyph.off()
        delay(500)
    }
}
