package com.akos.glypheggs

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.content.Context
import android.content.Intent
import android.graphics.Bitmap
import android.graphics.Canvas
import android.graphics.Paint
import java.time.LocalDate
import java.time.LocalDateTime
import java.time.ZoneId
import kotlin.math.abs
import kotlin.math.cos
import kotlin.math.floor
import kotlin.math.sin
import kotlin.math.sqrt

/*
 * Statisztika és kitűzők. Minden funkció-futás (indítás, hossz, napszak) és a játékok eredményei
 * (szint, pontszám, kinyitott zár…) ide kerülnek; ebből számol a Stat fül, a kiértékelés, a szint (XP)
 * és a kitűzők. Minden a telefonon marad.
 */
object GameStats {
    private const val PREFS = "glyph_eggs_stats"
    private fun p(c: Context) = c.getSharedPreferences(PREFS, Context.MODE_PRIVATE)
    private fun today() = LocalDate.now().toEpochDay()

    /** Egy funkció-futás vége ([ms] hosszú). A 3 mp-nél rövidebbeket nem számolja. */
    fun session(c: Context, f: Feature, ms: Long) {
        if (ms < 3_000) return
        val pr = p(c)
        val day = today()
        val hour = LocalDateTime.now().minusNanos(ms * 1_000_000).hour
        val e = pr.edit()
        e.putInt("plays_${f.name}", pr.getInt("plays_${f.name}", 0) + 1)
        e.putLong("ms_${f.name}", pr.getLong("ms_${f.name}", 0L) + ms)
        e.putLong("last_${f.name}", System.currentTimeMillis())
        e.putInt("h_$hour", pr.getInt("h_$hour", 0) + 1)
        e.putInt("d_$day", pr.getInt("d_$day", 0) + 1)
        e.putLong("dms_$day", pr.getLong("dms_$day", 0L) + ms)
        e.putInt("fd_${f.name}_$day", pr.getInt("fd_${f.name}_$day", 0) + 1)
        if (hour in 0..3) e.putInt("night", pr.getInt("night", 0) + 1)
        if (hour in 5..6) e.putInt("early", pr.getInt("early", 0) + 1)
        // Napsorozat
        val lastDay = pr.getLong("streak_last", Long.MIN_VALUE)
        if (lastDay != day) {
            val streak = if (lastDay == day - 1) pr.getInt("streak", 0) + 1 else 1
            e.putInt("streak", streak).putLong("streak_last", day)
            e.putInt("streak_best", maxOf(streak, pr.getInt("streak_best", 0)))
        }
        e.apply()
        // 60 napnál régebbi napi adatok törlése
        if (day % 7 == 0L) cleanup(c, day)
    }

    private fun cleanup(c: Context, day: Long) {
        val e = p(c).edit()
        for (k in p(c).all.keys) {
            val d = k.substringAfterLast('_').toLongOrNull() ?: continue
            if ((k.startsWith("d_") || k.startsWith("dms_") || k.startsWith("fd_")) && d < day - 60) e.remove(k)
        }
        e.apply()
    }

    /** Legjobb eredmény (szint, pontszám) – csak ha jobb az eddiginél. */
    fun best(c: Context, key: String, v: Int) {
        if (v > p(c).getInt("best_$key", 0)) p(c).edit().putInt("best_$key", v).apply()
        p(c).edit().putInt("sum_$key", p(c).getInt("sum_$key", 0) + v).apply()
    }

    fun count(c: Context, key: String, add: Int = 1) = p(c).edit().putInt("cnt_$key", p(c).getInt("cnt_$key", 0) + add).apply()

    fun plays(c: Context, f: Feature) = p(c).getInt("plays_${f.name}", 0)
    fun ms(c: Context, f: Feature) = p(c).getLong("ms_${f.name}", 0L)
    fun last(c: Context, f: Feature) = p(c).getLong("last_${f.name}", 0L)
    fun bestOf(c: Context, key: String) = p(c).getInt("best_$key", 0)
    fun sumOf(c: Context, key: String) = p(c).getInt("sum_$key", 0)
    fun cnt(c: Context, key: String) = p(c).getInt("cnt_$key", 0)
    fun totalPlays(c: Context) = Feature.entries.sumOf { plays(c, it) }
    fun totalMs(c: Context) = Feature.entries.sumOf { ms(c, it) }
    fun hour(c: Context, h: Int) = p(c).getInt("h_$h", 0)
    fun dayPlays(c: Context, day: Long) = p(c).getInt("d_$day", 0)
    fun dayMs(c: Context, day: Long) = p(c).getLong("dms_$day", 0L)
    fun featureDay(c: Context, f: Feature, day: Long) = p(c).getInt("fd_${f.name}_$day", 0)
    fun streak(c: Context): Int {
        val last = p(c).getLong("streak_last", Long.MIN_VALUE)
        return if (last >= today() - 1) p(c).getInt("streak", 0) else 0
    }
    fun bestStreak(c: Context) = p(c).getInt("streak_best", 0)
    fun night(c: Context) = p(c).getInt("night", 0)
    fun early(c: Context) = p(c).getInt("early", 0)
    fun today(c: Context) = today()

    /** Tapasztalat: indításonként 10, percenként 1, kitűzőnként a fokozata szerint. */
    fun xp(c: Context): Int =
        totalPlays(c) * 10 + (totalMs(c) / 60_000L).toInt() + Achievements.unlocked(c).sumOf { it.tier.xp }

    /** Játékos-szint az XP-ből (négyzetgyökös: eleinte gyors, később lassul). */
    fun level(xp: Int): Int = floor(sqrt(xp / 60.0)).toInt() + 1
    fun xpFor(level: Int): Int = (level - 1) * (level - 1) * 60

    fun rank(level: Int): String = when {
        level >= 30 -> "GLYPH-LEGENDA"
        level >= 20 -> "FÉNYMESTER"
        level >= 12 -> "VETERÁN"
        level >= 7 -> "HALADÓ"
        level >= 3 -> "FELFEDEZŐ"
        else -> "ÚJONC"
    }
}

/** A kitűzők fokozata: szín és tapasztalat. */
enum class Tier(val title: String, val color: Int, val glow: Int, val xp: Int) {
    BRONZE("Bronz", 0xFFC98B5A.toInt(), 0xFFFFC79A.toInt(), 50),
    SILVER("Ezüst", 0xFFC9CCD3.toInt(), 0xFFFFFFFF.toInt(), 100),
    GOLD("Arany", 0xFFF2C14E.toInt(), 0xFFFFF0B8.toInt(), 200),
    LEGEND("Legendás", 0xFFD71921.toInt(), 0xFFFF8A8F.toInt(), 500)
}

/** A kitűzők: cél, fokozat, ikon (9×9 pontminta) és hogy hol tart a haladás. */
enum class Badge(val title: String, val desc: String, val tier: Tier, val icon: String, val target: Int) {
    FIRST_LIGHT("Első fény", "Indíts el bármit először", Tier.BRONZE, "STAR", 1),
    PLAYS_25("Rendszeres", "25 indítás összesen", Tier.SILVER, "BOLT", 25),
    PLAYS_100("Glyph-függő", "100 indítás összesen", Tier.GOLD, "FLAME", 100),
    PLAYS_500("Fénylegenda", "500 indítás összesen", Tier.LEGEND, "CROWN", 500),
    TIME_1H("Egy óra fényben", "1 óra összesen a LED-ekkel", Tier.BRONZE, "CLOCK", 60),
    TIME_10H("Tíz óra ragyogás", "10 óra összesen a LED-ekkel", Tier.GOLD, "SUN", 600),
    STREAK_3("Visszatérő", "3 egymást követő napon játszottál", Tier.SILVER, "STREAK", 3),
    STREAK_7("Heti rituálé", "7 egymást követő napon játszottál", Tier.GOLD, "STREAK", 7),
    NIGHT_OWL("Éjjeli bagoly", "Játék éjfél és hajnali 4 között", Tier.SILVER, "MOON", 1),
    EARLY_BIRD("Korán kelő", "Játék reggel 5 és 7 között", Tier.SILVER, "SUNRISE", 1),
    SIMON_5("Emlékező", "Simonban az 5. szint", Tier.BRONZE, "GRID", 5),
    SIMON_WIN("Simon mester", "Simonban mind a 8 kör", Tier.GOLD, "TROPHY", 8),
    LOCK_OPEN("Betörő", "Zárfeltörőben mind a 4 tüske", Tier.SILVER, "LOCK", 4),
    DINO_50("Futó", "Dínófutásban 50 pont", Tier.BRONZE, "DINO", 50),
    DINO_150("Meteor elől", "Dínófutásban 150 pont", Tier.GOLD, "DINO", 150),
    BLOW_POP("Durr!", "Kidurrantott lufi a Fújósban", Tier.BRONZE, "BALLOON", 1),
    BLOW_20("Szélgép", "20 Fújós játék", Tier.SILVER, "WIND", 20),
    PET_HATCH("Kikelt!", "A Glyph Tojás kikelt", Tier.BRONZE, "EGG", 1),
    PET_ADULT("Felnevelő", "A Tojás felnőtt lett", Tier.GOLD, "HEART", 3),
    SPIN_25("Szerencsekerék", "25 pörgetés", Tier.SILVER, "SPIRAL", 25),
    SAFE_OPEN("Kódtörő", "Kinyitottad a Széfet", Tier.SILVER, "KEY", 1),
    LEVEL_ZERO("Tökéletes vízszint", "10-szer pont vízszintes", Tier.BRONZE, "LEVEL", 10),
    BREATH_60("Zen", "60 perc vezetett légzés", Tier.GOLD, "WAVE", 60),
    FOCUS_5H("Fókuszgép", "5 óra az Időzítővel", Tier.GOLD, "HOURGLASS", 300),
    LECTURE_10("Szorgalmas hallgató", "10 előadás", Tier.SILVER, "CAP", 10),
    BEACON("Megvagy!", "Füttyel megtaláltad a telefont", Tier.SILVER, "RADAR", 1),
    AI_TALK("Beszélgető", "10 beszélgetés az AI-val", Tier.BRONZE, "MIC", 10),
    ALL_GAMES("Mindenevő", "Minden játékot kipróbáltál", Tier.SILVER, "TARGET", 5),
    EXPLORER("Felfedező", "Minden funkciót kipróbáltál", Tier.GOLD, "ROSE", Feature.entries.size),
    DETOX_FIRST("Első csend", "10 perc egyhuzamban a Csendzónában", Tier.BRONZE, "LEAF", 10),
    DETOX_60("Lekapcsolva", "60 perc egyhuzamban a Csendzónában", Tier.SILVER, "ZZZ", 60),
    DETOX_GOALS("Fegyelem", "10-szer teljesített Csendzóna-cél", Tier.SILVER, "STONES", 10),
    DETOX_3H("Remete", "3 óra egyhuzamban a Csendzónában", Tier.GOLD, "ENSO", 180),
    DETOX_10H("Csendmester", "10 óra összesen a Csendzónában", Tier.GOLD, "LOTUS", 600),
    STUDIO("Fényrendező", "Saját animáció a Glyph Stúdióban", Tier.BRONZE, "FILM", 1),
    MORSE_FIRST("Első jel", "Az első megfejtett morzeszó", Tier.BRONZE, "KEYER", 1),
    MORSE_FAST("Gyorsfülű", "10 szó az első 8 mp-en belül", Tier.SILVER, "DOTDASH", 10),
    MORSE_25("Rádiós", "25 megfejtett morzeszó", Tier.SILVER, "ANTENNA", 25),
    MORSE_STREAK("Hibátlan adás", "10 szó egymás után hiba nélkül", Tier.GOLD, "SOS", 10),
    MORSE_100("Távírász", "100 megfejtett morzeszó", Tier.GOLD, "TELEGRAPH", 100),
    COLLECTOR("Gyűjtő", "20 kitűző megszerzése", Tier.LEGEND, "MEDAL", 20);

    /** Hol tart most (0..target). */
    fun progress(c: Context): Int = when (this) {
        FIRST_LIGHT, PLAYS_25, PLAYS_100, PLAYS_500 -> GameStats.totalPlays(c)
        TIME_1H, TIME_10H -> (GameStats.totalMs(c) / 60_000L).toInt()
        STREAK_3, STREAK_7 -> GameStats.bestStreak(c)
        NIGHT_OWL -> GameStats.night(c)
        EARLY_BIRD -> GameStats.early(c)
        SIMON_5, SIMON_WIN -> GameStats.bestOf(c, "simon")
        LOCK_OPEN -> GameStats.bestOf(c, "lock")
        DINO_50, DINO_150 -> maxOf(GameStats.bestOf(c, "dino"), Settings.dinoBest(c))
        BLOW_POP -> Settings.blowPops(c)
        BLOW_20 -> GameStats.plays(c, Feature.BLOW)
        PET_HATCH, PET_ADULT -> PetStore.load(c).stage.ordinal
        SPIN_25 -> GameStats.plays(c, Feature.SPIN)
        SAFE_OPEN -> GameStats.cnt(c, "safe_open")
        LEVEL_ZERO -> GameStats.cnt(c, "level_zero")
        BREATH_60 -> (GameStats.ms(c, Feature.BREATH) / 60_000L).toInt()
        FOCUS_5H -> (GameStats.ms(c, Feature.TIMER) / 60_000L).toInt()
        LECTURE_10 -> GameStats.plays(c, Feature.LECTURE)
        BEACON -> GameStats.cnt(c, "beacon_found")
        AI_TALK -> GameStats.cnt(c, "ai_talk")
        DETOX_FIRST, DETOX_60, DETOX_3H -> GameStats.bestOf(c, "detox_min")
        DETOX_GOALS -> GameStats.cnt(c, "detox_goal")
        MORSE_FIRST, MORSE_25, MORSE_100 -> MorseStats.solved(c)
        MORSE_FAST -> MorseStats.fast(c)
        MORSE_STREAK -> MorseStats.bestStreak(c)
        DETOX_10H -> (GameStats.ms(c, Feature.DETOX) / 60_000L).toInt()
        STUDIO -> GameStats.cnt(c, "studio_made") + GameStats.plays(c, Feature.STUDIO)
        ALL_GAMES -> Feature.entries.count { it.game && GameStats.plays(c, it) > 0 }
        EXPLORER -> Feature.entries.count { GameStats.plays(c, it) > 0 }
        COLLECTOR -> Achievements.unlocked(c).count { it != COLLECTOR }
    }.coerceAtMost(if (this == ALL_GAMES) Feature.entries.count { it.game } else target)

    fun goal(): Int = if (this == ALL_GAMES) Feature.entries.count { it.game } else target
}

object Achievements {
    private const val PREFS = "glyph_eggs_badges"
    private const val CHANNEL = "glyph_eggs_badges"
    private fun p(c: Context) = c.getSharedPreferences(PREFS, Context.MODE_PRIVATE)

    fun unlockedAt(c: Context, b: Badge): Long = p(c).getLong(b.name, 0L)
    fun isUnlocked(c: Context, b: Badge) = unlockedAt(c, b) > 0
    fun unlocked(c: Context): List<Badge> = Badge.entries.filter { isUnlocked(c, it) }
    /** A megszerzettek, a legutóbbi elöl. */
    fun recent(c: Context): List<Badge> = unlocked(c).sortedByDescending { unlockedAt(c, it) }

    /** Ellenőrzi, mi teljesült; az újakat elmenti, értesít, és frissíti a widgetet. */
    fun check(c: Context): List<Badge> {
        val fresh = mutableListOf<Badge>()
        repeat(2) { // a Gyűjtő a többiektől függ: kétszer fut
            for (b in Badge.entries) {
                if (isUnlocked(c, b)) continue
                val ok = try { b.progress(c) >= b.goal() } catch (t: Throwable) { false }
                if (ok) {
                    p(c).edit().putLong(b.name, System.currentTimeMillis()).apply()
                    fresh += b
                }
            }
        }
        if (fresh.isNotEmpty()) {
            for (b in fresh) DebugState.log("Új kitűző: ${b.title} (${b.tier.title})")
            notify(c, fresh)
            Widgets.updateBadges(c)
            NeonThemes.checkNew(c)
        }
        return fresh
    }

    private fun notify(c: Context, list: List<Badge>) {
        if (!Settings.notifBadges(c)) return
        try {
            val nm = c.getSystemService(NotificationManager::class.java)
            nm.createNotificationChannel(NotificationChannel(CHANNEL, "Kitűzők", NotificationManager.IMPORTANCE_DEFAULT))
            val open = PendingIntent.getActivity(c, 5100,
                Intent(c, MainActivity::class.java).putExtra(MainActivity.EXTRA_TAB, MainActivity.TAB_STATS)
                    .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_CLEAR_TOP),
                PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT)
            val b = list.first()
            nm.notify(5100 + b.ordinal, Notification.Builder(c, CHANNEL)
                .setSmallIcon(R.drawable.ic_trophy)
                .setLargeIcon(BadgeArt.bitmap(b, 0.15f, true, 192))
                .setContentTitle("Új kitűző: ${b.title}" + if (list.size > 1) " (+${list.size - 1})" else "")
                .setContentText("${b.tier.title} · ${b.desc}")
                .setContentIntent(open)
                .setAutoCancel(true)
                .build())
        } catch (t: Throwable) { }
    }
}

/**
 * A kitűzők rajza: pontokból álló érem. Kívül a fokozat színű pontgyűrű, amin egy fényes csillanás
 * fut körbe; belül a 9×9 pontos ikon, amin átsöpör a fény. A [phase] (0..1) mozgatja – az appban
 * folyamatosan, a widgeten képkockánként.
 */
object BadgeArt {

    private val ICONS: Map<String, Array<String>> = mapOf(
        "STAR" to arrayOf("....#....", "....#....", "...###...", "#########", ".#######.", "..#####..", "..##.##..", ".##...##.", ".#.....#."),
        "BOLT" to arrayOf(".....##..", "....##...", "...##....", "..######.", ".....##..", "....##...", "...##....", "..##.....", ".#......."),
        "FLAME" to arrayOf("....#....", "...##....", "...###...", "..####.#.", ".#######.", ".###.###.", ".##...##.", "..#...#..", "...###..."),
        "CROWN" to arrayOf(".........", "#...#...#", "##.###.##", "#########", "#########", "##.#.#.##", ".........", "#########", "........."),
        "CLOCK" to arrayOf("..#####..", ".#..#..#.", "#...#...#", "#...#...#", "#...###.#", "#.......#", "#.......#", ".#.....#.", "..#####.."),
        "SUN" to arrayOf("#...#...#", ".#.....#.", "...###...", "..#####..", "#.#####.#", "..#####..", "...###...", ".#.....#.", "#...#...#"),
        "STREAK" to arrayOf(".........", "......##.", "......##.", "...##.##.", "...##.##.", "##.##.##.", "##.##.##.", "##.##.##.", "#########"),
        "MOON" to arrayOf("...####..", "..##.....", ".##......", ".##......", ".##......", ".##......", ".##....#.", "..##..##.", "...####.."),
        "SUNRISE" to arrayOf("....#....", ".#.....#.", "...###...", "..#####..", ".#######.", "#########", ".........", "#########", "........."),
        "GRID" to arrayOf("####.####", "####.####", "####.####", "####.####", ".........", "####.####", "####.####", "####.####", "####.####"),
        "TROPHY" to arrayOf("#########", "##.###.##", "#..###..#", ".#.###.#.", "..#####..", "...###...", "....#....", "...###...", "..#####.."),
        "LOCK" to arrayOf("...###...", "..#...#..", "..#...#..", ".#######.", ".###.###.", ".##...##.", ".###.###.", ".#######.", "........."),
        "DINO" to arrayOf(".....####", ".....#.##", ".....####", "#...###..", "##.#####.", "#######..", ".#####...", "..#..#...", "..##.##.."),
        "BALLOON" to arrayOf("..#####..", ".#######.", ".#####.#.", ".######..", "..#####..", "...###...", "....#....", "...#.....", "....#...."),
        "WIND" to arrayOf(".........", "######...", "......#..", "#######..", ".........", "########.", "........#", "#####..#.", "........."),
        "EGG" to arrayOf("...###...", "..#####..", ".#######.", ".##.#.##.", "#########", "#.#.#.#.#", "#########", ".#######.", "..#####.."),
        "HEART" to arrayOf(".........", ".##...##.", "#########", "#########", "#########", ".#######.", "..#####..", "...###...", "....#...."),
        "SPIRAL" to arrayOf("#########", "#.......#", "#.#####.#", "#.#...#.#", "#.#.#.#.#", "#.#.###.#", "#.#.....#", "#.#######", "#........"),
        "KEY" to arrayOf(".###.....", "#...#....", "#...#####", "#...#.#.#", ".###..#.#", ".........", ".........", ".........", "........."),
        "LEVEL" to arrayOf(".........", ".........", "#########", "#...#...#", "#..###..#", "#...#...#", "#########", ".........", "........."),
        "WAVE" to arrayOf(".........", ".##......", "#..#.....", "....#...#", ".....#.#.", "......#..", ".##......", "#..#...#.", "....###.."),
        "HOURGLASS" to arrayOf("#########", ".#######.", "..#####..", "...###...", "....#....", "...#.#...", "..#...#..", ".#.###.#.", "#########"),
        "CAP" to arrayOf(".........", "....#....", "..#####..", "#########", "..#####..", "..#...#.#", "..#####.#", "........#", "........."),
        "RADAR" to arrayOf("#.......#", ".#.....#.", "#.#...#.#", ".#.#.#.#.", "#.#.#.#.#", ".#.#.#.#.", "#.#...#.#", ".#.....#.", "#.......#"),
        "MIC" to arrayOf("...###...", "..#####..", "..#####..", "..#####..", "#.#####.#", "#..###..#", ".#.....#.", "..#####..", "....#...."),
        "TARGET" to arrayOf("..#####..", ".#.....#.", "#..###..#", "#.#...#.#", "#.#.#.#.#", "#.#...#.#", "#..###..#", ".#.....#.", "..#####.."),
        "ROSE" to arrayOf("....#....", "....#....", "...###...", "..#.#.#..", "####.####", "..#.#.#..", "...###...", "....#....", "....#...."),
        "LEAF" to arrayOf(".....####", "...######", "..###.###", ".###..##.", ".##..###.", "##..###..", "#.####...", "#........", "#........"),
        "STONES" to arrayOf(".........", "...###...", "..#####..", ".........", ".#######.", "#########", ".........", "#########", "#########"),
        "ENSO" to arrayOf("..#####..", ".##...###", "##.....##", "#.......#", "#.......#", "#.......#", "##.....#.", ".##...#..", "..###...."),
        "LOTUS" to arrayOf("....#....", "...###...", ".#.###.#.", "##.###.##", "###.#.###", ".#######.", "..#####..", "#########", "........."),
        "KEYER" to arrayOf(".........", ".....##..", "....#..#.", "..######.", ".#.......", "#########", "#.......#", "#########", "........."),
        "DOTDASH" to arrayOf(".........", "##.......", "##.#####.", ".........", "#####.##.", "......##.", ".........", "##.##.##.", "........."),
        "ANTENNA" to arrayOf("#.......#", ".#..#..#.", "#.#.#.#.#", "....#....", "...###...", "....#....", "...#.#...", "..#...#..", ".#.....#."),
        "SOS" to arrayOf(".........", "#.#.#....", ".........", "###.###.#", "###.###.#", ".........", "....#.#.#", ".........", "........."),
        "TELEGRAPH" to arrayOf("....#....", "...###...", "..#.#.#..", "....#....", "#########", "#.#.#.#.#", "#########", "...#.#...", "..#...#.."),
        "ZZZ" to arrayOf("....#####", "......#..", ".....#...", "....#####", "#####....", "...#.....", "..#......", ".#.......", "#####...."),
        "FILM" to arrayOf("#.#.#.#.#", "#########", "#.......#", "#.##.##.#", "#.##.##.#", "#.......#", "#########", "#.#.#.#.#", "........."),
        "MEDAL" to arrayOf("##.....##", ".##...##.", "..##.##..", "...###...", "..#####..", ".###.###.", ".##.#.##.", ".###.###.", "..#####..")
    )

    /** Kitűző rajzolása a [cx],[cy] középpontú, [r] sugarú körbe. */
    fun draw(cv: Canvas, cx: Float, cy: Float, r: Float, b: Badge, phase: Float, unlocked: Boolean, progress: Float = 0f) {
        val p = Paint(Paint.ANTI_ALIAS_FLAG)
        val tier = b.tier
        // Háttérkorong
        p.color = if (unlocked) 0xFF141414.toInt() else 0xFF101010.toInt()
        cv.drawCircle(cx, cy, r, p)
        // Külső pontgyűrű, körbefutó csillanással (legendásnál kettővel)
        val n = 32
        for (k in 0 until n) {
            val a = k.toDouble() / n
            val ang = a * 2 * Math.PI
            val x = cx + (r * 0.88f * sin(ang)).toFloat()
            val y = cy - (r * 0.88f * cos(ang)).toFloat()
            if (!unlocked) {
                p.color = if (a < progress) 0xFF8A8A8A.toInt() else 0xFF2E2E2E.toInt()
                cv.drawCircle(x, y, r * 0.035f, p)
                continue
            }
            var d = abs(((a - phase) % 1.0 + 1.5) % 1.0 - 0.5).toFloat() * n
            if (tier == Tier.LEGEND) d = minOf(d, abs(((a - phase - 0.5) % 1.0 + 1.5) % 1.0 - 0.5).toFloat() * n)
            val glow = (1f - d / 3.5f).coerceIn(0f, 1f)
            p.color = mix(tier.color, tier.glow, glow)
            cv.drawCircle(x, y, r * (0.04f + 0.03f * glow), p)
        }
        // Belső vékony gyűrű
        p.style = Paint.Style.STROKE
        p.strokeWidth = r * 0.025f
        p.color = if (unlocked) mix(0xFF2A2A2A.toInt(), tier.color, 0.35f) else 0xFF242424.toInt()
        cv.drawCircle(cx, cy, r * 0.74f, p)
        p.style = Paint.Style.FILL
        // Ikon: 9×9 pont, átsöprő fénycsíkkal
        val pat = ICONS[b.icon] ?: ICONS.getValue("STAR")
        val step = r * 1.0f / 9f
        val x0 = cx - step * 4
        val y0 = cy - step * 4
        val sweep = phase * 2.6f - 0.8f // átlós söprés helye (−0,8..1,8)
        for (row in 0 until 9) for (col in 0 until 9) {
            val on = pat[row].getOrNull(col) == '#'
            val x = x0 + col * step
            val y = y0 + row * step
            if (!on) {
                if (unlocked) { p.color = 0xFF1E1E1E.toInt(); cv.drawCircle(x, y, step * 0.14f, p) }
                continue
            }
            if (!unlocked) {
                p.color = 0xFF4A4A4A.toInt()
                cv.drawCircle(x, y, step * 0.36f, p)
                continue
            }
            val diag = (col + row) / 16f
            val shine = (1f - abs(diag - sweep) * 5f).coerceIn(0f, 1f)
            p.color = mix(if (tier == Tier.SILVER) 0xFFE8E8E8.toInt() else tier.color, 0xFFFFFFFF.toInt(), shine)
            cv.drawCircle(x, y, step * (0.38f + 0.08f * shine), p)
        }
        // Legendás: lüktető külső glória
        if (unlocked && tier == Tier.LEGEND) {
            val pulse = (sin(phase * 2 * Math.PI) * 0.5 + 0.5).toFloat()
            p.style = Paint.Style.STROKE
            p.strokeWidth = r * 0.02f
            p.color = (((40 + 80 * pulse).toInt()) shl 24) or (tier.color and 0xFFFFFF)
            cv.drawCircle(cx, cy, r * (0.97f + 0.02f * pulse), p)
            p.style = Paint.Style.FILL
        }
    }

    /** Egy képkocka bitmapként (widget, értesítés). Fekete háttéren RGB_565 – fele akkora. */
    fun bitmap(b: Badge, phase: Float, unlocked: Boolean, size: Int, progress: Float = 0f, opaque: Boolean = false): Bitmap {
        val bmp = Bitmap.createBitmap(size, size, if (opaque) Bitmap.Config.RGB_565 else Bitmap.Config.ARGB_8888)
        val cv = Canvas(bmp)
        if (opaque) cv.drawColor(0xFF000000.toInt())
        draw(cv, size / 2f, size / 2f, size / 2f * 0.96f, b, phase, unlocked, progress)
        return bmp
    }

    fun mix(a: Int, b: Int, t: Float): Int {
        val tt = t.coerceIn(0f, 1f)
        fun ch(s: Int) = ((a shr s and 0xFF) * (1 - tt) + (b shr s and 0xFF) * tt).toInt()
        return (0xFF shl 24) or (ch(16) shl 16) or (ch(8) shl 8) or ch(0)
    }
}

/** Kitűző-nézet az appban: folyamatosan mozog (a Stat fül hajtja a [phase]-t). */
class BadgeView(context: Context, val badge: Badge) : android.view.View(context) {
    var phase = 0f
    var unlocked = false
    var progress = 0f
    override fun onDraw(canvas: Canvas) {
        val s = minOf(width, height) / 2f
        BadgeArt.draw(canvas, width / 2f, height / 2f, s * 0.96f, badge, phase, unlocked, progress)
    }
}

/** Napi időpont szövegben (pl. „okt. 12.”). */
fun shortDate(ms: Long): String {
    if (ms <= 0) return "–"
    val d = java.time.Instant.ofEpochMilli(ms).atZone(ZoneId.systemDefault()).toLocalDate()
    val months = arrayOf("jan.", "febr.", "márc.", "ápr.", "máj.", "jún.", "júl.", "aug.", "szept.", "okt.", "nov.", "dec.")
    return "${months[d.monthValue - 1]} ${d.dayOfMonth}."
}

/** Időtartam röviden: „3 ó 12 p” / „45 p” / „30 mp”. */
fun shortDuration(ms: Long): String {
    val m = ms / 60_000
    return when {
        m >= 60 -> "${m / 60} ó ${m % 60} p"
        m >= 1 -> "$m p"
        else -> "${ms / 1000} mp"
    }
}
