package com.akos.glypheggs

import android.Manifest
import android.app.Activity
import android.content.Intent
import android.content.pm.PackageManager
import android.os.Bundle
import android.view.Gravity
import android.view.View
import android.view.ViewGroup.LayoutParams.MATCH_PARENT
import android.view.ViewGroup.LayoutParams.WRAP_CONTENT
import android.view.WindowManager
import android.widget.FrameLayout
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView
import kotlinx.coroutines.Job
import kotlinx.coroutines.MainScope
import kotlinx.coroutines.cancel
import kotlinx.coroutines.delay
import kotlinx.coroutines.isActive
import kotlinx.coroutines.launch

/**
 * A Fújós játék oldala. Amíg nyitva van, a mikrofon figyeli a fújást (semmit nem rögzít, csak a
 * hangerőt méri), a szolgáltatás pedig a LED-eken játssza az animációt. A képernyőn élőben látszik a
 * hátlap képe és a fújás ereje; az animáció futás közben is váltható. Az oldal bezárásakor leáll.
 */
class BlowActivity : Activity() {

    private val scope = MainScope()
    private lateinit var preview: GlyphMapView
    private lateinit var meter: LinearLayout
    private lateinit var meterText: TextView
    private lateinit var hint: TextView
    private lateinit var styleList: LinearLayout
    private val sensPills = mutableListOf<TextView>()
    private var recorder: BlowRecorder? = null
    private var liveJob: Job? = null
    private lateinit var listenToggle: ToggleView

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        darkWindow()
        window.addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)

        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(15), 0, dp(15), dp(24))
        }
        val scroll = ScrollView(this).apply {
            setBackgroundColor(Ui.BG)
            isVerticalScrollBarEnabled = false
            addView(root, FrameLayout.LayoutParams(MATCH_PARENT, WRAP_CONTENT))
            padForSystemBars()
        }
        setContentView(scroll)

        val header = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
            setPadding(dp(7), dp(28), 0, dp(14))
        }
        header.addView(ImageView(this).apply {
            setImageResource(R.drawable.ic_back)
            setOnClickListener { finish() }
        }, LinearLayout.LayoutParams(dp(24), dp(24)))
        header.addView(text("Fújós", 26f).apply { setPadding(dp(30), 0, 0, 0) })
        root.addView(header)

        // Élő hátlap-kép
        val box = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            background = rounded(Ui.BG, dp(22).toFloat(), Ui.LINE, dp(1.5f))
            setPadding(dp(14), dp(16), dp(14), dp(14))
        }
        preview = GlyphMapView(this).apply { unlitColor = 0xFF303030.toInt() }
        box.addView(preview, LinearLayout.LayoutParams(MATCH_PARENT, dp(240)))

        // Fújás-erősségmérő: 20 pont
        meter = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER
            setPadding(0, dp(14), 0, 0)
        }
        repeat(20) {
            meter.addView(View(this).apply { background = rounded(0xFF333333.toInt(), dp(5).toFloat()) },
                LinearLayout.LayoutParams(dp(10), dp(10)).apply { marginStart = dp(2); marginEnd = dp(2) })
        }
        box.addView(meter)
        meterText = text("", 13f, Ui.SUB).apply { gravity = Gravity.CENTER; setPadding(0, dp(8), 0, 0) }
        box.addView(meterText, LinearLayout.LayoutParams(MATCH_PARENT, WRAP_CONTENT))
        root.addView(box)

        hint = text(
            "Fújj a telefon aljába, a töltőport mellé – ott van a mikrofon. A LED-ek a hátlapon (és itt a képen) követik a fújásod. " +
                "A mikrofon csak a hangerőt méri, semmit nem rögzít és nem ment.",
            12.5f, Ui.SUB
        ).apply { setPadding(dp(8), dp(12), dp(8), 0); setLineSpacing(0f, 1.2f) }
        root.addView(hint)

        // Fújásfigyelés: a háttérben is figyel, és fújásra magától indul
        root.addView(sectionTitle("Fújásfigyelés"))
        val listenRow = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
            background = rounded(Ui.CARD, dp(20).toFloat())
            setPadding(dp(18), dp(15), dp(16), dp(15))
        }
        val listenTexts = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        listenTexts.addView(text("Mindig figyel", 17f))
        listenTexts.addView(text(
            "Bekapcsolva bármikor megfújhatod a telefont – az app megnyitása nélkül is elindul a játék, és 8 mp csend után leáll. " +
                "Közben a mikrofon folyamatosan fut (a rendszer zöld pöttyel jelzi), ez óránként kb. 0,3–0,5% akku.",
            12.5f, Ui.SUB
        ).apply { setPadding(0, dp(2), 0, 0); setLineSpacing(0f, 1.15f) })
        listenRow.addView(listenTexts, LinearLayout.LayoutParams(0, WRAP_CONTENT, 1f))
        listenToggle = ToggleView(this).apply {
            checked = SimonService.blowListening || Settings.blowAlways(this@BlowActivity)
            onChange = { on ->
                if (on && checkSelfPermission(Manifest.permission.RECORD_AUDIO) != PackageManager.PERMISSION_GRANTED) {
                    checked = false
                    requestPermissions(arrayOf(Manifest.permission.RECORD_AUDIO), 8)
                } else {
                    setListen(on)
                }
            }
        }
        listenRow.addView(listenToggle, LinearLayout.LayoutParams(WRAP_CONTENT, WRAP_CONTENT).apply { marginStart = dp(12) })
        listenRow.setOnClickListener { listenToggle.performClick() }
        root.addView(listenRow)

        root.addView(sectionTitle("Animáció"))
        styleList = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        root.addView(styleList)

        root.addView(sectionTitle("Fújás érzékenysége"))
        val sensRow = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
        listOf("Alacsony", "Közepes", "Magas", "Nagyon\nmagas").forEachIndexed { i, label ->
            val t = text(label, 13f).apply {
                gravity = Gravity.CENTER
                setOnClickListener {
                    Settings.setBlowSensitivity(this@BlowActivity, i)
                    render()
                }
            }
            sensPills += t
            sensRow.addView(t, LinearLayout.LayoutParams(0, dp(48), 1f).apply { marginEnd = dp(5) })
        }
        root.addView(sensRow)
        root.addView(text(
            "Ha zajos helyen magától is reagál, vegyél vissza; ha erős fújásra sem mozdul, emeld meg. A beszédet és a koppanásokat kiszűri.",
            12.5f, Ui.SUB
        ).apply { setPadding(dp(8), dp(8), dp(8), 0); setLineSpacing(0f, 1.2f) })

        val gest = FeatureCard(this, R.drawable.ic_gesture, "Indítás és leállítás",
            "Indul: ${Settings.trigger(this, Feature.BLOW).title}", false)
        gest.setOnClickListener {
            startActivity(Intent(this, GesturesActivity::class.java).putExtra(GesturesActivity.EXTRA_FEATURE, Feature.BLOW.name))
        }
        root.addView(sectionTitle("Indító mozdulat"))
        root.addView(row(gest, null, 130))

        render()
    }

    override fun onResume() {
        super.onResume()
        GlyphMirror.appVisible = true
        if (checkSelfPermission(Manifest.permission.RECORD_AUDIO) == PackageManager.PERMISSION_GRANTED) {
            startPlaying()
        } else {
            meterText.text = "A fújás érzékeléséhez engedélyezd a mikrofont"
            requestPermissions(arrayOf(Manifest.permission.RECORD_AUDIO), 7)
        }
        liveJob?.cancel()
        liveJob = scope.launch {
            while (isActive) {
                preview.lit = GlyphMirror.lit.value
                val lv = BlowInput.level.value
                val n = (lv * 20f).toInt()
                for (i in 0 until meter.childCount) {
                    val col = when {
                        i >= n -> 0xFF333333.toInt()
                        i >= 16 -> Ui.RED
                        else -> Ui.TEXT
                    }
                    meter.getChildAt(i).background = rounded(col, dp(5).toFloat())
                }
                if (BlowInput.active) {
                    meterText.text = if (lv > 0.05f) "Erő: ${(lv * 100).toInt()}%" else "Fújj!"
                }
                delay(40)
            }
        }
    }

    override fun onPause() {
        super.onPause()
        GlyphMirror.appVisible = false
        liveJob?.cancel()
        // Bezárás / háttérbe kerülés: a mikrofon leáll, a játék pár mp múlva magától befejeződik
        recorder?.stop()
        recorder = null
    }

    /** Fújásfigyelés be/ki (a szolgáltatásban fut, az oldal bezárása után is). */
    private fun setListen(on: Boolean) {
        if (on) {
            // Az oldal saját mikrofonját átadja a szolgáltatásnak (két felvétel egyszerre nem fut)
            recorder?.stop()
            recorder = null
            startForegroundService(Intent(this, SimonService::class.java).setAction(SimonService.ACTION_BLOW_LISTEN_ON))
        } else {
            startService(Intent(this, SimonService::class.java).setAction(SimonService.ACTION_BLOW_LISTEN_OFF))
            // A szolgáltatás leállítja a mikrofont: kis szünet után az oldal visszaveszi
            scope.launch {
                delay(400)
                startPlaying()
            }
        }
    }

    override fun onRequestPermissionsResult(requestCode: Int, permissions: Array<String>, grantResults: IntArray) {
        if (requestCode == 8) {
            if (grantResults.isNotEmpty() && grantResults[0] == PackageManager.PERMISSION_GRANTED) {
                listenToggle.checked = true
                setListen(true)
            }
            return
        }
        if (requestCode == 7 && grantResults.isNotEmpty() && grantResults[0] == PackageManager.PERMISSION_GRANTED) {
            startPlaying()
        } else if (requestCode == 7) {
            meterText.text = "Mikrofon nélkül nem érzékelhető a fújás"
        }
    }

    /** Mikrofon indítása, és a játék indítása a LED-eken (ha még nem fut). */
    private fun startPlaying() {
        // Ha a háttérbeli fújásfigyelés fut, annak a mikrofonját használja
        if (recorder == null && !SimonService.blowListening) {
            val r = BlowRecorder(this)
            if (r.start()) recorder = r else {
                meterText.text = "A mikrofon nem indult el"
                return
            }
        }
        meterText.text = "Fújj!"
        if (GlyphMirror.mode.value != Feature.BLOW) {
            startForegroundService(
                Intent(this, SimonService::class.java).setAction(SimonService.ACTION_BLOW)
                    .putExtra(SimonService.EXTRA_SOURCE, SimonService.SOURCE_BLOW_PAGE)
            )
        }
    }

    private fun render() {
        val cur = Settings.blowStyle(this)
        styleList.removeAllViews()
        for (st in BlowStyle.entries) {
            val best = Settings.blowBest(this, st)
            val extra = when {
                st == BlowStyle.BALLOON && Settings.blowPops(this) > 0 -> " · kidurrant: ${Settings.blowPops(this)}×"
                st.timed && best > 0 -> " · rekord: %.1f mp".format(best / 1000.0)
                else -> ""
            }
            val row = LinearLayout(this).apply {
                orientation = LinearLayout.HORIZONTAL
                gravity = Gravity.CENTER_VERTICAL
                background = rounded(Ui.CARD, dp(20).toFloat())
                setPadding(dp(18), dp(15), dp(16), dp(15))
                setOnClickListener {
                    Settings.setBlowStyle(this@BlowActivity, st)
                    render()
                }
            }
            val texts = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
            texts.addView(text(st.title + extra, 17f))
            texts.addView(text(st.desc, 12.5f, Ui.SUB).apply { setPadding(0, dp(2), 0, 0); setLineSpacing(0f, 1.15f) })
            row.addView(texts, LinearLayout.LayoutParams(0, WRAP_CONTENT, 1f))
            row.addView(RadioMark(this, st == cur), LinearLayout.LayoutParams(dp(26), dp(26)).apply { marginStart = dp(12) })
            styleList.addView(row, LinearLayout.LayoutParams(MATCH_PARENT, WRAP_CONTENT).apply { bottomMargin = dp(5) })
        }
        val sens = Settings.blowSensitivity(this)
        sensPills.forEachIndexed { i, t ->
            val sel = i == sens
            t.background = rounded(if (sel) Ui.LIGHT else Ui.CARD, dp(22).toFloat())
            t.setTextColor(if (sel) Ui.DARK_TEXT else Ui.TEXT)
        }
    }

    override fun onDestroy() {
        scope.cancel()
        recorder?.stop()
        super.onDestroy()
    }
}
