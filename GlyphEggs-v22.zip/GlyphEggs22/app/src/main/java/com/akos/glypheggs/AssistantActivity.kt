package com.akos.glypheggs

import android.Manifest
import android.app.Activity
import android.content.Intent
import android.content.pm.PackageManager
import android.os.Bundle
import android.os.SystemClock
import android.speech.RecognitionListener
import android.speech.RecognizerIntent
import android.speech.SpeechRecognizer
import android.speech.tts.TextToSpeech
import android.speech.tts.UtteranceProgressListener
import android.text.InputType
import android.view.Gravity
import android.view.View
import android.view.ViewGroup.LayoutParams.MATCH_PARENT
import android.view.ViewGroup.LayoutParams.WRAP_CONTENT
import android.widget.EditText
import android.widget.FrameLayout
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView
import kotlinx.coroutines.Job
import kotlinx.coroutines.MainScope
import kotlinx.coroutines.cancel
import kotlinx.coroutines.delay
import kotlinx.coroutines.isActive
import kotlinx.coroutines.launch
import java.util.Locale

/**
 * Hangasszisztens: nyomd meg a gombot, mondd el a kérdésed, Claude válaszol, a telefon felolvassa,
 * és közben a Glyph LED-ek a választott animációval „beszélnek”.
 */
class AssistantActivity : Activity() {

    companion object {
        /** Widgetről / kártyáról: azonnal hallgatni kezd. */
        const val EXTRA_LISTEN = "listen"
    }

    private val scope = MainScope()
    private lateinit var root: LinearLayout
    private lateinit var scroll: ScrollView
    private lateinit var preview: GlyphMapView
    private lateinit var stateView: ImageView
    private lateinit var heardView: TextView
    private lateinit var chat: LinearLayout
    private lateinit var micBtn: TextView
    private lateinit var settingsBox: LinearLayout
    private var settingsOpen = false

    private var recognizer: SpeechRecognizer? = null
    private var tts: TextToSpeech? = null
    private var ttsReady = false
    private var heldMic = false
    private var askJob: Job? = null
    private var pulseJob: Job? = null
    private var liveJob: Job? = null
    @Volatile private var lastRange = 0L
    private val history = mutableListOf<Pair<String, String>>()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        darkWindow()
        root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(15), 0, dp(15), dp(28))
        }
        scroll = ScrollView(this).apply {
            setBackgroundColor(Ui.BG)
            isVerticalScrollBarEnabled = false
            addView(root, FrameLayout.LayoutParams(MATCH_PARENT, WRAP_CONTENT))
            padForSystemBars()
        }
        setContentView(scroll)
        build()

        tts = TextToSpeech(this) { status ->
            ttsReady = status == TextToSpeech.SUCCESS
            if (ttsReady) {
                val r = tts?.setLanguage(Locale("hu", "HU")) ?: TextToSpeech.LANG_NOT_SUPPORTED
                if (r == TextToSpeech.LANG_MISSING_DATA || r == TextToSpeech.LANG_NOT_SUPPORTED) {
                    addBubble("A telefonon nincs magyar felolvasó hang. Beállítások → Rendszer → Nyelvek → Szövegfelolvasás: tölts le magyar hangot.", false, true)
                }
                tts?.setOnUtteranceProgressListener(progress)
            }
        }
        if (intent.getBooleanExtra(EXTRA_LISTEN, false)) scope.launch { delay(350); listen() }
    }

    // ------------------------------------------------------------------ felület

    private fun build() {
        val h = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
            setPadding(dp(7), dp(28), 0, dp(6))
        }
        h.addView(ImageView(this).apply { setImageResource(R.drawable.ic_back); setOnClickListener { finish() } },
            LinearLayout.LayoutParams(dp(24), dp(24)))
        h.addView(text("Asszisztens", 26f).apply { setPadding(dp(30), 0, 0, 0) }, LinearLayout.LayoutParams(0, WRAP_CONTENT, 1f))
        h.addView(ImageView(this).apply {
            setImageResource(R.drawable.ic_settings)
            setOnClickListener { settingsOpen = !settingsOpen; renderSettings(); if (settingsOpen) scroll.post { scroll.smoothScrollTo(0, settingsBox.top) } }
        }, LinearLayout.LayoutParams(dp(24), dp(24)).apply { marginEnd = dp(6) })
        root.addView(h)

        // Élő hátlap + állapot
        val box = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            gravity = Gravity.CENTER_HORIZONTAL
            background = rounded(Ui.BG, dp(22).toFloat(), Ui.LINE, dp(1.5f))
            setPadding(dp(14), dp(16), dp(14), dp(14))
        }
        preview = GlyphMapView(this).apply { unlitColor = 0xFF303030.toInt() }
        box.addView(preview, LinearLayout.LayoutParams(MATCH_PARENT, dp(220)))
        stateView = ImageView(this)
        box.addView(stateView, LinearLayout.LayoutParams(WRAP_CONTENT, WRAP_CONTENT).apply { topMargin = dp(12) })
        heardView = text("", 14f, Ui.SUB).apply { gravity = Gravity.CENTER; setPadding(dp(6), dp(6), dp(6), 0) }
        box.addView(heardView, LinearLayout.LayoutParams(MATCH_PARENT, WRAP_CONTENT))
        root.addView(box, LinearLayout.LayoutParams(MATCH_PARENT, WRAP_CONTENT).apply { topMargin = dp(14) })

        // Nagy mikrofon-gomb
        micBtn = text("●  Beszélj", 17f, Ui.DARK_TEXT, Ui.medium).apply {
            gravity = Gravity.CENTER
            background = rounded(Ui.LIGHT, dp(32).toFloat())
            setOnClickListener { onMic() }
        }
        root.addView(micBtn, LinearLayout.LayoutParams(MATCH_PARENT, dp(64)).apply { topMargin = dp(12) })

        // Beszélgetés
        root.addView(sectionTitle("Beszélgetés"))
        chat = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        root.addView(chat)
        val last = AssistantState.lastA(this)
        if (last.isNotEmpty()) addBubble("Előző válasz: $last", false, true)
        if (Settings.assistantKey(this).isBlank()) {
            addBubble("Szia! Ahhoz, hogy válaszolni tudjak, add meg a Claude API-kulcsodat a beállításoknál (fogaskerék fent).", false, true)
            settingsOpen = true
        }
        val newChat = text("Új beszélgetés", 13.5f).apply {
            gravity = Gravity.CENTER
            background = rounded(Ui.CARD, dp(20).toFloat())
            setOnClickListener { history.clear(); chat.removeAllViews(); addBubble("Új beszélgetés – nem emlékszem az előzőre.", false, true) }
        }
        root.addView(newChat, LinearLayout.LayoutParams(MATCH_PARENT, dp(42)).apply { topMargin = dp(8) })

        settingsBox = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        root.addView(settingsBox)
        renderSettings()
    }

    private fun addBubble(s: String, mine: Boolean, note: Boolean = false) {
        val t = text(s, 15f, if (note) Ui.SUB else if (mine) Ui.DARK_TEXT else Ui.TEXT).apply {
            setLineSpacing(0f, 1.2f)
            background = rounded(if (mine) Ui.LIGHT else Ui.CARD, dp(20).toFloat())
            setPadding(dp(16), dp(12), dp(16), dp(12))
        }
        val wrap = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = if (mine) Gravity.END else Gravity.START
        }
        wrap.addView(t, LinearLayout.LayoutParams(WRAP_CONTENT, WRAP_CONTENT).apply {
            if (mine) marginStart = dp(40) else marginEnd = dp(40)
        })
        chat.addView(wrap, LinearLayout.LayoutParams(MATCH_PARENT, WRAP_CONTENT).apply { bottomMargin = dp(6) })
        while (chat.childCount > 30) chat.removeViewAt(0)
    }

    private fun renderSettings() {
        settingsBox.removeAllViews()
        if (!settingsOpen) return
        settingsBox.addView(sectionTitle("Claude API-kulcs"))
        val key = EditText(this).apply {
            setText(Settings.assistantKey(this@AssistantActivity))
            hint = "sk-ant-…"
            setSingleLine(true)
            inputType = InputType.TYPE_CLASS_TEXT or InputType.TYPE_TEXT_VARIATION_PASSWORD
            setTextColor(Ui.TEXT)
            setHintTextColor(0xFF6A6A6A.toInt())
            textSize = 15f
            background = rounded(Ui.CARD, dp(18).toFloat())
            setPadding(dp(16), dp(12), dp(16), dp(12))
        }
        settingsBox.addView(key, LinearLayout.LayoutParams(MATCH_PARENT, WRAP_CONTENT))
        settingsBox.addView(text("Mentés", 14f, Ui.DARK_TEXT, Ui.medium).apply {
            gravity = Gravity.CENTER
            background = rounded(Ui.LIGHT, dp(20).toFloat())
            setOnClickListener {
                Settings.setAssistantKey(this@AssistantActivity, key.text.toString())
                addBubble("API-kulcs elmentve. Kérdezz bátran!", false, true)
            }
        }, LinearLayout.LayoutParams(MATCH_PARENT, dp(44)).apply { topMargin = dp(6) })
        settingsBox.addView(text(
            "A kulcsot a console.anthropic.com oldalon kapod (az API külön fizetős, nem a Claude-előfizetés része). " +
                "Csak ezen a telefonon tárolódik. A kérdésed szövege az Anthropic szerverére megy; a hangod nem – azt a telefon " +
                "beszédfelismerője alakítja szöveggé.", 12f, Ui.SUB).apply { setPadding(dp(8), dp(8), dp(8), 0); setLineSpacing(0f, 1.2f) })

        settingsBox.addView(sectionTitle("Modell"))
        val cur = Settings.assistantModel(this)
        settingsBox.addView(pillRow(AssistantModel.entries.map { it.title + "\n" + it.desc.substringBefore(" –") }, AssistantModel.entries.indexOf(cur), 58) {
            Settings.setAssistantModel(this, AssistantModel.entries[it]); renderSettings()
        })

        settingsBox.addView(sectionTitle("Beszéd-animáció a LED-eken"))
        val anim = Settings.talkAnim(this)
        val list = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            background = rounded(Ui.CARD, dp(22).toFloat())
            setPadding(0, dp(4), 0, dp(4))
        }
        TalkAnim.entries.forEachIndexed { i, a ->
            if (i > 0) list.addView(View(this).apply { setBackgroundColor(Ui.LINE) },
                LinearLayout.LayoutParams(MATCH_PARENT, 1).apply { marginStart = dp(18); marginEnd = dp(18) })
            val r = LinearLayout(this).apply {
                orientation = LinearLayout.HORIZONTAL
                gravity = Gravity.CENTER_VERTICAL
                setPadding(dp(18), dp(12), dp(16), dp(12))
                setOnClickListener { Settings.setTalkAnim(this@AssistantActivity, a); renderSettings(); demo() }
            }
            val tx = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
            tx.addView(text(a.title, 16f))
            if (a == anim) tx.addView(text(a.desc, 12.5f, Ui.SUB).apply { setPadding(0, dp(2), 0, 0); setLineSpacing(0f, 1.15f) })
            r.addView(tx, LinearLayout.LayoutParams(0, WRAP_CONTENT, 1f))
            r.addView(RadioMark(this, a == anim), LinearLayout.LayoutParams(dp(24), dp(24)).apply { marginStart = dp(12) })
            list.addView(r)
        }
        settingsBox.addView(list)
        settingsBox.addView(text("Koppints egy animációra: a telefon mond egy mondatot, és megmutatja.", 12f, Ui.SUB)
            .apply { setPadding(dp(8), dp(8), dp(8), 0) })

        settingsBox.addView(sectionTitle("Beszédtempó"))
        settingsBox.addView(pillRow(listOf("Lassú", "Normál", "Gyors", "Nagyon\ngyors"), Settings.talkRate(this), 50) {
            Settings.setTalkRate(this, it); renderSettings()
        })

        settingsBox.addView(sectionTitle("Egyéb"))
        val other = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            background = rounded(Ui.CARD, dp(22).toFloat())
            setPadding(0, dp(4), 0, dp(4))
        }
        other.addView(switchRow("Emlékezzen a beszélgetésre", "Az előző kérdéseidre is épít (az „Új beszélgetés” törli)", Settings.assistantMemory(this)) {
            Settings.setAssistantMemory(this, it)
        })
        other.addView(View(this).apply { setBackgroundColor(Ui.LINE) },
            LinearLayout.LayoutParams(MATCH_PARENT, 1).apply { marginStart = dp(18); marginEnd = dp(18) })
        other.addView(switchRow("LED-animáció", "A hátlap villog, amikor hallgat, gondolkodik és beszél", Settings.assistantLeds(this)) {
            Settings.setAssistantLeds(this, it)
        })
        settingsBox.addView(other)
    }

    private fun switchRow(t: String, s: String, on: Boolean, change: (Boolean) -> Unit): LinearLayout {
        val r = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
            setPadding(dp(18), dp(14), dp(16), dp(14))
        }
        val tx = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        tx.addView(text(t, 16f))
        tx.addView(text(s, 12.5f, Ui.SUB).apply { setPadding(0, dp(2), 0, 0) })
        r.addView(tx, LinearLayout.LayoutParams(0, WRAP_CONTENT, 1f))
        val tg = ToggleView(this).apply { checked = on; onChange = change }
        r.addView(tg, LinearLayout.LayoutParams(WRAP_CONTENT, WRAP_CONTENT).apply { marginStart = dp(12) })
        r.setOnClickListener { tg.performClick() }
        return r
    }

    private fun pillRow(labels: List<String>, selected: Int, height: Int, onPick: (Int) -> Unit): LinearLayout {
        val r = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
        labels.forEachIndexed { i, l ->
            val sel = i == selected
            r.addView(text(l, 13f, if (sel) Ui.DARK_TEXT else Ui.TEXT).apply {
                gravity = Gravity.CENTER
                background = rounded(if (sel) Ui.LIGHT else Ui.CARD, dp(22).toFloat())
                setOnClickListener { onPick(i) }
            }, LinearLayout.LayoutParams(0, dp(height), 1f).apply { if (i < labels.size - 1) marginEnd = dp(5) })
        }
        return r
    }

    // ------------------------------------------------------------------ állapot

    private fun setState(s: TalkState) {
        TalkBus.state.value = s
        stateView.setImageBitmap(Widgets.dotText(this, s.label, 15f, if (s == TalkState.LISTENING) Ui.RED else 0xFFF4F4F4.toInt()))
        micBtn.text = when (s) {
            TalkState.LISTENING -> "■  Kész"
            TalkState.THINKING -> "…"
            TalkState.SPEAKING -> "■  Csend"
            TalkState.IDLE -> "●  Beszélj"
        }
        micBtn.background = rounded(if (s == TalkState.LISTENING) Ui.RED else Ui.LIGHT, dp(32).toFloat())
        micBtn.setTextColor(if (s == TalkState.LISTENING) 0xFFFFFFFF.toInt() else Ui.DARK_TEXT)
        Widgets.updateAssistant(this)
        if (s != TalkState.IDLE) leds()
    }

    private fun leds() {
        if (!Settings.assistantLeds(this)) return
        try {
            startForegroundService(Intent(this, SimonService::class.java).setAction(SimonService.ACTION_TALK))
        } catch (t: Throwable) { }
    }

    private fun onMic() {
        when (TalkBus.state.value) {
            TalkState.IDLE -> listen()
            TalkState.LISTENING -> recognizer?.stopListening()
            TalkState.SPEAKING -> { tts?.stop(); pulseJob?.cancel(); setState(TalkState.IDLE) }
            TalkState.THINKING -> { askJob?.cancel(); setState(TalkState.IDLE) }
        }
    }

    // ------------------------------------------------------------------ beszédfelismerés

    private fun listen() {
        if (checkSelfPermission(Manifest.permission.RECORD_AUDIO) != PackageManager.PERMISSION_GRANTED) {
            requestPermissions(arrayOf(Manifest.permission.RECORD_AUDIO), 21)
            return
        }
        if (!SpeechRecognizer.isRecognitionAvailable(this)) {
            addBubble("Ezen a telefonon nincs elérhető beszédfelismerő (Google app / Beszédszolgáltatások).", false, true)
            return
        }
        tts?.stop()
        // A közös mikrofon (fütty- / fújásfigyelés) a felismerés idejére szünetel
        if (SimonService.micOn) {
            heldMic = true
            startService(Intent(this, SimonService::class.java).setAction(SimonService.ACTION_MIC_HOLD).putExtra(SimonService.EXTRA_HOLD, true))
        }
        val rec = recognizer ?: SpeechRecognizer.createSpeechRecognizer(this).also {
            it.setRecognitionListener(listener)
            recognizer = it
        }
        val i = Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH)
            .putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM)
            .putExtra(RecognizerIntent.EXTRA_LANGUAGE, "hu-HU")
            .putExtra(RecognizerIntent.EXTRA_PARTIAL_RESULTS, true)
        heardView.text = ""
        setState(TalkState.LISTENING)
        scope.launch { delay(250); try { rec.startListening(i) } catch (t: Throwable) { setState(TalkState.IDLE) } }
    }

    private fun releaseMic() {
        TalkBus.micLevel = 0f
        if (heldMic) {
            heldMic = false
            startService(Intent(this, SimonService::class.java).setAction(SimonService.ACTION_MIC_HOLD).putExtra(SimonService.EXTRA_HOLD, false))
        }
    }

    private val listener = object : RecognitionListener {
        override fun onReadyForSpeech(params: Bundle?) {}
        override fun onBeginningOfSpeech() {}
        override fun onRmsChanged(rmsdB: Float) { TalkBus.micLevel = ((rmsdB + 2f) / 12f).coerceIn(0f, 1f) }
        override fun onBufferReceived(buffer: ByteArray?) {}
        override fun onEndOfSpeech() { TalkBus.micLevel = 0f }
        override fun onError(error: Int) {
            releaseMic()
            setState(TalkState.IDLE)
            heardView.text = when (error) {
                SpeechRecognizer.ERROR_NO_MATCH, SpeechRecognizer.ERROR_SPEECH_TIMEOUT -> "Nem hallottam semmit – próbáld újra"
                SpeechRecognizer.ERROR_NETWORK, SpeechRecognizer.ERROR_NETWORK_TIMEOUT -> "Nincs internet a beszédfelismeréshez"
                SpeechRecognizer.ERROR_INSUFFICIENT_PERMISSIONS -> "Nincs mikrofon-engedély"
                else -> "A beszédfelismerés hibát jelzett ($error)"
            }
        }
        override fun onResults(results: Bundle?) {
            releaseMic()
            val text = results?.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION)?.firstOrNull()?.trim().orEmpty()
            if (text.isEmpty()) { setState(TalkState.IDLE); heardView.text = "Nem értettem – próbáld újra"; return }
            heardView.text = ""
            ask(text)
        }
        override fun onPartialResults(partialResults: Bundle?) {
            partialResults?.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION)?.firstOrNull()?.let { heardView.text = "„$it”" }
        }
        override fun onEvent(eventType: Int, params: Bundle?) {}
    }

    // ------------------------------------------------------------------ Claude

    private fun ask(q: String) {
        addBubble(q, true)
        setState(TalkState.THINKING)
        if (!Settings.assistantMemory(this)) history.clear()
        history += "user" to q
        while (history.size > 12) history.removeAt(0)
        askJob = scope.launch {
            val answer = try {
                ClaudeClient.ask(this@AssistantActivity, history.toList())
            } catch (t: kotlinx.coroutines.CancellationException) {
                throw t
            } catch (t: Throwable) {
                history.removeAt(history.size - 1)
                val msg = t.message ?: "Nem sikerült elérni a Claude-ot (${t.javaClass.simpleName})."
                addBubble(msg, false, true)
                speak(if (t is java.io.IOException) "Nincs internetkapcsolat." else "Hiba történt.")
                return@launch
            }
            history += "assistant" to answer
            addBubble(answer, false)
            AssistantState.setLast(this@AssistantActivity, q, answer)
            scroll.post { scroll.fullScroll(View.FOCUS_DOWN) }
            speak(ClaudeClient.forSpeech(answer))
        }
    }

    // ------------------------------------------------------------------ felolvasás + LED-szinkron

    private fun speak(s: String) {
        val t = tts
        if (t == null || !ttsReady || s.isBlank()) { setState(TalkState.IDLE); return }
        t.setSpeechRate(floatArrayOf(0.85f, 1.0f, 1.2f, 1.4f)[Settings.talkRate(this)])
        currentText = s
        lastRange = 0L
        setState(TalkState.SPEAKING)
        t.speak(s, TextToSpeech.QUEUE_FLUSH, null, "a" + SystemClock.elapsedRealtime())
        // Ha a felolvasó nem jelzi a szavakat, egyenletes szótag-ütem a LED-eknek
        pulseJob?.cancel()
        pulseJob = scope.launch {
            delay(600)
            while (isActive && TalkBus.state.value == TalkState.SPEAKING) {
                if (SystemClock.elapsedRealtime() - lastRange > 700) {
                    TalkBus.syllable(0.5f + (Math.random() * 0.5).toFloat())
                    if (Math.random() < 0.35) TalkBus.word()
                }
                delay((170 / rate()).toLong())
            }
        }
    }

    private var currentText = ""
    private var wordJob: Job? = null

    private fun rate() = floatArrayOf(0.85f, 1.0f, 1.2f, 1.4f)[Settings.talkRate(this)]

    private val progress = object : UtteranceProgressListener() {
        override fun onStart(utteranceId: String?) {}
        override fun onDone(utteranceId: String?) { runOnUiThread { if (TalkBus.state.value == TalkState.SPEAKING) setState(TalkState.IDLE) } }
        @Deprecated("régi API")
        override fun onError(utteranceId: String?) { runOnUiThread { setState(TalkState.IDLE) } }
        override fun onRangeStart(utteranceId: String?, start: Int, end: Int, frame: Int) {
            lastRange = SystemClock.elapsedRealtime()
            val word = currentText.substring(start.coerceIn(0, currentText.length), end.coerceIn(0, currentText.length))
            runOnUiThread { pulseWord(word) }
        }
    }

    /** Egy szó: szótagonként egy-egy impulzus; a hangsúlyos (első) szótag a legerősebb, a mondatvég halkul. */
    private fun pulseWord(word: String) {
        TalkBus.word()
        wordJob?.cancel()
        val n = syllables(word)
        val stressBoost = if (word.firstOrNull()?.isUpperCase() == true) 0.15f else 0f
        wordJob = scope.launch {
            for (i in 0 until n) {
                val base = if (i == 0) 0.95f else 0.6f + (Math.random() * 0.25).toFloat()
                TalkBus.syllable((base + stressBoost).coerceAtMost(1f))
                delay((165 / rate()).toLong())
            }
        }
    }

    private fun demo() {
        if (TalkBus.state.value != TalkState.IDLE) return
        speak("Szia! Így villogok, amikor beszélek. Tetszik ez az animáció?")
    }

    // ------------------------------------------------------------------ életciklus

    override fun onResume() {
        super.onResume()
        GlyphMirror.appVisible = true
        liveJob?.cancel()
        liveJob = scope.launch { GlyphMirror.lit.collect { preview.lit = it } }
        setState(TalkBus.state.value.takeIf { it != TalkState.LISTENING } ?: TalkState.IDLE)
    }

    override fun onPause() {
        super.onPause()
        GlyphMirror.appVisible = false
        liveJob?.cancel()
        if (TalkBus.state.value == TalkState.LISTENING) {
            recognizer?.cancel()
            releaseMic()
            setState(TalkState.IDLE)
        }
    }

    override fun onRequestPermissionsResult(requestCode: Int, permissions: Array<String>, grantResults: IntArray) {
        if (requestCode == 21 && grantResults.isNotEmpty() && grantResults[0] == PackageManager.PERMISSION_GRANTED) listen()
    }

    override fun onDestroy() {
        recognizer?.destroy()
        releaseMic()
        tts?.stop()
        tts?.shutdown()
        TalkBus.state.value = TalkState.IDLE
        Widgets.updateAssistant(this)
        scope.cancel()
        super.onDestroy()
    }
}
