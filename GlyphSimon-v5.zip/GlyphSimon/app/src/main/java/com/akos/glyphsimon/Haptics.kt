package com.akos.glyphsimon

import android.content.Context
import android.os.VibrationEffect
import android.os.VibratorManager

/** Rezgés: rövid jelzés az indító mozdulatra, hosszabb minta a győzelemre. */
class Haptics(context: Context) {
    private val vibrator = context.getSystemService(VibratorManager::class.java).defaultVibrator

    fun tick() {
        vibrator.vibrate(VibrationEffect.createOneShot(80, VibrationEffect.DEFAULT_AMPLITUDE))
    }

    /** Kb. 8 másodperces győzelmi rezgés: lüktető ütemek, a végén egy hosszú. */
    fun win() {
        val pattern = mutableListOf(0L)
        repeat(13) { pattern += listOf(400L, 150L) }
        pattern += 900L
        vibrator.vibrate(VibrationEffect.createWaveform(pattern.toLongArray(), -1))
    }
}
