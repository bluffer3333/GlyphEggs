package com.akos.glyphsimon

/**
 * Minden hangolható érték egy helyen.
 * Ha valami nem úgy működik a telefonon, ahogy szeretnéd, általában itt kell állítani.
 */
object Config {
    // --- Játékszabály ---
    /** true = klasszikus Simon Says: minden körben a teljes sort végig kell dönteni.
     *  false = csak a legújabb LED irányát kell eltalálni. */
    const val FULL_SEQUENCE = true
    /** Ennyi LED gyullad ki a C1 szintjelzőn körönként. */
    const val LEDS_PER_LEVEL = 2
    /** 16 LED / 2 = 8 kör, ekkor betelik a szintjelző és nyersz. */
    const val MAX_ROUNDS = 16 / LEDS_PER_LEVEL

    // --- Indító mozdulat: kijelzővel lefelé, 2x jobbra forgatni az asztalon ---
    /** true = csak akkor figyel, ha a telefon kijelzővel LEFELÉ fekszik (LED-ek felfelé). */
    const val FACE_DOWN_ONLY = true
    /** Hány jobbra forgatás indítja a játékot. */
    const val TURN_COUNT = 2
    /** Egy forgatás névleges szöge (fok). */
    const val TURN_DEGREES = 90f
    /** 0.75 = elég a 90° háromnegyede (~68°), hogy ne kelljen pontosan forgatni. */
    const val TURN_TOLERANCE = 0.75f
    /** Két forgatás között legfeljebb ennyi idő telhet el, különben újrakezdi a számolást. */
    const val TURN_GAP_MS = 4_000L
    /** Ha a jobbra forgatást balra forgatásnak érzékeli, állítsd true-ra. */
    const val INVERT_TURN = false
    /** Lerakás/mozdítás után ennyi ideig marad ébren a processzor a figyeléshez. */
    const val KEEP_AWAKE_MS = 10 * 60 * 1000L
    /** |gravitáció z| ennél nagyobb → vízszintesen fekszik (m/s², max 9.81). */
    const val FLAT_Z = 8.0f

    // --- Döntés felismerése ---
    /** Ekkora oldalirányú gravitációs komponens felett számít döntésnek (~21°). */
    const val TILT_ON = 3.5f
    /** Ez alá kell visszaengedni, hogy "középen" legyen. */
    const val TILT_OFF = 1.5f
    /** Ha a bal/jobb vagy előre/hátra fordítva jön ki, ezeket állítsd true-ra. */
    const val INVERT_X = false
    const val INVERT_Y = false

    // --- Időzítés ---
    /** Mennyi ideig ég egy irány a sor lejátszásakor. */
    const val SHOW_MS = 300L
    /** Szünet két irány között a lejátszásnál. */
    const val GAP_MS = 150L
    const val ANSWER_TIMEOUT_MS = 7_000L
    /** Győzelmi villogás hossza (a rezgés is kb. ennyi). */
    const val WIN_FLASH_MS = 8_000L
}
