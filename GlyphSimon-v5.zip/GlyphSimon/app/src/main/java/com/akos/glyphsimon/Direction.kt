package com.akos.glyphsimon

import com.nothing.ketchum.Glyph

/**
 * A négy döntési irány és a hozzájuk tartozó Phone (2) Glyph zónák.
 * Irányok kijelzővel lefelé fekvő telefonnál, töltőport feléd, kamera bal felül.
 */
enum class Direction(val label: String) {
    /** Kamera felé (felfelé) → kamera körüli gyűrű (A1, A2) + ferde csík (B1) */
    FORWARD("előre"),
    /** Töltőport felé (hátra) → függőleges vonal (D1, 8 zóna) + pont (E1) */
    BACK("hátra"),
    /** Balra (kamera felőli oldal) → bal felső ív (C2) + bal oldali függőleges darab (C3) */
    LEFT("balra"),
    /** Jobbra → jobb alsó ív (C5) + jobb oldali függőleges darab (C6) */
    RIGHT("jobbra");

    fun zones(): IntArray = when (this) {
        FORWARD -> intArrayOf(Glyph.Code_22111.A1, Glyph.Code_22111.A2, Glyph.Code_22111.B1)
        BACK -> intArrayOf(
            Glyph.Code_22111.D1_1, Glyph.Code_22111.D1_2, Glyph.Code_22111.D1_3,
            Glyph.Code_22111.D1_4, Glyph.Code_22111.D1_5, Glyph.Code_22111.D1_6,
            Glyph.Code_22111.D1_7, Glyph.Code_22111.D1_8, Glyph.Code_22111.E1
        )
        LEFT -> intArrayOf(Glyph.Code_22111.C2, Glyph.Code_22111.C3)
        RIGHT -> intArrayOf(Glyph.Code_22111.C5, Glyph.Code_22111.C6)
    }
}

/** Nem irányhoz kötött zónacsoportok. */
object Zones {
    /** C1 szintjelző, 16 LED. C1_1 a jobb alsó vége, C1_16 a bal felső – innen töltődik. */
    val LEVEL: IntArray = intArrayOf(
        Glyph.Code_22111.C1_1, Glyph.Code_22111.C1_2, Glyph.Code_22111.C1_3,
        Glyph.Code_22111.C1_4, Glyph.Code_22111.C1_5, Glyph.Code_22111.C1_6,
        Glyph.Code_22111.C1_7, Glyph.Code_22111.C1_8, Glyph.Code_22111.C1_9,
        Glyph.Code_22111.C1_10, Glyph.Code_22111.C1_11, Glyph.Code_22111.C1_12,
        Glyph.Code_22111.C1_13, Glyph.Code_22111.C1_14, Glyph.Code_22111.C1_15,
        Glyph.Code_22111.C1_16
    )

    /** Mind a 33 zóna (a C4 is, ami játék közben nincs használva). */
    val ALL: IntArray =
        (Direction.entries.flatMap { it.zones().toList() } + LEVEL.toList() +
            listOf(Glyph.Code_22111.C4)).distinct().toIntArray()
}
