package com.akos.glyphsimon

import android.app.PendingIntent
import android.content.Context
import android.content.Intent
import android.service.quicksettings.Tile
import android.service.quicksettings.TileService

/**
 * Gyorsbeállítás-csempe (a lehúzható felső menüben):
 * egy koppintással be- és kikapcsolja a háttérfigyelést.
 */
class SimonTileService : TileService() {

    override fun onStartListening() {
        super.onStartListening()
        show(SimonService.running)
    }

    override fun onClick() {
        super.onClick()
        val turnOn = !SimonService.running
        getSharedPreferences(MainActivity.PREFS, Context.MODE_PRIVATE)
            .edit().putBoolean(MainActivity.KEY_ENABLED, turnOn).apply()

        if (turnOn) {
            try {
                startForegroundService(Intent(this, SimonService::class.java))
            } catch (e: Exception) {
                // Ha a rendszer innen nem engedi elindítani, megnyitjuk az appot
                DebugState.log("Csempéről nem indult: ${e.message}")
                val open = PendingIntent.getActivity(
                    this, 0,
                    Intent(this, MainActivity::class.java).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK),
                    PendingIntent.FLAG_IMMUTABLE
                )
                startActivityAndCollapse(open)
                return
            }
        } else {
            stopService(Intent(this, SimonService::class.java))
        }
        show(turnOn)
    }

    private fun show(on: Boolean) {
        val tile = qsTile ?: return
        tile.state = if (on) Tile.STATE_ACTIVE else Tile.STATE_INACTIVE
        tile.subtitle = if (on) "Figyel" else "Ki"
        tile.updateTile()
    }
}
