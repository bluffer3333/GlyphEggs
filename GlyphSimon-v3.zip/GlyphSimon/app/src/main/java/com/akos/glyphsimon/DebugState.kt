package com.akos.glyphsimon

import android.util.Log
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.update
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

/** A szolgáltatás állapota, amit a főképernyő élőben mutat (hangoláshoz hasznos). */
object DebugState {
    val status = MutableStateFlow("Leállítva")
    val sensor = MutableStateFlow("–")
    val log = MutableStateFlow<List<String>>(emptyList())

    private val fmt = SimpleDateFormat("HH:mm:ss", Locale.getDefault())

    fun log(msg: String) {
        Log.d("GlyphSimon", msg)
        val line = "${fmt.format(Date())}  $msg"
        log.update { (it + line).takeLast(15) }
    }
}
