package com.akos.glyphsimon

import android.content.Context
import android.hardware.Sensor
import android.hardware.SensorEvent
import android.hardware.SensorEventListener
import android.hardware.SensorManager
import android.os.Handler
import android.os.HandlerThread
import android.os.Looper
import android.os.PowerManager
import android.os.SystemClock
import kotlinx.coroutines.flow.MutableStateFlow
import kotlin.math.abs
import kotlin.math.max
import kotlin.math.sqrt

/**
 * Szenzorfigyelés két üzemmódban:
 *  - Készenlét: ha a telefon kijelzővel lefelé fekszik, a giroszkóp számolja a
 *    jobbra forgatásokat (felülről nézve óramutató irányába). 4 forgatás → [onGesture].
 *  - Játék: gyors gyorsulásmérő, a dőlés irányát a [tilt] adja (null = középen).
 */
class MotionDetector(context: Context, private val onGesture: () -> Unit) : SensorEventListener {

    private val sm = context.getSystemService(SensorManager::class.java)

    /** Wake-up változat, ha van: kikapcsolt képernyőnél is felébreszti a processzort. */
    private val accel: Sensor? =
        sm.getDefaultSensor(Sensor.TYPE_ACCELEROMETER, true)
            ?: sm.getDefaultSensor(Sensor.TYPE_ACCELEROMETER)
    private val gyro: Sensor? = sm.getDefaultSensor(Sensor.TYPE_GYROSCOPE)

    private val thread = HandlerThread("glyph-motion").apply { start() }
    private val handler = Handler(thread.looper)
    private val mainHandler = Handler(Looper.getMainLooper())

    private val wakeLock = context.getSystemService(PowerManager::class.java)
        .newWakeLock(PowerManager.PARTIAL_WAKE_LOCK, "GlyphSimon:motion")
        .apply { setReferenceCounted(false) }

    /** Aktuális dőlés iránya játék közben (null = középen). */
    val tilt = MutableStateFlow<Direction?>(null)

    private val g = FloatArray(3)
    private var gInit = false
    private var gameMode = false
    private var wasFlat = false

    private var gyroOn = false
    private var lastGyroNs = 0L
    private var turnAngle = 0f
    private var turns = 0
    private var lastTurnMs = 0L
    private var cooldownUntil = 0L

    private var lastDebug = 0L

    fun start() {
        if (accel == null) {
            DebugState.log("Nincs gyorsulásmérő!")
            return
        }
        if (gyro == null) DebugState.log("Nincs giroszkóp – a forgatás nem fog működni")
        registerAccel(game = false)
        DebugState.log("Szenzorfigyelés indult (wake-up gyorsulásmérő: ${accel.isWakeUpSensor})")
    }

    fun stop() {
        handler.post {
            sm.unregisterListener(this)
            gyroOn = false
            if (wakeLock.isHeld) wakeLock.release()
            thread.quitSafely()
        }
    }

    fun setGameMode(on: Boolean) {
        handler.post {
            if (gameMode == on) return@post
            gameMode = on
            setGyro(false)
            tilt.value = null
            registerAccel(game = on)
            if (on) {
                wakeLock.acquire(15 * 60 * 1000L)
            } else {
                if (wakeLock.isHeld) wakeLock.release()
                cooldownUntil = SystemClock.elapsedRealtime() + 3_000
                wasFlat = false
            }
        }
    }

    private fun registerAccel(game: Boolean) {
        val s = accel ?: return
        sm.unregisterListener(this, s)
        if (game) {
            sm.registerListener(this, s, SensorManager.SENSOR_DELAY_GAME, 0, handler)
        } else {
            // ~5 Hz, 1 mp-es kötegelés: kevés ébresztés, alacsony fogyasztás
            sm.registerListener(this, s, SensorManager.SENSOR_DELAY_NORMAL, 1_000_000, handler)
        }
    }

    private fun setGyro(on: Boolean) {
        if (on == gyroOn) return
        val s = gyro ?: return
        gyroOn = on
        if (on) {
            resetTurns()
            lastGyroNs = 0L
            sm.registerListener(this, s, SensorManager.SENSOR_DELAY_GAME, 0, handler)
            keepAwake()
            DebugState.log("Forgatásfigyelés bekapcsolva")
        } else {
            sm.unregisterListener(this, s)
            if (!gameMode && wakeLock.isHeld) wakeLock.release()
        }
    }

    private fun keepAwake() = wakeLock.acquire(Config.KEEP_AWAKE_MS)

    private fun resetTurns() {
        turns = 0
        turnAngle = 0f
    }

    override fun onSensorChanged(event: SensorEvent) {
        when (event.sensor.type) {
            Sensor.TYPE_ACCELEROMETER -> onAccel(event.values)
            Sensor.TYPE_GYROSCOPE -> onGyro(event)
        }
    }

    private fun onAccel(v: FloatArray) {
        // Aluláteresztő szűrő: a rázkódást kiszűri, a gravitáció marad
        val alpha = if (gameMode) 0.7f else 0.3f
        if (!gInit) {
            v.copyInto(g, 0, 0, 3)
            gInit = true
        } else {
            for (i in 0..2) g[i] = alpha * g[i] + (1 - alpha) * v[i]
        }

        val now = SystemClock.elapsedRealtime()
        if (gameMode) {
            updateTilt()
        } else {
            val flat = if (Config.FACE_DOWN_ONLY) g[2] < -Config.FLAT_Z else abs(g[2]) > Config.FLAT_Z
            val mag = sqrt(v[0] * v[0] + v[1] * v[1] + v[2] * v[2])
            val moved = abs(mag - SensorManager.GRAVITY_EARTH) > 0.3f
            // Frissen lerakták vagy megmozdították → ébren marad egy ideig
            if (flat && (!wasFlat || moved)) keepAwake()
            wasFlat = flat
            setGyro(flat && now > cooldownUntil)
        }

        if (now - lastDebug > 150) {
            lastDebug = now
            DebugState.sensor.value = "x=%.1f  y=%.1f  z=%.1f\ndőlés: %s\njobbra forgatás: %d/%d (%.0f°)   giroszkóp: %s".format(
                g[0], g[1], g[2],
                tilt.value?.label ?: "középen",
                turns, Config.TURN_COUNT,
                Math.toDegrees(turnAngle.toDouble()),
                if (gyroOn) "be" else "ki"
            )
        }
    }

    private fun updateTilt() {
        var x = g[0]
        var y = g[1]
        if (Config.INVERT_X) x = -x
        if (Config.INVERT_Y) y = -y
        val ax = abs(x)
        val ay = abs(y)
        val m = max(ax, ay)
        // Hátulról nézve: jobb oldal le → x > 0; kamerás vég le → y < 0
        val new = when {
            m < Config.TILT_OFF -> null
            m >= Config.TILT_ON ->
                if (ax > ay) {
                    if (x > 0) Direction.RIGHT else Direction.LEFT
                } else {
                    if (y < 0) Direction.FORWARD else Direction.BACK
                }
            else -> tilt.value
        }
        if (new != tilt.value) tilt.value = new
    }

    private fun onGyro(event: SensorEvent) {
        if (!gyroOn) return
        val ts = event.timestamp
        val prev = lastGyroNs
        lastGyroNs = ts
        if (prev == 0L) return
        val dt = (ts - prev) / 1_000_000_000f
        if (dt !in 0f..0.5f) return

        // Kijelzővel lefelé fekve a +z tengely lefelé mutat, így felülről nézve
        // az óramutató irányú (jobbra) forgatás pozitív z-szögsebességet ad.
        var w = event.values[2]
        if (Config.INVERT_TURN) w = -w
        if (abs(w) < 0.15f) return // állás közbeni zaj/drift kiszűrése
        if (abs(w) > 0.5f) keepAwake()

        val now = SystemClock.elapsedRealtime()
        if (turns > 0 && now - lastTurnMs > Config.TURN_GAP_MS) {
            DebugState.log("Forgatás számlálás újraindult (túl lassú)")
            resetTurns()
        }

        // Balra forgatás nem számít, de le is nullázza a félkész forgatást
        turnAngle = (turnAngle + w * dt).coerceAtLeast(0f)
        val need = Math.toRadians(Config.TURN_DEGREES.toDouble()).toFloat() * Config.TURN_TOLERANCE
        if (turnAngle >= need) {
            turns++
            turnAngle = 0f
            lastTurnMs = now
            DebugState.log("Jobbra forgatás: $turns/${Config.TURN_COUNT}")
            if (turns >= Config.TURN_COUNT) {
                DebugState.log("Indító mozdulat felismerve!")
                resetTurns()
                cooldownUntil = now + 5_000
                setGyro(false)
                mainHandler.post { onGesture() }
            }
        }
    }

    override fun onAccuracyChanged(sensor: Sensor?, accuracy: Int) = Unit
}
