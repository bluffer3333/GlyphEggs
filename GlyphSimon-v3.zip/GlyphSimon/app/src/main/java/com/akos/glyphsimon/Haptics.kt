package com.akos.glyphsimon

import android.content.Context
import android.os.VibrationEffect
import android.os.VibratorManager

/** Rezgés: rövid jelzés az indító mozdulatra, hosszabb minta a győzelemre. */
class Haptics(context: Context) {
    private val vibrator = context.getSystemService(VibratorManager::class.java).defaultVibrator

    fun tick() {
        vibrator.vibrate(VibrationEffect.createOneShot(80, VibrationEffect.DEFAULT_AMPLITUDE))
    }

    fun win() {
        vibrator.vibrate(
            VibrationEffect.createWaveform(longArrayOf(0, 300, 120, 300, 120, 300, 120, 800), -1)
        )
    }
}
