package com.akos.glyphsimon

import android.content.ComponentName
import android.content.Context
import com.nothing.ketchum.Glyph
import com.nothing.ketchum.GlyphException
import com.nothing.ketchum.GlyphManager

/** Vékony réteg a Nothing GlyphManager körül. */
class GlyphController(context: Context) {

    private val gm: GlyphManager = GlyphManager.getInstance(context.applicationContext)

    @Volatile
    var connected = false
        private set

    @Volatile
    private var sessionOpen = false

    private val callback = object : GlyphManager.Callback {
        override fun onServiceConnected(componentName: ComponentName) {
            val ok = gm.register(Glyph.DEVICE_22111)
            connected = true
            DebugState.log("Glyph szolgáltatás csatlakozva (regisztráció: $ok)")
        }

        override fun onServiceDisconnected(componentName: ComponentName) {
            connected = false
            sessionOpen = false
            DebugState.log("Glyph szolgáltatás lecsatlakozott")
        }
    }

    fun init() = gm.init(callback)

    /** Csak a játék idejére nyitjuk meg, hogy a rendszer saját Glyph-értesítései máskor működjenek. */
    fun openSession(): Boolean {
        if (!connected) {
            DebugState.log("Glyph még nincs csatlakozva")
            return false
        }
        return try {
            gm.openSession()
            sessionOpen = true
            true
        } catch (e: GlyphException) {
            DebugState.log("openSession hiba: ${e.message}")
            false
        }
    }

    fun closeSession() {
        if (!sessionOpen) return
        try {
            gm.turnOff()
            gm.closeSession()
        } catch (e: GlyphException) {
            DebugState.log("closeSession hiba: ${e.message}")
        }
        sessionOpen = false
    }

    /** A megadott zónák kigyújtása (minden más kialszik). */
    fun show(zones: IntArray) {
        if (!sessionOpen) return
        val builder = gm.glyphFrameBuilder
        zones.forEach { builder.buildChannel(it) }
        gm.toggle(builder.build())
    }

    fun off() {
        if (sessionOpen) gm.turnOff()
    }

    /** Pontszám kijelzése a C1 ív 16 zónáján, mint egy töltéscsík. */
    fun progress(percent: Int) {
        if (!sessionOpen) return
        try {
            gm.displayProgress(gm.glyphFrameBuilder.buildChannelC().build(), percent.coerceIn(0, 100))
        } catch (e: GlyphException) {
            DebugState.log("displayProgress hiba: ${e.message}")
        }
    }

    fun release() {
        closeSession()
        gm.unInit()
        connected = false
    }
}
