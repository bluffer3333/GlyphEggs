plugins {
    id("com.android.application")
    id("org.jetbrains.kotlin.android")
}

android {
    namespace = "com.akos.glyphsimon"
    compileSdk = 35

    defaultConfig {
        applicationId = "com.akos.glyphsimon"
        // A Glyph SDK csak Android 14+ Nothing telefonokon működik
        minSdk = 34
        targetSdk = 35
        versionCode = 1
        versionName = "1.0"
    }

    buildTypes {
        release {
            isMinifyEnabled = false
        }
    }

    compileOptions {
        sourceCompatibility = JavaVersion.VERSION_17
        targetCompatibility = JavaVersion.VERSION_17
    }
    kotlinOptions {
        jvmTarget = "17"
    }
}

dependencies {
    // Nothing hivatalos Glyph SDK (github.com/Nothing-Developer-Programme/Glyph-Developer-Kit)
    implementation(files("libs/glyph-matrix-sdk-2.0.aar"))
    implementation("org.jetbrains.kotlinx:kotlinx-coroutines-android:1.9.0")
}
