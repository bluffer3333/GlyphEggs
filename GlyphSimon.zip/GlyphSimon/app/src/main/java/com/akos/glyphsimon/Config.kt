package com.akos.glyphsimon

/**
 * Minden hangolható érték egy helyen.
 * Ha valami nem úgy működik a telefonon, ahogy szeretnéd, általában itt kell állítani.
 */
object Config {
    // --- Játékszabály ---
    /** true = klasszikus Simon Says: minden körben a teljes sort végig kell dönteni.
     *  false = csak a legújabb LED irányát kell eltalálni. */
    const val FULL_SEQUENCE = true
    /** Ennyi kör után nyersz (a C1 progress-sáv 16 zónás, de mehet tovább is). */
    const val MAX_ROUNDS = 32

    // --- Indító mozdulat: 3x megpörgetni az asztalon ---
    /** true = csak akkor figyel, ha a telefon kijelzővel LEFELÉ fekszik (LED-ek felfelé). */
    const val FACE_DOWN_ONLY = true
    const val SPIN_TURNS = 3
    /** 0.85 = elég a 3 kör 85%-a (kb. 920°), hogy ne kelljen tökéletesen pörgetni. */
    const val SPIN_TOLERANCE = 0.85f
    /** Ennyi időn belül kell meglennie a 3 körnek. */
    const val SPIN_WINDOW_MS = 6_000L
    /** Lerakás vagy érintés után ennyi ideig figyel a giroszkóp (akkukímélés). */
    const val SPIN_ARM_MS = 20_000L
    /** |gravitáció z| ennél nagyobb → vízszintesen fekszik (m/s², max 9.81). */
    const val FLAT_Z = 8.0f

    // --- Döntés felismerése ---
    /** Ekkora oldalirányú gravitációs komponens felett számít döntésnek (~21°). */
    const val TILT_ON = 3.5f
    /** Ez alá kell visszaengedni, hogy "középen" legyen. */
    const val TILT_OFF = 1.5f
    /** Ha a bal/jobb vagy előre/hátra fordítva jön ki, ezeket állítsd true-ra. */
    const val INVERT_X = false
    const val INVERT_Y = false

    // --- Időzítés ---
    const val SHOW_MS = 550L
    const val GAP_MS = 300L
    const val ANSWER_TIMEOUT_MS = 7_000L
}
