package com.akos.glyphsimon

import com.nothing.ketchum.Glyph

/**
 * A négy döntési irány és a hozzájuk tartozó Phone (2) Glyph zónák.
 * Irányok a telefon HÁTULJÁRÓL nézve (kamera bal felül).
 */
enum class Direction(val label: String) {
    /** A kamerás vég lefelé → kamera körüli gyűrű (A1, A2) + ferde csík (B1) */
    FORWARD("előre"),
    /** Az alsó vég lefelé → függőleges vonal (D1, 8 zóna) + pont (E1) */
    BACK("hátra"),
    /** Bal oldal lefelé → a nagy gyűrű többi íve (C2–C6) */
    LEFT("balra"),
    /** Jobb oldal lefelé → a nagy gyűrű jobb felső negyede (C1, 16 zóna) */
    RIGHT("jobbra");

    fun zones(): IntArray = when (this) {
        FORWARD -> intArrayOf(
            Glyph.Code_22111.A1, Glyph.Code_22111.A2, Glyph.Code_22111.B1
        )
        BACK -> intArrayOf(
            Glyph.Code_22111.D1_1, Glyph.Code_22111.D1_2, Glyph.Code_22111.D1_3,
            Glyph.Code_22111.D1_4, Glyph.Code_22111.D1_5, Glyph.Code_22111.D1_6,
            Glyph.Code_22111.D1_7, Glyph.Code_22111.D1_8, Glyph.Code_22111.E1
        )
        LEFT -> intArrayOf(
            Glyph.Code_22111.C2, Glyph.Code_22111.C3, Glyph.Code_22111.C4,
            Glyph.Code_22111.C5, Glyph.Code_22111.C6
        )
        RIGHT -> intArrayOf(
            Glyph.Code_22111.C1_1, Glyph.Code_22111.C1_2, Glyph.Code_22111.C1_3,
            Glyph.Code_22111.C1_4, Glyph.Code_22111.C1_5, Glyph.Code_22111.C1_6,
            Glyph.Code_22111.C1_7, Glyph.Code_22111.C1_8, Glyph.Code_22111.C1_9,
            Glyph.Code_22111.C1_10, Glyph.Code_22111.C1_11, Glyph.Code_22111.C1_12,
            Glyph.Code_22111.C1_13, Glyph.Code_22111.C1_14, Glyph.Code_22111.C1_15,
            Glyph.Code_22111.C1_16
        )
    }

    companion object {
        fun allZones(): IntArray = entries.flatMap { it.zones().toList() }.toIntArray()
    }
}
