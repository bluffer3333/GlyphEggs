package com.akos.glyphsimon

import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.first
import kotlinx.coroutines.withTimeoutOrNull
import kotlin.random.Random

/**
 * A Simon Says játékmenet:
 *  1. Bevezető: a négy irány körbefut háromszor, majd minden felvillan.
 *  2. Minden körben egy új, véletlen irány kerül a sor végére.
 *  3. A telefon lejátssza a sort (az eddig eltaláltakat + az újat).
 *  4. A játékos a felvillant LED felé dönti a telefont, utána vissza középre.
 *     Jó válasznál az eltalált LED felvillan, rossznál vége a játéknak.
 */
class SimonGame(
    private val glyph: GlyphController,
    private val motion: MotionDetector
) {
    private val all = Direction.allZones()

    /** Visszaadja a pontszámot (hány kört teljesített). */
    suspend fun run(): Int {
        intro()
        val sequence = mutableListOf<Direction>()
        var score = 0

        while (sequence.size < Config.MAX_ROUNDS) {
            sequence += nextDirection(sequence)
            delay(500)
            playSequence(sequence)

            val toAnswer = if (Config.FULL_SEQUENCE) sequence.toList() else listOf(sequence.last())
            for (expected in toAnswer) {
                val answer = waitForTilt()
                if (answer == null) {
                    DebugState.log("Lejárt az idő")
                    return fail(score)
                }
                if (answer != expected) {
                    DebugState.log("Rossz irány: ${answer.label} (kellett: ${expected.label})")
                    glyph.show(answer.zones())
                    delay(300)
                    return fail(score)
                }
                // Jó válasz: az eltalált LED felvillan
                glyph.show(expected.zones())
                delay(300)
                glyph.off()
                waitNeutral()
            }

            score = sequence.size
            DebugState.log("Kör teljesítve: $score")
            delay(350)
        }

        win()
        return score
    }

    private suspend fun intro() {
        repeat(3) {
            for (d in listOf(Direction.FORWARD, Direction.RIGHT, Direction.BACK, Direction.LEFT)) {
                glyph.show(d.zones())
                delay(110)
            }
        }
        glyph.show(all)
        delay(400)
        glyph.off()
        delay(600)
    }

    private suspend fun playSequence(sequence: List<Direction>) {
        for (d in sequence) {
            glyph.show(d.zones())
            delay(Config.SHOW_MS)
            glyph.off()
            delay(Config.GAP_MS)
        }
    }

    /** Megvárja, hogy a telefon középen legyen, utána az első határozott dőlést. */
    private suspend fun waitForTilt(): Direction? {
        waitNeutral()
        return withTimeoutOrNull(Config.ANSWER_TIMEOUT_MS) {
            motion.tilt.first { it != null }
        }
    }

    private suspend fun waitNeutral() {
        withTimeoutOrNull(Config.ANSWER_TIMEOUT_MS) {
            motion.tilt.first { it == null }
        }
    }

    /** Véletlen irány, de háromszor egymás után ugyanaz nem jön. */
    private fun nextDirection(seq: List<Direction>): Direction {
        val options = Direction.entries.toMutableList()
        if (seq.size >= 2 && seq[seq.size - 1] == seq[seq.size - 2]) options.remove(seq.last())
        return options[Random.nextInt(options.size)]
    }

    private suspend fun fail(score: Int): Int {
        repeat(4) {
            glyph.show(all)
            delay(120)
            glyph.off()
            delay(120)
        }
        delay(400)
        showScore(score)
        return score
    }

    private suspend fun win() {
        repeat(6) {
            for (d in Direction.entries) {
                glyph.show(d.zones())
                delay(70)
            }
        }
        glyph.show(all)
        delay(1500)
        glyph.off()
    }

    /** Pontszám a C1 ív 16 zónáján: minden kör egy zóna. */
    private suspend fun showScore(score: Int) {
        glyph.progress(score * 100 / 16)
        delay(3000)
        glyph.off()
    }
}
