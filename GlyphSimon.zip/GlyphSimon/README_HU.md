# Glyph Simon – Simon Says a Nothing Phone (2) LED-jeivel

## Mit csinál

1. A háttérben fut, állandó értesítéssel.
2. Tedd le a telefont kijelzővel lefelé, és pörgesd meg háromszor az asztalon.
3. A LED-ek háromszor körbefutnak, majd elindul a játék.
4. Felvillan egy irány. Döntsd a telefont arra, aztán engedd vissza középre.
5. Ha eltaláltad, felvillan az eltalált LED. Utána a telefon lejátssza az eddigi sort és egy újat. Ezt kell végigdöntened.
6. Rossz iránynál vagy 7 mp tétlenség után vége. A pontszámot a gyűrű jobb felső íve mutatja, körönként egy zónával.

Irányok a telefon hátuljáról nézve (kamera bal felül):

| Döntés | LED |
|---|---|
| Előre (kamerás vég le) | Kamera körüli gyűrű + ferde csík (A1, A2, B1) |
| Hátra (alsó vég le) | Függőleges vonal + pont (D1, E1) |
| Jobbra | Nagy gyűrű jobb felső negyede (C1, 16 zóna) |
| Balra | Nagy gyűrű többi íve (C2–C6) |

## APK készítése

### A) Számítógépen, Android Studióval

1. Telepítsd az Android Studiót: developer.android.com/studio
2. Csomagold ki a zipet, és nyisd meg a `GlyphSimon` mappát: **File → Open**.
3. Várd meg, amíg a Gradle szinkronizál. Az első alkalommal ez letölt mindent, eltarthat pár percig.
4. **Build → Build App Bundle(s) / APK(s) → Build APK(s)**
5. Az APK itt lesz: `app/build/outputs/apk/debug/app-debug.apk`

Ha a telefon USB-n csatlakozik, bekapcsolt USB-hibakereséssel, a zöld ▶ gomb egyből fel is telepíti.

### B) Számítógép nélkül, GitHubbal

1. Hozz létre egy új, privát GitHub repót, és töltsd fel bele a mappa teljes tartalmát. A rejtett `.github` mappa is kell!
2. A feltöltés után a GitHub magától elkezdi építeni az APK-t (**Actions** fül).
3. Ha zöld pipa jelent meg, nyisd meg a futást, és lent az **Artifacts** résznél töltsd le a `glyph-simon-apk` fájlt.
4. Ez egy zip, benne az `app-debug.apk`.

### Telepítés a telefonra

1. Másold át az APK-t, és nyisd meg a telefonon.
2. Engedélyezd az "Ismeretlen forrásból származó alkalmazások telepítése" opciót annál az appnál, amivel megnyitod (pl. Fájlok).

## A Glyph engedélyezése (fontos!)

A Nothing a külső appoknak csak fejlesztői módban engedi a Glyph vezérlését:

- **Ha a telefonon Android 16 / Nothing OS 4 fut:** nem kell külön kulcs, működnie kell.
- **Ha régebbi rendszer fut:** számítógépről, USB-n kell egyszer kiadni ezt a parancsot:
  ```
  adb shell settings put global nt_glyph_interface_debug_enable 1
  ```
  Ez 48 óra után magától kikapcsol, akkor újra ki kell adni.

## Első indítás

1. Nyisd meg a **Glyph Simon** appot, és engedélyezd az értesítéseket.
2. Nyomd meg az **Akkumulátor-optimalizálás kikapcsolása** gombot. Enélkül a rendszer leállíthatja a háttérben.
3. Először a **Játék indítása most (teszt)** gombbal próbáld ki, nyitott apppal.
4. Nézd az **Élő szenzoradatok** részt: döntsd a telefont, és figyeld, jó irányt ír-e.
5. Ha minden rendben, nyomd meg a **Háttérfigyelés indítása** gombot.

## Hangolás

Minden beállítás az `app/src/main/java/com/akos/glyphsimon/Config.kt` fájlban van:

- `FULL_SEQUENCE`: `true` esetén a teljes sort végig kell dönteni, `false` esetén csak az újat.
- `INVERT_X` / `INVERT_Y`: ha a bal/jobb vagy az előre/hátra fordítva jön ki.
- `TILT_ON`: mekkora döntés számít. Kisebb szám = érzékenyebb.
- `SPIN_TOLERANCE`, `SPIN_WINDOW_MS`: mennyire pontos és gyors pörgetés kell.
- `SHOW_MS`, `ANSWER_TIMEOUT_MS`: a játék tempója.

## Ismert korlátok

- **A kód nincs telefonon kipróbálva.** A Nothing hivatalos SDK-jára épül, de az első futtatásnál számíts kisebb hangolásra.
- A Nothing leírása szerint a Glyph-et "előtérben lévő" app vezérelheti. Ha a háttérből indított játéknál nem gyulladnak ki a LED-ek, de a tesztgombbal igen, akkor ez a korlát okozza. A napló ilyenkor `openSession hiba` üzenetet mutat.
- A Nothing **Flip to Glyph** funkciója (kijelzővel lefelé fordítás) ütközhet ezzel. Ha furcsán viselkedik, kapcsold ki a Glyph beállításokban.
- A "balra" irány a gyűrű C2–C6 íveit használja. Ezek pontos helyét a Nothing nem írja le részletesen. Ha nem tetszik, a `Direction.kt` fájlban átírhatod.
