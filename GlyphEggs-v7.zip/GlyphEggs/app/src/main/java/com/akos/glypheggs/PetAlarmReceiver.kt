package com.akos.glypheggs

import android.app.AlarmManager
import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.os.SystemClock

/**
 * Óránként (pontatlanul, akkukímélően) ránéz a Tojásra, és ha valami kell neki
 * (éhes, piszkos, beteg…), értesítést küld. Legfeljebb 3 óránként szól.
 */
class PetAlarmReceiver : BroadcastReceiver() {

    companion object {
        private const val CHANNEL = "glyph_eggs_pet"
        private const val NOTIF_ID = 21
        private const val MIN_GAP_MS = 3 * 3_600_000L

        /** Beállítja az óránkénti ellenőrzést (többször hívva sem duplikál). */
        fun schedule(context: Context) {
            val am = context.getSystemService(AlarmManager::class.java)
            val pi = PendingIntent.getBroadcast(
                context, 0, Intent(context, PetAlarmReceiver::class.java),
                PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT
            )
            am.setInexactRepeating(
                AlarmManager.ELAPSED_REALTIME,
                SystemClock.elapsedRealtime() + AlarmManager.INTERVAL_HOUR,
                AlarmManager.INTERVAL_HOUR,
                pi
            )
        }
    }

    override fun onReceive(context: Context, intent: Intent) {
        val s = PetStore.load(context)
        if (!Settings.petNotifications(context)) return
        val need = s.need() ?: return
        val now = System.currentTimeMillis()
        if (now - s.lastNotified < MIN_GAP_MS) return
        s.lastNotified = now
        PetStore.save(context, s)

        val nm = context.getSystemService(NotificationManager::class.java)
        nm.createNotificationChannel(NotificationChannel(CHANNEL, "Glyph Tojás", NotificationManager.IMPORTANCE_DEFAULT))
        val open = PendingIntent.getActivity(
            context, 21, Intent(context, PetActivity::class.java).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK),
            PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT
        )
        val n = Notification.Builder(context, CHANNEL)
            .setSmallIcon(R.drawable.ic_pet)
            .setContentTitle("A Glyph Tojásod $need")
            .setContentText("Koppints, és gondozd – vagy tedd le kijelzővel lefelé, és kopogj.")
            .setContentIntent(open)
            .setAutoCancel(true)
            .build()
        nm.notify(NOTIF_ID, n)
    }
}
