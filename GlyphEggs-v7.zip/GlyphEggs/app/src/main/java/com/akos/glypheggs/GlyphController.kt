package com.akos.glypheggs

import android.content.ComponentName
import android.content.Context
import com.nothing.ketchum.Glyph
import com.nothing.ketchum.GlyphException
import com.nothing.ketchum.GlyphManager

/**
 * Vékony réteg a Nothing GlyphManager körül.
 * Minden kigyújtást a [GlyphMirror]-ba is beír, így a képernyőn is látszik.
 * Ha nincs Glyph (más telefon, vagy nincs engedély), csak a tükörkép frissül.
 */
class GlyphController(context: Context) {

    private val gm: GlyphManager? = try {
        GlyphManager.getInstance(context.applicationContext)
    } catch (t: Throwable) {
        DebugState.log("Glyph SDK nem érhető el: ${t.javaClass.simpleName}")
        null
    }

    @Volatile
    var connected = false
        private set

    @Volatile
    private var sessionOpen = false

    private val callback = object : GlyphManager.Callback {
        override fun onServiceConnected(componentName: ComponentName) {
            val ok = try {
                gm?.register(Glyph.DEVICE_22111) ?: false
            } catch (t: Throwable) {
                false
            }
            connected = true
            DebugState.log("Glyph szolgáltatás csatlakozva (regisztráció: $ok)")
        }

        override fun onServiceDisconnected(componentName: ComponentName) {
            connected = false
            sessionOpen = false
            GlyphMirror.hardware.value = false
            DebugState.log("Glyph szolgáltatás lecsatlakozott")
        }
    }

    fun init() {
        try {
            gm?.init(callback)
        } catch (t: Throwable) {
            DebugState.log("Glyph init hiba: ${t.javaClass.simpleName} – csak szimuláció")
        }
    }

    /**
     * Csak a feladat idejére nyitjuk meg, hogy a rendszer saját Glyph-értesítései máskor működjenek.
     * Ha nem sikerül, a feladat attól még fut, csak a képernyőn látszik.
     */
    fun openSession(): Boolean {
        val m = gm
        if (m == null || !connected) return false
        return try {
            m.openSession()
            sessionOpen = true
            GlyphMirror.hardware.value = true
            true
        } catch (e: GlyphException) {
            DebugState.log("openSession hiba: ${e.message}")
            false
        } catch (t: Throwable) {
            DebugState.log("openSession hiba: ${t.javaClass.simpleName}")
            false
        }
    }

    fun closeSession() {
        GlyphMirror.lit.value = emptySet()
        GlyphMirror.hardware.value = false
        if (!sessionOpen) return
        try {
            gm?.turnOff()
            gm?.closeSession()
        } catch (e: GlyphException) {
            DebugState.log("closeSession hiba: ${e.message}")
        } catch (t: Throwable) {
            DebugState.log("closeSession hiba: ${t.javaClass.simpleName}")
        }
        sessionOpen = false
    }

    /** A megadott zónák kigyújtása (minden más kialszik). */
    fun show(zones: IntArray) {
        GlyphMirror.lit.value = zones.toSet()
        val m = gm ?: return
        if (!sessionOpen) return
        try {
            val builder = m.glyphFrameBuilder
            zones.forEach { builder.buildChannel(it) }
            m.toggle(builder.build())
        } catch (t: Throwable) {
            DebugState.log("Glyph kijelzés hiba: ${t.javaClass.simpleName}")
        }
    }

    fun off() {
        GlyphMirror.lit.value = emptySet()
        if (!sessionOpen) return
        try {
            gm?.turnOff()
        } catch (t: Throwable) {
            DebugState.log("Glyph kikapcsolás hiba: ${t.javaClass.simpleName}")
        }
    }

    fun release() {
        closeSession()
        try {
            gm?.unInit()
        } catch (t: Throwable) {
            // nincs teendő
        }
        connected = false
    }
}
