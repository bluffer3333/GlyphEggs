package com.akos.glypheggs

import android.content.Context
import kotlinx.coroutines.flow.MutableSharedFlow
import kotlin.math.max
import kotlin.math.min

/** A Tojás fejlődési szakaszai. */
enum class PetStage(val title: String) {
    EGG("Tojás"),
    BABY("Kicsi"),
    TEEN("Kamasz"),
    ADULT("Felnőtt")
}

/** Hangulat – ebből választja a LED-animációt. */
enum class PetMood(val title: String) {
    HAPPY("Boldog"),
    OK("Elégedett"),
    SAD("Szomorú"),
    SICK("Beteg"),
    SLEEP("Alszik")
}

/** Gondozási műveletek. A [knocks] azt mutatja, hány kopogás váltja ki a LED-es gondozásban (0 = mással). */
enum class PetAction(val title: String, val knocks: Int) {
    PET("Simogatás", 1),
    FEED("Etetés", 2),
    PLAY("Játék", 3),
    SLEEP("Altatás / ébresztés", 4),
    CLEAN("Fürdetés", 0),
    HEAL("Gyógyítás", 0)
}

/** A Tojás teljes állapota. Az értékek 0–100 között (100 = minden rendben). */
class PetState(
    var stage: PetStage = PetStage.EGG,
    var food: Float = 80f,
    var fun_: Float = 80f,
    var energy: Float = 90f,
    var clean: Float = 100f,
    var sick: Boolean = false,
    var asleep: Boolean = false,
    var poops: Int = 0,
    var warmth: Int = 0,
    var bornAt: Long = System.currentTimeMillis(),
    var hatchedAt: Long = 0L,
    var lastUpdate: Long = System.currentTimeMillis(),
    var neglectMs: Long = 0L,
    var sinceLastPoopMs: Long = 0L,
    var lastNotified: Long = 0L,
    var ranAway: Boolean = false
) {
    val mood: PetMood
        get() = when {
            asleep -> PetMood.SLEEP
            sick -> PetMood.SICK
            minOf(food, fun_, energy, clean) < 25f || poops >= 2 -> PetMood.SAD
            fun_ > 65f && food > 50f -> PetMood.HAPPY
            else -> PetMood.OK
        }

    /** Életkor órában a kikelés óta. */
    fun ageHours(now: Long = System.currentTimeMillis()): Float =
        if (hatchedAt == 0L) 0f else (now - hatchedAt) / 3_600_000f

    /** Mi a legsürgősebb gond (értesítéshez, kijelzéshez). */
    fun need(): String? = when {
        stage == PetStage.EGG -> null
        sick -> "beteg, gyógyítsd meg"
        food < 25f -> "éhes"
        poops >= 2 || clean < 25f -> "piszkos, fürdesd meg"
        energy < 20f && !asleep -> "álmos"
        fun_ < 25f -> "unatkozik"
        else -> null
    }
}

/**
 * A Tojás mentése és "élete". Az idő múlását mindig betöltéskor számolja ki,
 * így a háttérben nem kell folyamatosan futnia semminek.
 */
object PetStore {
    private const val PREFS = "glyph_eggs_pet"
    private val lock = Any()

    /** Értesítés a futó LED-es gondozásnak, ha az appból gondoztad. */
    val actions = MutableSharedFlow<PetAction>(extraBufferCapacity = 8)

    // óránkénti változások
    private const val FOOD_PER_H = 7f
    private const val FUN_PER_H = 5f
    private const val ENERGY_AWAKE_PER_H = 4.5f
    private const val ENERGY_SLEEP_PER_H = 20f
    private const val CLEAN_PER_H = 3f
    private const val POOP_EVERY_MS = 3 * 3_600_000L
    private const val SICK_AFTER_NEGLECT_MS = 4 * 3_600_000L
    private const val RUN_AWAY_NEGLECT_MS = 48 * 3_600_000L
    private const val HATCH_AFTER_MS = 20 * 60_000L
    private const val HATCH_WARMTH = 3

    fun load(c: Context): PetState = synchronized(lock) {
        val p = c.getSharedPreferences(PREFS, Context.MODE_PRIVATE)
        val s = if (!p.contains("bornAt")) {
            PetState()
        } else {
            PetState(
                stage = PetStage.entries.getOrElse(p.getInt("stage", 0)) { PetStage.EGG },
                food = p.getFloat("food", 80f),
                fun_ = p.getFloat("fun", 80f),
                energy = p.getFloat("energy", 90f),
                clean = p.getFloat("clean", 100f),
                sick = p.getBoolean("sick", false),
                asleep = p.getBoolean("asleep", false),
                poops = p.getInt("poops", 0),
                warmth = p.getInt("warmth", 0),
                bornAt = p.getLong("bornAt", System.currentTimeMillis()),
                hatchedAt = p.getLong("hatchedAt", 0L),
                lastUpdate = p.getLong("lastUpdate", System.currentTimeMillis()),
                neglectMs = p.getLong("neglect", 0L),
                sinceLastPoopMs = p.getLong("sincePoop", 0L),
                lastNotified = p.getLong("lastNotified", 0L)
            )
        }
        advance(s, System.currentTimeMillis())
        val result = if (s.ranAway) {
            // Hosszú elhanyagolás után "elköltözött" – új tojás érkezik
            p.edit().putBoolean("ranAwayNote", true).apply()
            DebugState.log("A Tojás elköltözött, mert sokáig beteg volt. Új tojás érkezett.")
            PetState()
        } else s
        save(c, result)
        result
    }

    /** Egyszer igaz, ha a Tojás elköltözött (az app megmutatja). */
    fun takeRanAwayNote(c: Context): Boolean = synchronized(lock) {
        val p = c.getSharedPreferences(PREFS, Context.MODE_PRIVATE)
        val v = p.getBoolean("ranAwayNote", false)
        if (v) p.edit().putBoolean("ranAwayNote", false).apply()
        v
    }

    fun save(c: Context, s: PetState) = synchronized(lock) {
        c.getSharedPreferences(PREFS, Context.MODE_PRIVATE).edit()
            .putInt("stage", s.stage.ordinal)
            .putFloat("food", s.food)
            .putFloat("fun", s.fun_)
            .putFloat("energy", s.energy)
            .putFloat("clean", s.clean)
            .putBoolean("sick", s.sick)
            .putBoolean("asleep", s.asleep)
            .putInt("poops", s.poops)
            .putInt("warmth", s.warmth)
            .putLong("bornAt", s.bornAt)
            .putLong("hatchedAt", s.hatchedAt)
            .putLong("lastUpdate", s.lastUpdate)
            .putLong("neglect", s.neglectMs)
            .putLong("sincePoop", s.sinceLastPoopMs)
            .putLong("lastNotified", s.lastNotified)
            .apply()
    }

    /** Új tojás (az előző "elköltözik"). */
    fun reset(c: Context): PetState = synchronized(lock) {
        val s = PetState()
        save(c, s)
        s
    }

    /** Az eltelt idő hatása. */
    private fun advance(s: PetState, now: Long) {
        val dt = (now - s.lastUpdate).coerceIn(0L, 7 * 24 * 3_600_000L)
        s.lastUpdate = now
        if (dt <= 0L) return
        val h = dt / 3_600_000f

        if (s.stage == PetStage.EGG) {
            if (now - s.bornAt >= HATCH_AFTER_MS || s.warmth >= HATCH_WARMTH) hatch(s, now)
            return
        }

        s.food = clamp(s.food - FOOD_PER_H * h)
        s.fun_ = clamp(s.fun_ - FUN_PER_H * h * (if (s.food < 25f || s.sick) 1.6f else 1f))
        s.energy = clamp(if (s.asleep) s.energy + ENERGY_SLEEP_PER_H * h else s.energy - ENERGY_AWAKE_PER_H * h)
        s.clean = clamp(s.clean - CLEAN_PER_H * h)
        if (s.asleep && s.energy >= 100f) s.asleep = false

        if (!s.asleep) {
            s.sinceLastPoopMs += dt
            while (s.sinceLastPoopMs >= POOP_EVERY_MS) {
                s.sinceLastPoopMs -= POOP_EVERY_MS
                if (s.poops < 3) s.poops++
                s.clean = clamp(s.clean - 15f)
            }
        }

        val neglected = s.food < 10f || s.clean < 10f || s.poops >= 3
        s.neglectMs = if (neglected || s.sick) s.neglectMs + dt else max(0L, s.neglectMs - dt)
        if (!s.sick && s.neglectMs >= SICK_AFTER_NEGLECT_MS) s.sick = true
        if (s.sick && s.neglectMs >= RUN_AWAY_NEGLECT_MS) s.ranAway = true

        val age = s.ageHours(now)
        s.stage = when {
            age >= 72f -> PetStage.ADULT
            age >= 24f -> PetStage.TEEN
            else -> PetStage.BABY
        }
    }

    private fun hatch(s: PetState, now: Long) {
        s.stage = PetStage.BABY
        s.hatchedAt = now
        s.food = 70f
        s.fun_ = 80f
        s.energy = 90f
        s.clean = 100f
    }

    private fun clamp(v: Float) = min(100f, max(0f, v))

    /**
     * Egy gondozási művelet. Visszaadja a változás rövid leírását (naplóhoz),
     * és szól a futó LED-es gondozásnak.
     */
    fun act(c: Context, a: PetAction, notifySession: Boolean = true): String = synchronized(lock) {
        val s = load(c)
        val msg: String
        if (s.stage == PetStage.EGG) {
            // A tojást melegíteni lehet: bármilyen gondoskodás közelebb hozza a kikelést
            s.warmth++
            msg = if (s.warmth >= HATCH_WARMTH) {
                hatch(s, System.currentTimeMillis())
                "Kikelt a tojás!"
            } else {
                "A tojás melegszik (${s.warmth}/$HATCH_WARMTH)"
            }
        } else {
            msg = when (a) {
                PetAction.PET -> { s.fun_ = clamp(s.fun_ + 6f); "Dorombol" }
                PetAction.FEED ->
                    if (s.asleep) "Alszik, nem eszik"
                    else if (s.food > 95f) { s.fun_ = clamp(s.fun_ - 5f); "Már tele van!" }
                    else { s.food = clamp(s.food + 30f); "Nyam-nyam" }
                PetAction.PLAY ->
                    if (s.asleep) "Alszik"
                    else if (s.energy < 10f) "Túl fáradt a játékhoz"
                    else { s.fun_ = clamp(s.fun_ + 20f); s.energy = clamp(s.energy - 10f); s.food = clamp(s.food - 5f); "Juhú, játék!" }
                PetAction.SLEEP -> { s.asleep = !s.asleep; if (s.asleep) "Jó éjt" else "Felébredt" }
                PetAction.CLEAN -> { s.poops = 0; s.clean = 100f; "Tiszta és illatos" }
                PetAction.HEAL ->
                    if (s.sick) { s.sick = false; s.neglectMs = 0L; s.fun_ = clamp(s.fun_ - 5f); "Meggyógyult" }
                    else "Nem beteg"
            }
        }
        save(c, s)
        if (notifySession) actions.tryEmit(a)
        msg
    }
}
