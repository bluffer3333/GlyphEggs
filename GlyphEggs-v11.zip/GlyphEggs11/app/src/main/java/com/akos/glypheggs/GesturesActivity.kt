package com.akos.glypheggs

import android.app.Activity
import android.content.Context
import android.content.Intent
import android.graphics.Canvas
import android.graphics.Paint
import android.graphics.Path
import android.os.Bundle
import android.view.Gravity
import android.view.View
import android.view.ViewGroup.LayoutParams.MATCH_PARENT
import android.view.ViewGroup.LayoutParams.WRAP_CONTENT
import android.widget.FrameLayout
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView

/**
 * Indítás és leállítás beállítása funkciónként:
 *  - melyik mozdulat indítsa (egy mozdulat egyszerre csak egy funkcióhoz tartozhat),
 *  - mivel lehessen leállítani futás közben (több is bekapcsolható, pl. bekapcsoló gomb + felemelés).
 */
class GesturesActivity : Activity() {

    companion object {
        const val EXTRA_FEATURE = "feature"
    }

    private var feature = Feature.SIMON
    private lateinit var list: LinearLayout
    private lateinit var stopList: LinearLayout
    private val tabs = mutableMapOf<Feature, TextView>()
    private val sensPills = mutableListOf<TextView>()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        darkWindow()
        val name = intent.getStringExtra(EXTRA_FEATURE)
        feature = Feature.entries.firstOrNull { it.name == name } ?: Feature.SIMON

        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(15), 0, dp(15), dp(24))
        }
        val scroll = ScrollView(this).apply {
            setBackgroundColor(Ui.BG)
            isVerticalScrollBarEnabled = false
            addView(root, FrameLayout.LayoutParams(MATCH_PARENT, WRAP_CONTENT))
            padForSystemBars()
        }
        setContentView(scroll)

        // Fejléc: vissza nyíl + cím (mint a Nothing aloldalain)
        val header = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
            setPadding(dp(7), dp(28), 0, dp(8))
        }
        header.addView(ImageView(this).apply {
            setImageResource(R.drawable.ic_back)
            setOnClickListener { finish() }
        }, LinearLayout.LayoutParams(dp(24), dp(24)))
        header.addView(text("Indítás és leállítás", 26f, Ui.TEXT, Ui.regular).apply { setPadding(dp(30), 0, 0, 0) })
        root.addView(header)

        root.addView(text(
            "Válaszd ki, melyik mozdulat indítsa a funkciót, és mivel lehessen leállítani. Az indító mozdulatok akkor " +
                "működnek, ha a főképernyőn be van kapcsolva a Mozdulatfigyelés; a leállítás mindig, amíg a funkció fut.",
            13f, Ui.SUB
        ).apply { setPadding(dp(7), dp(14), dp(7), dp(6)); setLineSpacing(0f, 1.2f) })

        // Funkcióválasztó fülek
        root.addView(sectionTitle("Funkció"))
        for (chunk in Feature.entries.chunked(3)) {
            val tabRow = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
            for (f in chunk) {
                val t = pill(f.short) {
                    feature = f
                    render()
                }
                tabs[f] = t
                tabRow.addView(t, LinearLayout.LayoutParams(0, dp(44), 1f).apply { marginEnd = dp(5) })
            }
            root.addView(tabRow, LinearLayout.LayoutParams(MATCH_PARENT, WRAP_CONTENT).apply { bottomMargin = dp(5) })
        }

        root.addView(sectionTitle("Indító mozdulat"))
        list = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        root.addView(list)

        root.addView(sectionTitle("Leállítás futás közben"))
        stopList = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        root.addView(stopList)

        // Kopogás érzékenysége
        root.addView(sectionTitle("Kopogás érzékenysége"))
        val sensRow = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
        listOf("Alacsony", "Közepes", "Magas").forEachIndexed { i, label ->
            val t = pill(label) {
                Settings.setKnockSensitivity(this, i)
                render()
            }
            sensPills += t
            sensRow.addView(t, LinearLayout.LayoutParams(0, dp(44), 1f).apply { marginEnd = dp(5) })
        }
        root.addView(sensRow)

        // Tippek
        root.addView(sectionTitle("Tippek"))
        root.addView(tipsCard())

        render()
    }

    override fun onResume() {
        super.onResume()
        GlyphMirror.appVisible = true
    }

    override fun onPause() {
        super.onPause()
        GlyphMirror.appVisible = false
    }

    private fun pill(label: String, onClick: () -> Unit): TextView = text(label, 14f).apply {
        gravity = Gravity.CENTER
        setOnClickListener { onClick() }
    }

    private fun render() {
        for ((f, t) in tabs) {
            val sel = f == feature
            t.background = rounded(if (sel) Ui.LIGHT else Ui.CARD, dp(22).toFloat())
            t.setTextColor(if (sel) Ui.DARK_TEXT else Ui.TEXT)
        }
        val sens = Settings.knockSensitivity(this)
        sensPills.forEachIndexed { i, t ->
            val sel = i == sens
            t.background = rounded(if (sel) Ui.LIGHT else Ui.CARD, dp(22).toFloat())
            t.setTextColor(if (sel) Ui.DARK_TEXT else Ui.TEXT)
        }

        list.removeAllViews()
        val current = Settings.trigger(this, feature)
        for (t in Trigger.entries) {
            val owner = Settings.featureFor(this, t)
            val usedElsewhere = owner != null && owner != feature
            list.addView(optionRow(t, t == current, if (usedElsewhere) owner else null),
                LinearLayout.LayoutParams(MATCH_PARENT, WRAP_CONTENT).apply { bottomMargin = dp(5) })
        }

        stopList.removeAllViews()
        val stops = Settings.stopMethods(this, feature)
        for (m in StopMethod.entries) {
            stopList.addView(stopRow(m, stops),
                LinearLayout.LayoutParams(MATCH_PARENT, WRAP_CONTENT).apply { bottomMargin = dp(5) })
        }
        stopList.addView(text(
            "Mindig működik: a csempe, a widget, az értesítés „Leállítás” gombja és az app „Most fut” kártyája.",
            12.5f, Ui.SUB
        ).apply { setPadding(dp(8), dp(6), dp(8), 0); setLineSpacing(0f, 1.2f) })
    }

    /** Egy leállítási mód kapcsolóval; ha ennél a funkciónál nem választható, megmondja, miért. */
    private fun stopRow(m: StopMethod, current: Set<StopMethod>): LinearLayout {
        val blocked = m.blockedFor(feature)
        val builtIn = m.builtInFor(feature)
        val row = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
            background = rounded(Ui.CARD, dp(20).toFloat())
            setPadding(dp(18), dp(16), dp(16), dp(16))
            alpha = if (blocked != null) 0.55f else 1f
        }
        val texts = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        texts.addView(text(m.title, 17f))
        texts.addView(text(m.hint, 12.5f, Ui.SUB).apply { setPadding(0, dp(2), 0, 0); setLineSpacing(0f, 1.15f) })
        val note = when {
            builtIn -> "Ennél a funkciónál magától is így működik"
            blocked != null -> "Itt nem választható: $blocked"
            else -> null
        }
        if (note != null) {
            texts.addView(text(note, 12f, if (builtIn) Ui.SUB else 0xFFE0857F.toInt()).apply { setPadding(0, dp(4), 0, 0) })
        }
        row.addView(texts, LinearLayout.LayoutParams(0, WRAP_CONTENT, 1f))
        val toggle = ToggleView(this).apply {
            checked = builtIn || m in current
            isEnabled = blocked == null && !builtIn
            onChange = { on ->
                Settings.setStopMethod(this@GesturesActivity, feature, m, on)
                render()
            }
        }
        row.addView(toggle, LinearLayout.LayoutParams(WRAP_CONTENT, WRAP_CONTENT).apply { marginStart = dp(12) })
        if (blocked == null && !builtIn) row.setOnClickListener { toggle.performClick() }
        return row
    }

    private fun optionRow(t: Trigger, selected: Boolean, owner: Feature?): LinearLayout {
        val row = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
            background = rounded(Ui.CARD, dp(20).toFloat())
            setPadding(dp(18), dp(16), dp(16), dp(16))
            setOnClickListener {
                Settings.setTrigger(this@GesturesActivity, feature, t)
                notifyService()
                render()
            }
        }
        val texts = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        texts.addView(text(t.title, 17f))
        texts.addView(text(t.hint, 12.5f, Ui.SUB).apply { setPadding(0, dp(2), 0, 0) })
        if (owner != null) {
            texts.addView(text("Most: ${owner.title} – ha ezt választod, ott „Nincs” lesz", 12f, 0xFFE0857F.toInt()).apply {
                setPadding(0, dp(4), 0, 0)
            })
        }
        row.addView(texts, LinearLayout.LayoutParams(0, WRAP_CONTENT, 1f))
        row.addView(RadioMark(this, selected), LinearLayout.LayoutParams(dp(26), dp(26)).apply { marginStart = dp(12) })
        return row
    }

    private fun tipsCard(): LinearLayout {
        val card = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            background = rounded(Ui.CARD, dp(22).toFloat())
            setPadding(dp(18), dp(16), dp(18), dp(16))
        }
        val tips = listOf(
            "Forgatás és megpörgetés: kijelzővel lefelé, az asztalon fekve. A negyed fordulatot nem kell pontosan eltalálni.",
            "Kopogás: fekve kopogtass a telefonon (nem az asztalon). Ha nem érzékeli, állíts magasabb érzékenységet; ha magától is indul, alacsonyabbat.",
            "Rázás: a kezedben rázd meg néhányszor, aztán 6 mp-en belül tedd le kijelzővel lefelé.",
            "Lefordítás: ha a Nothing „Flip to Glyph” funkciója be van kapcsolva, zavarhatja – kapcsold ki a Glyph beállításokban.",
            "A kopogás figyelése sűrűbb mérést igényel, ezért kicsit több akkut fogyaszt, mint a forgatás.",
            "Leállítás: a bekapcsoló gomb a legbiztosabb – lefelé fekvő telefonnál a képernyő ki van kapcsolva, egy nyomás leállítja a futó funkciót. Ha a képernyő épp be van kapcsolva, nyomd meg kétszer.",
            "A játékokban a kopogás vagy a rázás maga az irányítás, ezért ott nem lehet leállító parancs.",
            "Hengerítés: fogd két kézzel, fekvő helyzetben magad előtt, a töltőport a jobb kezed felé; forgasd körbe háromszor a hosszanti tengelye körül (mint egy sodrófát). Bármelyik irányba jó."
        )
        for (tip in tips) {
            card.addView(text("•  $tip", 13f, Ui.SUB).apply {
                setPadding(0, dp(4), 0, dp(4))
                setLineSpacing(0f, 1.2f)
            })
        }
        return card
    }

    private fun notifyService() {
        if (SimonService.watching) {
            startService(Intent(this, SimonService::class.java).setAction(SimonService.ACTION_REFRESH))
        }
    }
}
